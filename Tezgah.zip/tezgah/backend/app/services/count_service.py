"""Stok sayımı: raf/kategori bazlı liste, sayım, fark raporu, onaylı uygulama."""

from decimal import Decimal
from typing import Any

from sqlmodel import Session, col, select

from app.core import audit
from app.core.deps import Actor
from app.core.errors import NotFound, ValidationFailed
from app.core.money import qty as to_qty
from app.core.money import round_half_up, validate_qty_for_unit
from app.core.permissions import P
from app.models import (
    Category,
    CountStatus,
    Location,
    MovementType,
    Product,
    StockCount,
    StockCountItem,
    UnitType,
    User,
    now,
)
from app.schemas.ops import CountCreate, CountItemsIn, CountScanIn
from app.services import catalog_service, product_service, stock_service


def _get(session: Session, count_id: int) -> StockCount:
    c = session.get(StockCount, count_id)
    if not c:
        raise NotFound("Sayım")
    return c


def list_counts(session: Session) -> list[dict[str, Any]]:
    counts = session.exec(select(StockCount).order_by(col(StockCount.created_at).desc())).all()
    users = {u.id: u.full_name for u in session.exec(select(User)).all()}
    locs = {loc.id: loc.code for loc in session.exec(select(Location)).all()}
    paths = catalog_service.category_paths(session)
    out = []
    for c in counts:
        items = session.exec(select(StockCountItem).where(StockCountItem.count_id == c.id)).all()
        out.append(
            {
                "id": c.id,
                "name": c.name,
                "status": c.status,
                "created_at": c.created_at,
                "applied_at": c.applied_at,
                "location_code": locs.get(c.location_id) if c.location_id else None,  # type: ignore[arg-type]
                "category_path": paths.get(c.category_id) if c.category_id else None,  # type: ignore[arg-type]
                "item_count": len(items),
                "counted_count": sum(1 for i in items if i.counted_qty is not None),
                "created_by_name": users.get(c.created_by),  # type: ignore[arg-type]
            }
        )
    return out


def create_count(session: Session, actor: Actor, data: CountCreate) -> dict[str, Any]:
    stmt = select(Product).where(Product.is_active == True, Product.unit_type != UnitType.SERVICE)  # noqa: E712
    label = []
    if data.location_id:
        loc = session.get(Location, data.location_id)
        if not loc:
            raise ValidationFailed("Konum bulunamadı.")
        stmt = stmt.where(Product.location_id == data.location_id)
        label.append(loc.code)
    if data.category_id:
        cat = session.get(Category, data.category_id)
        if not cat:
            raise ValidationFailed("Kategori bulunamadı.")
        stmt = stmt.where(col(Product.category_id).in_(catalog_service.descendant_ids(session, data.category_id)))
        label.append(cat.name)
    products = session.exec(stmt.order_by(Product.name)).all()
    if not products:
        raise ValidationFailed("Seçilen filtreye uyan stoklu ürün yok.")
    ts = now()
    c = StockCount(
        name=data.name or f"Sayım {ts:%d.%m.%Y}" + (f" · {' / '.join(label)}" if label else " · Tüm stok"),
        location_id=data.location_id,
        category_id=data.category_id,
        created_by=actor.id,
    )
    session.add(c)
    session.flush()
    for p in products:
        session.add(StockCountItem(count_id=c.id, product_id=p.id, expected_qty=p.stock_qty))  # type: ignore[arg-type]
    session.commit()
    return get_count(session, actor, c.id)  # type: ignore[arg-type]


def get_count(session: Session, actor: Actor, count_id: int) -> dict[str, Any]:
    c = _get(session, count_id)
    rows = session.exec(
        select(StockCountItem, Product)
        .join(Product, col(Product.id) == StockCountItem.product_id)
        .where(StockCountItem.count_id == count_id)
        .order_by(Product.name)
    ).all()
    lk = product_service.Lookups.load(session)
    can_cost = actor.can(P.PRODUCT_COST_VIEW)
    items = []
    total_value = 0
    for it, p in rows:
        expected = p.stock_qty if c.status == CountStatus.OPEN else it.expected_qty
        diff = (it.counted_qty - expected) if it.counted_qty is not None else None
        value = round_half_up(diff * product_service.unit_cost_kurus(p, lk)) if diff is not None else None
        total_value += value or 0
        row = {
            "id": it.id,
            "product_id": p.id,
            "sku": p.sku,
            "barcode": p.barcode,
            "name": p.name,
            "unit_type": p.unit_type,
            "location_code": lk.locations.get(p.location_id) if p.location_id else None,  # type: ignore[arg-type]
            "expected_qty": expected,
            "counted_qty": it.counted_qty,
            "diff": diff if c.status == CountStatus.OPEN else it.diff,
        }
        if can_cost:
            row["diff_value"] = value
        items.append(row)
    out = {
        "id": c.id,
        "name": c.name,
        "status": c.status,
        "note": c.note,
        "created_at": c.created_at,
        "applied_at": c.applied_at,
        "location_id": c.location_id,
        "category_id": c.category_id,
        "items": items,
        "counted_count": sum(1 for i in items if i["counted_qty"] is not None),
        "diff_count": sum(1 for i in items if i["diff"] not in (None, Decimal(0))),
    }
    if can_cost:
        out["diff_value_total"] = total_value
    return out


def _require_open(c: StockCount) -> None:
    if c.status != CountStatus.OPEN:
        raise ValidationFailed("Onaylanmış veya iptal edilmiş sayım değiştirilemez.", code="COUNT_LOCKED")


def _item_for(session: Session, c: StockCount, product: Product) -> StockCountItem:
    it = session.exec(select(StockCountItem).where(StockCountItem.count_id == c.id, StockCountItem.product_id == product.id)).first()
    if not it:
        if product.unit_type == UnitType.SERVICE:
            raise ValidationFailed("Hizmet ürünleri sayılmaz.")
        it = StockCountItem(count_id=c.id, product_id=product.id, expected_qty=product.stock_qty)  # type: ignore[arg-type]
        session.add(it)
        session.flush()
    return it


def update_items(session: Session, actor: Actor, count_id: int, data: CountItemsIn) -> dict[str, Any]:
    c = _get(session, count_id)
    _require_open(c)
    for upd in data.items:
        p = session.get(Product, upd.product_id)
        if not p:
            raise ValidationFailed("Ürün bulunamadı.")
        it = _item_for(session, c, p)
        if upd.counted_qty is not None:
            q = to_qty(upd.counted_qty)
            try:
                validate_qty_for_unit(q, p.unit_type)
            except ValueError as exc:
                raise ValidationFailed(str(exc)) from exc
            it.counted_qty = q
        else:
            it.counted_qty = None
        session.add(it)
    session.commit()
    return get_count(session, actor, count_id)


def scan(session: Session, actor: Actor, count_id: int, data: CountScanIn) -> dict[str, Any]:
    c = _get(session, count_id)
    _require_open(c)
    found = product_service.lookup(session, actor, data.code)
    p = session.get(Product, found["product"]["id"])
    assert p is not None
    if p.unit_type == UnitType.METER and data.qty is None:
        # Metre ürünlerde okutma sonrası miktar elle girilir.
        return {"product": found["product"], "needs_qty": True, "count": get_count(session, actor, count_id)}
    it = _item_for(session, c, p)
    it.counted_qty = (it.counted_qty or Decimal(0)) + to_qty(data.qty or Decimal(1))
    session.add(it)
    session.commit()
    return {"product": found["product"], "needs_qty": False, "counted_qty": it.counted_qty, "count": get_count(session, actor, count_id)}


def apply_count(session: Session, actor: Actor, count_id: int) -> dict[str, Any]:
    actor.require(P.COUNT_APPLY, "Sayım onayı yalnızca yöneticiye açıktır.")
    c = _get(session, count_id)
    _require_open(c)
    items = session.exec(select(StockCountItem).where(StockCountItem.count_id == c.id)).all()
    if not any(i.counted_qty is not None for i in items):
        raise ValidationFailed("Hiç sayılmış kalem yok.")
    applied = []
    for it in items:
        p = session.get(Product, it.product_id)
        assert p is not None
        it.expected_qty = p.stock_qty
        if it.counted_qty is None:
            continue
        it.diff = it.counted_qty - p.stock_qty
        if it.diff != 0:
            stock_service.apply_movement(
                session, p, MovementType.COUNT_ADJUST, it.diff, actor.id, ref_type="COUNT", ref_id=c.id, note=c.name, allow_negative=True
            )
            applied.append({"product_id": p.id, "diff": str(it.diff)})
        session.add(it)
    c.status = CountStatus.APPLIED
    c.applied_at = now()
    c.applied_by = actor.id
    session.add(c)
    audit.record(
        session, actor, "count.apply", "stock_count", c.id, {"status": CountStatus.OPEN}, {"status": c.status}, {"adjustments": applied}
    )
    session.commit()
    return get_count(session, actor, count_id)


def cancel_count(session: Session, actor: Actor, count_id: int) -> dict[str, Any]:
    c = _get(session, count_id)
    _require_open(c)
    c.status = CountStatus.CANCELLED
    session.add(c)
    audit.record(session, actor, "count.cancel", "stock_count", c.id, {"status": CountStatus.OPEN}, {"status": c.status})
    session.commit()
    return get_count(session, actor, count_id)
