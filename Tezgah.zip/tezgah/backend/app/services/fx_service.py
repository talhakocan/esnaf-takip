"""Döviz kurları: manuel giriş ve TCMB'den çekme."""

import xml.etree.ElementTree as ET
from datetime import datetime, timedelta
from decimal import Decimal, InvalidOperation
from typing import Any

import httpx
from sqlmodel import Session, col, select

from app.config import get_settings
from app.core import audit
from app.core.deps import Actor
from app.core.errors import AppError, ValidationFailed
from app.models import Currency, ExchangeRate, now

FX_CURRENCIES = (Currency.USD, Currency.EUR)


def latest(session: Session, currency: Currency) -> ExchangeRate | None:
    return session.exec(
        select(ExchangeRate)
        .where(ExchangeRate.currency == currency)
        .order_by(col(ExchangeRate.fetched_at).desc(), col(ExchangeRate.id).desc())
    ).first()


def rate_for(session: Session, currency: Currency | str, strict: bool = True) -> Decimal | None:
    currency = Currency(currency)
    if currency == Currency.TRY:
        return Decimal(1)
    row = latest(session, currency)
    if row is None:
        if strict:
            raise ValidationFailed(f"{currency} kuru tanımlı değil. Ayarlar › Fiyat & Kur ekranından girin.")
        return None
    return row.rate


def current_rates(session: Session) -> dict[str, Any]:
    from app.services.settings_service import get_settings_row

    stale_days = get_settings_row(session).fx_stale_days
    out: dict[str, Any] = {"rates": {}, "stale": False, "fetched_at": None}
    oldest: datetime | None = None
    for cur in FX_CURRENCIES:
        row = latest(session, cur)
        if row is None:
            out["stale"] = True
            continue
        out["rates"][cur.value] = {"rate": row.rate, "source": row.source, "fetched_at": row.fetched_at}
        oldest = row.fetched_at if oldest is None or row.fetched_at < oldest else oldest
    if oldest is not None:
        out["fetched_at"] = oldest
        if now() - oldest > timedelta(days=stale_days):
            out["stale"] = True
    out["stale_days"] = stale_days
    return out


def set_rates(session: Session, actor: Actor | None, rates: dict[str, Decimal], source: str = "MANUAL") -> int:
    """Kurları kaydeder ve kura bağlı ürünleri yeniden fiyatlar. Güncellenen ürün sayısını döner."""
    from app.services.pricing_service import reprice_all_fx_linked

    ts = now()
    before: dict[str, str] = {}
    after: dict[str, str] = {}
    for code, value in rates.items():
        cur = Currency(code)
        if cur == Currency.TRY:
            continue
        if value is None or value <= 0 or value > 10000:
            raise ValidationFailed("Kur değeri geçersiz.", {code: "Pozitif bir kur girin."})
        prev = latest(session, cur)
        before[code] = str(prev.rate) if prev else ""
        after[code] = str(value)
        session.add(ExchangeRate(currency=cur, rate=value, source=source, fetched_at=ts, user_id=actor.id if actor else None))
    session.flush()
    updated = reprice_all_fx_linked(session, actor.id if actor else None)
    audit.record(session, actor, "fx.update", "exchange_rates", None, before, after, {"source": source, "repriced": updated})
    session.commit()
    return updated


def parse_tcmb_xml(xml_text: str) -> dict[str, Decimal]:
    root = ET.fromstring(xml_text)
    out: dict[str, Decimal] = {}
    for node in root.findall("Currency"):
        code = node.get("CurrencyCode") or node.get("Kod")
        if code not in ("USD", "EUR"):
            continue
        text = (node.findtext("ForexSelling") or "").strip()
        try:
            out[code] = Decimal(text)
        except InvalidOperation:
            continue
    if len(out) < 2:
        raise ValueError("Beklenen kurlar XML içinde bulunamadı.")
    return out


def fetch_tcmb() -> dict[str, Decimal]:
    try:
        resp = httpx.get(get_settings().tcmb_url, timeout=8.0, follow_redirects=True)
        resp.raise_for_status()
        return parse_tcmb_xml(resp.text)
    except (httpx.HTTPError, ET.ParseError, ValueError) as exc:
        raise AppError(
            "TCMB_UNAVAILABLE",
            "TCMB kurlarına ulaşılamadı. İnternet bağlantısını kontrol edin veya kuru elle girin.",
            502,
        ) from exc


def history(session: Session, limit: int = 60) -> list[ExchangeRate]:
    return list(
        session.exec(select(ExchangeRate).order_by(col(ExchangeRate.fetched_at).desc(), col(ExchangeRate.id).desc()).limit(limit)).all()
    )
