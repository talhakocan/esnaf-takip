"""Dükkan ayarları (tekil kayıt)."""

from typing import Any

from sqlmodel import Session

from app.core import audit
from app.core.deps import Actor
from app.models import ShopSettings

DEFAULT_SERVICE_TERMS = (
    "1. Cihazınız, bu fişte belirtilen aksesuarlarla birlikte teslim alınmıştır.\n"
    "2. Arıza tespiti sonrası onarım ücreti size bildirilir; onayınız olmadan işlem yapılmaz.\n"
    "3. Veri yedeğinden müşteri sorumludur; işlem sırasında oluşabilecek veri kaybından "
    "servisimiz sorumlu tutulamaz.\n"
    "4. Onarımı tamamlanan veya onarılamayan cihazlar, bildirimden itibaren 90 gün içinde "
    "teslim alınmalıdır.\n"
    "5. Değiştirilen parçalar için garanti süresi fişte belirtilir."
)

DEFAULT_KVKK_TEXT = (
    "6698 sayılı Kişisel Verilerin Korunması Kanunu kapsamında; adınız, telefon numaranız ve "
    "adresiniz yalnızca satış, garanti ve teknik servis süreçlerinin yürütülmesi amacıyla "
    "işlenmekte ve üçüncü kişilerle paylaşılmamaktadır. Kanunun 11. maddesindeki haklarınızı "
    "kullanmak için dükkanımıza başvurabilirsiniz. (Bu metin örnektir; dükkan sahibi tarafından "
    "hukuki olarak gözden geçirilmelidir.)"
)

EDITABLE_FIELDS = [
    "shop_name",
    "address",
    "phone",
    "email",
    "tax_office",
    "tax_no",
    "receipt_footer",
    "default_vat_rate",
    "rounding_rule",
    "allow_negative_stock",
    "default_warranty_months",
    "credit_due_days",
    "dead_stock_days",
    "fx_stale_days",
    "service_terms",
    "kvkk_text",
]


def get_settings_row(session: Session) -> ShopSettings:
    row = session.get(ShopSettings, 1)
    if row is None:
        row = ShopSettings(id=1, service_terms=DEFAULT_SERVICE_TERMS, kvkk_text=DEFAULT_KVKK_TEXT)
        session.add(row)
        session.flush()
    return row


def update_settings(session: Session, actor: Actor, data: dict[str, Any]) -> ShopSettings:
    row = get_settings_row(session)
    before = audit.snapshot(row, EDITABLE_FIELDS)
    for key, value in data.items():
        if key in EDITABLE_FIELDS and value is not None:
            setattr(row, key, value)
    session.add(row)
    audit.record(session, actor, "settings.update", "settings", row.id, before, audit.snapshot(row, EDITABLE_FIELDS))
    session.commit()
    session.refresh(row)
    return row
