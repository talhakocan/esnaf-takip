"""Tedarikçiler ve satın alma siparişleri (mal kabul → stoğa otomatik giriş)."""

from datetime import datetime
from decimal import ROUND_CEILING, Decimal
from typing import Any

from sqlmodel import Session, col, func, select

from app.core import audit
from app.core.deps import Actor
from app.core.errors import NotFound, ValidationFailed
from app.core.money import qty as to_qty
from app.core.money import round_half_up, validate_qty_for_unit
from app.core.permissions import P
from app.models import (
    Currency,
    MovementType,
    POStatus,
    PriceReason,
    PricingMode,
    Product,
    PurchaseOrder,
    PurchaseOrderItem,
    Supplier,
    UnitType,
    User,
    now,
)
from app.schemas.ops import POCreate, POUpdate, ReceiveIn, SupplierIn
from app.services import fx_service, pricing_service, stock_service

STATUS_TR = {
    POStatus.DRAFT: "Taslak",
    POStatus.ORDERED: "Sipariş verildi",
    POStatus.PARTIAL: "Kısmi teslim",
    POStatus.RECEIVED: "Teslim alındı",
    POStatus.CANCELLED: "İptal",
}

# ---------------------------------------------------------------- tedarikçiler


def supplier_out(s: Supplier) -> dict[str, Any]:
    return {
        "id": s.id,
        "name": s.name,
        "contact": s.contact,
        "phone": s.phone,
        "email": s.email,
        "currency": s.currency,
        "note": s.note,
        "is_active": s.is_active,
        "created_at": s.created_at,
    }


def _lead_days(orders: list[PurchaseOrder]) -> float | None:
    spans = [(o.received_at - o.ordered_at).total_seconds() / 86400 for o in orders if o.received_at and o.ordered_at]
    return round(sum(spans) / len(spans), 1) if spans else None


def list_suppliers(session: Session, active: str = "active") -> list[dict[str, Any]]:
    stmt = select(Supplier)
    if active == "active":
        stmt = stmt.where(Supplier.is_active == True)  # noqa: E712
    orders = session.exec(select(PurchaseOrder)).all()
    by_supplier: dict[int, list[PurchaseOrder]] = {}
    for o in orders:
        by_supplier.setdefault(o.supplier_id, []).append(o)
    product_counts = dict(session.exec(select(Product.supplier_id, func.count(col(Product.id))).group_by(Product.supplier_id)).all())
    out = []
    for s in session.exec(stmt.order_by(Supplier.name)).all():
        os_ = by_supplier.get(s.id, [])  # type: ignore[arg-type]
        out.append(
            supplier_out(s)
            | {
                "order_count": len(os_),
                "open_orders": sum(1 for o in os_ if o.status in (POStatus.ORDERED, POStatus.PARTIAL)),
                "avg_lead_days": _lead_days(os_),
                "product_count": product_counts.get(s.id, 0),
                "last_order_at": max((o.created_at for o in os_), default=None),
            }
        )
    return out


def save_supplier(session: Session, actor: Actor, data: SupplierIn, supplier_id: int | None = None) -> dict[str, Any]:
    fields = ["name", "contact", "phone", "email", "currency", "note", "is_active"]
    if supplier_id:
        s = session.get(Supplier, supplier_id)
        if not s:
            raise NotFound("Tedarikçi")
        before = audit.snapshot(s, fields)
    else:
        s, before = Supplier(name=data.name), None
    for k, v in data.model_dump().items():
        setattr(s, k, v)
    session.add(s)
    session.flush()
    audit.record(
        session, actor, "supplier.update" if supplier_id else "supplier.create", "supplier", s.id, before, audit.snapshot(s, fields)
    )
    session.commit()
    session.refresh(s)
    return supplier_out(s)


def get_supplier(session: Session, supplier_id: int) -> dict[str, Any]:
    s = session.get(Supplier, supplier_id)
    if not s:
        raise NotFound("Tedarikçi")
    orders = list(
        session.exec(
            select(PurchaseOrder).where(PurchaseOrder.supplier_id == supplier_id).order_by(col(PurchaseOrder.created_at).desc())
        ).all()
    )
    return supplier_out(s) | {
        "avg_lead_days": _lead_days(orders),
        "orders": [order_summary(session, o) for o in orders],
        "products": [
            {"id": p.id, "sku": p.sku, "name": p.name, "stock_qty": p.stock_qty, "min_stock": p.min_stock, "unit_type": p.unit_type}
            for p in session.exec(
                select(Product).where(Product.supplier_id == supplier_id, Product.is_active == True).order_by(Product.name)
            ).all()
        ],  # noqa: E712
    }


# ---------------------------------------------------------------- siparişler


def next_order_no(session: Session, year: int) -> str:
    prefix = f"PO-{year}-"
    last = session.exec(
        select(PurchaseOrder.order_no).where(col(PurchaseOrder.order_no).like(f"{prefix}%")).order_by(col(PurchaseOrder.order_no).desc())
    ).first()
    return f"{prefix}{(int(last[-4:]) + 1 if last else 1):04d}"


def _items(session: Session, order_id: int) -> list[PurchaseOrderItem]:
    return list(
        session.exec(select(PurchaseOrderItem).where(PurchaseOrderItem.order_id == order_id).order_by(col(PurchaseOrderItem.id))).all()
    )


def order_summary(session: Session, o: PurchaseOrder) -> dict[str, Any]:
    items = _items(session, o.id)  # type: ignore[arg-type]
    total = sum(i.qty * i.unit_price for i in items)
    return {
        "id": o.id,
        "order_no": o.order_no,
        "supplier_id": o.supplier_id,
        "status": o.status,
        "status_label": STATUS_TR[o.status],
        "currency": o.currency,
        "total": total.quantize(Decimal("0.01")),
        "item_count": len(items),
        "created_at": o.created_at,
        "ordered_at": o.ordered_at,
        "expected_at": o.expected_at,
        "received_at": o.received_at,
    }


def _get(session: Session, order_id: int) -> PurchaseOrder:
    o = session.get(PurchaseOrder, order_id)
    if not o:
        raise NotFound("Sipariş")
    return o


def list_orders(session: Session, status: str | None = None, supplier_id: int | None = None) -> list[dict[str, Any]]:
    stmt = select(PurchaseOrder, Supplier.name).join(Supplier, col(Supplier.id) == PurchaseOrder.supplier_id)
    if status == "open":
        stmt = stmt.where(col(PurchaseOrder.status).in_([POStatus.DRAFT, POStatus.ORDERED, POStatus.PARTIAL]))
    elif status:
        stmt = stmt.where(PurchaseOrder.status == status)
    if supplier_id:
        stmt = stmt.where(PurchaseOrder.supplier_id == supplier_id)
    return [
        order_summary(session, o) | {"supplier_name": name}
        for o, name in session.exec(stmt.order_by(col(PurchaseOrder.created_at).desc())).all()
    ]


def get_order(session: Session, actor: Actor, order_id: int) -> dict[str, Any]:
    o = _get(session, order_id)
    supplier = session.get(Supplier, o.supplier_id)
    creator = session.get(User, o.created_by) if o.created_by else None
    rows = session.exec(
        select(PurchaseOrderItem, Product)
        .join(Product, col(Product.id) == PurchaseOrderItem.product_id)
        .where(PurchaseOrderItem.order_id == o.id)
        .order_by(col(PurchaseOrderItem.id))
    ).all()
    rate = fx_service.rate_for(session, o.currency, strict=False)
    return order_summary(session, o) | {
        "supplier_name": supplier.name if supplier else None,
        "note": o.note,
        "fx_rate": o.fx_rate,
        "current_rate": rate,
        "created_by_name": creator.full_name if creator else None,
        "items": [
            {
                "id": i.id,
                "product_id": p.id,
                "sku": p.sku,
                "name": p.name,
                "unit_type": p.unit_type,
                "track_serial": p.track_serial,
                "qty": i.qty,
                "received_qty": i.received_qty,
                "remaining": i.qty - i.received_qty,
                "unit_price": i.unit_price,
                "line_total": (i.qty * i.unit_price).quantize(Decimal("0.01")),
                "stock_qty": p.stock_qty,
            }
            for i, p in rows
        ],
    }


def _set_items(session: Session, o: PurchaseOrder, items: list) -> None:
    for old in _items(session, o.id):  # type: ignore[arg-type]
        session.delete(old)  # taslak sipariş kalemleri; stok etkisi yok
    session.flush()
    seen = set()
    for it in items:
        p = session.get(Product, it.product_id)
        if not p or p.unit_type == UnitType.SERVICE:
            raise ValidationFailed("Siparişe yalnızca stoklu ürün eklenebilir.")
        if p.id in seen:
            raise ValidationFailed(f"Ürün siparişte iki kez var: {p.name}")
        seen.add(p.id)
        q = to_qty(it.qty)
        try:
            validate_qty_for_unit(q, p.unit_type)
        except ValueError as exc:
            raise ValidationFailed(str(exc)) from exc
        session.add(PurchaseOrderItem(order_id=o.id, product_id=p.id, qty=q, unit_price=it.unit_price))  # type: ignore[arg-type]


def create_order(session: Session, actor: Actor, data: POCreate) -> dict[str, Any]:
    supplier = session.get(Supplier, data.supplier_id)
    if not supplier:
        raise ValidationFailed("Tedarikçi bulunamadı.", {"supplier_id": "Geçersiz tedarikçi."})
    ts = now()
    o = PurchaseOrder(
        order_no=next_order_no(session, ts.year),
        supplier_id=supplier.id,
        currency=data.currency or supplier.currency,  # type: ignore[arg-type]
        expected_at=data.expected_at,
        note=data.note,
        created_by=actor.id,
    )
    session.add(o)
    session.flush()
    _set_items(session, o, data.items)
    audit.record(session, actor, "purchase.create", "purchase_order", o.id, None, {"order_no": o.order_no})
    session.commit()
    return get_order(session, actor, o.id)  # type: ignore[arg-type]


def update_order(session: Session, actor: Actor, order_id: int, data: POUpdate) -> dict[str, Any]:
    o = _get(session, order_id)
    if o.status != POStatus.DRAFT:
        raise ValidationFailed("Yalnızca taslak siparişler düzenlenebilir.")
    changes = data.model_dump(exclude_unset=True)
    if "expected_at" in changes:
        o.expected_at = data.expected_at
    if data.note is not None:
        o.note = data.note
    if data.items is not None:
        _set_items(session, o, data.items)
    session.add(o)
    session.commit()
    return get_order(session, actor, order_id)


def mark_ordered(session: Session, actor: Actor, order_id: int) -> dict[str, Any]:
    o = _get(session, order_id)
    if o.status != POStatus.DRAFT:
        raise ValidationFailed("Yalnızca taslak sipariş gönderilebilir.")
    o.status = POStatus.ORDERED
    o.ordered_at = now()
    o.fx_rate = fx_service.rate_for(session, o.currency) or Decimal(1)
    session.add(o)
    audit.record(session, actor, "purchase.order", "purchase_order", o.id, {"status": POStatus.DRAFT}, {"status": o.status})
    session.commit()
    return get_order(session, actor, order_id)


def cancel_order(session: Session, actor: Actor, order_id: int) -> dict[str, Any]:
    o = _get(session, order_id)
    if o.status not in (POStatus.DRAFT, POStatus.ORDERED):
        raise ValidationFailed("Teslim alınmaya başlanmış sipariş iptal edilemez.")
    before = {"status": o.status}
    o.status = POStatus.CANCELLED
    session.add(o)
    audit.record(session, actor, "purchase.cancel", "purchase_order", o.id, before, {"status": o.status})
    session.commit()
    return get_order(session, actor, order_id)


def receive(session: Session, actor: Actor, order_id: int, data: ReceiveIn, at: datetime | None = None) -> dict[str, Any]:
    o = _get(session, order_id)
    if o.status not in (POStatus.ORDERED, POStatus.PARTIAL, POStatus.DRAFT):
        raise ValidationFailed("Bu sipariş mal kabule açık değil.")
    ts = at or now()
    rate = data.fx_rate if data.fx_rate else fx_service.rate_for(session, o.currency)
    if o.currency == Currency.TRY:
        rate = Decimal(1)
    items = {i.id: i for i in _items(session, o.id)}  # type: ignore[arg-type]
    received_lines = []
    for idx, ri in enumerate(data.items):
        item = items.get(ri.item_id)
        if not item:
            raise ValidationFailed("Kalem bu siparişe ait değil.", {f"items.{idx}.item_id": "Geçersiz kalem."})
        p = session.get(Product, item.product_id)
        assert p is not None
        q = to_qty(ri.qty)
        try:
            validate_qty_for_unit(q, p.unit_type)
        except ValueError as exc:
            raise ValidationFailed(str(exc), {f"items.{idx}.qty": str(exc)}) from exc
        if q > item.qty - item.received_qty:
            raise ValidationFailed(f"Gelen miktar kalan sipariş miktarını aşıyor: {p.name}", {f"items.{idx}.qty": "Miktar fazla."})
        if p.track_serial and len(stock_service.normalize_serials(ri.serials)) != int(q):
            raise ValidationFailed(
                f"Seri takipli üründe {int(q)} seri numarası girilmeden kabul tamamlanamaz: {p.name}",
                {f"items.{idx}.serials": "Seri numaraları eksik."},
                code="SERIALS_REQUIRED",
            )
        cost = round_half_up(item.unit_price * rate * 100)  # type: ignore[operator]
        movement = stock_service.apply_movement(
            session,
            p,
            MovementType.PURCHASE_IN,
            q,
            actor.id,
            unit_cost_kurus=cost,
            ref_type="PURCHASE_ORDER",
            ref_id=o.id,
            note=f"{o.order_no} · kur {rate}",
            at=ts,
        )
        if p.track_serial:
            stock_service.register_serials(session, p, ri.serials, movement)
        item.received_qty = item.received_qty + q
        session.add(item)
        if data.update_purchase_price and o.currency == p.purchase_currency and item.unit_price != p.purchase_price:
            p.purchase_price = item.unit_price
            if p.pricing_mode == PricingMode.FX_LINKED:
                pricing_service.reprice(session, p, actor.id, PriceReason.MANUAL)
            session.add(p)
        received_lines.append({"product_id": p.id, "qty": str(q), "unit_cost_kurus": cost})
    all_done = all(i.received_qty >= i.qty for i in items.values())
    o.status = POStatus.RECEIVED if all_done else POStatus.PARTIAL
    o.ordered_at = o.ordered_at or ts
    if all_done:
        o.received_at = ts
    session.add(o)
    audit.record(session, actor, "purchase.receive", "purchase_order", o.id, None, None, {"lines": received_lines, "fx_rate": rate})
    session.commit()
    return get_order(session, actor, order_id)


def from_critical(session: Session, actor: Actor, supplier_id: int) -> dict[str, Any]:
    supplier = session.get(Supplier, supplier_id)
    if not supplier:
        raise ValidationFailed("Tedarikçi bulunamadı.")
    products = session.exec(
        select(Product).where(
            Product.is_active == True,  # noqa: E712
            Product.unit_type != UnitType.SERVICE,
            Product.min_stock > 0,
            (Product.supplier_id == supplier_id) | (col(Product.supplier_id).is_(None)),
        )
    ).all()
    critical = [p for p in products if p.stock_qty <= p.min_stock]
    if not critical:
        raise ValidationFailed("Bu tedarikçi için kritik stokta ürün yok.", code="NO_CRITICAL")
    supplier_rate = fx_service.rate_for(session, supplier.currency)
    items = []
    for p in critical:
        need = p.min_stock * 2 - p.stock_qty
        if p.unit_type == UnitType.PIECE:
            need = need.to_integral_value(rounding=ROUND_CEILING)
        need = max(need, Decimal(1))
        if p.purchase_currency == supplier.currency:
            price = p.purchase_price
        else:
            product_rate = fx_service.rate_for(session, p.purchase_currency)
            price = (p.purchase_price * product_rate / supplier_rate).quantize(Decimal("0.01"))  # type: ignore[operator]
        items.append({"product_id": p.id, "qty": need, "unit_price": price})
    from app.schemas.ops import POItemIn

    return create_order(
        session, actor, POCreate(supplier_id=supplier_id, note="Kritik stoklardan oluşturuldu.", items=[POItemIn(**i) for i in items])
    )


def strip_prices(order: dict[str, Any], actor: Actor) -> dict[str, Any]:
    """Personel sipariş fiyatlarını (alış fiyatı) göremez."""
    if actor.can(P.PRODUCT_COST_VIEW):
        return order
    order = dict(order, total=None, fx_rate=None, current_rate=None)
    if "items" in order:
        order["items"] = [dict(i, unit_price=None, line_total=None) for i in order["items"]]
    return order
