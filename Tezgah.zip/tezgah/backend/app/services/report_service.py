"""Raporlar ve pano.

Tüm satış raporları ortak bir "olay" listesinden üretilir: satış kalemleri (+) ve
iade kalemleri (−, iade tarihinde). Ciro KDV dahil; kâr = KDV hariç ciro − maliyet.
Maliyet, satış anındaki ağırlıklı ortalama maliyettir (unit_cost_snapshot).
"""

from collections import defaultdict
from dataclasses import dataclass
from datetime import date, datetime, timedelta
from decimal import Decimal
from io import BytesIO
from typing import Any

from openpyxl import Workbook
from openpyxl.styles import Font
from sqlmodel import Session, col, select

from app.core.dates import date_range, day_end, day_start
from app.core.money import round_half_up, vat_of_gross
from app.models import (
    Category,
    Customer,
    DeviceType,
    Payment,
    PaymentMethod,
    Product,
    ProductSerial,
    Return,
    ReturnItem,
    Sale,
    SaleItem,
    SaleStatus,
    SerialStatus,
    ServiceStatus,
    ServiceStatusHistory,
    ServiceTicket,
    UnitType,
    User,
    now,
)
from app.services import catalog_service, customer_service, fx_service, product_service, stock_service
from app.services.service_ticket_service import OPEN_STATUSES, STATUS_TR
from app.services.settings_service import get_settings_row

METHOD_TR = {"CASH": "Nakit", "CARD": "Kart", "TRANSFER": "Havale/EFT", "CREDIT": "Veresiye"}
DEVICE_TR = {
    DeviceType.LAPTOP: "Dizüstü",
    DeviceType.DESKTOP: "Masaüstü",
    DeviceType.PRINTER: "Yazıcı",
    DeviceType.PHONE: "Telefon",
    DeviceType.MONITOR: "Monitör",
    DeviceType.OTHER: "Diğer",
}


def col_(key: str, label: str, type_: str = "text") -> dict[str, str]:
    return {"key": key, "label": label, "type": type_}


def pct(part: int | Decimal, whole: int | Decimal) -> Decimal | None:
    if not whole:
        return None
    return (Decimal(part) * 100 / Decimal(whole)).quantize(Decimal("0.1"))


@dataclass
class Fact:
    day: date
    sale_id: int
    product_id: int
    product_name: str
    user_id: int | None
    qty: Decimal
    revenue: int  # KDV dahil
    vat: int
    cost: int
    is_return: bool = False
    service: bool = False

    @property
    def net(self) -> int:
        return self.revenue - self.vat

    @property
    def profit(self) -> int:
        return self.net - self.cost


def sales_facts(session: Session, start: date, end: date) -> list[Fact]:
    facts: list[Fact] = []
    rows = session.exec(
        select(SaleItem, Sale)
        .join(Sale, col(Sale.id) == SaleItem.sale_id)
        .where(Sale.status == SaleStatus.COMPLETED, Sale.created_at >= day_start(start), Sale.created_at <= day_end(end))
    ).all()
    for it, s in rows:
        facts.append(
            Fact(
                s.created_at.date(),
                s.id,
                it.product_id,
                it.product_name,
                s.user_id,
                it.qty,
                it.net_total,  # type: ignore[arg-type]
                it.vat_amount,
                round_half_up(it.qty * it.unit_cost_snapshot),
                service=s.service_ticket_id is not None,
            )
        )
    ret_rows = session.exec(
        select(ReturnItem, Return, SaleItem, Sale)
        .join(Return, col(Return.id) == ReturnItem.return_id)
        .join(SaleItem, col(SaleItem.id) == ReturnItem.sale_item_id)
        .join(Sale, col(Sale.id) == Return.sale_id)
        .where(Return.created_at >= day_start(start), Return.created_at <= day_end(end))
    ).all()
    for ri, r, it, s in ret_rows:
        cost = round_half_up(ri.qty * it.unit_cost_snapshot) if ri.restock else 0
        facts.append(
            Fact(
                r.created_at.date(),
                s.id,
                it.product_id,
                it.product_name,
                r.user_id,
                -ri.qty,
                -ri.amount,  # type: ignore[arg-type]
                -vat_of_gross(ri.amount, it.vat_rate),
                -cost,
                is_return=True,
                service=s.service_ticket_id is not None,
            )
        )
    return facts


def _sum(facts: list[Fact]) -> dict[str, Any]:
    revenue = sum(f.revenue for f in facts)
    vat = sum(f.vat for f in facts)
    cost = sum(f.cost for f in facts)
    net = revenue - vat
    return {"revenue": revenue, "vat": vat, "net": net, "cost": cost, "profit": net - cost, "margin": pct(net - cost, net)}


def _period_key(d: date, group: str) -> tuple[str, date]:
    if group == "month":
        return d.strftime("%m.%Y"), d.replace(day=1)
    if group == "week":
        monday = d - timedelta(days=d.weekday())
        return f"{monday:%d.%m} haftası", monday
    return d.strftime("%d.%m.%Y"), d


# ---------------------------------------------------------------- raporlar


def report_sales(session: Session, start: date, end: date, group: str = "day", finance: bool = True) -> dict[str, Any]:
    facts = sales_facts(session, start, end)
    sales = session.exec(
        select(Sale).where(Sale.status == SaleStatus.COMPLETED, Sale.created_at >= day_start(start), Sale.created_at <= day_end(end))
    ).all()
    totals = _sum(facts)
    periods: dict[date, dict[str, Any]] = {}
    buckets: dict[date, list[Fact]] = defaultdict(list)
    labels: dict[date, str] = {}
    for f in facts:
        label, key = _period_key(f.day, group)
        buckets[key].append(f)
        labels[key] = label
    counts: dict[date, int] = defaultdict(int)
    for s in sales:
        counts[_period_key(s.created_at.date(), group)[1]] += 1
    if group == "day":
        for d in date_range(start, end):
            labels.setdefault(d, d.strftime("%d.%m.%Y"))
    for key in sorted(labels):
        agg = _sum(buckets.get(key, []))
        periods[key] = {"period": labels[key], "date": key, "count": counts.get(key, 0), **agg}
    methods: dict[str, int] = defaultdict(int)
    for p in session.exec(
        select(Payment)
        .join(Sale, col(Sale.id) == Payment.sale_id)
        .where(
            Sale.status == SaleStatus.COMPLETED, Payment.amount > 0, Sale.created_at >= day_start(start), Sale.created_at <= day_end(end)
        )
    ).all():
        methods[p.method] += p.amount
    method_total = sum(methods.values())
    vat_rows: dict[int, dict[str, int]] = {}
    for it, _s in session.exec(
        select(SaleItem, Sale)
        .join(Sale, col(Sale.id) == SaleItem.sale_id)
        .where(Sale.status == SaleStatus.COMPLETED, Sale.created_at >= day_start(start), Sale.created_at <= day_end(end))
    ).all():
        r = vat_rows.setdefault(it.vat_rate, {"rate": it.vat_rate, "base": 0, "vat": 0, "total": 0})
        r["vat"] += it.vat_amount
        r["total"] += it.net_total
        r["base"] += it.net_total - it.vat_amount
    returns_total = -sum(f.revenue for f in facts if f.is_return)
    period_cols = [col_("period", "Dönem"), col_("count", "Satış", "int"), col_("revenue", "Ciro (KDV dahil)", "money")]
    if finance:
        period_cols += [
            col_("net", "Ciro (KDV hariç)", "money"),
            col_("cost", "Maliyet", "money"),
            col_("profit", "Brüt kâr", "money"),
            col_("margin", "Marj", "pct"),
        ]
    kpis = [
        {"label": "Ciro", "value": totals["revenue"], "type": "money"},
        {"label": "Satış sayısı", "value": len(sales), "type": "int"},
        {"label": "Ortalama sepet", "value": round(totals["revenue"] / len(sales)) if sales else 0, "type": "money"},
        {"label": "İadeler", "value": returns_total, "type": "money"},
    ]
    if finance:
        kpis[1:1] = [
            {"label": "Maliyet", "value": totals["cost"], "type": "money"},
            {"label": "Brüt kâr", "value": totals["profit"], "type": "money"},
            {"label": "Marj", "value": totals["margin"], "type": "pct"},
        ]
    return {
        "title": "Satış & Kâr",
        "kpis": kpis,
        "chart": {
            "type": "line",
            "x": "period",
            "series": [{"key": "revenue", "label": "Ciro"}] + ([{"key": "profit", "label": "Kâr"}] if finance else []),
            "rows": list(periods.values()),
        },
        "tables": [
            {
                "key": "periods",
                "title": "Dönemler",
                "columns": period_cols,
                "rows": list(periods.values()),
                "totals": {"period": "Toplam", "count": len(sales), **totals},
            },
            {
                "key": "methods",
                "title": "Ödeme yöntemi dağılımı",
                "bar": "amount",
                "columns": [col_("label", "Yöntem"), col_("amount", "Tutar", "money"), col_("share", "Pay", "pct")],
                "rows": [
                    {"label": METHOD_TR[m], "amount": a, "share": pct(a, method_total)}
                    for m, a in sorted(methods.items(), key=lambda x: -x[1])
                ],
            },
            {
                "key": "vat",
                "title": "KDV dökümü",
                "columns": [
                    col_("rate_label", "Oran"),
                    col_("base", "Matrah", "money"),
                    col_("vat", "KDV", "money"),
                    col_("total", "Toplam", "money"),
                ],
                "rows": [dict(r, rate_label=f"%{r['rate']}") for r in sorted(vat_rows.values(), key=lambda r: r["rate"])],
            },
        ],
    }


def report_cashbox(session: Session, day: date) -> dict[str, Any]:
    start, end = day_start(day), day_end(day)
    users = {u.id: u.full_name for u in session.exec(select(User)).all()}
    pays = session.exec(
        select(Payment, Sale)
        .join(Sale, col(Sale.id) == Payment.sale_id, isouter=True)
        .where(Payment.created_at >= start, Payment.created_at <= end)
    ).all()
    by_method: dict[str, dict[str, int]] = {m.value: {"sales": 0, "collections": 0, "refunds": 0} for m in PaymentMethod}
    by_user: dict[int | None, dict[str, Any]] = {}
    for p, s in pays:
        if s is not None and s.status == SaleStatus.CANCELLED and p.return_id is None:
            continue
        bucket = "refunds" if p.return_id else ("sales" if p.sale_id else "collections")
        by_method[p.method][bucket] += p.amount
        u = by_user.setdefault(p.user_id, {"user": users.get(p.user_id, "—"), "sales": 0, "collections": 0, "refunds": 0, "count": 0})  # type: ignore[arg-type]
        u[bucket] += p.amount
    sales = session.exec(select(Sale).where(Sale.created_at >= start, Sale.created_at <= end)).all()
    for s in sales:
        if s.status == SaleStatus.COMPLETED and s.user_id in by_user:
            by_user[s.user_id]["count"] += 1
    rows = []
    for m, v in by_method.items():
        net = v["sales"] + v["collections"] + v["refunds"]
        if any(v.values()):
            rows.append({"label": METHOD_TR[m], **v, "net": net})
    cancelled = [s for s in sales if s.status == SaleStatus.CANCELLED]
    returns = session.exec(
        select(Return, Sale.receipt_no)
        .join(Sale, col(Sale.id) == Return.sale_id)
        .where(Return.created_at >= start, Return.created_at <= end)
    ).all()
    cash = by_method["CASH"]
    return {
        "title": f"Gün sonu kasa raporu — {day:%d.%m.%Y}",
        "notes": ["Bu rapor bilgi amaçlıdır; mali Z raporu değildir."],
        "kpis": [
            {"label": "Kasadaki nakit hareketi", "value": cash["sales"] + cash["collections"] + cash["refunds"], "type": "money"},
            {"label": "Tamamlanan satış", "value": sum(1 for s in sales if s.status == SaleStatus.COMPLETED), "type": "int"},
            {"label": "İptal", "value": len(cancelled), "type": "int"},
            {"label": "İade tutarı", "value": sum(r.total for r, _ in returns), "type": "money"},
        ],
        "tables": [
            {
                "key": "methods",
                "title": "Ödeme yöntemlerine göre",
                "columns": [
                    col_("label", "Yöntem"),
                    col_("sales", "Satış", "money"),
                    col_("collections", "Tahsilat", "money"),
                    col_("refunds", "İade", "money"),
                    col_("net", "Net", "money"),
                ],
                "rows": rows,
                "totals": {"label": "Toplam", **{k: sum(r[k] for r in rows) for k in ("sales", "collections", "refunds", "net")}},
            },
            {
                "key": "staff",
                "title": "Personel bazında",
                "columns": [
                    col_("user", "Personel"),
                    col_("count", "Satış", "int"),
                    col_("sales", "Satış tutarı", "money"),
                    col_("collections", "Tahsilat", "money"),
                    col_("refunds", "İade", "money"),
                ],
                "rows": list(by_user.values()),
            },
            {
                "key": "cancelled",
                "title": "İptal edilen satışlar",
                "columns": [
                    col_("receipt_no", "Fiş no", "code"),
                    col_("at", "Saat", "datetime"),
                    col_("total", "Tutar", "money"),
                    col_("reason", "Neden"),
                ],
                "rows": [
                    {
                        "receipt_no": s.receipt_no,
                        "at": s.cancelled_at,
                        "total": s.total,
                        "reason": s.cancelled_reason,
                        "link": f"/satislar/{s.id}",
                    }
                    for s in cancelled
                ],
            },
            {
                "key": "returns",
                "title": "İadeler",
                "columns": [
                    col_("receipt_no", "Fiş no", "code"),
                    col_("at", "Saat", "datetime"),
                    col_("method", "Yöntem"),
                    col_("total", "Tutar", "money"),
                    col_("reason", "Neden"),
                ],
                "rows": [
                    {
                        "receipt_no": no,
                        "at": r.created_at,
                        "method": METHOD_TR[r.method],
                        "total": r.total,
                        "reason": r.reason,
                        "link": f"/satislar/{r.sale_id}",
                    }
                    for r, no in returns
                ],
            },
        ],
    }


def report_top_products(session: Session, start: date, end: date, finance: bool = True, limit: int = 30) -> dict[str, Any]:
    facts = sales_facts(session, start, end)
    products = {p.id: p for p in session.exec(select(Product)).all()}
    paths = catalog_service.category_paths(session)
    agg: dict[int, dict[str, Any]] = {}
    cats: dict[str, dict[str, Any]] = {}
    for f in facts:
        p = products.get(f.product_id)
        if p is None or p.sku == "HZM-ISCILIK":
            continue
        a = agg.setdefault(
            f.product_id,
            {
                "product_id": f.product_id,
                "sku": p.sku,
                "name": p.name,
                "unit_type": p.unit_type,
                "qty": Decimal(0),
                "revenue": 0,
                "profit": 0,
                "link": f"/urunler/{p.id}",
            },
        )
        a["qty"] += f.qty
        a["revenue"] += f.revenue
        a["profit"] += f.profit
        cname = paths.get(p.category_id, "Kategorisiz") if p.category_id else "Kategorisiz"  # type: ignore[arg-type]
        c = cats.setdefault(cname, {"category": cname, "qty_lines": 0, "revenue": 0, "profit": 0})
        c["qty_lines"] += 1
        c["revenue"] += f.revenue
        c["profit"] += f.profit
    by_qty = sorted(agg.values(), key=lambda r: -r["qty"])[:limit]
    by_rev = sorted(agg.values(), key=lambda r: -r["revenue"])[:limit]
    total_rev = sum(c["revenue"] for c in cats.values())
    cat_rows = sorted(cats.values(), key=lambda r: -r["revenue"])
    for c in cat_rows:
        c["share"] = pct(c["revenue"], total_rev)
        c["margin"] = None
    base_cols = [col_("sku", "SKU", "code"), col_("name", "Ürün"), col_("qty", "Miktar", "qty"), col_("revenue", "Ciro", "money")]
    if finance:
        base_cols.append(col_("profit", "Brüt kâr", "money"))
    cat_cols = [col_("category", "Kategori"), col_("revenue", "Ciro", "money"), col_("share", "Pay", "pct")]
    if finance:
        cat_cols.insert(2, col_("profit", "Brüt kâr", "money"))
    return {
        "title": "En çok satanlar",
        "kpis": [
            {"label": "Satılan farklı ürün", "value": len(agg), "type": "int"},
            {"label": "Toplam ciro", "value": total_rev, "type": "money"},
        ],
        "tables": [
            {"key": "by_revenue", "title": "Ciroya göre", "bar": "revenue", "columns": base_cols, "rows": by_rev},
            {"key": "by_qty", "title": "Miktara göre", "columns": base_cols, "rows": by_qty},
            {"key": "categories", "title": "Kategori performansı", "bar": "revenue", "columns": cat_cols, "rows": cat_rows},
        ],
    }


def dead_stock_rows(session: Session, days: int) -> list[dict[str, Any]]:
    lk = product_service.Lookups.load(session)
    limit = now() - timedelta(days=days)
    rows = []
    for p in session.exec(
        select(Product).where(Product.is_active == True, Product.unit_type != UnitType.SERVICE, Product.stock_qty > 0)
    ).all():  # noqa: E712
        last = p.last_movement_at or p.created_at
        if last >= limit:
            continue
        cost = product_service.unit_cost_kurus(p, lk)
        rows.append(
            {
                "product_id": p.id,
                "sku": p.sku,
                "name": p.name,
                "unit_type": p.unit_type,
                "stock_qty": p.stock_qty,
                "last_movement_at": p.last_movement_at,
                "idle_days": (now() - last).days,
                "capital": round_half_up(p.stock_qty * cost),
                "sale_value": round_half_up(p.stock_qty * p.sale_price_kurus),
                "location": lk.locations.get(p.location_id) if p.location_id else None,
                "link": f"/urunler/{p.id}",
            }
        )  # type: ignore[arg-type]
    return sorted(rows, key=lambda r: -r["capital"])


def report_dead_stock(session: Session, days: int | None = None) -> dict[str, Any]:
    days = days or get_settings_row(session).dead_stock_days
    rows = dead_stock_rows(session, days)
    return {
        "title": f"Ölü stok — {days} gündür hareketsiz",
        "kpis": [
            {"label": "Ürün", "value": len(rows), "type": "int"},
            {"label": "Bağlanan sermaye", "value": sum(r["capital"] for r in rows), "type": "money"},
            {"label": "Satış değeri", "value": sum(r["sale_value"] for r in rows), "type": "money"},
        ],
        "tables": [
            {
                "key": "dead",
                "title": "Hareketsiz ürünler",
                "bar": "capital",
                "columns": [
                    col_("sku", "SKU", "code"),
                    col_("name", "Ürün"),
                    col_("location", "Raf", "code"),
                    col_("stock_qty", "Stok", "qty"),
                    col_("idle_days", "Gün", "int"),
                    col_("last_movement_at", "Son hareket", "datetime"),
                    col_("capital", "Sermaye", "money"),
                ],
                "rows": rows,
            }
        ],
    }


def report_abc(session: Session, start: date, end: date) -> dict[str, Any]:
    facts = sales_facts(session, start, end)
    agg: dict[int, dict[str, Any]] = {}
    products = {p.id: p for p in session.exec(select(Product)).all()}
    for f in facts:
        p = products[f.product_id]
        a = agg.setdefault(f.product_id, {"product_id": p.id, "sku": p.sku, "name": p.name, "revenue": 0, "link": f"/urunler/{p.id}"})
        a["revenue"] += f.revenue
    rows = sorted((r for r in agg.values() if r["revenue"] > 0), key=lambda r: -r["revenue"])
    total = sum(r["revenue"] for r in rows)
    cum = 0
    counts = {"A": 0, "B": 0, "C": 0}
    revs = {"A": 0, "B": 0, "C": 0}
    for i, r in enumerate(rows, 1):
        before = cum
        cum += r["revenue"]
        share_before = Decimal(before) * 100 / total if total else Decimal(0)
        r["rank"] = i
        r["share"] = pct(r["revenue"], total)
        r["cumulative"] = pct(cum, total)
        r["cls"] = "A" if share_before < 80 else ("B" if share_before < 95 else "C")
        counts[r["cls"]] += 1
        revs[r["cls"]] += r["revenue"]
    return {
        "title": "ABC analizi",
        "notes": ["A: cironun ilk %80'i · B: sonraki %15 · C: kalan %5"],
        "kpis": [{"label": f"{k} sınıfı", "value": f"{counts[k]} ürün · %{pct(revs[k], total) or 0}", "type": "text"} for k in "ABC"],
        "chart": {
            "type": "pareto",
            "x": "rank",
            "series": [{"key": "cumulative", "label": "Kümülatif %"}],
            "rows": [{"rank": r["rank"], "cumulative": r["cumulative"], "revenue": r["revenue"], "name": r["name"]} for r in rows],
        },
        "tables": [
            {
                "key": "abc",
                "title": "Ürünler",
                "columns": [
                    col_("rank", "#", "int"),
                    col_("cls", "Sınıf", "code"),
                    col_("sku", "SKU", "code"),
                    col_("name", "Ürün"),
                    col_("revenue", "Ciro", "money"),
                    col_("share", "Pay", "pct"),
                    col_("cumulative", "Kümülatif", "pct"),
                ],
                "rows": rows,
            }
        ],
    }


def report_stock_value(session: Session) -> dict[str, Any]:
    lk = product_service.Lookups.load(session)
    cats: dict[str, dict[str, Any]] = {}
    for p in session.exec(select(Product).where(Product.is_active == True, Product.unit_type != UnitType.SERVICE)).all():  # noqa: E712
        if p.stock_qty <= 0:
            continue
        name = lk.categories.get(p.category_id, "Kategorisiz") if p.category_id else "Kategorisiz"  # type: ignore[arg-type]
        c = cats.setdefault(name, {"category": name, "items": 0, "cost_value": 0, "sale_value": 0})
        c["items"] += 1
        c["cost_value"] += round_half_up(p.stock_qty * product_service.unit_cost_kurus(p, lk))
        c["sale_value"] += round_half_up(p.stock_qty * p.sale_price_kurus)
    rows = sorted(cats.values(), key=lambda r: -r["cost_value"])
    tc, ts = sum(r["cost_value"] for r in rows), sum(r["sale_value"] for r in rows)
    return {
        "title": "Stok değeri",
        "notes": ["Alış değeri ağırlıklı ortalama maliyetle (KDV hariç), satış değeri güncel etiket fiyatıyla (KDV dahil) hesaplanır."],
        "kpis": [
            {"label": "Alış değeri", "value": tc, "type": "money"},
            {"label": "Satış değeri", "value": ts, "type": "money"},
            {"label": "Stoklu ürün", "value": sum(r["items"] for r in rows), "type": "int"},
        ],
        "tables": [
            {
                "key": "categories",
                "title": "Kategori kırılımı",
                "bar": "cost_value",
                "columns": [
                    col_("category", "Kategori"),
                    col_("items", "Ürün", "int"),
                    col_("cost_value", "Alış değeri", "money"),
                    col_("sale_value", "Satış değeri", "money"),
                ],
                "rows": rows,
                "totals": {"category": "Toplam", "items": sum(r["items"] for r in rows), "cost_value": tc, "sale_value": ts},
            }
        ],
    }


def report_staff(session: Session, start: date, end: date) -> dict[str, Any]:
    users = session.exec(select(User)).all()
    sales = session.exec(
        select(Sale).where(Sale.status == SaleStatus.COMPLETED, Sale.created_at >= day_start(start), Sale.created_at <= day_end(end))
    ).all()
    facts = sales_facts(session, start, end)
    closes = session.exec(
        select(ServiceStatusHistory).where(
            col(ServiceStatusHistory.to_status).in_([ServiceStatus.READY, ServiceStatus.DELIVERED]),
            ServiceStatusHistory.at >= day_start(start),
            ServiceStatusHistory.at <= day_end(end),
        )
    ).all()
    rows = []
    for u in users:
        us = [s for s in sales if s.user_id == u.id]
        uf = [f for f in facts if f.user_id == u.id and not f.is_return]
        revenue = sum(s.total for s in us)
        rows.append(
            {
                "user": u.full_name,
                "role": "Yönetici" if u.role == "ADMIN" else "Personel",
                "count": len(us),
                "revenue": revenue,
                "avg_basket": round(revenue / len(us)) if us else 0,
                "profit": sum(f.profit for f in uf),
                "service_closed": sum(1 for h in closes if h.user_id == u.id and h.to_status == ServiceStatus.READY),
                "delivered": sum(1 for h in closes if h.user_id == u.id and h.to_status == ServiceStatus.DELIVERED),
            }
        )
    return {
        "title": "Personel performansı",
        "tables": [
            {
                "key": "staff",
                "title": "Personel",
                "bar": "revenue",
                "columns": [
                    col_("user", "Personel"),
                    col_("role", "Rol"),
                    col_("count", "Satış", "int"),
                    col_("revenue", "Ciro", "money"),
                    col_("avg_basket", "Ort. sepet", "money"),
                    col_("profit", "Brüt kâr", "money"),
                    col_("service_closed", "Onarım bitirdi", "int"),
                    col_("delivered", "Teslim etti", "int"),
                ],
                "rows": sorted(rows, key=lambda r: -r["revenue"]),
            }
        ],
    }


def report_service(session: Session, start: date, end: date) -> dict[str, Any]:
    tickets = session.exec(select(ServiceTicket)).all()
    in_range = [t for t in tickets if start <= t.received_at.date() <= end]
    delivered = [t for t in tickets if t.delivered_at and start <= t.delivered_at.date() <= end]
    durations = [(t.delivered_at - t.received_at).total_seconds() / 86400 for t in delivered if t.delivered_at]
    open_counts: dict[str, int] = defaultdict(int)
    for t in tickets:
        if t.status in OPEN_STATUSES:
            open_counts[t.status] += 1
    devices: dict[str, int] = defaultdict(int)
    for t in in_range:
        devices[t.device_type] += 1
    revenue = sum(
        s.total
        for s in session.exec(
            select(Sale).where(
                Sale.status == SaleStatus.COMPLETED,
                col(Sale.service_ticket_id).is_not(None),
                Sale.created_at >= day_start(start),
                Sale.created_at <= day_end(end),
            )
        ).all()
    )
    return {
        "title": "Servis raporu",
        "kpis": [
            {"label": "Alınan cihaz", "value": len(in_range), "type": "int"},
            {"label": "Teslim edilen", "value": len(delivered), "type": "int"},
            {"label": "Ort. onarım süresi", "value": f"{sum(durations) / len(durations):.1f} gün" if durations else "—", "type": "text"},
            {"label": "Servis geliri", "value": revenue, "type": "money"},
        ],
        "tables": [
            {
                "key": "status",
                "title": "Açık kayıtların durum dağılımı",
                "bar": "count",
                "columns": [col_("label", "Durum"), col_("count", "Kayıt", "int")],
                "rows": [{"label": STATUS_TR[s], "count": open_counts[s]} for s in OPEN_STATUSES if open_counts.get(s)],
            },
            {
                "key": "devices",
                "title": "Cihaz tiplerine göre gelen arızalar",
                "bar": "count",
                "columns": [col_("label", "Cihaz tipi"), col_("count", "Kayıt", "int"), col_("share", "Pay", "pct")],
                "rows": [
                    {"label": DEVICE_TR[DeviceType(d)], "count": c, "share": pct(c, len(in_range))}
                    for d, c in sorted(devices.items(), key=lambda x: -x[1])
                ],
            },
        ],
    }


def report_warranty(session: Session, days: int = 30) -> dict[str, Any]:
    today = date.today()
    rows = session.exec(
        select(ProductSerial, Product.name, Sale, Customer.full_name, Customer.phone)
        .join(Product, col(Product.id) == ProductSerial.product_id)
        .join(SaleItem, col(SaleItem.id) == ProductSerial.sale_item_id)
        .join(Sale, col(Sale.id) == SaleItem.sale_id)
        .join(Customer, col(Customer.id) == Sale.customer_id, isouter=True)
        .where(
            ProductSerial.status == SerialStatus.SOLD,
            ProductSerial.warranty_until >= today,
            ProductSerial.warranty_until <= today + timedelta(days=days),
        )
        .order_by(col(ProductSerial.warranty_until))
    ).all()
    return {
        "title": f"Garantisi {days} gün içinde bitecek satışlar",
        "kpis": [{"label": "Kayıt", "value": len(rows), "type": "int"}],
        "tables": [
            {
                "key": "warranty",
                "title": "Seri numaraları",
                "columns": [
                    col_("serial_no", "Seri no", "code"),
                    col_("product", "Ürün"),
                    col_("receipt_no", "Fiş", "code"),
                    col_("sold_at", "Satış", "datetime"),
                    col_("customer", "Müşteri"),
                    col_("warranty_until", "Garanti bitişi", "date"),
                    col_("days_left", "Kalan gün", "int"),
                ],
                "rows": [
                    {
                        "serial_no": s.serial_no,
                        "product": name,
                        "receipt_no": sale.receipt_no,
                        "sold_at": sale.created_at,
                        "customer": cname or "—",
                        "warranty_until": s.warranty_until,
                        "days_left": (s.warranty_until - today).days if s.warranty_until else None,
                        "link": f"/satislar/{sale.id}",
                    }
                    for s, name, sale, cname, _ in rows
                ],
            }
        ],
    }


# ---------------------------------------------------------------- pano


def dashboard(session: Session, finance: bool) -> dict[str, Any]:
    today = date.today()
    yesterday = today - timedelta(days=1)
    start30 = today - timedelta(days=29)
    facts = sales_facts(session, start30, today)
    sales = session.exec(select(Sale).where(Sale.status == SaleStatus.COMPLETED, Sale.created_at >= day_start(yesterday))).all()
    by_day: dict[date, list[Fact]] = defaultdict(list)
    for f in facts:
        by_day[f.day].append(f)
    t, y = _sum(by_day.get(today, [])), _sum(by_day.get(yesterday, []))
    count_t = sum(1 for s in sales if s.created_at.date() == today)
    count_y = sum(1 for s in sales if s.created_at.date() == yesterday)

    tickets = session.exec(select(ServiceTicket).where(col(ServiceTicket.status).in_(OPEN_STATUSES))).all()
    ready = sum(1 for tk in tickets if tk.status == ServiceStatus.READY)
    received_today = session.exec(select(ServiceTicket.id).where(ServiceTicket.received_at >= day_start(today))).all()

    stock_products = session.exec(select(Product).where(Product.is_active == True, Product.unit_type != UnitType.SERVICE)).all()  # noqa: E712
    critical = sorted(
        (p for p in stock_products if p.min_stock > 0 and p.stock_qty <= p.min_stock), key=lambda p: p.stock_qty - p.min_stock
    )
    out_count = sum(1 for p in critical if p.stock_qty <= 0)

    balances = customer_service.balances(session)
    overdue = customer_service.overdue_amounts(session)
    receivable = sum(v for v in balances.values() if v > 0)
    customers = {c.id: c for c in session.exec(select(Customer).where(col(Customer.id).in_(list(overdue) or [0]))).all()}

    series = []
    for d in date_range(start30, today):
        agg = _sum(by_day.get(d, []))
        row: dict[str, Any] = {"date": d, "label": d.strftime("%d.%m"), "revenue": agg["revenue"]}
        if finance:
            row["profit"] = agg["profit"]
        series.append(row)

    kpis = [
        {
            "key": "revenue",
            "label": "Bugün ciro",
            "value": t["revenue"],
            "type": "money",
            "delta": t["revenue"] - y["revenue"],
            "delta_type": "money",
            "link": "/satislar",
        },
    ]
    if finance:
        kpis.append(
            {
                "key": "profit",
                "label": "Brüt kâr",
                "value": t["profit"],
                "type": "money",
                "delta": t["profit"] - y["profit"],
                "delta_type": "money",
                "link": "/raporlar/satis",
            }
        )
    kpis += [
        {
            "key": "count",
            "label": "Satış sayısı",
            "value": count_t,
            "type": "int",
            "delta": count_t - count_y,
            "delta_type": "int",
            "link": "/satislar",
        },
        {
            "key": "service",
            "label": "Açık servis",
            "value": len(tickets),
            "type": "int",
            "sub": f"{ready} teslime hazır · bugün +{len(received_today)}",
            "link": "/servis",
        },
        {
            "key": "critical",
            "label": "Kritik stok",
            "value": len(critical),
            "type": "int",
            "sub": f"{out_count} ürün tükendi",
            "link": "/urunler?stok=critical",
            "tone": "crit" if critical else None,
        },
        {
            "key": "receivable",
            "label": "Veresiye alacağı",
            "value": receivable,
            "type": "money",
            "sub": "vadesi geçen",
            "sub_amount": sum(overdue.values()),
            "link": "/cari?filtre=debt",
        },
    ]

    attention: list[dict[str, Any]] = []
    fx = fx_service.current_rates(session)
    if fx["stale"]:
        attention.append(
            {
                "kind": "fx",
                "tone": "warn",
                "title": "Döviz kuru eski",
                "detail": f"Son güncelleme {fx['fetched_at']:%d.%m.%Y %H:%M}" if fx["fetched_at"] else "Kur girilmemiş",
                "link": "/ayarlar/kur",
            }
        )
    for p in critical[:8]:
        attention.append(
            {
                "kind": "stock",
                "tone": "crit" if p.stock_qty <= 0 else "warn",
                "title": p.name,
                "detail": f"Stok {stock_service.fmt_qty(p.stock_qty, p.unit_type)} · min {stock_service.fmt_qty(p.min_stock, p.unit_type)}",
                "link": f"/urunler/{p.id}",
            }
        )
    if len(critical) > 8:
        attention.append(
            {
                "kind": "stock",
                "tone": "warn",
                "title": f"+{len(critical) - 8} kritik ürün daha",
                "detail": "Tümünü gör",
                "link": "/urunler?stok=critical",
            }
        )
    ref = now()
    for tk in tickets:
        if tk.status == ServiceStatus.WAITING_PARTS and tk.status_changed_at and (ref - tk.status_changed_at).days >= 3:
            attention.append(
                {
                    "kind": "service",
                    "tone": "warn",
                    "title": f"{tk.code} · {tk.brand} {tk.model}".strip(),
                    "detail": f"{(ref - tk.status_changed_at).days} gündür parça bekliyor",
                    "link": f"/servis/{tk.id}",
                }
            )
    for cid, amount in sorted(overdue.items(), key=lambda x: -x[1]):
        c = customers.get(cid)
        if c:
            attention.append(
                {
                    "kind": "credit",
                    "tone": "crit",
                    "title": c.full_name,
                    "detail": "Vadesi geçen borç",
                    "amount": amount,
                    "link": f"/cari/{cid}",
                }
            )
    dead = dead_stock_rows(session, get_settings_row(session).dead_stock_days)
    if dead:
        item: dict[str, Any] = {
            "kind": "dead",
            "tone": "info",
            "title": f"{len(dead)} ürün ölü stokta",
            "detail": f"{get_settings_row(session).dead_stock_days}+ gün hareketsiz",
            "link": "/raporlar/olu-stok",
        }
        if finance:
            item["amount"] = sum(r["capital"] for r in dead)
        attention.append(item)

    return {
        "kpis": kpis,
        "series": series,
        "recent_movements": stock_service.list_movements(session, limit=12),
        "attention": attention,
        "generated_at": now(),
        "has_categories": bool(session.exec(select(Category.id)).first()),
    }


def status_info(session: Session) -> dict[str, Any]:
    from app.services import backup_service

    today = date.today()
    count = len(session.exec(select(Sale.id).where(Sale.status == SaleStatus.COMPLETED, Sale.created_at >= day_start(today))).all())
    last = backup_service.last_backup_time()
    return {"today_sales": count, "last_backup_at": last, "fx": fx_service.current_rates(session)}


# ---------------------------------------------------------------- Excel dışa aktarma


def to_xlsx(report: dict[str, Any]) -> bytes:
    wb = Workbook()
    wb.remove(wb.active)
    tables = report.get("tables") or []
    if report.get("kpis"):
        ws = wb.create_sheet("Özet")
        ws.append([report.get("title", "Rapor")])
        ws["A1"].font = Font(bold=True, size=13)
        for k in report["kpis"]:
            v = k["value"]
            ws.append([k["label"], v / 100 if k["type"] == "money" and isinstance(v, int) else (float(v) if isinstance(v, Decimal) else v)])
        for n in report.get("notes", []):
            ws.append([n])
    for t in tables:
        ws = wb.create_sheet(t["title"][:31].replace("/", "-"))
        ws.append([c["label"] for c in t["columns"]])
        for cell in ws[1]:
            cell.font = Font(bold=True)
        for r in t["rows"] + ([t["totals"]] if t.get("totals") else []):
            out = []
            for c in t["columns"]:
                v = r.get(c["key"])
                if c["type"] == "money" and isinstance(v, int):
                    v = v / 100
                elif isinstance(v, Decimal):
                    v = float(v)
                elif isinstance(v, datetime):
                    v = v.strftime("%d.%m.%Y %H:%M")
                elif isinstance(v, date):
                    v = v.strftime("%d.%m.%Y")
                out.append(v)
            ws.append(out)
        for column in ws.columns:
            width = max(len(str(c.value or "")) for c in column)
            ws.column_dimensions[column[0].column_letter].width = min(max(width + 2, 8), 50)
    if not wb.worksheets:
        wb.create_sheet("Rapor")
    buf = BytesIO()
    wb.save(buf)
    return buf.getvalue()
