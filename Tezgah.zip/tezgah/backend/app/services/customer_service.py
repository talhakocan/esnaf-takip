"""Cari hesaplar: müşteri kartı, veresiye borç/tahsilat, hesap ekstresi."""

from datetime import date
from typing import Any

from sqlalchemy import case
from sqlmodel import Session, col, func, or_, select

from app.core import audit
from app.core.deps import Actor
from app.core.errors import NotFound, ValidationFailed
from app.models import (
    Customer,
    LedgerEntry,
    LedgerType,
    Payment,
    PaymentMethod,
    Product,
    ProductSerial,
    Sale,
    SaleItem,
    SaleStatus,
    ServiceTicket,
    User,
    now,
)

METHOD_TR = {
    PaymentMethod.CASH: "nakit",
    PaymentMethod.CARD: "kart",
    PaymentMethod.TRANSFER: "havale",
    PaymentMethod.CREDIT: "veresiye",
}

CUSTOMER_FIELDS = ["full_name", "phone", "email", "tax_no", "address", "note", "credit_limit_kurus", "kvkk_consent_at", "is_active"]

_signed = case(
    (col(LedgerEntry.type) == LedgerType.PAYMENT, -col(LedgerEntry.amount)),
    else_=col(LedgerEntry.amount),
)


def signed_amount(e: LedgerEntry) -> int:
    return -e.amount if e.type == LedgerType.PAYMENT else e.amount


def balance(session: Session, customer_id: int) -> int:
    """Pozitif bakiye: müşterinin borcu."""
    value = session.exec(select(func.coalesce(func.sum(_signed), 0)).where(LedgerEntry.customer_id == customer_id)).one()
    return int(value)


def balances(session: Session) -> dict[int, int]:
    rows = session.exec(select(LedgerEntry.customer_id, func.sum(_signed)).group_by(LedgerEntry.customer_id)).all()
    return {cid: int(total or 0) for cid, total in rows}


def overdue_amounts(session: Session, today: date | None = None) -> dict[int, int]:
    """Vadesi geçmiş borç: vadesi geçmiş borçlar − tüm tahsilat/alacaklar (FIFO), en az 0."""
    today = today or date.today()
    out: dict[int, int] = {}
    entries = session.exec(select(LedgerEntry)).all()
    due: dict[int, int] = {}
    credit: dict[int, int] = {}
    for e in entries:
        amt = signed_amount(e)
        if amt > 0 and e.due_date and e.due_date < today:
            due[e.customer_id] = due.get(e.customer_id, 0) + amt
        elif amt < 0:
            credit[e.customer_id] = credit.get(e.customer_id, 0) - amt
    for cid, amount in due.items():
        rest = amount - credit.get(cid, 0)
        if rest > 0:
            out[cid] = rest
    return out


def add_debt(
    session: Session,
    customer_id: int,
    amount: int,
    description: str,
    ref_type: str,
    ref_id: int | None,
    due_date: date | None,
    user_id: int | None,
) -> LedgerEntry:
    entry = LedgerEntry(
        customer_id=customer_id,
        type=LedgerType.DEBT,
        amount=amount,
        description=description,
        ref_type=ref_type,
        ref_id=ref_id,
        due_date=due_date,
        user_id=user_id,
    )
    session.add(entry)
    return entry


def add_adjust(
    session: Session, customer_id: int, amount: int, description: str, ref_type: str | None, ref_id: int | None, user_id: int | None
) -> LedgerEntry:
    entry = LedgerEntry(
        customer_id=customer_id,
        type=LedgerType.ADJUST,
        amount=amount,
        description=description,
        ref_type=ref_type,
        ref_id=ref_id,
        user_id=user_id,
    )
    session.add(entry)
    return entry


# ---------------------------------------------------------------- müşteri kartı


def _get(session: Session, customer_id: int) -> Customer:
    c = session.get(Customer, customer_id)
    if not c:
        raise NotFound("Müşteri")
    return c


def customer_out(c: Customer, bal: int = 0, overdue: int = 0) -> dict[str, Any]:
    return {
        "id": c.id,
        "full_name": c.full_name,
        "phone": c.phone,
        "email": c.email,
        "tax_no": c.tax_no,
        "address": c.address,
        "note": c.note,
        "credit_limit_kurus": c.credit_limit_kurus,
        "kvkk_consent_at": c.kvkk_consent_at,
        "is_active": c.is_active,
        "created_at": c.created_at,
        "balance": bal,
        "overdue": overdue,
    }


def list_customers(session: Session, q: str | None = None, filter_: str | None = None, active: str = "active") -> list[dict[str, Any]]:
    stmt = select(Customer)
    if active == "active":
        stmt = stmt.where(Customer.is_active == True)  # noqa: E712
    elif active == "archived":
        stmt = stmt.where(Customer.is_active == False)  # noqa: E712
    if q:
        like = f"%{q.strip()}%"
        digits = "".join(ch for ch in q if ch.isdigit())
        conds = [col(Customer.full_name).ilike(like)]
        if digits:
            conds.append(col(Customer.phone).like(f"%{digits}%"))
        stmt = stmt.where(or_(*conds))
    bals = balances(session)
    overdue = overdue_amounts(session)
    rows = [customer_out(c, bals.get(c.id, 0), overdue.get(c.id, 0)) for c in session.exec(stmt.order_by(Customer.full_name)).all()]  # type: ignore[arg-type]
    if filter_ == "debt":
        rows = [r for r in rows if r["balance"] > 0]
    elif filter_ == "overdue":
        rows = [r for r in rows if r["overdue"] > 0]
    return rows


def normalize_phone(phone: str) -> str:
    digits = "".join(ch for ch in phone if ch.isdigit())
    if digits.startswith("90") and len(digits) == 12:
        digits = "0" + digits[2:]
    if len(digits) == 10 and digits.startswith("5"):
        digits = "0" + digits
    return digits


def save_customer(session: Session, actor: Actor, data: dict[str, Any], customer_id: int | None = None) -> dict[str, Any]:
    if "phone" in data and data["phone"]:
        data["phone"] = normalize_phone(data["phone"])
        if len(data["phone"]) not in (10, 11):
            raise ValidationFailed("Telefon numarası geçersiz.", {"phone": "05xx xxx xx xx biçiminde girin."})
    if "credit_limit_kurus" in data and not actor.is_admin:
        current = session.get(Customer, customer_id).credit_limit_kurus if customer_id else 0  # type: ignore[union-attr]
        if data["credit_limit_kurus"] != current:
            raise ValidationFailed("Kredi limitini yalnızca yönetici değiştirebilir.", {"credit_limit_kurus": "Yetkiniz yok."})
    if data.pop("kvkk_consent", None):
        data["kvkk_consent_at"] = now()
    if customer_id:
        c = _get(session, customer_id)
        before = audit.snapshot(c, CUSTOMER_FIELDS)
        if data.get("is_active") is False and not actor.is_admin:
            raise ValidationFailed("Müşteri arşivleme yalnızca yöneticiye açıktır.")
        for k, v in data.items():
            if v is not None:
                setattr(c, k, v)
    else:
        before = None
        c = Customer(**{k: v for k, v in data.items() if v is not None}, created_by=actor.id)
    session.add(c)
    session.flush()
    audit.record(
        session,
        actor,
        "customer.update" if customer_id else "customer.create",
        "customer",
        c.id,
        before,
        audit.snapshot(c, CUSTOMER_FIELDS),
    )
    session.commit()
    session.refresh(c)
    return customer_out(c, balance(session, c.id))  # type: ignore[arg-type]


def get_customer(session: Session, customer_id: int) -> dict[str, Any]:
    c = _get(session, customer_id)
    out = customer_out(c, balance(session, customer_id), overdue_amounts(session).get(customer_id, 0))
    sales = session.exec(
        select(Sale, User.full_name)
        .join(User, col(User.id) == Sale.user_id, isouter=True)
        .where(Sale.customer_id == customer_id)
        .order_by(col(Sale.created_at).desc())
        .limit(200)
    ).all()
    out["sales"] = [
        {"id": s.id, "receipt_no": s.receipt_no, "at": s.created_at, "total": s.total, "status": s.status, "user_name": n} for s, n in sales
    ]
    tickets = session.exec(
        select(ServiceTicket).where(ServiceTicket.customer_id == customer_id).order_by(col(ServiceTicket.received_at).desc())
    ).all()
    out["service_tickets"] = [
        {
            "id": t.id,
            "code": t.code,
            "device_type": t.device_type,
            "brand": t.brand,
            "model": t.model,
            "status": t.status,
            "received_at": t.received_at,
            "delivered_at": t.delivered_at,
        }
        for t in tickets
    ]
    serials = session.exec(
        select(ProductSerial, Product.name, Sale.receipt_no, Sale.created_at, Sale.id)
        .join(SaleItem, col(SaleItem.id) == ProductSerial.sale_item_id)
        .join(Sale, col(Sale.id) == SaleItem.sale_id)
        .join(Product, col(Product.id) == ProductSerial.product_id)
        .where(Sale.customer_id == customer_id, Sale.status == SaleStatus.COMPLETED)
        .order_by(col(Sale.created_at).desc())
    ).all()
    today = date.today()
    out["serials"] = [
        {
            "serial_no": s.serial_no,
            "product_name": name,
            "receipt_no": rno,
            "sold_at": at,
            "sale_id": sid,
            "warranty_until": s.warranty_until,
            "status": s.status,
            "under_warranty": bool(s.warranty_until and s.warranty_until >= today),
        }
        for s, name, rno, at, sid in serials
    ]
    return out


def statement(session: Session, customer_id: int, date_from: date | None = None, date_to: date | None = None) -> dict[str, Any]:
    c = _get(session, customer_id)
    entries = session.exec(
        select(LedgerEntry, User.full_name)
        .join(User, col(User.id) == LedgerEntry.user_id, isouter=True)
        .where(LedgerEntry.customer_id == customer_id)
        .order_by(col(LedgerEntry.created_at), col(LedgerEntry.id))
    ).all()
    running = 0
    opening = 0
    rows = []
    for e, user_name in entries:
        amt = signed_amount(e)
        d = e.created_at.date()
        if date_from and d < date_from:
            opening += amt
            running += amt
            continue
        if date_to and d > date_to:
            continue
        running += amt
        rows.append(
            {
                "id": e.id,
                "at": e.created_at,
                "type": e.type,
                "description": e.description,
                "ref_type": e.ref_type,
                "ref_id": e.ref_id,
                "due_date": e.due_date,
                "debit": amt if amt > 0 else 0,
                "credit": -amt if amt < 0 else 0,
                "balance": running,
                "user_name": user_name,
            }
        )
    return {
        "customer": customer_out(c, balance(session, customer_id), overdue_amounts(session).get(customer_id, 0)),
        "opening_balance": opening,
        "rows": rows,
        "closing_balance": running,
        "total_debit": sum(r["debit"] for r in rows),
        "total_credit": sum(r["credit"] for r in rows),
    }


def collect_payment(session: Session, actor: Actor, customer_id: int, amount: int, method: PaymentMethod, note: str) -> dict[str, Any]:
    _get(session, customer_id)
    if method == PaymentMethod.CREDIT:
        raise ValidationFailed("Tahsilat yöntemi nakit, kart veya havale olmalıdır.", {"method": "Geçersiz yöntem."})
    if amount <= 0:
        raise ValidationFailed("Tutar sıfırdan büyük olmalıdır.", {"amount": "Tutar girin."})
    payment = Payment(customer_id=customer_id, method=method, amount=amount, note=note, user_id=actor.id)
    session.add(payment)
    session.flush()
    session.add(
        LedgerEntry(
            customer_id=customer_id,
            type=LedgerType.PAYMENT,
            amount=amount,
            description=f"Tahsilat ({METHOD_TR[method]})" + (f" — {note}" if note else ""),
            ref_type="PAYMENT",
            ref_id=payment.id,
            user_id=actor.id,
        )
    )
    audit.record(session, actor, "customer.payment", "customer", customer_id, None, None, {"amount": amount, "method": method})
    session.commit()
    return {"payment_id": payment.id, "balance": balance(session, customer_id)}


def adjust_balance(session: Session, actor: Actor, customer_id: int, amount: int, description: str) -> dict[str, Any]:
    _get(session, customer_id)
    if amount == 0:
        raise ValidationFailed("Tutar sıfır olamaz.")
    before = {"balance": balance(session, customer_id)}
    add_adjust(session, customer_id, amount, description or "Bakiye düzeltme", "MANUAL", None, actor.id)
    session.flush()
    audit.record(
        session,
        actor,
        "customer.adjust",
        "customer",
        customer_id,
        before,
        {"balance": balance(session, customer_id)},
        {"amount": amount, "description": description},
    )
    session.commit()
    return {"balance": balance(session, customer_id)}
