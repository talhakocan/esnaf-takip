"""SQLite yedekleme ve geri yükleme (sqlite3 backup API ile, uygulama açıkken güvenli)."""

import logging
import re
import sqlite3
import tempfile
import threading
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any

from app.config import get_settings
from app.core.errors import NotFound, ValidationFailed
from app.db import db_file_path, get_engine

log = logging.getLogger("tezgah.backup")
NAME_RE = re.compile(r"^tezgah-\d{8}-\d{4}(-\d+)?(-[a-z]+)?\.db$")
_lock = threading.Lock()


def backup_dir() -> Path:
    d = Path(get_settings().backup_dir)
    d.mkdir(parents=True, exist_ok=True)
    return d


def list_backups() -> list[dict[str, Any]]:
    files = sorted((p for p in backup_dir().glob("tezgah-*.db") if NAME_RE.match(p.name)), key=lambda p: p.stat().st_mtime, reverse=True)
    return [
        {
            "name": p.name,
            "size": p.stat().st_size,
            "created_at": datetime.fromtimestamp(p.stat().st_mtime).replace(microsecond=0),
            "kind": "pre-restore" if "-onyedek" in p.name else ("manual" if "-manuel" in p.name else "auto"),
        }
        for p in files
    ]


def last_backup_time() -> datetime | None:
    items = list_backups()
    return items[0]["created_at"] if items else None


def _target_name(suffix: str = "") -> Path:
    stamp = datetime.now().strftime("%Y%m%d-%H%M")
    base = backup_dir() / f"tezgah-{stamp}{suffix}.db"
    n = 2
    while base.exists():
        base = backup_dir() / f"tezgah-{stamp}-{n}{suffix}.db"
        n += 1
    return base


def create_backup(kind: str = "auto") -> dict[str, Any]:
    src_path = db_file_path()
    if src_path is None or not src_path.exists():
        raise ValidationFailed("Yedeklenecek veritabanı dosyası bulunamadı.")
    suffix = {"manual": "-manuel", "pre-restore": "-onyedek"}.get(kind, "")
    with _lock:
        target = _target_name(suffix)
        src = sqlite3.connect(str(src_path))
        dst = sqlite3.connect(str(target))
        try:
            src.backup(dst)
        finally:
            dst.close()
            src.close()
        prune()
    log.info("Yedek alındı: %s", target.name)
    return next(b for b in list_backups() if b["name"] == target.name)


def prune() -> None:
    keep = get_settings().backup_keep
    autos = [b for b in list_backups() if b["kind"] == "auto"]
    for b in autos[keep:]:
        (backup_dir() / b["name"]).unlink(missing_ok=True)
    others = [b for b in list_backups() if b["kind"] != "auto"]
    for b in others[keep:]:
        (backup_dir() / b["name"]).unlink(missing_ok=True)


def backup_path(name: str) -> Path:
    if not NAME_RE.match(name):
        raise NotFound("Yedek")
    p = backup_dir() / name
    if not p.exists():
        raise NotFound("Yedek")
    return p


def _validate_sqlite(path: Path) -> None:
    try:
        conn = sqlite3.connect(f"file:{path.as_posix()}?mode=ro", uri=True)
        try:
            ok = conn.execute("PRAGMA integrity_check").fetchone()[0]
            tables = {r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        finally:
            conn.close()
    except sqlite3.DatabaseError as exc:
        raise ValidationFailed("Dosya geçerli bir Tezgâh yedeği değil.") from exc
    if ok != "ok" or not {"users", "products", "stock_movements"} <= tables:
        raise ValidationFailed("Dosya geçerli bir Tezgâh yedeği değil.")


def restore_from_bytes(content: bytes) -> dict[str, Any]:
    """Önce otomatik ön-yedek alır, sonra yüklenen yedeği canlı veritabanına kopyalar."""
    with tempfile.TemporaryDirectory() as tmp:
        upload = Path(tmp) / "upload.db"
        upload.write_bytes(content)
        _validate_sqlite(upload)
        pre = create_backup("pre-restore")
        dst_path = db_file_path()
        assert dst_path is not None
        engine = get_engine()
        engine.dispose()
        with _lock:
            src = sqlite3.connect(str(upload))
            dst = sqlite3.connect(str(dst_path))
            try:
                src.backup(dst)
            finally:
                dst.close()
                src.close()
        engine.dispose()
    from app.migrations import upgrade_db

    upgrade_db()
    return {"restored": True, "pre_backup": pre["name"]}


# ---------------------------------------------------------------- zamanlayıcı


class BackupScheduler:
    """Her gece 03:00'te ve açılışta (son yedek 24 saatten eskiyse) yedek alır."""

    def __init__(self, hour: int = 3) -> None:
        self.hour = hour
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None
        self._last_nightly: str | None = None

    def start(self) -> None:
        try:
            last = last_backup_time()
            if last is None or datetime.now() - last > timedelta(hours=24):
                create_backup("auto")
        except Exception:  # pragma: no cover - yedekleme hatası uygulamayı durdurmamalı
            log.exception("Açılış yedeği alınamadı")
        self._thread = threading.Thread(target=self._run, name="tezgah-backup", daemon=True)
        self._thread.start()

    def _run(self) -> None:  # pragma: no cover - zaman bağımlı döngü
        while not self._stop.wait(60):
            n = datetime.now()
            key = n.strftime("%Y%m%d")
            if n.hour == self.hour and self._last_nightly != key:
                self._last_nightly = key
                try:
                    create_backup("auto")
                except Exception:
                    log.exception("Gece yedeği alınamadı")

    def stop(self) -> None:
        self._stop.set()
