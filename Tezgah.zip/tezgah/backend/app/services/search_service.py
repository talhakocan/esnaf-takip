"""Genel arama (komut paleti): ürün, müşteri, servis, seri no, fiş no."""

from datetime import date
from typing import Any

from sqlmodel import Session, col, func, or_, select

from app.models import Customer, Product, ProductSerial, Sale, SaleItem, ServiceTicket
from app.services.service_ticket_service import STATUS_TR


def search(session: Session, q: str, limit: int = 6) -> dict[str, list[dict[str, Any]]]:
    q = q.strip()
    if len(q) < 2:
        return {"products": [], "customers": [], "tickets": [], "serials": [], "sales": []}
    like = f"%{q}%"
    products = session.exec(
        select(Product)
        .where(
            Product.is_active == True,  # noqa: E712
            or_(col(Product.name).ilike(like), col(Product.sku).ilike(like), col(Product.barcode).ilike(like)),
        )
        .order_by(Product.name)
        .limit(limit)
    ).all()
    digits = "".join(ch for ch in q if ch.isdigit())
    cconds = [col(Customer.full_name).ilike(like)]
    if len(digits) >= 3:
        cconds.append(col(Customer.phone).like(f"%{digits}%"))
    customers = session.exec(
        select(Customer).where(Customer.is_active == True, or_(*cconds)).order_by(Customer.full_name).limit(limit)
    ).all()  # noqa: E712
    tickets = session.exec(
        select(ServiceTicket, Customer.full_name)
        .join(Customer, col(Customer.id) == ServiceTicket.customer_id)
        .where(or_(col(ServiceTicket.code).ilike(like), col(ServiceTicket.model).ilike(like), col(ServiceTicket.serial_no).ilike(like)))
        .order_by(col(ServiceTicket.received_at).desc())
        .limit(limit)
    ).all()
    serials = session.exec(
        select(ProductSerial, Product.name, Sale.receipt_no, Sale.id, Sale.created_at)
        .join(Product, col(Product.id) == ProductSerial.product_id)
        .join(SaleItem, col(SaleItem.id) == ProductSerial.sale_item_id, isouter=True)
        .join(Sale, col(Sale.id) == SaleItem.sale_id, isouter=True)
        .where(func.upper(ProductSerial.serial_no).like(f"%{q.upper()}%"))
        .limit(limit)
    ).all()
    sales = session.exec(select(Sale).where(col(Sale.receipt_no).ilike(like)).order_by(col(Sale.created_at).desc()).limit(limit)).all()
    today = date.today()
    return {
        "products": [
            {
                "id": p.id,
                "name": p.name,
                "sku": p.sku,
                "stock_qty": p.stock_qty,
                "unit_type": p.unit_type,
                "sale_price_kurus": p.sale_price_kurus,
            }
            for p in products
        ],
        "customers": [{"id": c.id, "full_name": c.full_name, "phone": c.phone} for c in customers],
        "tickets": [
            {
                "id": t.id,
                "code": t.code,
                "model": f"{t.brand} {t.model}".strip(),
                "customer_name": n,
                "status": t.status,
                "status_label": STATUS_TR[t.status],
            }
            for t, n in tickets
        ],
        "serials": [
            {
                "id": s.id,
                "serial_no": s.serial_no,
                "product_id": s.product_id,
                "product_name": name,
                "status": s.status,
                "receipt_no": rno,
                "sale_id": sid,
                "sold_at": sat,
                "warranty_until": s.warranty_until,
                "under_warranty": bool(s.warranty_until and s.warranty_until >= today),
            }
            for s, name, rno, sid, sat in serials
        ],
        "sales": [
            {"id": s.id, "receipt_no": s.receipt_no, "total": s.total, "created_at": s.created_at, "status": s.status} for s in sales
        ],
    }
