"""Ürünler: CRUD, arama, seri numaraları, toplu fiyat, dışa/içe aktarma."""

from dataclasses import dataclass, field
from datetime import timedelta
from decimal import Decimal
from io import BytesIO
from typing import Any

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Font
from sqlmodel import Session, col, func, or_, select

from app.core import audit
from app.core.deps import Actor
from app.core.errors import Conflict, NotFound, ValidationFailed
from app.core.money import apply_rounding, round_half_up, tl_to_kurus, to_decimal, validate_qty_for_unit
from app.core.permissions import P
from app.models import (
    Brand,
    Category,
    Currency,
    Location,
    MovementType,
    PriceHistory,
    PriceReason,
    PricingMode,
    Product,
    ProductSerial,
    PurchaseOrder,
    PurchaseOrderItem,
    Sale,
    SaleItem,
    Supplier,
    UnitType,
    User,
    now,
)
from app.schemas.catalog import BulkFilter, BulkPriceIn, BulkUpdateIn, ProductCreate, ProductUpdate
from app.services import catalog_service, fx_service, pricing_service, stock_service
from app.services.settings_service import get_settings_row

COST_FIELDS = ("purchase_currency", "purchase_price", "markup_pct", "avg_cost_kurus", "margin_pct", "cost_kurus", "price_breakdown")
AUDIT_FIELDS = [
    "sku",
    "barcode",
    "name",
    "category_id",
    "brand_id",
    "supplier_id",
    "location_id",
    "unit_type",
    "vat_rate",
    "purchase_currency",
    "purchase_price",
    "pricing_mode",
    "markup_pct",
    "sale_price_kurus",
    "min_stock",
    "track_serial",
    "warranty_months",
    "notes",
    "is_active",
]


# ---------------------------------------------------------------- serileştirme


@dataclass
class Lookups:
    categories: dict[int, str] = field(default_factory=dict)
    brands: dict[int, str] = field(default_factory=dict)
    locations: dict[int, str] = field(default_factory=dict)
    suppliers: dict[int, str] = field(default_factory=dict)
    dead_days: int = 90
    rates: dict[str, Decimal] = field(default_factory=dict)

    @classmethod
    def load(cls, session: Session) -> "Lookups":
        rates = {"TRY": Decimal(1)}
        for cur in fx_service.FX_CURRENCIES:
            r = fx_service.rate_for(session, cur, strict=False)
            if r is not None:
                rates[cur.value] = r
        return cls(
            categories=catalog_service.category_paths(session),
            brands={b.id: b.name for b in session.exec(select(Brand)).all()},  # type: ignore[misc]
            locations={loc.id: loc.code for loc in session.exec(select(Location)).all()},  # type: ignore[misc]
            suppliers={s.id: s.name for s in session.exec(select(Supplier)).all()},  # type: ignore[misc]
            dead_days=get_settings_row(session).dead_stock_days,
            rates=rates,
        )


def stock_status(p: Product) -> str:
    if p.unit_type == UnitType.SERVICE:
        return "service"
    if p.stock_qty <= 0:
        return "out"
    if p.min_stock > 0 and p.stock_qty <= p.min_stock:
        return "critical"
    if p.min_stock > 0 and p.stock_qty < p.min_stock * 2:
        return "warn"
    return "ok"


def is_dead(p: Product, dead_days: int) -> bool:
    if p.unit_type == UnitType.SERVICE or p.stock_qty <= 0 or not p.is_active:
        return False
    last = p.last_movement_at or p.created_at
    return last < now() - timedelta(days=dead_days)


def unit_cost_kurus(p: Product, lk: Lookups) -> int:
    """Birim maliyet (KDV hariç): ağırlıklı ortalama, yoksa güncel kurla alış fiyatı."""
    if p.avg_cost_kurus:
        return p.avg_cost_kurus
    rate = lk.rates.get(p.purchase_currency.value if hasattr(p.purchase_currency, "value") else str(p.purchase_currency))
    return pricing_service.purchase_cost_kurus(p.purchase_price, rate) if rate else 0


def margin_pct(p: Product, cost: int) -> Decimal | None:
    if p.sale_price_kurus <= 0:
        return None
    net = Decimal(p.sale_price_kurus) * 100 / (100 + p.vat_rate)
    return ((net - cost) / net * 100).quantize(Decimal("0.1"))


def product_out(p: Product, lk: Lookups, can_cost: bool) -> dict[str, Any]:
    out: dict[str, Any] = {
        "id": p.id,
        "sku": p.sku,
        "barcode": p.barcode,
        "name": p.name,
        "category_id": p.category_id,
        "category_path": lk.categories.get(p.category_id) if p.category_id else None,  # type: ignore[arg-type]
        "brand_id": p.brand_id,
        "brand_name": lk.brands.get(p.brand_id) if p.brand_id else None,  # type: ignore[arg-type]
        "supplier_id": p.supplier_id,
        "supplier_name": lk.suppliers.get(p.supplier_id) if p.supplier_id else None,  # type: ignore[arg-type]
        "location_id": p.location_id,
        "location_code": lk.locations.get(p.location_id) if p.location_id else None,  # type: ignore[arg-type]
        "unit_type": p.unit_type,
        "vat_rate": p.vat_rate,
        "pricing_mode": p.pricing_mode,
        "sale_price_kurus": p.sale_price_kurus,
        "min_stock": p.min_stock,
        "stock_qty": p.stock_qty,
        "track_serial": p.track_serial,
        "warranty_months": p.warranty_months,
        "notes": p.notes,
        "is_active": p.is_active,
        "last_movement_at": p.last_movement_at,
        "created_at": p.created_at,
        "updated_at": p.updated_at,
        "stock_status": stock_status(p),
        "is_dead": is_dead(p, lk.dead_days),
    }
    if can_cost:
        cost = unit_cost_kurus(p, lk)
        out.update(
            purchase_currency=p.purchase_currency,
            purchase_price=p.purchase_price,
            markup_pct=p.markup_pct,
            avg_cost_kurus=p.avg_cost_kurus,
            cost_kurus=cost,
            margin_pct=margin_pct(p, cost),
        )
    return out


def strip_cost(data: dict[str, Any]) -> dict[str, Any]:
    return {k: v for k, v in data.items() if k not in COST_FIELDS}


# ---------------------------------------------------------------- sorgular


def _get(session: Session, product_id: int) -> Product:
    p = session.get(Product, product_id)
    if not p:
        raise NotFound("Ürün")
    return p


def list_products(
    session: Session,
    actor: Actor,
    q: str | None = None,
    category_id: int | None = None,
    brand_id: int | None = None,
    location_id: int | None = None,
    supplier_id: int | None = None,
    stock: str | None = None,
    pricing_mode: PricingMode | None = None,
    unit_type: UnitType | None = None,
    active: str = "active",
) -> list[dict[str, Any]]:
    stmt = select(Product)
    if active == "active":
        stmt = stmt.where(Product.is_active == True)  # noqa: E712
    elif active == "archived":
        stmt = stmt.where(Product.is_active == False)  # noqa: E712
    if q:
        like = f"%{q.strip()}%"
        stmt = stmt.where(or_(col(Product.name).ilike(like), col(Product.sku).ilike(like), col(Product.barcode).ilike(like)))
    if category_id:
        stmt = stmt.where(col(Product.category_id).in_(catalog_service.descendant_ids(session, category_id)))
    if brand_id:
        stmt = stmt.where(Product.brand_id == brand_id)
    if location_id:
        stmt = stmt.where(Product.location_id == location_id)
    if supplier_id:
        stmt = stmt.where(Product.supplier_id == supplier_id)
    if pricing_mode:
        stmt = stmt.where(Product.pricing_mode == pricing_mode)
    if unit_type:
        stmt = stmt.where(Product.unit_type == unit_type)
    lk = Lookups.load(session)
    can_cost = actor.can(P.PRODUCT_COST_VIEW)
    rows = [product_out(p, lk, can_cost) for p in session.exec(stmt.order_by(Product.name)).all()]
    if stock == "critical":
        rows = [r for r in rows if r["stock_status"] in ("critical", "out")]
    elif stock == "out":
        rows = [r for r in rows if r["stock_status"] == "out"]
    elif stock == "dead":
        rows = [r for r in rows if r["is_dead"]]
    elif stock == "warn":
        rows = [r for r in rows if r["stock_status"] == "warn"]
    return rows


def get_product(session: Session, actor: Actor, product_id: int) -> dict[str, Any]:
    p = _get(session, product_id)
    lk = Lookups.load(session)
    can_cost = actor.can(P.PRODUCT_COST_VIEW)
    out = product_out(p, lk, can_cost)
    if can_cost:
        out["price_breakdown"] = pricing_service.price_breakdown(session, p)
    out["serial_counts"] = (
        dict(
            session.exec(
                select(ProductSerial.status, func.count(col(ProductSerial.id)))
                .where(ProductSerial.product_id == p.id)
                .group_by(ProductSerial.status)
            ).all()
        )
        if p.track_serial
        else {}
    )
    return out


def lookup(session: Session, actor: Actor, code: str) -> dict[str, Any]:
    """Barkod, SKU veya seri numarasıyla tek ürün bulur (POS ve sayım için)."""
    code = code.strip()
    if not code:
        raise NotFound("Ürün")
    lk = Lookups.load(session)
    can_cost = actor.can(P.PRODUCT_COST_VIEW)
    p = session.exec(select(Product).where(Product.barcode == code)).first()
    matched = "barcode"
    if not p:
        p = session.exec(select(Product).where(func.upper(Product.sku) == code.upper())).first()
        matched = "sku"
    serial = None
    if not p:
        serials = session.exec(select(ProductSerial).where(func.upper(ProductSerial.serial_no) == code.upper())).all()
        if serials:
            serial = next((s for s in serials if s.status in stock_service.AVAILABLE_SERIAL), serials[0])
            p = session.get(Product, serial.product_id)
            matched = "serial"
    if not p:
        raise NotFound("Bu koda ait ürün")
    return {
        "matched_by": matched,
        "product": product_out(p, lk, can_cost),
        "serial": {"id": serial.id, "serial_no": serial.serial_no, "status": serial.status} if serial else None,
    }


def next_internal_barcode(session: Session) -> str:
    codes = session.exec(select(Product.barcode).where(col(Product.barcode).like("TL________"))).all()
    nums = [int(c[2:]) for c in codes if c and c[2:].isdigit()]
    return f"TL{(max(nums) + 1 if nums else 10000001):08d}"


# ---------------------------------------------------------------- yazma


def _validate_refs(session: Session, data: dict[str, Any]) -> None:
    for key, model, label in (
        ("category_id", Category, "Kategori"),
        ("brand_id", Brand, "Marka"),
        ("location_id", Location, "Konum"),
        ("supplier_id", Supplier, "Tedarikçi"),
    ):
        if data.get(key) and not session.get(model, data[key]):
            raise ValidationFailed(f"{label} bulunamadı.", {key: f"{label} bulunamadı."})


def _check_unique(session: Session, sku: str | None, barcode: str | None, product_id: int | None) -> None:
    if sku:
        other = session.exec(select(Product).where(func.upper(Product.sku) == sku.upper())).first()
        if other and other.id != product_id:
            raise Conflict(f"SKU başka bir üründe kullanılıyor: {other.name}", code="DUPLICATE_SKU")
    if barcode:
        other = session.exec(select(Product).where(Product.barcode == barcode)).first()
        if other and other.id != product_id:
            raise Conflict(f"Barkod başka bir üründe kullanılıyor: {other.name}", code="DUPLICATE_BARCODE")


def _normalize(p: Product) -> None:
    if p.unit_type == UnitType.SERVICE:
        p.track_serial = False
        p.min_stock = Decimal(0)
    if p.unit_type == UnitType.METER:
        p.track_serial = False
    if p.purchase_currency == Currency.TRY and p.pricing_mode == PricingMode.FX_LINKED:
        # TL alışlı ürün de marjla fiyatlanabilir; kur 1 kabul edilir.
        pass
    try:
        validate_qty_for_unit(p.min_stock, p.unit_type)
    except ValueError as exc:
        raise ValidationFailed(str(exc), {"min_stock": str(exc)}) from exc


def _initial_avg_cost(session: Session, p: Product) -> int:
    rate = fx_service.rate_for(session, p.purchase_currency, strict=False)
    return pricing_service.purchase_cost_kurus(p.purchase_price, rate) if rate else 0


def create_product(session: Session, actor: Actor, data: ProductCreate) -> dict[str, Any]:
    payload = data.model_dump(exclude={"initial_stock", "initial_serials", "sku"})
    _validate_refs(session, payload)
    sku = (data.sku or "").strip().upper() or None
    _check_unique(session, sku, data.barcode, None)
    p = Product(**payload, sku=sku or f"TMP-{now().timestamp()}", created_by=actor.id)
    _normalize(p)
    if p.pricing_mode == PricingMode.FX_LINKED:
        pricing_service.reprice(session, p, actor.id, PriceReason.MANUAL)
    elif p.sale_price_kurus <= 0 and p.unit_type != UnitType.SERVICE:
        raise ValidationFailed("Satış fiyatı girilmelidir.", {"sale_price_kurus": "Satış fiyatı girin."})
    p.avg_cost_kurus = _initial_avg_cost(session, p)
    session.add(p)
    session.flush()
    if not sku:
        p.sku = f"TL-{p.id:05d}"
    if data.initial_stock > 0:
        movement = stock_service.apply_movement(
            session, p, MovementType.ADJUST_IN, data.initial_stock, actor.id, ref_type="MANUAL", note="Açılış stoğu"
        )
        if p.track_serial:
            if len(stock_service.normalize_serials(data.initial_serials)) != int(data.initial_stock):
                raise ValidationFailed(
                    "Seri takipli üründe açılış stoğu kadar seri numarası girilmelidir.",
                    {"initial_serials": "Seri numarası sayısı stokla eşleşmiyor."},
                )
            stock_service.register_serials(session, p, data.initial_serials, movement)
    audit.record(session, actor, "product.create", "product", p.id, None, audit.snapshot(p, AUDIT_FIELDS))
    session.commit()
    return get_product(session, actor, p.id)  # type: ignore[arg-type]


def update_product(session: Session, actor: Actor, product_id: int, data: ProductUpdate) -> dict[str, Any]:
    p = _get(session, product_id)
    changes = data.model_dump(exclude_unset=True)
    _validate_refs(session, changes)
    if "sku" in changes and changes["sku"]:
        changes["sku"] = changes["sku"].upper()
    if "sku" in changes and not changes["sku"]:
        changes.pop("sku")
    _check_unique(session, changes.get("sku"), changes.get("barcode"), p.id)
    if "unit_type" in changes and changes["unit_type"] != p.unit_type:
        has_moves = p.stock_qty != 0 or session.exec(select(SaleItem.id).where(SaleItem.product_id == p.id)).first()
        if has_moves:
            raise ValidationFailed("Hareket görmüş ürünün birim tipi değiştirilemez.", {"unit_type": "Değiştirilemez."})
    if (
        changes.get("track_serial") is False
        and p.track_serial
        and session.exec(select(ProductSerial.id).where(ProductSerial.product_id == p.id)).first()
    ):
        raise ValidationFailed("Seri kaydı olan üründe seri takibi kapatılamaz.", {"track_serial": "Kapatılamaz."})
    if changes.get("track_serial") and not p.track_serial and p.stock_qty > 0:
        raise ValidationFailed(
            "Stoğu olan ürüne seri takibi açılamaz; önce stoğu sıfırlayın veya yeni ürün kartı açın.",
            {"track_serial": "Stoklu üründe açılamaz."},
        )
    before = audit.snapshot(p, AUDIT_FIELDS)
    new_price = changes.pop("sale_price_kurus", None)
    for key, value in changes.items():
        setattr(p, key, value)
    _normalize(p)
    if p.pricing_mode == PricingMode.FX_LINKED:
        pricing_service.reprice(session, p, actor.id, PriceReason.MANUAL)
    elif new_price is not None:
        pricing_service.set_price(session, p, new_price, actor.id, PriceReason.MANUAL)
    if not p.avg_cost_kurus and p.stock_qty <= 0:
        p.avg_cost_kurus = _initial_avg_cost(session, p)
    session.add(p)
    audit.record(session, actor, "product.update", "product", p.id, before, audit.snapshot(p, AUDIT_FIELDS))
    session.commit()
    return get_product(session, actor, p.id)  # type: ignore[arg-type]


def set_active(session: Session, actor: Actor, product_id: int, active: bool) -> dict[str, Any]:
    p = _get(session, product_id)
    before = {"is_active": p.is_active}
    p.is_active = active
    session.add(p)
    audit.record(session, actor, "product.archive" if not active else "product.restore", "product", p.id, before, {"is_active": active})
    session.commit()
    return get_product(session, actor, product_id)


# ---------------------------------------------------------------- detay sekmeleri


def list_serials(session: Session, product_id: int) -> list[dict[str, Any]]:
    rows = session.exec(
        select(ProductSerial, SaleItem, Sale)
        .join(SaleItem, col(SaleItem.id) == ProductSerial.sale_item_id, isouter=True)
        .join(Sale, col(Sale.id) == SaleItem.sale_id, isouter=True)
        .where(ProductSerial.product_id == product_id)
        .order_by(col(ProductSerial.created_at).desc())
    ).all()
    return [
        {
            "id": s.id,
            "serial_no": s.serial_no,
            "status": s.status,
            "warranty_until": s.warranty_until,
            "created_at": s.created_at,
            "sale_id": sale.id if sale else None,
            "receipt_no": sale.receipt_no if sale else None,
            "sold_at": sale.created_at if sale else None,
        }
        for s, _item, sale in rows
    ]


def price_history(session: Session, product_id: int) -> list[dict[str, Any]]:
    rows = session.exec(
        select(PriceHistory, User.full_name)
        .join(User, col(User.id) == PriceHistory.user_id, isouter=True)
        .where(PriceHistory.product_id == product_id)
        .order_by(col(PriceHistory.created_at).desc(), col(PriceHistory.id).desc())
    ).all()
    return [
        {"id": h.id, "at": h.created_at, "old_price": h.old_price, "new_price": h.new_price, "reason": h.reason, "user_name": name}
        for h, name in rows
    ]


def product_suppliers(session: Session, product_id: int, can_cost: bool) -> list[dict[str, Any]]:
    rows = session.exec(
        select(PurchaseOrderItem, PurchaseOrder, Supplier)
        .join(PurchaseOrder, col(PurchaseOrder.id) == PurchaseOrderItem.order_id)
        .join(Supplier, col(Supplier.id) == PurchaseOrder.supplier_id)
        .where(PurchaseOrderItem.product_id == product_id)
        .order_by(col(PurchaseOrder.created_at).desc())
    ).all()
    out = []
    for item, order, supplier in rows:
        row = {
            "supplier_id": supplier.id,
            "supplier_name": supplier.name,
            "order_id": order.id,
            "order_no": order.order_no,
            "status": order.status,
            "date": order.created_at,
            "qty": item.qty,
            "received_qty": item.received_qty,
        }
        if can_cost:
            row.update(unit_price=item.unit_price, currency=order.currency)
        out.append(row)
    return out


# ---------------------------------------------------------------- toplu işlemler


def _bulk_targets(session: Session, f: BulkFilter) -> list[Product]:
    stmt = select(Product).where(Product.is_active == True)  # noqa: E712
    if f.product_ids:
        stmt = stmt.where(col(Product.id).in_(f.product_ids))
    if f.category_id:
        stmt = stmt.where(col(Product.category_id).in_(catalog_service.descendant_ids(session, f.category_id)))
    if f.brand_id:
        stmt = stmt.where(Product.brand_id == f.brand_id)
    if f.supplier_id:
        stmt = stmt.where(Product.supplier_id == f.supplier_id)
    if not (f.product_ids or f.category_id or f.brand_id or f.supplier_id):
        raise ValidationFailed("En az bir filtre veya ürün seçin.")
    return list(session.exec(stmt.order_by(Product.name)).all())


def _bulk_new_price(session: Session, p: Product, pct: Decimal, rule: str) -> tuple[int, Decimal | None]:
    factor = Decimal(1) + pct / 100
    if p.pricing_mode == PricingMode.FX_LINKED:
        new_markup = ((Decimal(1) + p.markup_pct / 100) * factor - 1) * 100
        new_markup = new_markup.quantize(Decimal("0.01"))
        rate = fx_service.rate_for(session, p.purchase_currency)
        _, price = pricing_service.compute_fx_price(p.purchase_price, rate, new_markup, rule)  # type: ignore[arg-type]
        return price, new_markup
    return apply_rounding(round_half_up(Decimal(p.sale_price_kurus) * factor), rule), None


def bulk_price_preview(session: Session, data: BulkPriceIn) -> dict[str, Any]:
    rule = get_settings_row(session).rounding_rule
    rows = []
    for p in _bulk_targets(session, data):
        new_price, new_markup = _bulk_new_price(session, p, data.pct, rule)
        rows.append(
            {
                "id": p.id,
                "sku": p.sku,
                "name": p.name,
                "pricing_mode": p.pricing_mode,
                "old_price": p.sale_price_kurus,
                "new_price": new_price,
                "old_markup": p.markup_pct if p.pricing_mode == PricingMode.FX_LINKED else None,
                "new_markup": new_markup,
            }
        )
    return {"pct": data.pct, "rounding_rule": rule, "count": len(rows), "rows": rows}


def bulk_price_apply(session: Session, actor: Actor, data: BulkPriceIn) -> dict[str, Any]:
    rule = get_settings_row(session).rounding_rule
    changed = 0
    targets = _bulk_targets(session, data)
    for p in targets:
        new_price, new_markup = _bulk_new_price(session, p, data.pct, rule)
        if new_markup is not None:
            p.markup_pct = new_markup
        if pricing_service.set_price(session, p, new_price, actor.id, PriceReason.BULK):
            changed += 1
        session.add(p)
    audit.record(
        session,
        actor,
        "product.bulk_price",
        "product",
        None,
        None,
        None,
        {"pct": data.pct, "count": changed, "product_ids": [p.id for p in targets]},
    )
    session.commit()
    return {"updated": changed, "matched": len(targets)}


def bulk_update(session: Session, actor: Actor, data: BulkUpdateIn) -> dict[str, Any]:
    products = session.exec(select(Product).where(col(Product.id).in_(data.product_ids))).all()
    if data.category_id and not session.get(Category, data.category_id):
        raise ValidationFailed("Kategori bulunamadı.")
    if data.location_id and not session.get(Location, data.location_id):
        raise ValidationFailed("Konum bulunamadı.")
    for p in products:
        before = audit.snapshot(p, ["category_id", "location_id", "is_active"])
        if data.category_id:
            p.category_id = data.category_id
        if data.location_id:
            p.location_id = data.location_id
        if data.archive is not None:
            p.is_active = not data.archive
        session.add(p)
        audit.record(
            session, actor, "product.bulk_update", "product", p.id, before, audit.snapshot(p, ["category_id", "location_id", "is_active"])
        )
    session.commit()
    return {"updated": len(products)}


# ---------------------------------------------------------------- Excel

XLSX_COLUMNS = [
    "SKU",
    "Barkod",
    "Ürün adı",
    "Kategori",
    "Marka",
    "Birim",
    "KDV %",
    "Alış para birimi",
    "Alış fiyatı",
    "Fiyat modu",
    "Kâr marjı %",
    "Satış fiyatı (TL)",
    "Min. stok",
    "Raf",
    "Seri takibi",
    "Garanti (ay)",
    "Açılış stoğu",
]
UNIT_TR = {UnitType.PIECE: "ADET", UnitType.METER: "METRE", UnitType.SERVICE: "HİZMET"}
UNIT_FROM_TR = {"ADET": UnitType.PIECE, "METRE": UnitType.METER, "HİZMET": UnitType.SERVICE, "HIZMET": UnitType.SERVICE}
MODE_TR = {PricingMode.FIXED: "SABİT", PricingMode.FX_LINKED: "KUR"}
MODE_FROM_TR = {"SABİT": PricingMode.FIXED, "SABIT": PricingMode.FIXED, "KUR": PricingMode.FX_LINKED}


def _tr_upper(value: str) -> str:
    return value.replace("i", "İ").replace("ı", "I").upper().strip()


def export_xlsx(session: Session, actor: Actor) -> bytes:
    can_cost = actor.can(P.PRODUCT_COST_VIEW)
    lk = Lookups.load(session)
    wb = Workbook()
    ws = wb.active
    ws.title = "Ürünler"
    headers = XLSX_COLUMNS[:-1] + ["Stok"]
    if not can_cost:
        headers = [h for h in headers if h not in ("Alış para birimi", "Alış fiyatı", "Kâr marjı %")]
    ws.append(headers)
    for cell in ws[1]:
        cell.font = Font(bold=True)
    for p in session.exec(select(Product).where(Product.is_active == True).order_by(Product.name)).all():  # noqa: E712
        row = {
            "SKU": p.sku,
            "Barkod": p.barcode or "",
            "Ürün adı": p.name,
            "Kategori": lk.categories.get(p.category_id, "") if p.category_id else "",  # type: ignore[arg-type]
            "Marka": lk.brands.get(p.brand_id, "") if p.brand_id else "",  # type: ignore[arg-type]
            "Birim": UNIT_TR[p.unit_type],
            "KDV %": p.vat_rate,
            "Alış para birimi": p.purchase_currency.value,
            "Alış fiyatı": float(p.purchase_price),
            "Fiyat modu": MODE_TR[p.pricing_mode],
            "Kâr marjı %": float(p.markup_pct),
            "Satış fiyatı (TL)": p.sale_price_kurus / 100,
            "Min. stok": float(p.min_stock),
            "Raf": lk.locations.get(p.location_id, "") if p.location_id else "",  # type: ignore[arg-type]
            "Seri takibi": "EVET" if p.track_serial else "HAYIR",
            "Garanti (ay)": p.warranty_months,
            "Stok": float(p.stock_qty),
        }
        ws.append([row[h] for h in headers])
    for column in ws.columns:
        width = max(len(str(c.value or "")) for c in column)
        ws.column_dimensions[column[0].column_letter].width = min(max(width + 2, 8), 48)
    buf = BytesIO()
    wb.save(buf)
    return buf.getvalue()


def import_template_xlsx() -> bytes:
    wb = Workbook()
    ws = wb.active
    ws.title = "Ürünler"
    ws.append(XLSX_COLUMNS)
    ws.append(
        ["", "", "NYA 2,5 mm² kablo", "Elektrik › Kablo", "Öznur", "METRE", 20, "TRY", 9.5, "SABİT", 0, 14.9, 100, "A-01", "HAYIR", 0, 500]
    )
    for cell in ws[1]:
        cell.font = Font(bold=True)
    buf = BytesIO()
    wb.save(buf)
    return buf.getvalue()


def _cell(row: dict[str, Any], key: str) -> str:
    v = row.get(key)
    return "" if v is None else str(v).strip()


def _parse_import(session: Session, content: bytes) -> list[dict[str, Any]]:
    try:
        wb = load_workbook(BytesIO(content), read_only=True, data_only=True)
    except Exception as exc:
        raise ValidationFailed("Dosya okunamadı. Geçerli bir .xlsx dosyası yükleyin.") from exc
    ws = wb.worksheets[0]
    rows_iter = ws.iter_rows(values_only=True)
    header = [str(h).strip() if h is not None else "" for h in next(rows_iter, [])]
    if "Ürün adı" not in header:
        raise ValidationFailed("İlk satırda 'Ürün adı' sütunu bulunamadı. Şablonu kullanın.")
    out = []
    for idx, values in enumerate(rows_iter, start=2):
        if values is None or all(v is None or str(v).strip() == "" for v in values):
            continue
        raw = dict(zip(header, values, strict=False))
        errors: list[str] = []
        name = _cell(raw, "Ürün adı")
        sku = _cell(raw, "SKU").upper()
        existing = session.exec(select(Product).where(func.upper(Product.sku) == sku)).first() if sku else None
        parsed: dict[str, Any] = {"name": name}
        if len(name) < 2:
            errors.append("Ürün adı eksik.")
        unit = UNIT_FROM_TR.get(_tr_upper(_cell(raw, "Birim") or "ADET"))
        if unit is None:
            errors.append("Birim ADET, METRE veya HİZMET olmalı.")
        parsed["unit_type"] = unit or UnitType.PIECE
        mode = MODE_FROM_TR.get(_tr_upper(_cell(raw, "Fiyat modu") or "SABİT"))
        if mode is None:
            errors.append("Fiyat modu SABİT veya KUR olmalı.")
        parsed["pricing_mode"] = mode or PricingMode.FIXED
        cur = (_cell(raw, "Alış para birimi") or "TRY").upper().replace("TL", "TRY")
        if cur not in ("TRY", "USD", "EUR"):
            errors.append("Alış para birimi TRY, USD veya EUR olmalı.")
            cur = "TRY"
        parsed["purchase_currency"] = Currency(cur)
        for key, col_name, conv in (
            ("vat_rate", "KDV %", lambda v: int(to_decimal(v or 20))),
            ("purchase_price", "Alış fiyatı", lambda v: to_decimal(v or 0)),
            ("markup_pct", "Kâr marjı %", lambda v: to_decimal(v or 0)),
            ("sale_price_kurus", "Satış fiyatı (TL)", lambda v: tl_to_kurus(v or 0)),
            ("min_stock", "Min. stok", lambda v: to_decimal(v or 0)),
            ("warranty_months", "Garanti (ay)", lambda v: int(to_decimal(v or 0))),
            ("initial_stock", "Açılış stoğu", lambda v: to_decimal(v or 0)),
        ):
            try:
                parsed[key] = conv(raw.get(col_name))
            except (ValueError, ArithmeticError):
                errors.append(f"'{col_name}' sayı olmalı.")
        if parsed.get("vat_rate") not in (0, 1, 10, 20):
            errors.append("KDV %0, %1, %10 veya %20 olmalı.")
        if parsed.get("pricing_mode") == PricingMode.FIXED and parsed.get("sale_price_kurus", 0) <= 0 and unit != UnitType.SERVICE:
            errors.append("Sabit fiyatlı üründe satış fiyatı girilmeli.")
        parsed["track_serial"] = _tr_upper(_cell(raw, "Seri takibi")) in ("EVET", "E", "1", "TRUE")
        if parsed["track_serial"] and parsed.get("initial_stock", 0) > 0:
            errors.append("Seri takipli üründe açılış stoğu içe aktarılamaz; stok girişinden seri numaralarıyla girin.")
        parsed.update(
            barcode=_cell(raw, "Barkod") or None,
            category=_cell(raw, "Kategori"),
            brand=_cell(raw, "Marka"),
            location=_cell(raw, "Raf").upper(),
        )
        if parsed["barcode"]:
            other = session.exec(select(Product).where(Product.barcode == parsed["barcode"])).first()
            if other and (not existing or other.id != existing.id):
                errors.append(f"Barkod başka üründe kullanılıyor ({other.name}).")
        out.append(
            {
                "row": idx,
                "sku": sku,
                "name": name,
                "action": "ERROR" if errors else ("UPDATE" if existing else "NEW"),
                "errors": errors,
                "product_id": existing.id if existing else None,
                "data": parsed,
            }
        )
    return out


def import_preview(session: Session, content: bytes) -> dict[str, Any]:
    rows = _parse_import(session, content)
    public = [
        {k: v for k, v in r.items() if k != "data"}
        | {"sale_price_kurus": r["data"].get("sale_price_kurus"), "unit_type": r["data"].get("unit_type")}
        for r in rows
    ]
    return {
        "rows": public,
        "counts": {a: sum(1 for r in rows if r["action"] == a) for a in ("NEW", "UPDATE", "ERROR")},
    }


def _ensure_category(session: Session, path: str) -> int | None:
    if not path:
        return None
    parent_id = None
    for part in [p.strip() for p in path.replace(">", "›").split("›") if p.strip()]:
        cat = session.exec(select(Category).where(Category.name == part, Category.parent_id == parent_id)).first()
        if not cat:
            cat = Category(name=part, parent_id=parent_id)
            session.add(cat)
            session.flush()
        parent_id = cat.id
    return parent_id


def _ensure_named(session: Session, model: type, attr: str, value: str) -> int | None:
    if not value:
        return None
    row = session.exec(select(model).where(getattr(model, attr) == value)).first()
    if not row:
        row = model(**{attr: value})
        session.add(row)
        session.flush()
    return row.id


def import_apply(session: Session, actor: Actor, content: bytes) -> dict[str, Any]:
    rows = _parse_import(session, content)
    errors = [r for r in rows if r["action"] == "ERROR"]
    if errors:
        raise ValidationFailed(f"{len(errors)} satırda hata var. Önizlemedeki hataları düzeltip tekrar yükleyin.")
    created = updated = 0
    for r in rows:
        d = r["data"]
        fields = {
            "name": d["name"],
            "unit_type": d["unit_type"],
            "vat_rate": d["vat_rate"],
            "purchase_currency": d["purchase_currency"],
            "purchase_price": d["purchase_price"],
            "pricing_mode": d["pricing_mode"],
            "markup_pct": d["markup_pct"],
            "min_stock": d["min_stock"],
            "warranty_months": d["warranty_months"],
            "track_serial": d["track_serial"],
            "category_id": _ensure_category(session, d["category"]),
            "brand_id": _ensure_named(session, Brand, "name", d["brand"]),
            "location_id": _ensure_named(session, Location, "code", d["location"]),
        }
        if d["barcode"]:
            fields["barcode"] = d["barcode"]
        if r["product_id"]:
            p = session.get(Product, r["product_id"])
            assert p is not None
            before = audit.snapshot(p, AUDIT_FIELDS)
            if p.track_serial and not fields["track_serial"]:
                fields["track_serial"] = True
            for k, v in fields.items():
                setattr(p, k, v)
            _normalize(p)
            if p.pricing_mode == PricingMode.FX_LINKED:
                pricing_service.reprice(session, p, actor.id, PriceReason.IMPORT)
            else:
                pricing_service.set_price(session, p, d["sale_price_kurus"], actor.id, PriceReason.IMPORT)
            session.add(p)
            audit.record(session, actor, "product.import_update", "product", p.id, before, audit.snapshot(p, AUDIT_FIELDS))
            updated += 1
        else:
            p = Product(
                **fields, sku=r["sku"] or f"TMP-{r['row']}-{now().timestamp()}", sale_price_kurus=d["sale_price_kurus"], created_by=actor.id
            )
            _normalize(p)
            if p.pricing_mode == PricingMode.FX_LINKED:
                pricing_service.reprice(session, p, actor.id, PriceReason.IMPORT)
            p.avg_cost_kurus = _initial_avg_cost(session, p)
            session.add(p)
            session.flush()
            if not r["sku"]:
                p.sku = f"TL-{p.id:05d}"
            if d["initial_stock"] > 0 and p.unit_type != UnitType.SERVICE:
                stock_service.apply_movement(
                    session,
                    p,
                    MovementType.ADJUST_IN,
                    d["initial_stock"],
                    actor.id,
                    ref_type="IMPORT",
                    note="Excel içe aktarma açılış stoğu",
                )
            audit.record(session, actor, "product.import_create", "product", p.id, None, audit.snapshot(p, AUDIT_FIELDS))
            created += 1
    session.commit()
    return {"created": created, "updated": updated}
