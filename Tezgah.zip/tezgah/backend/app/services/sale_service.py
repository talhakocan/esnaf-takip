"""Satış, iptal ve iade. Her işlem tek transaction içinde yapılır."""

from dataclasses import dataclass
from datetime import date, datetime, timedelta
from decimal import Decimal
from typing import Any

from sqlmodel import Session, col, func, or_, select

from app.core import audit
from app.core.dates import add_months, day_end, day_start
from app.core.deps import Actor
from app.core.errors import Forbidden, NotFound, ValidationFailed
from app.core.money import allocate, line_amount, round_half_up, validate_qty_for_unit, vat_of_gross
from app.core.money import qty as to_qty
from app.core.permissions import P
from app.models import (
    Customer,
    MovementType,
    Payment,
    PaymentMethod,
    Product,
    ProductSerial,
    Return,
    ReturnItem,
    Sale,
    SaleItem,
    SaleStatus,
    SerialStatus,
    UnitType,
    User,
    now,
)
from app.schemas.sales import Override, PaymentIn, ReturnCreate, SaleCreate
from app.services import auth_service, customer_service, stock_service
from app.services.settings_service import get_settings_row

METHOD_LABEL = {"CASH": "Nakit", "CARD": "Kart", "TRANSFER": "Havale", "CREDIT": "Veresiye"}


@dataclass
class Line:
    product: Product
    qty: Decimal
    unit_price: int
    discount: int = 0
    serial: ProductSerial | None = None
    stock_already_moved: bool = False
    cost_snapshot: int | None = None


def next_receipt_no(session: Session, year: int) -> str:
    prefix = f"TL-{year}-"
    last = session.exec(
        select(Sale.receipt_no).where(col(Sale.receipt_no).like(f"{prefix}%")).order_by(col(Sale.receipt_no).desc())
    ).first()
    seq = int(last[-6:]) + 1 if last else 1
    return f"{prefix}{seq:06d}"


def warranty_months_for(session: Session, product: Product) -> int:
    if product.warranty_months:
        return product.warranty_months
    return get_settings_row(session).default_warranty_months if product.track_serial else 0


def check_discount(actor: Actor, gross: int, total_discount: int, lines: list[Line]) -> None:
    if actor.is_admin or total_discount <= 0:
        return
    limit = actor.user.max_discount_pct
    msg = f"İndirim yetki sınırınızı aşıyor (en fazla %{limit.normalize():f})."
    if gross <= 0 or Decimal(total_discount) * 100 / gross > limit:
        raise Forbidden(msg)
    for ln in lines:
        lg = line_amount(ln.qty, ln.unit_price)
        if ln.discount and (lg <= 0 or Decimal(ln.discount) * 100 / lg > limit):
            raise Forbidden(msg)


def check_credit(session: Session, customer: Customer | None, credit_amount: int, override: Override | None) -> int | None:
    """Veresiye kontrolü; limit aşımında yönetici onayı ister. Onaylayan yöneticinin id'sini döner."""
    if credit_amount <= 0:
        return None
    if customer is None:
        raise ValidationFailed("Veresiye satış için müşteri seçilmelidir.", {"customer_id": "Müşteri seçin."})
    current = customer_service.balance(session, customer.id)  # type: ignore[arg-type]
    if current + credit_amount <= customer.credit_limit_kurus:
        return None
    approver = auth_service.verify_admin_override(
        session,
        override,
        f"Kredi limiti aşılıyor: {customer.full_name} (limit {customer.credit_limit_kurus / 100:,.2f} TL, "
        f"mevcut borç {current / 100:,.2f} TL, veresiye {credit_amount / 100:,.2f} TL). Yönetici onayı gerekli.",
    )
    return approver.id


def create_sale_core(
    session: Session,
    actor: Actor,
    lines: list[Line],
    discount: int,
    payments: list[PaymentIn],
    customer_id: int | None,
    note: str = "",
    override: Override | None = None,
    service_ticket_id: int | None = None,
    at: datetime | None = None,
    enforce_discount: bool = True,
) -> Sale:
    if not lines:
        raise ValidationFailed("Sepet boş.")
    ts = at or now()
    customer = None
    if customer_id:
        customer = session.get(Customer, customer_id)
        if not customer or not customer.is_active:
            raise ValidationFailed("Müşteri bulunamadı.", {"customer_id": "Geçersiz müşteri."})

    gross_total = 0
    line_totals: list[int] = []
    for idx, ln in enumerate(lines):
        if not ln.product.is_active:
            raise ValidationFailed(f"Ürün arşivde: {ln.product.name}")
        try:
            validate_qty_for_unit(ln.qty, ln.product.unit_type)
        except ValueError as exc:
            raise ValidationFailed(str(exc), {f"items.{idx}.qty": str(exc)}) from exc
        if ln.product.track_serial and not ln.stock_already_moved:
            if ln.serial is None:
                raise ValidationFailed(f"Seri numarası seçilmeli: {ln.product.name}", {f"items.{idx}.serial_id": "Seri no seçin."})
            if ln.qty != 1:
                raise ValidationFailed("Seri takipli ürünlerde her satır 1 adet olmalıdır.")
        gross = line_amount(ln.qty, ln.unit_price)
        if ln.discount > gross:
            raise ValidationFailed(f"Satır indirimi tutarı aşıyor: {ln.product.name}")
        gross_total += gross
        line_totals.append(gross - ln.discount)
    subtotal = sum(line_totals)
    if discount > subtotal:
        raise ValidationFailed("Genel indirim ara toplamı aşıyor.", {"discount": "İndirim çok yüksek."})
    total = subtotal - discount
    if enforce_discount:
        check_discount(actor, gross_total, sum(ln.discount for ln in lines) + discount, lines)

    paid = sum(p.amount for p in payments)
    if paid != total:
        raise ValidationFailed(
            f"Ödeme toplamı ({paid / 100:,.2f} TL) satış tutarıyla ({total / 100:,.2f} TL) eşleşmiyor.",
            {"payments": "Ödeme toplamı eşleşmiyor."},
            code="PAYMENT_MISMATCH",
        )
    credit_amount = sum(p.amount for p in payments if p.method == PaymentMethod.CREDIT)
    approver_id = check_credit(session, customer, credit_amount, override)

    allocated = allocate(discount, line_totals)
    sale = Sale(
        receipt_no=next_receipt_no(session, ts.year),
        customer_id=customer_id,
        subtotal=subtotal,
        discount=discount,
        total=total,
        note=note,
        user_id=actor.id,
        service_ticket_id=service_ticket_id,
        created_at=ts,
        updated_at=ts,
    )
    session.add(sale)
    session.flush()

    vat_total = 0
    for ln, lt, alloc in zip(lines, line_totals, allocated, strict=True):
        net = lt - alloc
        vat = vat_of_gross(net, ln.product.vat_rate)
        vat_total += vat
        item = SaleItem(
            sale_id=sale.id,  # type: ignore[arg-type]
            product_id=ln.product.id,  # type: ignore[arg-type]
            product_name=ln.product.name,
            qty=ln.qty,
            unit_price=ln.unit_price,
            discount=ln.discount,
            allocated_discount=alloc,
            vat_rate=ln.product.vat_rate,
            vat_amount=vat,
            line_total=lt,
            net_total=net,
            unit_cost_snapshot=ln.cost_snapshot if ln.cost_snapshot is not None else ln.product.avg_cost_kurus,
            serial_id=ln.serial.id if ln.serial else None,
            created_at=ts,
            updated_at=ts,
        )
        session.add(item)
        session.flush()
        if not ln.stock_already_moved:
            stock_service.apply_movement(
                session,
                ln.product,
                MovementType.SALE_OUT,
                -ln.qty,
                actor.id,
                ref_type="SALE",
                ref_id=sale.id,
                note=sale.receipt_no,
                at=ts,
            )
        if ln.serial:
            months = warranty_months_for(session, ln.product)
            ln.serial.status = SerialStatus.SOLD
            ln.serial.sale_item_id = item.id
            ln.serial.warranty_until = add_months(ts.date(), months) if months else None
            session.add(ln.serial)
    sale.vat_total = vat_total

    due = ts.date() + timedelta(days=get_settings_row(session).credit_due_days)
    for p in payments:
        if p.method == PaymentMethod.CASH and p.tendered is not None and p.tendered < p.amount:
            raise ValidationFailed("Alınan nakit tutar ödemeden az olamaz.", {"tendered": "Tutar yetersiz."})
        session.add(
            Payment(
                sale_id=sale.id,
                customer_id=customer_id,
                method=p.method,
                amount=p.amount,
                tendered=p.tendered if p.method == PaymentMethod.CASH else None,
                user_id=actor.id,
                created_at=ts,
                updated_at=ts,
            )
        )
        if p.method == PaymentMethod.CREDIT:
            entry = customer_service.add_debt(
                session,
                customer_id,
                p.amount,
                f"Veresiye satış {sale.receipt_no}",
                "SALE",
                sale.id,
                due,
                actor.id,  # type: ignore[arg-type]
            )
            entry.created_at = entry.updated_at = ts
    if approver_id:
        audit.record(
            session, actor, "sale.credit_override", "sale", sale.id, None, None, {"approved_by": approver_id, "credit": credit_amount}
        )
    session.add(sale)
    session.flush()
    return sale


def create_sale(session: Session, actor: Actor, data: SaleCreate) -> dict[str, Any]:
    lines: list[Line] = []
    seen_serials: set[int] = set()
    for idx, it in enumerate(data.items):
        product = session.get(Product, it.product_id)
        if not product:
            raise ValidationFailed("Ürün bulunamadı.", {f"items.{idx}.product_id": "Geçersiz ürün."})
        price = product.sale_price_kurus if it.unit_price is None else it.unit_price
        if price != product.sale_price_kurus and product.unit_type != UnitType.SERVICE and not actor.can(P.PRODUCT_WRITE):
            raise Forbidden("Satış fiyatını değiştirme yetkiniz yok; indirim alanını kullanın.")
        serial = None
        if product.track_serial:
            if it.serial_id is None:
                raise ValidationFailed(f"Seri numarası seçilmeli: {product.name}", {f"items.{idx}.serial_id": "Seri no seçin."})
            if it.serial_id in seen_serials:
                raise ValidationFailed("Aynı seri numarası sepette iki kez var.")
            seen_serials.add(it.serial_id)
            serial = stock_service.get_available_serial(session, product, it.serial_id)
        lines.append(Line(product=product, qty=to_qty(it.qty), unit_price=price, discount=it.discount, serial=serial))
    sale = create_sale_core(session, actor, lines, data.discount, data.payments, data.customer_id, data.note, data.override)
    session.commit()
    return get_sale(session, actor, sale.id)  # type: ignore[arg-type]


# ---------------------------------------------------------------- sorgular


def sale_out_items(session: Session, sale_id: int, can_cost: bool) -> list[dict[str, Any]]:
    rows = session.exec(
        select(SaleItem, Product.sku, Product.unit_type, ProductSerial)
        .join(Product, col(Product.id) == SaleItem.product_id)
        .join(ProductSerial, col(ProductSerial.id) == SaleItem.serial_id, isouter=True)
        .where(SaleItem.sale_id == sale_id)
        .order_by(col(SaleItem.id))
    ).all()
    out = []
    for it, sku, unit_type, serial in rows:
        row = {
            "id": it.id,
            "product_id": it.product_id,
            "product_name": it.product_name,
            "sku": sku,
            "unit_type": unit_type,
            "qty": it.qty,
            "unit_price": it.unit_price,
            "discount": it.discount,
            "allocated_discount": it.allocated_discount,
            "vat_rate": it.vat_rate,
            "vat_amount": it.vat_amount,
            "line_total": it.line_total,
            "net_total": it.net_total,
            "returned_qty": it.returned_qty,
            "serial_id": it.serial_id,
            "serial_no": serial.serial_no if serial else None,
            "warranty_until": serial.warranty_until if serial else None,
        }
        if can_cost:
            cost = round_half_up(it.qty * it.unit_cost_snapshot)
            row.update(unit_cost=it.unit_cost_snapshot, profit=it.net_total - it.vat_amount - cost)
        out.append(row)
    return out


def can_cancel(sale: Sale, actor: Actor, has_returns: bool) -> bool:
    return (
        actor.can(P.SALE_CANCEL)
        and sale.status == SaleStatus.COMPLETED
        and sale.created_at.date() == date.today()
        and not has_returns
        and sale.service_ticket_id is None
    )


def get_sale(session: Session, actor: Actor, sale_id: int) -> dict[str, Any]:
    sale = session.get(Sale, sale_id)
    if not sale:
        raise NotFound("Satış")
    can_cost = actor.can(P.PRODUCT_COST_VIEW)
    customer = session.get(Customer, sale.customer_id) if sale.customer_id else None
    user = session.get(User, sale.user_id) if sale.user_id else None
    payments = session.exec(select(Payment).where(Payment.sale_id == sale_id).order_by(col(Payment.id))).all()
    returns = session.exec(select(Return).where(Return.sale_id == sale_id).order_by(col(Return.id))).all()
    vat_breakdown: dict[int, dict[str, int]] = {}
    items = sale_out_items(session, sale_id, can_cost)
    for it in items:
        b = vat_breakdown.setdefault(it["vat_rate"], {"rate": it["vat_rate"], "base": 0, "vat": 0, "total": 0})
        b["vat"] += it["vat_amount"]
        b["total"] += it["net_total"]
        b["base"] += it["net_total"] - it["vat_amount"]
    out: dict[str, Any] = {
        "id": sale.id,
        "receipt_no": sale.receipt_no,
        "created_at": sale.created_at,
        "status": sale.status,
        "subtotal": sale.subtotal,
        "discount": sale.discount,
        "vat_total": sale.vat_total,
        "total": sale.total,
        "note": sale.note,
        "cancelled_reason": sale.cancelled_reason,
        "cancelled_at": sale.cancelled_at,
        "service_ticket_id": sale.service_ticket_id,
        "customer": {"id": customer.id, "full_name": customer.full_name, "phone": customer.phone} if customer else None,
        "user_name": user.full_name if user else None,
        "items": items,
        "vat_breakdown": sorted(vat_breakdown.values(), key=lambda b: b["rate"]),
        "payments": [
            {
                "id": p.id,
                "method": p.method,
                "amount": p.amount,
                "tendered": p.tendered,
                "change": (p.tendered - p.amount) if p.tendered else None,
            }
            for p in payments
        ],
        "returns": [{"id": r.id, "at": r.created_at, "total": r.total, "method": r.method, "reason": r.reason} for r in returns],
        "can_cancel": can_cancel(sale, actor, bool(returns)),
    }
    if can_cost:
        out["profit"] = sum(i["profit"] for i in items)
    return out


def list_sales(
    session: Session,
    date_from: date | None = None,
    date_to: date | None = None,
    status: SaleStatus | None = None,
    user_id: int | None = None,
    customer_id: int | None = None,
    q: str | None = None,
    limit: int = 3000,
) -> list[dict[str, Any]]:
    stmt = (
        select(Sale, Customer.full_name, User.full_name)
        .join(Customer, col(Customer.id) == Sale.customer_id, isouter=True)
        .join(User, col(User.id) == Sale.user_id, isouter=True)
    )
    if date_from:
        stmt = stmt.where(Sale.created_at >= day_start(date_from))
    if date_to:
        stmt = stmt.where(Sale.created_at <= day_end(date_to))
    if status:
        stmt = stmt.where(Sale.status == status)
    if user_id:
        stmt = stmt.where(Sale.user_id == user_id)
    if customer_id:
        stmt = stmt.where(Sale.customer_id == customer_id)
    if q:
        stmt = stmt.where(or_(col(Sale.receipt_no).ilike(f"%{q}%"), col(Customer.full_name).ilike(f"%{q}%")))
    sales = session.exec(stmt.order_by(col(Sale.created_at).desc()).limit(limit)).all()
    ids = [s.id for s, _, _ in sales]
    methods: dict[int, set[str]] = {}
    counts: dict[int, int] = {}
    returned: dict[int, int] = {}
    if ids:
        for sid, method in session.exec(
            select(Payment.sale_id, Payment.method).where(col(Payment.sale_id).in_(ids), Payment.amount > 0)
        ).all():
            methods.setdefault(sid, set()).add(method)  # type: ignore[arg-type]
        counts = dict(
            session.exec(
                select(SaleItem.sale_id, func.count(col(SaleItem.id))).where(col(SaleItem.sale_id).in_(ids)).group_by(SaleItem.sale_id)
            ).all()
        )
        returned = dict(
            session.exec(select(Return.sale_id, func.sum(Return.total)).where(col(Return.sale_id).in_(ids)).group_by(Return.sale_id)).all()
        )
    return [
        {
            "id": s.id,
            "receipt_no": s.receipt_no,
            "created_at": s.created_at,
            "customer_id": s.customer_id,
            "customer_name": cname,
            "user_name": uname,
            "item_count": counts.get(s.id, 0),
            "total": s.total,
            "discount": s.discount,
            "status": s.status,
            "methods": sorted(methods.get(s.id, set())),  # type: ignore[arg-type]
            "returned_total": int(returned.get(s.id) or 0),
            "service_ticket_id": s.service_ticket_id,
        }
        for s, cname, uname in sales
    ]


# ---------------------------------------------------------------- iptal ve iade


def cancel_sale(session: Session, actor: Actor, sale_id: int, reason: str, at: datetime | None = None) -> dict[str, Any]:
    ts = at or now()
    actor.require(P.SALE_CANCEL, "Satış iptali yalnızca yöneticiye açıktır.")
    sale = session.get(Sale, sale_id)
    if not sale:
        raise NotFound("Satış")
    has_returns = session.exec(select(Return.id).where(Return.sale_id == sale_id)).first() is not None
    if sale.status != SaleStatus.COMPLETED:
        raise ValidationFailed("Satış zaten iptal edilmiş.")
    if sale.created_at.date() != ts.date():
        raise ValidationFailed("Yalnızca bugünkü satışlar iptal edilebilir. Önceki günler için iade kullanın.", code="CANCEL_NOT_TODAY")
    if has_returns:
        raise ValidationFailed("İade işlemi yapılmış satış iptal edilemez.")
    if sale.service_ticket_id:
        raise ValidationFailed("Servis teslim satışı iptal edilemez; iade kullanın.")
    items = session.exec(select(SaleItem).where(SaleItem.sale_id == sale_id)).all()
    for it in items:
        product = session.get(Product, it.product_id)
        assert product is not None
        stock_service.apply_movement(
            session,
            product,
            MovementType.SALE_RETURN,
            it.qty,
            actor.id,
            unit_cost_kurus=it.unit_cost_snapshot,
            ref_type="SALE",
            ref_id=sale.id,
            note=f"İptal {sale.receipt_no}",
            allow_negative=True,
            at=ts,
        )
        if it.serial_id:
            serial = session.get(ProductSerial, it.serial_id)
            if serial:
                serial.status, serial.sale_item_id, serial.warranty_until = SerialStatus.IN_STOCK, None, None
                session.add(serial)
    credit = sum(
        p.amount for p in session.exec(select(Payment).where(Payment.sale_id == sale_id, Payment.method == PaymentMethod.CREDIT)).all()
    )
    if credit and sale.customer_id:
        entry = customer_service.add_adjust(
            session, sale.customer_id, -credit, f"Satış iptali {sale.receipt_no}", "SALE_CANCEL", sale.id, actor.id
        )
        entry.created_at = entry.updated_at = ts
    before = {"status": sale.status}
    sale.status = SaleStatus.CANCELLED
    sale.cancelled_reason = reason
    sale.cancelled_at = ts
    sale.cancelled_by = actor.id
    session.add(sale)
    audit.record(
        session,
        actor,
        "sale.cancel",
        "sale",
        sale.id,
        before,
        {"status": sale.status},
        {"receipt_no": sale.receipt_no, "total": sale.total, "reason": reason},
        at=ts,
    )
    session.commit()
    return get_sale(session, actor, sale_id)


def create_return(session: Session, actor: Actor, data: ReturnCreate, at: datetime | None = None) -> dict[str, Any]:
    ts = at or now()
    sale = session.get(Sale, data.sale_id)
    if not sale:
        raise NotFound("Satış")
    if sale.status != SaleStatus.COMPLETED:
        raise ValidationFailed("İptal edilmiş satışta iade yapılamaz.")
    if data.method == PaymentMethod.CREDIT and not sale.customer_id:
        raise ValidationFailed("Cariye iade için satışta müşteri olmalıdır.", {"method": "Müşterisiz satış."})
    ret = Return(
        sale_id=sale.id,  # type: ignore[arg-type]
        customer_id=sale.customer_id,
        method=data.method,
        reason=data.reason,
        user_id=actor.id,
        created_at=ts,
        updated_at=ts,
    )
    session.add(ret)
    session.flush()
    total = 0
    seen: set[int] = set()
    for idx, ri in enumerate(data.items):
        if ri.sale_item_id in seen:
            raise ValidationFailed("Aynı kalem iki kez seçilmiş.")
        seen.add(ri.sale_item_id)
        item = session.get(SaleItem, ri.sale_item_id)
        if not item or item.sale_id != sale.id:
            raise ValidationFailed("Kalem bu satışa ait değil.", {f"items.{idx}.sale_item_id": "Geçersiz kalem."})
        q = to_qty(ri.qty)
        product = session.get(Product, item.product_id)
        assert product is not None
        try:
            validate_qty_for_unit(q, product.unit_type)
        except ValueError as exc:
            raise ValidationFailed(str(exc)) from exc
        remaining = item.qty - item.returned_qty
        if q > remaining:
            raise ValidationFailed(f"İade miktarı satılan miktarı aşıyor: {item.product_name}", {f"items.{idx}.qty": "Miktar fazla."})
        # Son iadede kalan tutarın tamamı, diğerlerinde orantılı tutar (kuruş kaybı olmaz).
        already = sum(r.amount for r in session.exec(select(ReturnItem).where(ReturnItem.sale_item_id == item.id)).all())
        amount = item.net_total - already if q == remaining else round_half_up(Decimal(item.net_total) * q / item.qty)
        item.returned_qty = item.returned_qty + q
        session.add(item)
        session.add(ReturnItem(return_id=ret.id, sale_item_id=item.id, product_id=product.id, qty=q, amount=amount, restock=ri.restock))  # type: ignore[arg-type]
        total += amount
        stock_service.apply_movement(
            session,
            product,
            MovementType.SALE_RETURN,
            q,
            actor.id,
            unit_cost_kurus=item.unit_cost_snapshot,
            ref_type="RETURN",
            ref_id=ret.id,
            note=f"İade {sale.receipt_no}",
            allow_negative=True,
            at=ts,
        )
        if not ri.restock:
            stock_service.apply_movement(
                session,
                product,
                MovementType.WASTE,
                -q,
                actor.id,
                ref_type="RETURN",
                ref_id=ret.id,
                note=f"İade — kusurlu ürün {sale.receipt_no}",
                allow_negative=True,
                at=ts,
            )
        if item.serial_id:
            serial = session.get(ProductSerial, item.serial_id)
            if serial:
                serial.status = SerialStatus.RETURNED if ri.restock else SerialStatus.DEFECTIVE
                serial.sale_item_id = None
                serial.warranty_until = None
                session.add(serial)
    ret.total = total
    session.add(ret)
    if data.method == PaymentMethod.CREDIT:
        entry = customer_service.add_adjust(session, sale.customer_id, -total, f"İade {sale.receipt_no}", "RETURN", ret.id, actor.id)  # type: ignore[arg-type]
        entry.created_at = entry.updated_at = ts
    else:
        session.add(
            Payment(
                sale_id=sale.id,
                customer_id=sale.customer_id,
                return_id=ret.id,
                method=data.method,
                amount=-total,
                note=f"İade {sale.receipt_no}",
                user_id=actor.id,
                created_at=ts,
                updated_at=ts,
            )
        )
    audit.record(
        session,
        actor,
        "sale.return",
        "sale",
        sale.id,
        None,
        None,
        {"return_id": ret.id, "total": total, "method": data.method, "reason": data.reason},
        at=ts,
    )
    session.commit()
    return {"id": ret.id, "total": total, "sale": get_sale(session, actor, sale.id)}  # type: ignore[arg-type]
