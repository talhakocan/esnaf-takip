"""Giriş, yönetici onayı ve kullanıcı yönetimi."""

from typing import Any

from sqlmodel import Session, func, select

from app.core import audit
from app.core.deps import Actor
from app.core.errors import Conflict, Forbidden, NotFound, Unauthorized, ValidationFailed
from app.core.security import hash_password, validate_password_strength, verify_password
from app.models import Role, User
from app.schemas.sales import Override

# Kullanıcı bulunamadığında da hash doğrulaması yapılır (zamanlama saldırısına karşı).
_DUMMY_HASH = hash_password("tezgah-dummy-password-1")


def authenticate(session: Session, username: str, password: str) -> User:
    user = session.exec(select(User).where(func.lower(User.username) == username.strip().lower())).first()
    if not user:
        verify_password(password, _DUMMY_HASH)
        raise Unauthorized("Kullanıcı adı veya şifre hatalı.")
    if not verify_password(password, user.password_hash) or not user.is_active:
        raise Unauthorized("Kullanıcı adı veya şifre hatalı.")
    return user


def verify_admin_override(session: Session, override: Override | None, reason: str) -> User:
    if override is None:
        raise Conflict(reason, code="ADMIN_APPROVAL_REQUIRED")
    try:
        user = authenticate(session, override.username, override.password)
    except Unauthorized as exc:
        raise Forbidden("Yönetici onayı geçersiz: kullanıcı adı veya şifre hatalı.") from exc
    if user.role != Role.ADMIN:
        raise Forbidden("Onay yalnızca yönetici hesabıyla verilebilir.")
    return user


def user_out(u: User) -> dict[str, Any]:
    return {
        "id": u.id,
        "username": u.username,
        "full_name": u.full_name,
        "role": u.role,
        "max_discount_pct": u.max_discount_pct,
        "is_active": u.is_active,
        "created_at": u.created_at,
    }


def list_users(session: Session) -> list[dict[str, Any]]:
    return [user_out(u) for u in session.exec(select(User).order_by(User.full_name)).all()]


USER_AUDIT = ["username", "full_name", "role", "max_discount_pct", "is_active"]


def create_user(session: Session, actor: Actor, data: dict[str, Any]) -> dict[str, Any]:
    username = data["username"].strip().lower()
    if session.exec(select(User).where(func.lower(User.username) == username)).first():
        raise Conflict("Bu kullanıcı adı zaten kullanılıyor.")
    problem = validate_password_strength(data["password"])
    if problem:
        raise ValidationFailed(problem, {"password": problem})
    user = User(
        username=username,
        full_name=data["full_name"],
        role=data.get("role", Role.STAFF),
        max_discount_pct=data.get("max_discount_pct", 0),
        password_hash=hash_password(data["password"]),
    )
    session.add(user)
    session.flush()
    audit.record(session, actor, "user.create", "user", user.id, None, audit.snapshot(user, USER_AUDIT))
    session.commit()
    session.refresh(user)
    return user_out(user)


def update_user(session: Session, actor: Actor, user_id: int, data: dict[str, Any]) -> dict[str, Any]:
    user = session.get(User, user_id)
    if not user:
        raise NotFound("Kullanıcı")
    before = audit.snapshot(user, USER_AUDIT)
    if user.id == actor.id and (data.get("is_active") is False or data.get("role") == Role.STAFF):
        raise ValidationFailed("Kendi hesabınızı pasifleştiremez veya yetkisini düşüremezsiniz.")
    for key in ("full_name", "role", "max_discount_pct", "is_active"):
        if data.get(key) is not None:
            setattr(user, key, data[key])
    extra = None
    if data.get("password"):
        problem = validate_password_strength(data["password"])
        if problem:
            raise ValidationFailed(problem, {"password": problem})
        user.password_hash = hash_password(data["password"])
        extra = {"password_changed": True}
    session.add(user)
    audit.record(session, actor, "user.update", "user", user.id, before, audit.snapshot(user, USER_AUDIT), extra)
    session.commit()
    session.refresh(user)
    return user_out(user)


def change_own_password(session: Session, actor: Actor, current: str, new: str) -> None:
    if not verify_password(current, actor.user.password_hash):
        raise ValidationFailed("Mevcut şifre hatalı.", {"current_password": "Mevcut şifre hatalı."})
    problem = validate_password_strength(new)
    if problem:
        raise ValidationFailed(problem, {"new_password": problem})
    actor.user.password_hash = hash_password(new)
    session.add(actor.user)
    audit.record(session, actor, "user.password", "user", actor.id, None, None, {"password_changed": True})
    session.commit()
