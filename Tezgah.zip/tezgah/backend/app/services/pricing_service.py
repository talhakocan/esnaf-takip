"""Fiyatlandırma: kura bağlı fiyat hesabı, yuvarlama ve fiyat geçmişi."""

from decimal import Decimal
from typing import Any

from sqlmodel import Session, select

from app.core.money import apply_rounding, round_half_up
from app.models import Currency, PriceHistory, PriceReason, PricingMode, Product, RoundingRule
from app.services import fx_service
from app.services.settings_service import get_settings_row


def purchase_cost_kurus(purchase_price: Decimal, rate: Decimal) -> int:
    """Dövizli alış fiyatını TL kuruşa çevirir."""
    return round_half_up(purchase_price * rate * 100)


def compute_fx_price(purchase_price: Decimal, rate: Decimal, markup_pct: Decimal, rule: RoundingRule | str) -> tuple[int, int]:
    """(yuvarlanmamış, yuvarlanmış) satış fiyatı, kuruş."""
    raw = round_half_up(purchase_price * rate * (Decimal(1) + markup_pct / 100) * 100)
    return raw, apply_rounding(raw, rule)


def price_breakdown(session: Session, product: Product) -> dict[str, Any] | None:
    """Kura bağlı fiyatın hesap dökümü (yalnızca yetkili kullanıcılara gösterilir)."""
    if product.pricing_mode != PricingMode.FX_LINKED:
        return None
    rate = fx_service.rate_for(session, product.purchase_currency, strict=False)
    if rate is None:
        return None
    rule = get_settings_row(session).rounding_rule
    raw, rounded = compute_fx_price(product.purchase_price, rate, product.markup_pct, rule)
    return {
        "purchase_price": product.purchase_price,
        "currency": product.purchase_currency,
        "rate": rate,
        "markup_pct": product.markup_pct,
        "raw_kurus": raw,
        "rounded_kurus": rounded,
        "rounding_rule": rule,
    }


def set_price(session: Session, product: Product, new_price: int, user_id: int | None, reason: PriceReason) -> bool:
    """Fiyatı değiştirir, değiştiyse geçmişe yazar."""
    if new_price == product.sale_price_kurus:
        return False
    if product.id is not None:
        session.add(
            PriceHistory(
                product_id=product.id,
                old_price=product.sale_price_kurus,
                new_price=new_price,
                reason=reason,
                user_id=user_id,
            )
        )
    product.sale_price_kurus = new_price
    session.add(product)
    return True


def reprice(session: Session, product: Product, user_id: int | None, reason: PriceReason) -> bool:
    """Kura bağlı ürünün fiyatını güncel kurla yeniden hesaplar."""
    if product.pricing_mode != PricingMode.FX_LINKED:
        return False
    rate = fx_service.rate_for(session, product.purchase_currency)
    rule = get_settings_row(session).rounding_rule
    _, rounded = compute_fx_price(product.purchase_price, rate, product.markup_pct, rule)
    return set_price(session, product, rounded, user_id, reason)


def reprice_all_fx_linked(session: Session, user_id: int | None) -> int:
    products = session.exec(
        select(Product).where(
            Product.pricing_mode == PricingMode.FX_LINKED,
            Product.is_active == True,  # noqa: E712
            Product.purchase_currency != Currency.TRY,
        )
    ).all()
    return sum(1 for p in products if reprice(session, p, user_id, PriceReason.FX_UPDATE))
