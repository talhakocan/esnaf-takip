"""Stok defteri. Stok miktarı YALNIZCA bu modül üzerinden değişir.

Her değişiklik: hareket kaydı + products.stock_qty + balance_after (aynı transaction içinde).
"""

from datetime import date, datetime
from decimal import Decimal
from typing import Any

from sqlmodel import Session, col, func, select

from app.core import audit
from app.core.deps import Actor
from app.core.errors import NotFound, ValidationFailed
from app.core.money import qty as to_qty
from app.core.money import round_half_up, validate_qty_for_unit
from app.models import (
    MovementType,
    Product,
    ProductSerial,
    SerialStatus,
    StockMovement,
    UnitType,
    User,
    now,
)
from app.services.settings_service import get_settings_row

INBOUND = {MovementType.PURCHASE_IN, MovementType.SALE_RETURN, MovementType.SERVICE_RETURN, MovementType.ADJUST_IN}
OUTBOUND = {MovementType.SALE_OUT, MovementType.SERVICE_OUT, MovementType.ADJUST_OUT, MovementType.WASTE}
AVG_COST_AFFECTING = {MovementType.PURCHASE_IN, MovementType.SALE_RETURN}
AVAILABLE_SERIAL = (SerialStatus.IN_STOCK, SerialStatus.RETURNED)

UNIT_SHORT = {UnitType.PIECE: "ad", UnitType.METER: "m", UnitType.SERVICE: ""}


def fmt_qty(value: Decimal, unit: UnitType) -> str:
    text = f"{value.normalize():f}".replace(".", ",") if value != value.to_integral_value() else str(int(value))
    return f"{text} {UNIT_SHORT[unit]}".strip()


def apply_movement(
    session: Session,
    product: Product,
    mtype: MovementType,
    quantity: Decimal,
    user_id: int | None,
    *,
    unit_cost_kurus: int | None = None,
    ref_type: str | None = None,
    ref_id: int | None = None,
    note: str = "",
    allow_negative: bool | None = None,
    at: datetime | None = None,
) -> StockMovement | None:
    """Stok hareketi uygular. Hizmet ürünlerinde hareket üretmez (None döner)."""
    if product.unit_type == UnitType.SERVICE:
        return None
    quantity = to_qty(quantity)
    if quantity == 0:
        raise ValidationFailed("Miktar sıfır olamaz.", {"qty": "Miktar sıfır olamaz."})
    try:
        validate_qty_for_unit(abs(quantity), product.unit_type)
    except ValueError as exc:
        raise ValidationFailed(str(exc), {"qty": str(exc)}) from exc
    if mtype in INBOUND and quantity < 0:
        raise ValidationFailed("Giriş hareketinde miktar pozitif olmalıdır.")
    if mtype in OUTBOUND and quantity > 0:
        raise ValidationFailed("Çıkış hareketinde miktar negatif olmalıdır.")

    if allow_negative is None:
        allow_negative = get_settings_row(session).allow_negative_stock
    new_balance = product.stock_qty + quantity
    if new_balance < 0 and not allow_negative and quantity < 0:
        raise ValidationFailed(
            f"Yetersiz stok: {product.name} (mevcut {fmt_qty(product.stock_qty, product.unit_type)}, "
            f"istenen {fmt_qty(-quantity, product.unit_type)}).",
            code="INSUFFICIENT_STOCK",
        )

    cost = product.avg_cost_kurus if unit_cost_kurus is None else unit_cost_kurus
    if quantity > 0 and mtype in AVG_COST_AFFECTING and unit_cost_kurus is not None:
        old_qty = max(product.stock_qty, Decimal(0))
        total_qty = old_qty + quantity
        if total_qty > 0:
            product.avg_cost_kurus = round_half_up((old_qty * product.avg_cost_kurus + quantity * unit_cost_kurus) / total_qty)

    ts = at or now()
    product.stock_qty = new_balance
    product.last_movement_at = ts
    movement = StockMovement(
        product_id=product.id,  # type: ignore[arg-type]
        type=mtype,
        qty=quantity,
        unit_cost_kurus=cost,
        ref_type=ref_type,
        ref_id=ref_id,
        note=note,
        user_id=user_id,
        balance_after=new_balance,
        created_at=ts,
        updated_at=ts,
    )
    session.add(product)
    session.add(movement)
    session.flush()
    return movement


# ---------------------------------------------------------------- seri numaraları


def normalize_serials(serials: list[str]) -> list[str]:
    cleaned = [s.strip().upper() for s in serials if s and s.strip()]
    if len(cleaned) != len(set(cleaned)):
        raise ValidationFailed("Aynı seri numarası birden fazla kez girilmiş.", {"serials": "Tekrarlanan seri no."})
    return cleaned


def register_serials(session: Session, product: Product, serials: list[str], movement: StockMovement | None) -> list[ProductSerial]:
    serials = normalize_serials(serials)
    existing = session.exec(
        select(ProductSerial).where(ProductSerial.product_id == product.id, col(ProductSerial.serial_no).in_(serials))
    ).all()
    if existing:
        taken = ", ".join(s.serial_no for s in existing)
        raise ValidationFailed(f"Bu seri numaraları zaten kayıtlı: {taken}", {"serials": "Kayıtlı seri no."})
    rows = []
    for sn in serials:
        row = ProductSerial(
            product_id=product.id,  # type: ignore[arg-type]
            serial_no=sn,
            status=SerialStatus.IN_STOCK,
            purchase_movement_id=movement.id if movement else None,
        )
        session.add(row)
        rows.append(row)
    session.flush()
    return rows


def get_available_serial(session: Session, product: Product, serial_id: int) -> ProductSerial:
    serial = session.get(ProductSerial, serial_id)
    if not serial or serial.product_id != product.id:
        raise ValidationFailed(f"Seri numarası bu ürüne ait değil: {product.name}", {"serial_id": "Geçersiz seri no."})
    if serial.status not in AVAILABLE_SERIAL:
        raise ValidationFailed(f"Seri numarası stokta değil: {serial.serial_no}", {"serial_id": "Seri no stokta değil."})
    return serial


def available_serials(session: Session, product_id: int) -> list[ProductSerial]:
    return list(
        session.exec(
            select(ProductSerial)
            .where(ProductSerial.product_id == product_id, col(ProductSerial.status).in_(AVAILABLE_SERIAL))
            .order_by(ProductSerial.serial_no)
        ).all()
    )


# ---------------------------------------------------------------- elle düzeltme / fire


def manual_adjust(
    session: Session,
    actor: Actor,
    product_id: int,
    quantity: Decimal,
    mtype: MovementType,
    note: str,
    unit_cost_kurus: int | None = None,
    serials: list[str] | None = None,
    serial_ids: list[int] | None = None,
) -> StockMovement | None:
    """Stok girişi (ADJUST_IN/PURCHASE_IN), çıkışı (ADJUST_OUT) veya fire (WASTE)."""
    product = session.get(Product, product_id)
    if not product or not product.is_active:
        raise NotFound("Ürün")
    if product.unit_type == UnitType.SERVICE:
        raise ValidationFailed("Hizmet ürünlerinin stoğu tutulmaz.")
    if mtype not in (MovementType.ADJUST_IN, MovementType.ADJUST_OUT, MovementType.WASTE, MovementType.PURCHASE_IN):
        raise ValidationFailed("Geçersiz hareket tipi.")
    quantity = abs(to_qty(quantity))
    if quantity == 0:
        raise ValidationFailed("Miktar sıfır olamaz.", {"qty": "Miktar sıfır olamaz."})
    if not note.strip() and mtype != MovementType.PURCHASE_IN:
        raise ValidationFailed("Açıklama zorunludur.", {"note": "Neden girişi yapın."})
    if unit_cost_kurus is not None and not actor.is_admin:
        unit_cost_kurus = None  # personel maliyet giremez; ortalama maliyet kullanılır

    signed = quantity if mtype in INBOUND else -quantity
    if product.track_serial:
        if mtype in INBOUND:
            if len(normalize_serials(serials or [])) != int(quantity):
                raise ValidationFailed(
                    f"Seri takipli üründe {int(quantity)} adet seri numarası girilmelidir.",
                    {"serials": "Seri numarası sayısı miktarla eşleşmiyor."},
                )
        elif len(set(serial_ids or [])) != int(quantity):
            raise ValidationFailed(
                f"Seri takipli üründe çıkış için {int(quantity)} seri numarası seçilmelidir.",
                {"serial_ids": "Seri numarası seçin."},
            )

    before = {"stock_qty": str(product.stock_qty)}
    movement = apply_movement(
        session, product, mtype, signed, actor.id, unit_cost_kurus=unit_cost_kurus, ref_type="MANUAL", note=note.strip()
    )
    if product.track_serial and movement:
        if mtype in INBOUND:
            register_serials(session, product, serials or [], movement)
        else:
            for sid in set(serial_ids or []):
                serial = get_available_serial(session, product, sid)
                serial.status = SerialStatus.DEFECTIVE
                session.add(serial)
    audit.record(
        session,
        actor,
        f"stock.{mtype.lower()}",
        "product",
        product.id,
        before,
        {"stock_qty": str(product.stock_qty)},
        {"qty": str(signed), "note": note},
    )
    session.commit()
    if movement:
        session.refresh(movement)
    return movement


# ---------------------------------------------------------------- sorgular

MOVEMENT_LABELS = {
    MovementType.PURCHASE_IN: "GİRİŞ",
    MovementType.SALE_OUT: "SATIŞ",
    MovementType.SALE_RETURN: "İADE",
    MovementType.SERVICE_OUT: "SERVİS",
    MovementType.SERVICE_RETURN: "SERVİS İADE",
    MovementType.ADJUST_IN: "GİRİŞ",
    MovementType.ADJUST_OUT: "ÇIKIŞ",
    MovementType.COUNT_ADJUST: "SAYIM",
    MovementType.WASTE: "FİRE",
}


def list_movements(
    session: Session,
    product_id: int | None = None,
    types: list[MovementType] | None = None,
    user_id: int | None = None,
    date_from: date | None = None,
    date_to: date | None = None,
    ref_type: str | None = None,
    ref_id: int | None = None,
    limit: int = 3000,
    include_cost: bool = False,
) -> list[dict[str, Any]]:
    stmt = (
        select(StockMovement, Product.name, Product.sku, Product.unit_type, User.full_name)
        .join(Product, col(Product.id) == StockMovement.product_id)
        .join(User, col(User.id) == StockMovement.user_id, isouter=True)
    )
    if product_id:
        stmt = stmt.where(StockMovement.product_id == product_id)
    if types:
        stmt = stmt.where(col(StockMovement.type).in_(types))
    if user_id:
        stmt = stmt.where(StockMovement.user_id == user_id)
    if date_from:
        stmt = stmt.where(StockMovement.created_at >= datetime.combine(date_from, datetime.min.time()))
    if date_to:
        stmt = stmt.where(StockMovement.created_at <= datetime.combine(date_to, datetime.max.time()))
    if ref_type:
        stmt = stmt.where(StockMovement.ref_type == ref_type)
    if ref_id:
        stmt = stmt.where(StockMovement.ref_id == ref_id)
    stmt = stmt.order_by(col(StockMovement.created_at).desc(), col(StockMovement.id).desc()).limit(limit)
    results = session.exec(stmt).all()
    refs = _resolve_refs(session, [(m.ref_type, m.ref_id) for m, *_ in results])
    out = []
    for m, name, sku, unit_type, user_name in results:
        ref_label, ref_link = refs.get((m.ref_type, m.ref_id), (None, None))
        row = {
            "ref_label": ref_label,
            "ref_link": ref_link,
            "id": m.id,
            "at": m.created_at,
            "type": m.type,
            "label": MOVEMENT_LABELS[m.type],
            "product_id": m.product_id,
            "product_name": name,
            "sku": sku,
            "unit_type": unit_type,
            "qty": m.qty,
            "balance_after": m.balance_after,
            "ref_type": m.ref_type,
            "ref_id": m.ref_id,
            "note": m.note,
            "user_name": user_name,
        }
        if include_cost:
            row["unit_cost_kurus"] = m.unit_cost_kurus
        out.append(row)
    return out


def _resolve_refs(session: Session, pairs: list[tuple[str | None, int | None]]) -> dict[tuple[str, int], tuple[str, str]]:
    """Hareketin kaynak belgesini (fiş no, servis kodu, sipariş no, sayım) etiket + arayüz bağlantısı olarak çözer."""
    from app.models import PurchaseOrder, Return, Sale, ServiceTicket, StockCount

    ids: dict[str, set[int]] = {}
    for rt, rid in pairs:
        if rt and rid:
            ids.setdefault(rt, set()).add(rid)
    out: dict[tuple[str, int], tuple[str, str]] = {}
    if ids.get("SALE"):
        for sid, no in session.exec(select(Sale.id, Sale.receipt_no).where(col(Sale.id).in_(ids["SALE"]))).all():
            out[("SALE", sid)] = (no, f"/satislar/{sid}")  # type: ignore[index]
    if ids.get("RETURN"):
        rows = session.exec(
            select(Return.id, Sale.id, Sale.receipt_no).join(Sale, col(Sale.id) == Return.sale_id).where(col(Return.id).in_(ids["RETURN"]))
        ).all()
        for rid, sid, no in rows:
            out[("RETURN", rid)] = (f"İade · {no}", f"/satislar/{sid}")  # type: ignore[index]
    if ids.get("SERVICE"):
        for tid, code in session.exec(select(ServiceTicket.id, ServiceTicket.code).where(col(ServiceTicket.id).in_(ids["SERVICE"]))).all():
            out[("SERVICE", tid)] = (code, f"/servis/{tid}")  # type: ignore[index]
    if ids.get("PURCHASE_ORDER"):
        rows = session.exec(select(PurchaseOrder.id, PurchaseOrder.order_no).where(col(PurchaseOrder.id).in_(ids["PURCHASE_ORDER"]))).all()
        for oid, no in rows:
            out[("PURCHASE_ORDER", oid)] = (no, f"/siparisler/{oid}")  # type: ignore[index]
    if ids.get("COUNT"):
        for cid, name in session.exec(select(StockCount.id, StockCount.name).where(col(StockCount.id).in_(ids["COUNT"]))).all():
            out[("COUNT", cid)] = (name, f"/sayim/{cid}")  # type: ignore[index]
    return out


def ledger_mismatches(session: Session) -> list[tuple[int, Decimal, Decimal]]:
    """Defter toplamı ile stok önbelleği tutmayan ürünler (tutarlılık kontrolü)."""
    sums = dict(session.exec(select(StockMovement.product_id, func.sum(StockMovement.qty)).group_by(StockMovement.product_id)).all())
    bad = []
    for p in session.exec(select(Product).where(Product.unit_type != UnitType.SERVICE)).all():
        total = sums.get(p.id) or Decimal(0)
        if Decimal(total) != p.stock_qty:
            bad.append((p.id, Decimal(total), p.stock_qty))  # type: ignore[arg-type]
    return bad
