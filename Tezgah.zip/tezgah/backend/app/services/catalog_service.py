"""Kategori, marka ve raf konumları."""

from typing import Any

from sqlmodel import Session, col, func, select

from app.core import audit
from app.core.deps import Actor
from app.core.errors import Conflict, NotFound, ValidationFailed
from app.models import Brand, Category, Location, Product
from app.schemas.catalog import BrandIn, CategoryIn, LocationIn


def category_paths(session: Session) -> dict[int, str]:
    cats = {c.id: c for c in session.exec(select(Category)).all()}
    cache: dict[int, str] = {}

    def path(cid: int, depth: int = 0) -> str:
        if cid in cache:
            return cache[cid]
        c = cats[cid]
        p = c.name if not c.parent_id or depth > 8 else f"{path(c.parent_id, depth + 1)} › {c.name}"
        cache[cid] = p
        return p

    for cid in cats:
        path(cid)  # type: ignore[arg-type]
    return cache


def descendant_ids(session: Session, category_id: int) -> list[int]:
    cats = session.exec(select(Category.id, Category.parent_id)).all()
    children: dict[int | None, list[int]] = {}
    for cid, pid in cats:
        children.setdefault(pid, []).append(cid)  # type: ignore[arg-type]
    out, stack = [], [category_id]
    while stack:
        cur = stack.pop()
        out.append(cur)
        stack.extend(children.get(cur, []))
    return out


def list_categories(session: Session) -> list[dict[str, Any]]:
    paths = category_paths(session)
    counts = dict(
        session.exec(
            select(Product.category_id, func.count(col(Product.id)))
            .where(Product.is_active == True)  # noqa: E712
            .group_by(Product.category_id)
        ).all()
    )
    rows = session.exec(select(Category)).all()
    out = [
        {
            "id": c.id,
            "name": c.name,
            "parent_id": c.parent_id,
            "path": paths[c.id],
            "is_active": c.is_active,  # type: ignore[index]
            "product_count": counts.get(c.id, 0),
        }
        for c in rows
    ]
    return sorted(out, key=lambda r: r["path"].casefold())


def save_category(session: Session, actor: Actor, data: CategoryIn, category_id: int | None = None) -> Category:
    if category_id:
        cat = session.get(Category, category_id)
        if not cat:
            raise NotFound("Kategori")
        if data.parent_id and data.parent_id in descendant_ids(session, category_id):
            raise ValidationFailed("Kategori kendi alt kategorisine taşınamaz.", {"parent_id": "Geçersiz üst kategori."})
    else:
        cat = Category(name=data.name)
    if data.parent_id and not session.get(Category, data.parent_id):
        raise ValidationFailed("Üst kategori bulunamadı.", {"parent_id": "Geçersiz üst kategori."})
    before = audit.snapshot(cat, ["name", "parent_id", "is_active"]) if category_id else {}
    cat.name, cat.parent_id, cat.is_active = data.name, data.parent_id, data.is_active
    session.add(cat)
    session.flush()
    audit.record(
        session,
        actor,
        "category.update" if category_id else "category.create",
        "category",
        cat.id,
        before,
        audit.snapshot(cat, ["name", "parent_id", "is_active"]),
    )
    session.commit()
    session.refresh(cat)
    return cat


def list_brands(session: Session) -> list[Brand]:
    return list(session.exec(select(Brand).order_by(Brand.name)).all())


def save_brand(session: Session, actor: Actor, data: BrandIn, brand_id: int | None = None) -> Brand:
    dup = session.exec(select(Brand).where(func.lower(Brand.name) == data.name.lower())).first()
    if dup and dup.id != brand_id:
        raise Conflict("Bu marka zaten kayıtlı.")
    brand = session.get(Brand, brand_id) if brand_id else Brand(name=data.name)
    if not brand:
        raise NotFound("Marka")
    brand.name, brand.is_active = data.name, data.is_active
    session.add(brand)
    session.flush()
    audit.record(session, actor, "brand.save", "brand", brand.id, None, audit.snapshot(brand, ["name", "is_active"]))
    session.commit()
    session.refresh(brand)
    return brand


def list_locations(session: Session) -> list[Location]:
    return list(session.exec(select(Location).order_by(Location.code)).all())


def save_location(session: Session, actor: Actor, data: LocationIn, location_id: int | None = None) -> Location:
    code = data.code.upper()
    dup = session.exec(select(Location).where(Location.code == code)).first()
    if dup and dup.id != location_id:
        raise Conflict("Bu raf kodu zaten kayıtlı.")
    loc = session.get(Location, location_id) if location_id else Location(code=code)
    if not loc:
        raise NotFound("Konum")
    loc.code, loc.name, loc.is_active = code, data.name, data.is_active
    session.add(loc)
    session.flush()
    audit.record(session, actor, "location.save", "location", loc.id, None, audit.snapshot(loc, ["code", "name", "is_active"]))
    session.commit()
    session.refresh(loc)
    return loc
