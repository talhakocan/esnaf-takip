"""Teknik servis: kayıt, durum makinesi, parçalar, teslim → satış, herkese açık takip."""

import secrets
from datetime import datetime
from decimal import Decimal
from typing import Any

from sqlmodel import Session, col, func, or_, select

from app.core.deps import Actor
from app.core.errors import NotFound, ValidationFailed
from app.core.money import line_amount, round_half_up, validate_qty_for_unit
from app.core.money import qty as to_qty
from app.core.permissions import P
from app.models import (
    Customer,
    MovementType,
    NoteVisibility,
    PricingMode,
    Product,
    ProductSerial,
    SerialStatus,
    ServiceNote,
    ServicePart,
    ServiceStatus,
    ServiceStatusHistory,
    ServiceTicket,
    UnitType,
    User,
    now,
)
from app.schemas.service import DeliverIn, NoteCreate, PartAdd, StatusChange, TicketCreate, TicketUpdate
from app.services import customer_service, sale_service, stock_service
from app.services.settings_service import get_settings_row

S = ServiceStatus
CODE_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"  # O, 0, I, 1 bilinçli olarak yok
LABOR_SKU = "HZM-ISCILIK"

STATUS_TR = {
    S.RECEIVED: "Teslim alındı",
    S.DIAGNOSING: "İnceleniyor",
    S.WAITING_APPROVAL: "Onay bekleniyor",
    S.WAITING_PARTS: "Parça bekleniyor",
    S.IN_REPAIR: "Onarımda",
    S.READY: "Teslime hazır",
    S.DELIVERED: "Teslim edildi",
    S.CANCELLED: "İptal / onarılamadı",
}

TRANSITIONS: dict[ServiceStatus, set[ServiceStatus]] = {
    S.RECEIVED: {S.DIAGNOSING, S.CANCELLED},
    S.DIAGNOSING: {S.WAITING_APPROVAL, S.WAITING_PARTS, S.IN_REPAIR, S.READY, S.CANCELLED},
    S.WAITING_APPROVAL: {S.WAITING_PARTS, S.IN_REPAIR, S.CANCELLED},
    S.WAITING_PARTS: {S.IN_REPAIR, S.CANCELLED},
    S.IN_REPAIR: {S.WAITING_PARTS, S.READY, S.CANCELLED},
    S.READY: {S.IN_REPAIR},  # DELIVERED yalnızca teslim akışıyla
    S.DELIVERED: set(),
    S.CANCELLED: set(),
}

NEXT_SUGGESTED: dict[ServiceStatus, ServiceStatus] = {
    S.RECEIVED: S.DIAGNOSING,
    S.DIAGNOSING: S.WAITING_APPROVAL,
    S.WAITING_APPROVAL: S.IN_REPAIR,
    S.WAITING_PARTS: S.IN_REPAIR,
    S.IN_REPAIR: S.READY,
    S.READY: S.DELIVERED,
}

OPEN_STATUSES = [s for s in S if s not in (S.DELIVERED, S.CANCELLED)]
PUBLIC_STEPS = [S.RECEIVED, S.DIAGNOSING, S.WAITING_APPROVAL, S.WAITING_PARTS, S.IN_REPAIR, S.READY, S.DELIVERED]


def can_transition(frm: ServiceStatus, to: ServiceStatus) -> bool:
    return to in TRANSITIONS.get(frm, set())


def generate_code(session: Session) -> str:
    for _ in range(50):
        code = "SRV-" + "".join(secrets.choice(CODE_ALPHABET) for _ in range(4))
        if not session.exec(select(ServiceTicket.id).where(ServiceTicket.code == code)).first():
            return code
    raise RuntimeError("Servis kodu üretilemedi.")


def normalize_code(code: str) -> str:
    code = code.strip().upper().replace(" ", "")
    return code if code.startswith("SRV-") else f"SRV-{code.removeprefix('SRV')}"


def _get(session: Session, ticket_id: int) -> ServiceTicket:
    t = session.get(ServiceTicket, ticket_id)
    if not t:
        raise NotFound("Servis kaydı")
    return t


def _history(
    session: Session, t: ServiceTicket, frm: ServiceStatus | None, to: ServiceStatus, note: str, user_id: int | None, at: datetime
) -> None:
    session.add(ServiceStatusHistory(ticket_id=t.id, from_status=frm, to_status=to, note=note, user_id=user_id, at=at))  # type: ignore[arg-type]


def labor_product(session: Session) -> Product:
    p = session.exec(select(Product).where(Product.sku == LABOR_SKU)).first()
    if not p:
        p = Product(
            sku=LABOR_SKU,
            name="Servis işçiliği",
            unit_type=UnitType.SERVICE,
            vat_rate=get_settings_row(session).default_vat_rate,
            pricing_mode=PricingMode.FIXED,
            sale_price_kurus=0,
            notes="Sistem ürünü: servis teslimlerinde işçilik satırı.",
        )
        session.add(p)
        session.flush()
    return p


# ---------------------------------------------------------------- oluşturma / güncelleme


def create_ticket(session: Session, actor: Actor, data: TicketCreate, at: datetime | None = None) -> dict[str, Any]:
    ts = at or now()
    customer_id = data.customer_id
    if not customer_id:
        if not data.new_customer:
            raise ValidationFailed("Müşteri seçin veya yeni müşteri ekleyin.", {"customer_id": "Müşteri zorunlu."})
        nc = data.new_customer
        c = Customer(
            full_name=nc.full_name,
            phone=customer_service.normalize_phone(nc.phone),
            kvkk_consent_at=ts if nc.kvkk_consent else None,
            created_by=actor.id,
        )
        session.add(c)
        session.flush()
        customer_id = c.id
    elif not session.get(Customer, customer_id):
        raise ValidationFailed("Müşteri bulunamadı.", {"customer_id": "Geçersiz müşteri."})
    if data.assigned_to and not session.get(User, data.assigned_to):
        raise ValidationFailed("Atanan kullanıcı bulunamadı.")
    t = ServiceTicket(
        code=generate_code(session),
        customer_id=customer_id,
        device_type=data.device_type,
        brand=data.brand,  # type: ignore[arg-type]
        model=data.model,
        serial_no=data.serial_no.upper(),
        accessories=[a for a in data.accessories if a],
        complaint=data.complaint,
        estimated_cost=data.estimated_cost,
        assigned_to=data.assigned_to or actor.id,
        received_at=ts,
        status_changed_at=ts,
        created_by=actor.id,
        created_at=ts,
        updated_at=ts,
    )
    session.add(t)
    session.flush()
    _history(session, t, None, S.RECEIVED, "Cihaz teslim alındı.", actor.id, ts)
    session.commit()
    return get_ticket(session, actor, t.id)  # type: ignore[arg-type]


def update_ticket(session: Session, actor: Actor, ticket_id: int, data: TicketUpdate) -> dict[str, Any]:
    t = _get(session, ticket_id)
    if t.status in (S.DELIVERED, S.CANCELLED):
        raise ValidationFailed("Kapanmış servis kaydı düzenlenemez.")
    for k, v in data.model_dump(exclude_unset=True).items():
        if k == "serial_no" and v:
            v = v.upper()
        setattr(t, k, v)
    session.add(t)
    session.commit()
    return get_ticket(session, actor, ticket_id)


def change_status(session: Session, actor: Actor, ticket_id: int, data: StatusChange, at: datetime | None = None) -> dict[str, Any]:
    t = _get(session, ticket_id)
    ts = at or now()
    if data.status == S.DELIVERED:
        raise ValidationFailed("Teslim için 'Teslim et' işlemini kullanın.", code="USE_DELIVER")
    if not can_transition(t.status, data.status):
        raise ValidationFailed(
            f"'{STATUS_TR[t.status]}' durumundan '{STATUS_TR[data.status]}' durumuna geçilemez.", code="INVALID_TRANSITION"
        )
    if data.status == S.CANCELLED and _active_parts(session, t.id):  # type: ignore[arg-type]
        raise ValidationFailed("İptal etmeden önce kullanılan parçaları stoğa geri alın.")
    frm = t.status
    if frm == S.WAITING_APPROVAL and data.status in (S.WAITING_PARTS, S.IN_REPAIR):
        t.approved_by_customer_at = ts
    t.status = data.status
    t.status_changed_at = ts
    session.add(t)
    _history(session, t, frm, data.status, data.note, actor.id, ts)
    if data.note and data.notify_customer:
        session.add(
            ServiceNote(ticket_id=t.id, body=data.note, visibility=NoteVisibility.CUSTOMER, user_id=actor.id, created_at=ts, updated_at=ts)
        )  # type: ignore[arg-type]
    session.commit()
    return get_ticket(session, actor, ticket_id)


def add_note(session: Session, actor: Actor, ticket_id: int, data: NoteCreate) -> dict[str, Any]:
    t = _get(session, ticket_id)
    session.add(ServiceNote(ticket_id=t.id, body=data.body, visibility=data.visibility, user_id=actor.id))  # type: ignore[arg-type]
    session.commit()
    return get_ticket(session, actor, ticket_id)


# ---------------------------------------------------------------- parçalar


def _active_parts(session: Session, ticket_id: int) -> list[ServicePart]:
    return list(session.exec(select(ServicePart).where(ServicePart.ticket_id == ticket_id, col(ServicePart.removed_at).is_(None))).all())


def add_part(session: Session, actor: Actor, ticket_id: int, data: PartAdd, at: datetime | None = None) -> dict[str, Any]:
    t = _get(session, ticket_id)
    if t.status in (S.DELIVERED, S.CANCELLED):
        raise ValidationFailed("Kapanmış servis kaydına parça eklenemez.")
    product = session.get(Product, data.product_id)
    if not product or not product.is_active:
        raise ValidationFailed("Ürün bulunamadı.", {"product_id": "Geçersiz ürün."})
    q = to_qty(data.qty)
    try:
        validate_qty_for_unit(q, product.unit_type)
    except ValueError as exc:
        raise ValidationFailed(str(exc), {"qty": str(exc)}) from exc
    serial = None
    if product.track_serial:
        if not data.serial_id or q != 1:
            raise ValidationFailed("Seri takipli parçada 1 adet ve seri numarası seçilmelidir.", {"serial_id": "Seri no seçin."})
        serial = stock_service.get_available_serial(session, product, data.serial_id)
    price = product.sale_price_kurus if data.unit_price is None else data.unit_price
    if price != product.sale_price_kurus and product.unit_type != UnitType.SERVICE and not actor.can(P.PRODUCT_WRITE):
        raise ValidationFailed("Parça fiyatını değiştirme yetkiniz yok.")
    part = ServicePart(
        ticket_id=t.id,
        product_id=product.id,
        qty=q,
        unit_price=price,
        serial_id=serial.id if serial else None,  # type: ignore[arg-type]
        unit_cost_snapshot=product.avg_cost_kurus,
        user_id=actor.id,
    )
    if at:
        part.created_at = part.updated_at = at
    session.add(part)
    session.flush()
    stock_service.apply_movement(
        session, product, MovementType.SERVICE_OUT, -q, actor.id, ref_type="SERVICE", ref_id=t.id, note=t.code, at=at
    )
    if serial:
        serial.status = SerialStatus.SOLD
        serial.service_part_id = part.id
        session.add(serial)
    session.commit()
    return get_ticket(session, actor, ticket_id)


def remove_part(session: Session, actor: Actor, ticket_id: int, part_id: int) -> dict[str, Any]:
    t = _get(session, ticket_id)
    part = session.get(ServicePart, part_id)
    if not part or part.ticket_id != t.id or part.removed_at:
        raise NotFound("Parça")
    if t.status in (S.DELIVERED, S.CANCELLED):
        raise ValidationFailed("Kapanmış servis kaydında parça değiştirilemez.")
    product = session.get(Product, part.product_id)
    assert product is not None
    stock_service.apply_movement(
        session,
        product,
        MovementType.SERVICE_RETURN,
        part.qty,
        actor.id,
        ref_type="SERVICE",
        ref_id=t.id,
        note=f"{t.code} parça iadesi",
        allow_negative=True,
    )
    if part.serial_id:
        serial = session.get(ProductSerial, part.serial_id)
        if serial:
            serial.status, serial.service_part_id = SerialStatus.IN_STOCK, None
            session.add(serial)
    part.removed_at = now()
    session.add(part)
    session.commit()
    return get_ticket(session, actor, ticket_id)


# ---------------------------------------------------------------- teslim


def ticket_totals(session: Session, t: ServiceTicket) -> dict[str, int]:
    parts_total = sum(line_amount(p.qty, p.unit_price) for p in _active_parts(session, t.id))  # type: ignore[arg-type]
    return {"parts_total": parts_total, "labor_fee": t.labor_fee, "total": parts_total + t.labor_fee}


def deliver(session: Session, actor: Actor, ticket_id: int, data: DeliverIn, at: datetime | None = None) -> dict[str, Any]:
    t = _get(session, ticket_id)
    ts = at or now()
    if t.status != S.READY:
        raise ValidationFailed("Yalnızca 'Teslime hazır' durumundaki cihazlar teslim edilebilir.", code="NOT_READY")
    lines: list[sale_service.Line] = []
    for part in _active_parts(session, t.id):  # type: ignore[arg-type]
        product = session.get(Product, part.product_id)
        assert product is not None
        serial = session.get(ProductSerial, part.serial_id) if part.serial_id else None
        lines.append(
            sale_service.Line(
                product=product,
                qty=part.qty,
                unit_price=part.unit_price,
                serial=serial,
                stock_already_moved=True,
                cost_snapshot=part.unit_cost_snapshot,
            )
        )
    if t.labor_fee > 0:
        lines.append(sale_service.Line(product=labor_product(session), qty=Decimal(1), unit_price=t.labor_fee, cost_snapshot=0))
    sale = None
    if lines:
        sale = sale_service.create_sale_core(
            session,
            actor,
            lines,
            data.discount,
            data.payments,
            t.customer_id,
            note=data.note or f"Servis {t.code}",
            override=data.override,
            service_ticket_id=t.id,
            at=ts,
        )
        t.sale_id = sale.id
    elif data.payments:
        raise ValidationFailed("Ücretsiz teslimde ödeme alınmaz.")
    frm = t.status
    t.status = S.DELIVERED
    t.status_changed_at = ts
    t.delivered_at = ts
    session.add(t)
    _history(session, t, frm, S.DELIVERED, f"Cihaz teslim edildi{' — ' + sale.receipt_no if sale else ''}.", actor.id, ts)
    session.commit()
    return get_ticket(session, actor, ticket_id)


# ---------------------------------------------------------------- sorgular


def waiting_days(t: ServiceTicket, ref: datetime | None = None) -> int:
    end = t.delivered_at or ref or now()
    return max((end - t.received_at).days, 0)


def list_tickets(
    session: Session, status: str | None = None, q: str | None = None, assigned_to: int | None = None, customer_id: int | None = None
) -> list[dict[str, Any]]:
    stmt = (
        select(ServiceTicket, Customer.full_name, Customer.phone, User.full_name)
        .join(Customer, col(Customer.id) == ServiceTicket.customer_id)
        .join(User, col(User.id) == ServiceTicket.assigned_to, isouter=True)
    )
    if status == "open":
        stmt = stmt.where(col(ServiceTicket.status).in_(OPEN_STATUSES))
    elif status == "closed":
        stmt = stmt.where(col(ServiceTicket.status).in_([S.DELIVERED, S.CANCELLED]))
    elif status:
        stmt = stmt.where(ServiceTicket.status == status)
    if q:
        like = f"%{q.strip()}%"
        stmt = stmt.where(
            or_(
                col(ServiceTicket.code).ilike(like),
                col(ServiceTicket.model).ilike(like),
                col(ServiceTicket.brand).ilike(like),
                col(ServiceTicket.serial_no).ilike(like),
                col(Customer.full_name).ilike(like),
                col(Customer.phone).like(like),
            )
        )
    if assigned_to:
        stmt = stmt.where(ServiceTicket.assigned_to == assigned_to)
    if customer_id:
        stmt = stmt.where(ServiceTicket.customer_id == customer_id)
    rows = session.exec(stmt.order_by(col(ServiceTicket.received_at).desc())).all()
    ref = now()
    return [
        {
            "id": t.id,
            "code": t.code,
            "device_type": t.device_type,
            "brand": t.brand,
            "model": t.model,
            "customer_id": t.customer_id,
            "customer_name": cname,
            "customer_phone": cphone,
            "status": t.status,
            "status_changed_at": t.status_changed_at,
            "received_at": t.received_at,
            "delivered_at": t.delivered_at,
            "waiting_days": waiting_days(t, ref),
            "assigned_to": t.assigned_to,
            "assigned_name": aname,
            "estimated_cost": t.estimated_cost,
            "complaint": t.complaint,
        }
        for t, cname, cphone, aname in rows
    ]


def get_ticket(session: Session, actor: Actor, ticket_id: int) -> dict[str, Any]:
    t = _get(session, ticket_id)
    customer = session.get(Customer, t.customer_id)
    users = {u.id: u.full_name for u in session.exec(select(User)).all()}
    history = session.exec(
        select(ServiceStatusHistory)
        .where(ServiceStatusHistory.ticket_id == t.id)
        .order_by(col(ServiceStatusHistory.at), col(ServiceStatusHistory.id))
    ).all()
    notes = session.exec(
        select(ServiceNote).where(ServiceNote.ticket_id == t.id).order_by(col(ServiceNote.created_at), col(ServiceNote.id))
    ).all()
    parts = session.exec(
        select(ServicePart, Product.name, Product.sku, Product.unit_type, ProductSerial.serial_no)
        .join(Product, col(Product.id) == ServicePart.product_id)
        .join(ProductSerial, col(ProductSerial.id) == ServicePart.serial_id, isouter=True)
        .where(ServicePart.ticket_id == t.id)
        .order_by(col(ServicePart.id))
    ).all()
    can_cost = actor.can(P.PRODUCT_COST_VIEW)
    timeline = [
        {
            "kind": "status",
            "at": h.at,
            "from_status": h.from_status,
            "to_status": h.to_status,
            "note": h.note,
            "user_name": users.get(h.user_id),
        }
        for h in history
    ]  # type: ignore[arg-type]
    timeline += [
        {"kind": "note", "at": n.created_at, "id": n.id, "body": n.body, "visibility": n.visibility, "user_name": users.get(n.user_id)}
        for n in notes
    ]  # type: ignore[arg-type]
    timeline.sort(key=lambda e: e["at"])
    totals = ticket_totals(session, t)
    part_rows = []
    for p, name, sku, unit_type, serial_no in parts:
        row = {
            "id": p.id,
            "product_id": p.product_id,
            "product_name": name,
            "sku": sku,
            "unit_type": unit_type,
            "qty": p.qty,
            "unit_price": p.unit_price,
            "total": line_amount(p.qty, p.unit_price),
            "serial_no": serial_no,
            "removed_at": p.removed_at,
            "added_at": p.created_at,
        }
        if can_cost:
            row["unit_cost"] = p.unit_cost_snapshot
        part_rows.append(row)
    out: dict[str, Any] = {
        "id": t.id,
        "code": t.code,
        "device_type": t.device_type,
        "brand": t.brand,
        "model": t.model,
        "serial_no": t.serial_no,
        "accessories": t.accessories,
        "complaint": t.complaint,
        "diagnosis": t.diagnosis,
        "status": t.status,
        "status_label": STATUS_TR[t.status],
        "status_changed_at": t.status_changed_at,
        "estimated_cost": t.estimated_cost,
        "approved_by_customer_at": t.approved_by_customer_at,
        "labor_fee": t.labor_fee,
        "assigned_to": t.assigned_to,
        "assigned_name": users.get(t.assigned_to) if t.assigned_to else None,
        "received_at": t.received_at,  # type: ignore[arg-type]
        "delivered_at": t.delivered_at,
        "sale_id": t.sale_id,
        "waiting_days": waiting_days(t),
        "customer": {"id": customer.id, "full_name": customer.full_name, "phone": customer.phone} if customer else None,
        "timeline": timeline,
        "parts": part_rows,
        **totals,
        "allowed_transitions": sorted(TRANSITIONS[t.status], key=lambda s: list(S).index(s)),
        "next_status": NEXT_SUGGESTED.get(t.status),
    }
    if can_cost:
        out["parts_cost"] = sum(round_half_up(p.qty * p.unit_cost_snapshot) for p, *_ in parts if not p.removed_at)
    return out


def public_track(session: Session, code: str) -> dict[str, Any]:
    """Herkese açık takip. Kişisel veri (ad, telefon, seri no) DÖNMEZ."""
    t = session.exec(select(ServiceTicket).where(func.upper(ServiceTicket.code) == normalize_code(code))).first()
    if not t:
        raise NotFound("Servis kaydı")
    settings = get_settings_row(session)
    history = session.exec(
        select(ServiceStatusHistory).where(ServiceStatusHistory.ticket_id == t.id).order_by(col(ServiceStatusHistory.at))
    ).all()
    notes = session.exec(
        select(ServiceNote)
        .where(ServiceNote.ticket_id == t.id, ServiceNote.visibility == NoteVisibility.CUSTOMER)
        .order_by(col(ServiceNote.created_at))
    ).all()
    reached = {h.to_status: h.at for h in history}
    steps = [
        {"status": s, "label": STATUS_TR[s], "at": reached.get(s), "done": s in reached, "current": s == t.status}
        for s in PUBLIC_STEPS
        if s in reached or s == t.status or s not in (S.WAITING_APPROVAL, S.WAITING_PARTS)
    ]
    return {
        "code": t.code,
        "status": t.status,
        "status_label": STATUS_TR[t.status],
        "device_type": t.device_type,
        "brand": t.brand,
        "model": t.model,
        "received_at": t.received_at,
        "delivered_at": t.delivered_at,
        "updated_at": t.status_changed_at,
        "estimated_cost": t.estimated_cost,
        "cancelled": t.status == S.CANCELLED,
        "steps": steps,
        "notes": [{"at": n.created_at, "body": n.body} for n in notes],
        "shop": {"name": settings.shop_name, "phone": settings.phone, "address": settings.address},
    }


def status_counts(session: Session) -> dict[str, int]:
    return {
        s: c for s, c in session.exec(select(ServiceTicket.status, func.count(col(ServiceTicket.id))).group_by(ServiceTicket.status)).all()
    }
