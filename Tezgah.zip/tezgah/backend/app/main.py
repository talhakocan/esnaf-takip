"""Tezgâh — FastAPI uygulaması. Üretimde derlenmiş frontend'i de aynı porttan sunar."""

import logging
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI, Request
from fastapi.responses import FileResponse, JSONResponse
from sqlmodel import Session

from app.config import get_settings
from app.core.errors import install_error_handlers
from app.db import get_engine
from app.routers import auth, catalog, customers, products, purchasing, reports, sales, service, system

log = logging.getLogger("tezgah")
SAFE_METHODS = {"GET", "HEAD", "OPTIONS"}
CSRF_HEADER = "x-tezgah"


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncIterator[None]:
    from app.migrations import upgrade_db
    from app.services.backup_service import BackupScheduler
    from app.services.settings_service import get_settings_row

    settings = get_settings()
    upgrade_db()
    with Session(get_engine()) as s:
        get_settings_row(s)
        s.commit()
    scheduler = None
    if settings.enable_scheduler:
        scheduler = BackupScheduler()
        scheduler.start()
    yield
    if scheduler:
        scheduler.stop()


def create_app(run_lifespan: bool = True) -> FastAPI:
    settings = get_settings()
    app = FastAPI(
        title="Tezgâh API",
        version=settings.app_version,
        description="Teknolife dükkan yönetim sistemi — stok, satış, teknik servis, cari ve raporlar.",
        lifespan=lifespan if run_lifespan else None,
        docs_url="/api/docs",
        openapi_url="/api/openapi.json",
        redoc_url=None,
    )
    install_error_handlers(app)

    @app.middleware("http")
    async def csrf_guard(request: Request, call_next):
        # Çerez tabanlı oturumda CSRF'ye karşı: durum değiştiren API isteklerinde özel başlık zorunlu.
        # Tarayıcılar başka sitelerden bu başlığı CORS izni olmadan gönderemez.
        if request.url.path.startswith("/api/") and request.method not in SAFE_METHODS and request.headers.get(CSRF_HEADER) != "1":
            return JSONResponse({"error": {"code": "CSRF", "message": "Geçersiz istek kaynağı.", "fields": {}}}, 403)
        response = await call_next(request)
        response.headers.setdefault("X-Content-Type-Options", "nosniff")
        response.headers.setdefault("Referrer-Policy", "same-origin")
        if request.url.path.startswith("/api/"):
            response.headers.setdefault("Cache-Control", "no-store")
        return response

    for r in (auth, catalog, products, sales, customers, service, purchasing, reports, system):
        app.include_router(r.router, prefix="/api")

    @app.get("/api/health", tags=["Sistem"])
    def health() -> dict:
        return {"status": "ok", "version": settings.app_version}

    @app.api_route("/api/{path:path}", methods=["GET", "POST", "PATCH", "PUT", "DELETE"], include_in_schema=False)
    def api_not_found(path: str) -> JSONResponse:
        return JSONResponse({"error": {"code": "NOT_FOUND", "message": "Uç bulunamadı.", "fields": {}}}, 404)

    dist = settings.frontend_dist
    if (dist / "index.html").exists():
        # Not: StaticFiles yerine basit yol kontrolü kullanılır; çok uzun Windows yollarında
        # realpath "\\?\" önekiyle döndüğü için StaticFiles dosyaları bulamayabiliyor.
        @app.get("/{path:path}", include_in_schema=False)
        def spa(path: str) -> FileResponse:
            parts = Path(path).parts
            candidate = dist.joinpath(*parts) if parts else dist
            if path and ".." not in parts and not Path(path).is_absolute() and candidate.is_file():
                cache = "public, max-age=31536000, immutable" if parts[0] == "assets" else "no-cache"
                return FileResponse(candidate, headers={"Cache-Control": cache})
            if parts and parts[0] == "assets":
                return JSONResponse({"error": {"code": "NOT_FOUND", "message": "Dosya bulunamadı.", "fields": {}}}, 404)
            return FileResponse(dist / "index.html", headers={"Cache-Control": "no-cache"})
    else:

        @app.get("/", include_in_schema=False)
        def no_frontend() -> JSONResponse:
            return JSONResponse(
                {"message": "Frontend derlenmemiş. 'frontend' klasöründe 'npm run build' çalıştırın.", "api_docs": "/api/docs"}
            )

    return app


app = create_app()
