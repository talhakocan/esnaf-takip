"""Demo verisi: gerçekçi Türkçe katalog, müşteriler ve tedarikçiler.

Ürün satırı: (ad, kategori, marka, birim, para birimi, alış fiyatı, fiyat modu, kâr %, satış TL | None,
              seri takibi, garanti ay, popülerlik, tedarikçi, raf, özel işaret)
Özel işaret: "dead" → hiç satılmaz (ölü stok), "critical" → dönem sonunda kritik stokta bırakılır.
"""

CATEGORIES = {
    "Elektrik": ["Kablo", "Sigorta & Şalter", "Priz & Anahtar", "Aydınlatma", "Uzatma & Grup Priz", "Tesisat"],
    "Bilgisayar": ["Depolama", "Bellek", "Çevre Birimleri", "Ağ Ürünleri", "Kablo & Adaptör", "Sarf"],
    "Hizmet": [],
}

BRANDS = [
    "Öznur Kablo", "Hes Kablo", "Viko", "Makel", "Schneider Electric", "Legrand", "Philips", "Osram", "Cata", "Pelsan",
    "Samsung", "Kingston", "Crucial", "Western Digital", "Seagate", "SanDisk", "Logitech", "Rampage", "Everest",
    "TP-Link", "Ugreen", "Baseus", "Arctic", "HP", "Canon", "Duracell", "Teknolife",
]

LOCATIONS = [("A-01", "Elektrik rafı — kablo"), ("A-02", "Elektrik rafı — sigorta, priz"), ("B-01", "Bilgisayar vitrini"),
             ("B-02", "Bilgisayar arka raf"), ("DEPO-1", "Arka depo")]

SUPPLIERS = [
    # anahtar, ad, yetkili, telefon, e-posta, para birimi
    ("ozdemir", "Özdemir Elektrik Toptan", "Kemal Özdemir", "02125550101", "siparis@ozdemirelektrik.com.tr", "TRY"),
    ("isik", "Işık Aydınlatma Dağıtım", "Selin Işık", "02165550202", "satis@isikaydinlatma.com.tr", "TRY"),
    ("arena", "Arena Bilgisayar", "Burak Tan", "02125550303", "bayi@arenabilgisayar.com.tr", "USD"),
    ("penta", "Penta Teknoloji", "Derya Kara", "02165550404", "bayi@pentateknoloji.com.tr", "USD"),
    ("index", "İndeks Bilgisayar", "Onur Çelik", "02125550505", "siparis@indeksbilgisayar.com.tr", "USD"),
    ("sarf", "Ofis Sarf Market", "Gamze Uçar", "02325550606", "info@ofissarfmarket.com.tr", "TRY"),
]

K_ELK = "Elektrik"
K_PC = "Bilgisayar"

# fmt: off
PRODUCTS = [
    # --- Elektrik › Kablo (metre, TL, sabit fiyat)
    ("NYA 1,5 mm² kablo (kırmızı)", "Kablo", "Öznur Kablo", "METER", "TRY", 7.40, "FIXED", 0, 11.90, False, 0, 9, "ozdemir", "A-01", None),
    ("NYA 1,5 mm² kablo (mavi)", "Kablo", "Öznur Kablo", "METER", "TRY", 7.40, "FIXED", 0, 11.90, False, 0, 7, "ozdemir", "A-01", None),
    ("NYA 1,5 mm² kablo (sarı-yeşil)", "Kablo", "Öznur Kablo", "METER", "TRY", 7.40, "FIXED", 0, 11.90, False, 0, 6, "ozdemir", "A-01", None),
    ("NYA 2,5 mm² kablo (siyah)", "Kablo", "Öznur Kablo", "METER", "TRY", 11.60, "FIXED", 0, 18.50, False, 0, 8, "ozdemir", "A-01", None),
    ("NYA 4 mm² kablo", "Kablo", "Hes Kablo", "METER", "TRY", 18.20, "FIXED", 0, 28.90, False, 0, 3, "ozdemir", "A-01", None),
    ("NYA 6 mm² kablo", "Kablo", "Hes Kablo", "METER", "TRY", 27.50, "FIXED", 0, 42.50, False, 0, 2, "ozdemir", "A-01", None),
    ("TTR 2×1,5 mm² kablo", "Kablo", "Öznur Kablo", "METER", "TRY", 16.80, "FIXED", 0, 26.50, False, 0, 6, "ozdemir", "A-01", None),
    ("TTR 3×1,5 mm² kablo", "Kablo", "Öznur Kablo", "METER", "TRY", 23.50, "FIXED", 0, 36.90, False, 0, 6, "ozdemir", "A-01", None),
    ("TTR 3×2,5 mm² kablo", "Kablo", "Öznur Kablo", "METER", "TRY", 34.00, "FIXED", 0, 52.90, False, 0, 7, "ozdemir", "A-01", "critical"),
    ("TTR 3×4 mm² kablo", "Kablo", "Hes Kablo", "METER", "TRY", 52.00, "FIXED", 0, 79.90, False, 0, 2, "ozdemir", "A-01", None),
    ("NYM 3×2,5 mm² antigron kablo", "Kablo", "Hes Kablo", "METER", "TRY", 38.50, "FIXED", 0, 59.90, False, 0, 3, "ozdemir", "A-01", None),
    ("RG6 koaksiyel anten kablosu", "Kablo", "Hes Kablo", "METER", "TRY", 9.80, "FIXED", 0, 15.90, False, 0, 4, "ozdemir", "A-01", None),
    ("Hoparlör kablosu 2×1,5 mm²", "Kablo", "Öznur Kablo", "METER", "TRY", 12.40, "FIXED", 0, 19.90, False, 0, 2, "ozdemir", "A-01", None),
    # --- Sigorta & Şalter
    ("B6 otomat sigorta 1 kutup", "Sigorta & Şalter", "Schneider Electric", "PIECE", "TRY", 62.00, "FIXED", 0, 99.90, False, 0, 3, "ozdemir", "A-02", None),
    ("B10 otomat sigorta 1 kutup", "Sigorta & Şalter", "Schneider Electric", "PIECE", "TRY", 62.00, "FIXED", 0, 99.90, False, 0, 4, "ozdemir", "A-02", None),
    ("B16 otomat sigorta 1 kutup", "Sigorta & Şalter", "Schneider Electric", "PIECE", "TRY", 64.00, "FIXED", 0, 104.90, False, 0, 9, "ozdemir", "A-02", None),
    ("B20 otomat sigorta 1 kutup", "Sigorta & Şalter", "Schneider Electric", "PIECE", "TRY", 66.00, "FIXED", 0, 109.90, False, 0, 5, "ozdemir", "A-02", None),
    ("B25 otomat sigorta 1 kutup", "Sigorta & Şalter", "Schneider Electric", "PIECE", "TRY", 69.00, "FIXED", 0, 114.90, False, 0, 3, "ozdemir", "A-02", None),
    ("C16 otomat sigorta 1 kutup", "Sigorta & Şalter", "Legrand", "PIECE", "TRY", 72.00, "FIXED", 0, 119.90, False, 0, 2, "ozdemir", "A-02", None),
    ("3 faz 25 A otomat sigorta", "Sigorta & Şalter", "Legrand", "PIECE", "TRY", 248.00, "FIXED", 0, 389.90, False, 0, 0, "ozdemir", "DEPO-1", "dead"),
    ("30 mA kaçak akım rölesi 2×40 A", "Sigorta & Şalter", "Schneider Electric", "PIECE", "TRY", 520.00, "FIXED", 0, 799.00, False, 0, 5, "ozdemir", "A-02", "critical"),
    ("300 mA kaçak akım rölesi 4×40 A", "Sigorta & Şalter", "Legrand", "PIECE", "TRY", 890.00, "FIXED", 0, 1349.00, False, 0, 1, "ozdemir", "A-02", None),
    ("Parafudr 4 kutup 40 kA", "Sigorta & Şalter", "Legrand", "PIECE", "TRY", 1450.00, "FIXED", 0, 2190.00, False, 0, 0, "ozdemir", "DEPO-1", "dead"),
    ("Sıva altı sigorta kutusu 8'li", "Sigorta & Şalter", "Makel", "PIECE", "TRY", 135.00, "FIXED", 0, 209.90, False, 0, 2, "ozdemir", "A-02", None),
    ("Sıva üstü sigorta kutusu 12'li", "Sigorta & Şalter", "Makel", "PIECE", "TRY", 210.00, "FIXED", 0, 329.90, False, 0, 1, "ozdemir", "A-02", None),
    # --- Priz & Anahtar
    ("Sıva altı topraklı priz (beyaz)", "Priz & Anahtar", "Viko", "PIECE", "TRY", 58.00, "FIXED", 0, 94.90, False, 0, 9, "ozdemir", "A-02", None),
    ("Sıva altı topraklı priz (krem)", "Priz & Anahtar", "Viko", "PIECE", "TRY", 58.00, "FIXED", 0, 94.90, False, 0, 4, "ozdemir", "A-02", None),
    ("Sıva üstü topraklı priz", "Priz & Anahtar", "Makel", "PIECE", "TRY", 44.00, "FIXED", 0, 72.90, False, 0, 5, "ozdemir", "A-02", None),
    ("Çocuk korumalı topraklı priz", "Priz & Anahtar", "Viko", "PIECE", "TRY", 76.00, "FIXED", 0, 124.90, False, 0, 3, "ozdemir", "A-02", None),
    ("USB şarjlı priz 2×USB-A", "Priz & Anahtar", "Viko", "PIECE", "TRY", 310.00, "FIXED", 0, 489.00, False, 0, 3, "ozdemir", "A-02", None),
    ("Tekli anahtar (beyaz)", "Priz & Anahtar", "Viko", "PIECE", "TRY", 46.00, "FIXED", 0, 74.90, False, 0, 6, "ozdemir", "A-02", None),
    ("Komütatör anahtar", "Priz & Anahtar", "Viko", "PIECE", "TRY", 58.00, "FIXED", 0, 92.90, False, 0, 3, "ozdemir", "A-02", None),
    ("Vavien anahtar", "Priz & Anahtar", "Makel", "PIECE", "TRY", 55.00, "FIXED", 0, 89.90, False, 0, 0, "ozdemir", "A-02", "dead"),
    ("Cat6 data prizi", "Priz & Anahtar", "Legrand", "PIECE", "TRY", 118.00, "FIXED", 0, 184.90, False, 0, 2, "ozdemir", "A-02", None),
    ("TV/SAT anten prizi", "Priz & Anahtar", "Makel", "PIECE", "TRY", 64.00, "FIXED", 0, 104.90, False, 0, 0, "ozdemir", "A-02", "dead"),
    # --- Aydınlatma
    ("9W LED ampul E27 beyaz ışık", "Aydınlatma", "Philips", "PIECE", "TRY", 48.00, "FIXED", 0, 79.90, False, 0, 10, "isik", "A-02", None),
    ("12W LED ampul E27 günışığı", "Aydınlatma", "Philips", "PIECE", "TRY", 62.00, "FIXED", 0, 99.90, False, 0, 7, "isik", "A-02", None),
    ("15W LED ampul E27 beyaz ışık", "Aydınlatma", "Osram", "PIECE", "TRY", 78.00, "FIXED", 0, 124.90, False, 0, 4, "isik", "A-02", None),
    ("5W LED mum ampul E14", "Aydınlatma", "Osram", "PIECE", "TRY", 42.00, "FIXED", 0, 69.90, False, 0, 5, "isik", "A-02", None),
    ("60×60 LED panel 40W", "Aydınlatma", "Cata", "PIECE", "TRY", 460.00, "FIXED", 0, 699.00, False, 24, 2, "isik", "DEPO-1", None),
    ("Sıva üstü yuvarlak LED panel 18W", "Aydınlatma", "Cata", "PIECE", "TRY", 185.00, "FIXED", 0, 289.00, False, 24, 3, "isik", "A-02", None),
    ("10W LED projektör IP65", "Aydınlatma", "Cata", "PIECE", "TRY", 175.00, "FIXED", 0, 279.00, False, 24, 3, "isik", "A-02", None),
    ("50W LED projektör IP65", "Aydınlatma", "Cata", "PIECE", "TRY", 520.00, "FIXED", 0, 799.00, False, 24, 0, "isik", "DEPO-1", "dead"),
    ("Şerit LED 5 m 3000K (adaptörlü)", "Aydınlatma", "Pelsan", "PIECE", "TRY", 290.00, "FIXED", 0, 459.00, False, 12, 3, "isik", "A-02", None),
    ("Hareket sensörlü duy E27", "Aydınlatma", "Pelsan", "PIECE", "TRY", 120.00, "FIXED", 0, 189.90, False, 12, 2, "isik", "A-02", None),
    ("T8 LED floresan 120 cm 18W", "Aydınlatma", "Osram", "PIECE", "TRY", 98.00, "FIXED", 0, 154.90, False, 12, 2, "isik", "DEPO-1", None),
    # --- Uzatma & Grup Priz
    ("3'lü grup priz 1,5 m", "Uzatma & Grup Priz", "Viko", "PIECE", "TRY", 165.00, "FIXED", 0, 259.00, False, 24, 7, "ozdemir", "A-02", None),
    ("3'lü grup priz 3 m", "Uzatma & Grup Priz", "Viko", "PIECE", "TRY", 205.00, "FIXED", 0, 319.00, False, 24, 5, "ozdemir", "A-02", None),
    ("5'li akım korumalı grup priz", "Uzatma & Grup Priz", "Viko", "PIECE", "TRY", 420.00, "FIXED", 0, 649.00, False, 24, 4, "ozdemir", "A-02", "critical"),
    ("6'lı anahtarlı grup priz 2 m", "Uzatma & Grup Priz", "Makel", "PIECE", "TRY", 310.00, "FIXED", 0, 479.00, False, 24, 3, "ozdemir", "A-02", None),
    ("Makaralı uzatma kablosu 25 m", "Uzatma & Grup Priz", "Makel", "PIECE", "TRY", 980.00, "FIXED", 0, 1490.00, False, 24, 0, "ozdemir", "DEPO-1", "dead"),
    ("2'li topraklı grup priz", "Uzatma & Grup Priz", "Makel", "PIECE", "TRY", 88.00, "FIXED", 0, 139.90, False, 12, 4, "ozdemir", "A-02", None),
    ("Topraklı T-priz (üçlü)", "Uzatma & Grup Priz", "Makel", "PIECE", "TRY", 52.00, "FIXED", 0, 84.90, False, 0, 5, "ozdemir", "A-02", None),
    # --- Tesisat
    ("Sıva altı buat 85 mm", "Tesisat", "Makel", "PIECE", "TRY", 5.20, "FIXED", 0, 8.90, False, 0, 7, "ozdemir", "A-01", None),
    ("İzole bant 10 m (siyah)", "Tesisat", "Legrand", "PIECE", "TRY", 14.50, "FIXED", 0, 24.90, False, 0, 8, "ozdemir", "A-01", None),
    ("Klemens 12'li 6 mm²", "Tesisat", "Makel", "PIECE", "TRY", 21.00, "FIXED", 0, 34.90, False, 0, 5, "ozdemir", "A-01", None),
    ("Kablo bağı 200 mm 100'lü", "Tesisat", "Makel", "PIECE", "TRY", 38.00, "FIXED", 0, 59.90, False, 0, 4, "ozdemir", "A-01", None),
    ("Kablo kanalı 25×16 mm 2 m", "Tesisat", "Legrand", "PIECE", "TRY", 34.00, "FIXED", 0, 54.90, False, 0, 3, "ozdemir", "A-01", None),
    # --- Bilgisayar › Depolama (USD, kura bağlı, seri takipli)
    ("Samsung 980 250 GB NVMe SSD", "Depolama", "Samsung", "PIECE", "USD", 27.00, "FX_LINKED", 32, None, True, 36, 3, "arena", "B-01", None),
    ("Kingston NV3 500 GB NVMe SSD", "Depolama", "Kingston", "PIECE", "USD", 34.00, "FX_LINKED", 30, None, True, 36, 6, "arena", "B-01", "critical"),
    ("Samsung 990 EVO 1 TB NVMe SSD", "Depolama", "Samsung", "PIECE", "USD", 68.00, "FX_LINKED", 25, None, True, 60, 4, "arena", "B-01", None),
    ("WD Blue SN580 2 TB NVMe SSD", "Depolama", "Western Digital", "PIECE", "USD", 118.00, "FX_LINKED", 22, None, True, 60, 1, "penta", "B-01", None),
    ("Kingston A400 480 GB SATA SSD", "Depolama", "Kingston", "PIECE", "USD", 29.00, "FX_LINKED", 32, None, True, 36, 5, "penta", "B-01", None),
    ("Crucial MX500 1 TB SATA SSD", "Depolama", "Crucial", "PIECE", "USD", 62.00, "FX_LINKED", 25, None, True, 60, 3, "penta", "B-01", None),
    ("Seagate BarraCuda 1 TB HDD 7200 rpm", "Depolama", "Seagate", "PIECE", "USD", 44.00, "FX_LINKED", 25, None, True, 24, 1, "arena", "B-02", None),
    ("WD Blue 2 TB HDD", "Depolama", "Western Digital", "PIECE", "USD", 58.00, "FX_LINKED", 25, None, True, 24, 0, "arena", "B-02", "dead"),
    ("SanDisk Ultra 64 GB USB bellek", "Depolama", "SanDisk", "PIECE", "USD", 6.50, "FX_LINKED", 45, None, False, 24, 7, "index", "B-01", None),
    ("SanDisk Ultra 128 GB USB bellek", "Depolama", "SanDisk", "PIECE", "USD", 10.50, "FX_LINKED", 40, None, False, 24, 4, "index", "B-01", None),
    ("SanDisk 64 GB microSD kart", "Depolama", "SanDisk", "PIECE", "USD", 7.20, "FX_LINKED", 45, None, False, 24, 5, "index", "B-01", None),
    ("Seagate Expansion 1 TB harici disk", "Depolama", "Seagate", "PIECE", "USD", 55.00, "FX_LINKED", 25, None, True, 24, 1, "penta", "B-01", None),
    ("2,5\" USB 3.0 disk kutusu", "Depolama", "Ugreen", "PIECE", "USD", 7.80, "FX_LINKED", 45, None, False, 12, 2, "index", "B-02", None),
    # --- Bellek
    ("Kingston 8 GB DDR4 3200 MHz masaüstü RAM", "Bellek", "Kingston", "PIECE", "USD", 19.00, "FX_LINKED", 32, None, True, 36, 5, "arena", "B-01", None),
    ("Kingston 16 GB DDR4 3200 MHz masaüstü RAM", "Bellek", "Kingston", "PIECE", "USD", 34.00, "FX_LINKED", 28, None, True, 36, 4, "arena", "B-01", "critical"),
    ("Crucial 8 GB DDR4 3200 MHz SODIMM RAM", "Bellek", "Crucial", "PIECE", "USD", 18.50, "FX_LINKED", 32, None, True, 36, 5, "penta", "B-01", None),
    ("Crucial 16 GB DDR4 3200 MHz SODIMM RAM", "Bellek", "Crucial", "PIECE", "USD", 33.00, "FX_LINKED", 28, None, True, 36, 3, "penta", "B-01", None),
    ("Kingston Fury 16 GB DDR5 5600 MHz RAM", "Bellek", "Kingston", "PIECE", "USD", 48.00, "FX_LINKED", 25, None, True, 36, 2, "arena", "B-01", None),
    ("Kingston Fury 32 GB DDR5 5600 MHz RAM", "Bellek", "Kingston", "PIECE", "USD", 92.00, "FX_LINKED", 22, None, True, 36, 0, "arena", "B-02", "dead"),
    ("4 GB DDR3L 1600 MHz SODIMM RAM (yenilenmiş)", "Bellek", "Kingston", "PIECE", "USD", 9.50, "FX_LINKED", 40, None, True, 3, 2, "index", "B-02", None),
    # --- Çevre Birimleri
    ("Logitech M185 kablosuz mouse", "Çevre Birimleri", "Logitech", "PIECE", "USD", 9.80, "FX_LINKED", 40, None, False, 24, 8, "index", "B-01", None),
    ("Logitech B100 kablolu mouse", "Çevre Birimleri", "Logitech", "PIECE", "USD", 4.60, "FX_LINKED", 45, None, False, 24, 6, "index", "B-01", None),
    ("Rampage mekanik oyuncu klavyesi", "Çevre Birimleri", "Rampage", "PIECE", "USD", 24.00, "FX_LINKED", 35, None, False, 24, 2, "index", "B-01", None),
    ("Everest Türkçe Q kablolu klavye", "Çevre Birimleri", "Everest", "PIECE", "USD", 5.20, "FX_LINKED", 45, None, False, 24, 5, "index", "B-01", None),
    ("Logitech MK270 kablosuz klavye-mouse seti", "Çevre Birimleri", "Logitech", "PIECE", "USD", 22.00, "FX_LINKED", 35, None, False, 24, 4, "index", "B-01", "critical"),
    ("Rampage mikrofonlu kulaklık", "Çevre Birimleri", "Rampage", "PIECE", "USD", 11.00, "FX_LINKED", 40, None, False, 24, 3, "index", "B-01", None),
    ("Everest USB masaüstü hoparlör", "Çevre Birimleri", "Everest", "PIECE", "USD", 8.50, "FX_LINKED", 45, None, False, 24, 2, "index", "B-02", None),
    ("Logitech C270 HD web kamerası", "Çevre Birimleri", "Logitech", "PIECE", "USD", 21.00, "FX_LINKED", 35, None, False, 24, 2, "index", "B-01", None),
    ("Rampage XL mousepad 90×40 cm", "Çevre Birimleri", "Rampage", "PIECE", "USD", 4.20, "FX_LINKED", 50, None, False, 0, 3, "index", "B-02", None),
    ("Everest laptop soğutucu stand", "Çevre Birimleri", "Everest", "PIECE", "USD", 12.00, "FX_LINKED", 40, None, False, 12, 0, "index", "B-02", "dead"),
    ("Ugreen USB 3.0 4 port hub", "Çevre Birimleri", "Ugreen", "PIECE", "USD", 9.00, "FX_LINKED", 40, None, False, 24, 3, "index", "B-01", None),
    # --- Ağ Ürünleri
    ("TP-Link Archer T2U Nano USB Wi-Fi adaptör", "Ağ Ürünleri", "TP-Link", "PIECE", "USD", 11.00, "FX_LINKED", 40, None, False, 24, 4, "penta", "B-01", None),
    ("TP-Link Archer T5E PCIe Wi-Fi kart", "Ağ Ürünleri", "TP-Link", "PIECE", "USD", 24.00, "FX_LINKED", 32, None, False, 24, 1, "penta", "B-02", None),
    ("TP-Link Archer AX23 Wi-Fi 6 router", "Ağ Ürünleri", "TP-Link", "PIECE", "USD", 48.00, "FX_LINKED", 28, None, True, 24, 2, "penta", "B-01", None),
    ("TP-Link Archer VR300 VDSL modem", "Ağ Ürünleri", "TP-Link", "PIECE", "USD", 38.00, "FX_LINKED", 30, None, True, 24, 3, "penta", "B-01", "critical"),
    ("TP-Link TL-SG108 8 port gigabit switch", "Ağ Ürünleri", "TP-Link", "PIECE", "USD", 21.00, "FX_LINKED", 32, None, False, 24, 1, "penta", "B-02", None),
    ("TP-Link LS1005G 5 port switch", "Ağ Ürünleri", "TP-Link", "PIECE", "USD", 11.50, "FX_LINKED", 40, None, False, 24, 2, "penta", "B-02", None),
    ("TP-Link RE315 menzil genişletici", "Ağ Ürünleri", "TP-Link", "PIECE", "USD", 19.00, "FX_LINKED", 35, None, False, 24, 2, "penta", "B-01", None),
    ("Cat6 patch kablo 2 m", "Ağ Ürünleri", "Ugreen", "PIECE", "USD", 1.60, "FX_LINKED", 80, None, False, 0, 6, "index", "B-02", None),
    ("Cat6 patch kablo 5 m", "Ağ Ürünleri", "Ugreen", "PIECE", "USD", 2.80, "FX_LINKED", 70, None, False, 0, 4, "index", "B-02", None),
    ("RJ45 Cat6 konnektör 100'lü", "Ağ Ürünleri", "Ugreen", "PIECE", "USD", 6.00, "FX_LINKED", 60, None, False, 0, 1, "index", "B-02", None),
    ("Cat6 UTP kablo (metre)", "Ağ Ürünleri", "Hes Kablo", "METER", "TRY", 14.00, "FIXED", 0, 22.90, False, 0, 3, "ozdemir", "A-01", None),
    # --- Kablo & Adaptör
    ("HDMI kablo 1,5 m 4K", "Kablo & Adaptör", "Ugreen", "PIECE", "USD", 3.40, "FX_LINKED", 60, None, False, 12, 8, "index", "B-01", "critical"),
    ("HDMI kablo 3 m 4K", "Kablo & Adaptör", "Ugreen", "PIECE", "USD", 5.10, "FX_LINKED", 55, None, False, 12, 4, "index", "B-01", None),
    ("DisplayPort kablo 1,8 m", "Kablo & Adaptör", "Ugreen", "PIECE", "USD", 5.60, "FX_LINKED", 50, None, False, 12, 1, "index", "B-02", None),
    ("Baseus 65W USB-C GaN şarj adaptörü", "Kablo & Adaptör", "Baseus", "PIECE", "USD", 18.00, "FX_LINKED", 38, None, False, 24, 5, "index", "B-01", None),
    ("USB-C – USB-C kablo 1 m 60W", "Kablo & Adaptör", "Baseus", "PIECE", "USD", 3.20, "FX_LINKED", 60, None, False, 12, 9, "index", "B-01", None),
    ("USB-A – Lightning kablo 1 m", "Kablo & Adaptör", "Baseus", "PIECE", "USD", 3.60, "FX_LINKED", 60, None, False, 12, 5, "index", "B-01", None),
    ("VGA – HDMI çevirici", "Kablo & Adaptör", "Ugreen", "PIECE", "USD", 6.80, "FX_LINKED", 50, None, False, 12, 2, "index", "B-02", None),
    ("USB-C 6'sı 1 arada hub", "Kablo & Adaptör", "Ugreen", "PIECE", "USD", 19.00, "FX_LINKED", 38, None, False, 24, 2, "index", "B-01", None),
    ("Universal laptop adaptörü 90W", "Kablo & Adaptör", "Teknolife", "PIECE", "USD", 14.00, "FX_LINKED", 45, None, False, 12, 4, "index", "B-02", None),
    ("Bilgisayar güç kablosu 1,5 m", "Kablo & Adaptör", "Teknolife", "PIECE", "TRY", 38.00, "FIXED", 0, 64.90, False, 0, 4, "ozdemir", "B-02", None),
    ("SATA data kablosu", "Kablo & Adaptör", "Teknolife", "PIECE", "TRY", 22.00, "FIXED", 0, 39.90, False, 0, 2, "index", "B-02", None),
    ("USB-C – HDMI çevirici 4K", "Kablo & Adaptör", "Ugreen", "PIECE", "USD", 9.50, "FX_LINKED", 45, None, False, 12, 2, "index", "B-01", None),
    # --- Sarf
    ("Arctic MX-4 termal macun 4 g", "Sarf", "Arctic", "PIECE", "USD", 5.50, "FX_LINKED", 55, None, False, 0, 3, "index", "B-02", None),
    ("HP 85A uyumlu toner", "Sarf", "Teknolife", "PIECE", "TRY", 290.00, "FIXED", 0, 449.00, False, 6, 4, "sarf", "B-02", None),
    ("Canon 728 uyumlu toner", "Sarf", "Teknolife", "PIECE", "TRY", 310.00, "FIXED", 0, 479.00, False, 6, 0, "sarf", "DEPO-1", "dead"),
    ("HP 305 siyah mürekkep kartuşu", "Sarf", "HP", "PIECE", "TRY", 420.00, "FIXED", 0, 629.00, False, 6, 2, "sarf", "B-02", None),
    ("A4 fotokopi kâğıdı 500'lü", "Sarf", "Teknolife", "PIECE", "TRY", 118.00, "FIXED", 0, 169.90, False, 0, 5, "sarf", "DEPO-1", None),
    ("Ekran temizleme spreyi 200 ml", "Sarf", "Teknolife", "PIECE", "TRY", 42.00, "FIXED", 0, 74.90, False, 0, 3, "sarf", "B-02", None),
    ("CR2032 düğme pil 5'li", "Sarf", "Duracell", "PIECE", "TRY", 58.00, "FIXED", 0, 94.90, False, 0, 4, "sarf", "B-02", None),
    ("Duracell AA kalem pil 4'lü", "Sarf", "Duracell", "PIECE", "TRY", 88.00, "FIXED", 0, 139.90, False, 0, 6, "sarf", "B-02", None),
]

SERVICES = [
    # ad, satış TL, popülerlik
    ("Format + Windows kurulumu", 750.00, 5),
    ("Laptop fan temizliği ve termal macun", 900.00, 3),
    ("Veri kurtarma (ön inceleme)", 500.00, 1),
    ("Masaüstü bakım ve temizlik", 650.00, 2),
    ("Yazıcı kurulumu ve ayarı", 350.00, 1),
    ("Laptop ekran değişim işçiliği", 1200.00, 1),
    ("Elektrik arıza tespiti (saatlik)", 800.00, 1),
]
# fmt: on

FIRST_NAMES = [
    "Ahmet", "Mehmet", "Mustafa", "Ali", "Hüseyin", "Hasan", "İbrahim", "İsmail", "Yusuf", "Osman", "Murat", "Emre",
    "Burak", "Serkan", "Fatma", "Ayşe", "Emine", "Hatice", "Zeynep", "Elif", "Merve", "Şeyma", "Gül", "Özlem",
    "Derya", "Esra", "Cem", "Oğuz", "Kübra", "Gökhan",
]
LAST_NAMES = [
    "Yılmaz", "Kaya", "Demir", "Şahin", "Çelik", "Yıldız", "Yıldırım", "Öztürk", "Aydın", "Özdemir", "Arslan", "Doğan",
    "Kılıç", "Aslan", "Çetin", "Kara", "Koç", "Kurt", "Özkan", "Şimşek", "Polat", "Erdoğan", "Güneş", "Aksoy",
]
BUSINESS_CUSTOMERS = ["Kardeşler Yapı İnşaat", "Deniz Muhasebe Bürosu", "Özgür Emlak", "Yeşil Vadi Sitesi Yönetimi"]

COMPLAINTS = {
    "LAPTOP": ["Açılmıyor, şarj ışığı yanmıyor", "Çok ısınıyor ve fan sesi yüksek", "Ekranda dikey çizgiler var", "Klavyenin bazı tuşları çalışmıyor",
               "Çok yavaş açılıyor, format isteniyor", "Üzerine çay döküldü", "Şarj soketi gevşek"],
    "DESKTOP": ["Açılıyor ama görüntü gelmiyor", "Sürekli mavi ekran veriyor", "Bilgisayar kendiliğinden kapanıyor", "SSD takılıp Windows kurulacak"],
    "PRINTER": ["Kâğıt sıkıştırıyor", "Çıktılar soluk geliyor", "Bilgisayar yazıcıyı görmüyor"],
    "PHONE": ["Şarj olmuyor", "Ekran kırık, dokunmatik çalışmıyor"],
    "MONITOR": ["Görüntü gelip gidiyor", "Güç ışığı yanıp sönüyor"],
    "OTHER": ["Modem internet vermiyor", "Tablet açılmıyor"],
}
DEVICES = {
    "LAPTOP": [("Lenovo", "IdeaPad 3 15ITL6"), ("HP", "Pavilion 15-eg"), ("Asus", "VivoBook X515"), ("Dell", "Inspiron 3520"),
               ("Acer", "Aspire 5 A515"), ("Monster", "Abra A5 V19"), ("Casper", "Nirvana C600")],
    "DESKTOP": [("Hazır sistem", "i5-10400 / 8 GB"), ("HP", "ProDesk 400 G6"), ("Dell", "OptiPlex 3080")],
    "PRINTER": [("HP", "LaserJet P1102"), ("Canon", "i-SENSYS LBP6030"), ("Epson", "L3150")],
    "PHONE": [("Samsung", "Galaxy A54"), ("Xiaomi", "Redmi Note 12")],
    "MONITOR": [("Samsung", "S24R350"), ("LG", "24MK430H")],
    "OTHER": [("TP-Link", "Archer VR300"), ("Samsung", "Galaxy Tab A8")],
}
ACCESSORIES = ["Şarj adaptörü", "Çanta", "Güç kablosu", "Pil", "Mouse", "USB kablo"]
