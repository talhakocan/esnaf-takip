"""Demo verisi yükleyici.

Kullanım:
    python -m app.seed             # veritabanı boşsa demo verisini yükler
    python -m app.seed --reset     # tüm verileri siler ve demo verisini yeniden yükler (uygulama kapalıyken!)
"""

import argparse
import logging
import sys
import time

from sqlmodel import Session, select

from app.db import get_engine
from app.migrations import upgrade_db
from app.models import User
from app.seed.generator import generate


def is_empty() -> bool:
    with Session(get_engine()) as s:
        return s.exec(select(User.id)).first() is None


def reset() -> None:
    """Tüm tabloları siler (döngüsel yabancı anahtarlar nedeniyle kontroller geçici olarak kapatılır)."""
    eng = get_engine()
    raw = eng.raw_connection()
    try:
        cur = raw.cursor()
        cur.execute("PRAGMA foreign_keys=OFF")
        tables = [r[0] for r in cur.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'")]
        for name in tables:
            cur.execute(f'DROP TABLE IF EXISTS "{name}"')
        cur.execute("PRAGMA foreign_keys=ON")
        cur.close()
    finally:
        raw.close()
    eng.dispose()


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="python -m app.seed", description="Tezgâh demo verisi")
    parser.add_argument("--reset", action="store_true", help="Mevcut tüm verileri silip demo verisini yeniden yükle")
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.WARNING)
    if args.reset:
        print("Veritabanı sıfırlanıyor…")
        reset()
    upgrade_db()
    if not is_empty():
        print("Veritabanında kayıt var; demo verisi yüklenmedi. Sıfırlamak için: python -m app.seed --reset")
        return 0
    started = time.monotonic()
    print("Demo verisi üretiliyor (yaklaşık 1 dakika)…")
    with Session(get_engine()) as session:
        result = generate(session)
    print(
        f"Tamam: {result['products']} ürün, {result['customers']} müşteri, {result['sales']} satış "
        f"({time.monotonic() - started:.0f} sn)."
    )
    print("Giriş: yonetici / Tezgah2026!  ·  personel / Personel2026!")
    return 0


if __name__ == "__main__":
    sys.exit(main())
