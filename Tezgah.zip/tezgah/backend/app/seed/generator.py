"""Deterministik demo verisi üretici (sabit random seed).

Tüm kayıtlar gerçek servisler üzerinden, geriye dönük zaman damgalarıyla üretilir; böylece stok
defteri, cari hesap ve raporlar gerçek kullanımdaki gibi tutarlıdır. Olaylar zaman sırasıyla işlenir.
"""

import heapq
import itertools
import logging
import random
from collections.abc import Callable
from dataclasses import dataclass, field
from datetime import date, datetime, time, timedelta
from decimal import ROUND_CEILING, Decimal

from sqlmodel import Session

from app.core.deps import Actor
from app.core.errors import AppError
from app.core.money import apply_rounding, round_half_up
from app.core.security import hash_password
from app.models import (
    Brand,
    Category,
    Currency,
    Customer,
    ExchangeRate,
    LedgerEntry,
    LedgerType,
    Location,
    MovementType,
    Payment,
    PaymentMethod,
    POStatus,
    PriceHistory,
    PriceReason,
    PricingMode,
    Product,
    PurchaseOrder,
    Role,
    RoundingRule,
    ServiceStatus,
    Supplier,
    UnitType,
    User,
)
from app.schemas.ops import CountCreate, CountItemsIn, CountItemUpdate, POCreate, POItemIn, ReceiveIn, ReceiveItemIn
from app.schemas.sales import PaymentIn, ReturnCreate, ReturnItemIn
from app.schemas.service import DeliverIn, NoteCreate, PartAdd, StatusChange, TicketCreate, TicketUpdate
from app.seed import data as D
from app.services import count_service, pricing_service, purchase_service, sale_service, stock_service
from app.services import service_ticket_service as svc
from app.services.settings_service import DEFAULT_KVKK_TEXT, DEFAULT_SERVICE_TERMS, get_settings_row

log = logging.getLogger("tezgah.seed")
SEED = 2026
HISTORY_DAYS = 90
OPENING_DAYS = 100
SKU_PREFIX = {
    "Kablo": "KBL", "Sigorta & Şalter": "SGR", "Priz & Anahtar": "PRZ", "Aydınlatma": "AYD", "Uzatma & Grup Priz": "UZT",
    "Tesisat": "TST", "Depolama": "DPL", "Bellek": "RAM", "Çevre Birimleri": "CVR", "Ağ Ürünleri": "AG",
    "Kablo & Adaptör": "ADP", "Sarf": "SRF", "Hizmet": "HZM",
}
S = ServiceStatus


def ean13(body12: str) -> str:
    total = sum(int(d) * (3 if i % 2 else 1) for i, d in enumerate(body12))
    return body12 + str((10 - total % 10) % 10)


@dataclass
class Meta:
    popularity: int
    flag: str | None
    supplier_key: str
    base_stock: Decimal


@dataclass
class World:
    session: Session
    rng: random.Random
    today: date
    admin: Actor
    staff: Actor
    products: list[Product] = field(default_factory=list)
    meta: dict[int, Meta] = field(default_factory=dict)
    suppliers: dict[str, Supplier] = field(default_factory=dict)
    customers: list[Customer] = field(default_factory=list)
    credit_good: list[Customer] = field(default_factory=list)
    credit_bad: list[Customer] = field(default_factory=list)
    rates: dict[str, Decimal] = field(default_factory=dict)
    sales_done: list[int] = field(default_factory=list)
    counter: itertools.count = field(default_factory=itertools.count)
    queue: list = field(default_factory=list)

    def day(self, offset: int) -> date:
        return self.today - timedelta(days=offset)

    def at(self, d: date, h: int, m: int = 0, s: int = 0) -> datetime:
        return datetime.combine(d, time(h, m, s))

    def schedule(self, when: datetime, fn: Callable[[], None]) -> None:
        heapq.heappush(self.queue, (when, next(self.counter), fn))


# ---------------------------------------------------------------- kurulum


def _setup_basics(w: World) -> None:
    s = w.session
    st = get_settings_row(s)
    st.shop_name = "Teknolife"
    st.address = "Cumhuriyet Mah. Atatürk Cad. No: 42/B, Merkez"
    st.phone = "0 (212) 555 42 42"
    st.email = "info@teknolife.com.tr"
    st.tax_office = "Merkez"
    st.tax_no = "8430512976"
    st.receipt_footer = "Teknolife'ı tercih ettiğiniz için teşekkür ederiz. İade ve değişim 14 gün içinde, fiş ile yapılır."
    st.rounding_rule = RoundingRule.NEAREST_5
    st.service_terms = DEFAULT_SERVICE_TERMS
    st.kvkk_text = DEFAULT_KVKK_TEXT
    s.add(st)
    cats: dict[str, int] = {}
    for root, children in D.CATEGORIES.items():
        rc = Category(name=root)
        s.add(rc)
        s.flush()
        cats[root] = rc.id  # type: ignore[assignment]
        for child in children:
            cc = Category(name=child, parent_id=rc.id)
            s.add(cc)
            s.flush()
            cats[child] = cc.id  # type: ignore[assignment]
    w.cat_ids = cats  # type: ignore[attr-defined]
    w.brand_ids = {}  # type: ignore[attr-defined]
    for name in D.BRANDS:
        b = Brand(name=name)
        s.add(b)
        s.flush()
        w.brand_ids[name] = b.id  # type: ignore[attr-defined]
    w.loc_ids = {}  # type: ignore[attr-defined]
    for code, name in D.LOCATIONS:
        loc = Location(code=code, name=name)
        s.add(loc)
        s.flush()
        w.loc_ids[code] = loc.id  # type: ignore[attr-defined]
    opening = w.at(w.day(OPENING_DAYS + 5), 10)
    for key, name, contact, phone, email, cur in D.SUPPLIERS:
        sup = Supplier(name=name, contact=contact, phone=phone, email=email, currency=Currency(cur), created_at=opening, updated_at=opening)
        s.add(sup)
        s.flush()
        w.suppliers[key] = sup
    s.commit()


def _add_rate(w: World, when: datetime, usd: Decimal, eur: Decimal, reprice: bool) -> None:
    s = w.session
    for cur, val in (("USD", usd), ("EUR", eur)):
        s.add(ExchangeRate(currency=Currency(cur), rate=val, source="MANUAL", fetched_at=when, user_id=w.admin.id,
                           created_at=when, updated_at=when))
        w.rates[cur] = val
    s.flush()
    if not reprice:
        return
    rule = get_settings_row(s).rounding_rule
    for p in w.products:
        if p.pricing_mode != PricingMode.FX_LINKED:
            continue
        _, new = pricing_service.compute_fx_price(p.purchase_price, w.rates[p.purchase_currency.value], p.markup_pct, rule)
        if new != p.sale_price_kurus:
            s.add(PriceHistory(product_id=p.id, old_price=p.sale_price_kurus, new_price=new, reason=PriceReason.FX_UPDATE,  # type: ignore[arg-type]
                               user_id=w.admin.id, created_at=when, updated_at=when))
            p.sale_price_kurus = new
            s.add(p)


def _create_products(w: World) -> None:
    s = w.session
    rng = w.rng
    created = w.at(w.day(OPENING_DAYS + 3), 9, 30)
    seq: dict[str, int] = {}
    barcode_seq = itertools.count(100001)
    internal_seq = itertools.count(10000001)
    rule = get_settings_row(s).rounding_rule
    for row in D.PRODUCTS:
        name, cat, brand, unit, cur, pprice, mode, markup, sale_tl, serial, warranty, pop, sup_key, loc, flag = row
        prefix = SKU_PREFIX[cat]
        seq[prefix] = seq.get(prefix, 0) + 1
        if rng.random() < 0.8:
            barcode = ean13(f"869{rng.randint(1000, 9999)}{next(barcode_seq) % 100000:05d}")
        else:
            barcode = f"TL{next(internal_seq):08d}"
        p = Product(
            sku=f"{prefix}-{seq[prefix]:03d}", barcode=barcode, name=name, category_id=w.cat_ids[cat],  # type: ignore[attr-defined]
            brand_id=w.brand_ids[brand], supplier_id=w.suppliers[sup_key].id, location_id=w.loc_ids[loc],  # type: ignore[attr-defined]
            unit_type=UnitType(unit), vat_rate=20, purchase_currency=Currency(cur), purchase_price=Decimal(str(pprice)),
            pricing_mode=PricingMode(mode), markup_pct=Decimal(str(markup)), track_serial=serial, warranty_months=warranty,
            created_by=w.admin.id, created_at=created, updated_at=created,
        )
        if p.pricing_mode == PricingMode.FX_LINKED:
            _, p.sale_price_kurus = pricing_service.compute_fx_price(p.purchase_price, w.rates[cur], p.markup_pct, rule)
        else:
            p.sale_price_kurus = round_half_up(Decimal(str(sale_tl)) * 100)
        if p.unit_type == UnitType.METER:
            base = Decimal(rng.choice([300, 400, 500])) if pop >= 5 else Decimal(rng.choice([100, 150, 200]))
            p.min_stock = Decimal(50 if pop >= 5 else 25)
        else:
            base = Decimal(max(3, pop * 3 + rng.randint(2, 6))) if flag != "dead" else Decimal(rng.randint(3, 6))
            p.min_stock = Decimal(5 if pop >= 6 else 3 if pop >= 3 else 1)
        if flag == "critical":
            base = Decimal(max(6, int(base * Decimal("0.7")))) if p.unit_type == UnitType.PIECE else Decimal(150)
        s.add(p)
        s.flush()
        w.products.append(p)
        w.meta[p.id] = Meta(pop, flag, sup_key, base)  # type: ignore[index]
    hz = w.cat_ids["Hizmet"]  # type: ignore[attr-defined]
    for idx, (name, price, pop) in enumerate(D.SERVICES, start=1):
        p = Product(sku=f"HZM-{idx:03d}", name=name, category_id=hz, unit_type=UnitType.SERVICE, vat_rate=20,
                    sale_price_kurus=round_half_up(Decimal(str(price)) * 100), created_by=w.admin.id, created_at=created, updated_at=created)
        s.add(p)
        s.flush()
        w.products.append(p)
        w.meta[p.id] = Meta(pop, None, "ozdemir", Decimal(0))  # type: ignore[index]
    s.commit()


def _serials(w: World, product: Product, n: int) -> list[str]:
    prefix = "".join(ch for ch in (product.name.split()[0]).upper() if ch.isalnum())[:2] or "SN"
    return [f"{prefix}{w.rng.randint(10, 99)}{''.join(w.rng.choice('ABCDEFGHJKLMNPRSTUVWXYZ23456789') for _ in range(7))}" for _ in range(n)]


def _po_price(w: World, p: Product, sup: Supplier) -> Decimal:
    if p.purchase_currency == sup.currency:
        return p.purchase_price
    tl = p.purchase_price * w.rates.get(p.purchase_currency.value, Decimal(1))
    return (tl / w.rates.get(sup.currency.value, Decimal(1))).quantize(Decimal("0.01"))


def _receive_po(w: World, sup: Supplier, lines: list[tuple[Product, Decimal]], ordered: datetime, received: datetime, note: str) -> None:
    s = w.session
    po = purchase_service.create_order(s, w.admin, POCreate(supplier_id=sup.id, note=note, items=[
        POItemIn(product_id=p.id, qty=q, unit_price=_po_price(w, p, sup)) for p, q in lines]))  # type: ignore[arg-type]
    order = s.get(PurchaseOrder, po["id"])
    assert order is not None
    order.created_at = order.updated_at = ordered - timedelta(hours=1)
    order.status = POStatus.ORDERED
    order.ordered_at = ordered
    order.fx_rate = w.rates.get(sup.currency.value, Decimal(1))
    order.expected_at = received.date()
    s.add(order)
    s.commit()
    items = []
    for it in purchase_service.get_order(s, w.admin, order.id)["items"]:  # type: ignore[arg-type]
        p = s.get(Product, it["product_id"])
        assert p is not None
        items.append(ReceiveItemIn(item_id=it["id"], qty=it["qty"], serials=_serials(w, p, int(it["qty"])) if p.track_serial else []))
    purchase_service.receive(s, w.admin, order.id, ReceiveIn(items=items, fx_rate=w.rates.get(sup.currency.value), update_purchase_price=False), at=received)  # type: ignore[arg-type]


def _opening_stock(w: World) -> None:
    by_sup: dict[str, list[tuple[Product, Decimal]]] = {}
    for p in w.products:
        if p.unit_type == UnitType.SERVICE:
            continue
        by_sup.setdefault(w.meta[p.id].supplier_key, []).append((p, w.meta[p.id].base_stock))  # type: ignore[index]
    for key, lines in by_sup.items():
        _receive_po(w, w.suppliers[key], lines, w.at(w.day(OPENING_DAYS + 3), 11), w.at(w.day(OPENING_DAYS), 10, 15), "Açılış stoğu siparişi")


def _customers(w: World) -> None:
    s = w.session
    rng = w.rng
    names: set[str] = set()
    while len(names) < 36:
        names.add(f"{rng.choice(D.FIRST_NAMES)} {rng.choice(D.LAST_NAMES)}")
    all_names = sorted(names) + D.BUSINESS_CUSTOMERS
    rng.shuffle(all_names)
    for i, name in enumerate(all_names):
        when = w.at(w.day(rng.randint(10, OPENING_DAYS)), rng.randint(9, 18), rng.randint(0, 59))
        business = name in D.BUSINESS_CUSTOMERS
        c = Customer(
            full_name=name,
            phone=f"05{rng.choice(['30', '32', '33', '35', '42', '44', '52', '53', '54', '55'])}{rng.randint(1000000, 9999999)}",
            email=(f"{name.split()[0].lower().translate(str.maketrans('çğıöşüİ', 'cgiosui'))}@ornekmail.com" if rng.random() < 0.3 else ""),
            tax_no=str(rng.randint(1000000000, 9999999999)) if business else "",
            address=f"{rng.choice(['Yeni', 'Cumhuriyet', 'Fatih', 'Bahçelievler', 'Kültür'])} Mah. No: {rng.randint(1, 90)}" if rng.random() < 0.5 else "",
            credit_limit_kurus=0, kvkk_consent_at=when, created_by=w.staff.id, created_at=when, updated_at=when,
        )
        s.add(c)
        s.flush()
        w.customers.append(c)
    credit = w.customers[:9]
    for c in credit:
        c.credit_limit_kurus = rng.choice([1500000, 2000000, 3000000, 5000000])
        s.add(c)
    w.credit_good, w.credit_bad = credit[:4], credit[4:]
    s.commit()


# ---------------------------------------------------------------- olaylar


def _pick_products(w: World, n: int) -> list[Product]:
    pool = [p for p in w.products if w.meta[p.id].flag != "dead" and w.meta[p.id].popularity > 0  # type: ignore[index]
            and (p.unit_type == UnitType.SERVICE or p.stock_qty > 0) and p.sku != svc.LABOR_SKU]
    weights = [w.meta[p.id].popularity ** 1.3 for p in pool]  # type: ignore[index]
    chosen: list[Product] = []
    for _ in range(n * 3):
        p = w.rng.choices(pool, weights)[0]
        if p not in chosen:
            chosen.append(p)
        if len(chosen) == n:
            break
    return chosen


def _event_sale(w: World, when: datetime, force_customer: Customer | None = None, force_credit: bool = False) -> None:
    s, rng = w.session, w.rng
    actor = w.staff if rng.random() < 0.65 else w.admin
    n = rng.choices([1, 2, 3, 4], [50, 30, 15, 5])[0]
    lines: list[sale_service.Line] = []
    for p in _pick_products(w, n):
        if p.unit_type == UnitType.METER:
            q = Decimal(str(rng.choice([2, 3, 5, 7.5, 10, 12.5, 15, 20, 25, 50])))
            if q > p.stock_qty:
                continue
        elif p.unit_type == UnitType.SERVICE:
            q = Decimal(1)
        else:
            q = Decimal(rng.choices([1, 2, 3, 5], [80, 14, 4, 2])[0])
            if p.track_serial:
                q = Decimal(1)
            if q > p.stock_qty:
                q = p.stock_qty
            if q <= 0:
                continue
        serial = None
        if p.track_serial:
            avail = stock_service.available_serials(s, p.id)  # type: ignore[arg-type]
            if not avail:
                continue
            serial = rng.choice(avail)
        lines.append(sale_service.Line(product=p, qty=q, unit_price=p.sale_price_kurus, serial=serial))
    if not lines:
        return
    subtotal = sum(round_half_up(ln.qty * ln.unit_price) for ln in lines)
    discount = 0
    if rng.random() < 0.1 and subtotal > 20000:
        pct = Decimal(rng.choice([2, 3, 4, 5])) if actor is w.staff else Decimal(rng.choice([5, 7, 10]))
        discount = int((Decimal(subtotal) * pct / 100) // 100 * 100)
    total = subtotal - discount
    customer = force_customer
    if customer is None and rng.random() < 0.3:
        customer = rng.choice(w.customers)
    payments: list[PaymentIn] = []
    use_credit = force_credit or (customer in w.credit_good + w.credit_bad and rng.random() < 0.45)
    if use_credit and customer is not None:
        payments.append(PaymentIn(method=PaymentMethod.CREDIT, amount=total))
    else:
        r = rng.random()
        if r < 0.55:
            tendered = int((Decimal(total) / 5000).to_integral_value(rounding=ROUND_CEILING) * 5000)
            payments.append(PaymentIn(method=PaymentMethod.CASH, amount=total, tendered=max(tendered, total)))
        elif r < 0.93:
            payments.append(PaymentIn(method=PaymentMethod.CARD, amount=total))
        elif r < 0.96 or total < 20000:
            payments.append(PaymentIn(method=PaymentMethod.TRANSFER, amount=total))
        else:
            cash = total // 2 // 100 * 100
            payments += [PaymentIn(method=PaymentMethod.CASH, amount=cash), PaymentIn(method=PaymentMethod.CARD, amount=total - cash)]
    try:
        sale = sale_service.create_sale_core(s, actor, lines, discount, payments, customer.id if customer else None, at=when)
    except AppError:
        s.rollback()
        return
    s.commit()
    w.sales_done.append(sale.id)  # type: ignore[arg-type]
    if rng.random() < 1 / 70 and when.date() != w.today and not use_credit:
        w.schedule(when + timedelta(minutes=rng.randint(4, 40)), lambda sid=sale.id, t=when: _event_cancel(w, sid, t))
    elif rng.random() < 1 / 110:
        later = when + timedelta(days=rng.randint(1, 6), hours=rng.randint(0, 3))
        if later.date() < w.today:
            w.schedule(later, lambda sid=sale.id, t=later: _event_return(w, sid, t))


def _event_cancel(w: World, sale_id: int, sale_time: datetime) -> None:
    when = sale_time + timedelta(minutes=w.rng.randint(5, 45))
    if when.date() != sale_time.date():
        return
    reason = w.rng.choice(["Müşteri vazgeçti", "Yanlış ürün okutuldu", "Fiyat hatası, yeniden kesildi"])
    try:
        sale_service.cancel_sale(w.session, w.admin, sale_id, reason, at=when)
    except AppError:
        w.session.rollback()


def _event_return(w: World, sale_id: int, when: datetime) -> None:
    s = w.session
    detail = sale_service.get_sale(s, w.admin, sale_id)
    if detail["status"] != "COMPLETED" or detail["service_ticket_id"]:
        return
    item = detail["items"][0]
    restock = w.rng.random() < 0.7
    method = PaymentMethod.CREDIT if any(p["method"] == "CREDIT" for p in detail["payments"]) else PaymentMethod.CASH
    qty = Decimal(1) if item["unit_type"] != "METER" else min(Decimal(5), item["qty"])
    try:
        sale_service.create_return(s, w.staff, ReturnCreate(sale_id=sale_id, items=[ReturnItemIn(sale_item_id=item["id"], qty=qty, restock=restock)],
                                                            method=method, reason="Müşteri iadesi" if restock else "Arızalı ürün, fire"), at=when)
    except AppError:
        s.rollback()


def _event_restock(w: World, when: datetime) -> None:
    """Pazartesi: tedarikçi başına min. stok altına inen ürünler için sipariş (3 gün önce verilmiş) teslim alınır."""
    late = (w.today - when.date()).days < 40
    by_sup: dict[str, list[tuple[Product, Decimal]]] = {}
    for p in w.products:
        m = w.meta[p.id]  # type: ignore[index]
        if p.unit_type == UnitType.SERVICE or m.flag == "dead" or (m.flag == "critical" and late):
            continue
        if p.stock_qty <= max(p.min_stock * Decimal("1.5"), m.base_stock * Decimal("0.35")):
            need = m.base_stock - p.stock_qty
            if p.unit_type == UnitType.PIECE:
                need = need.to_integral_value(rounding=ROUND_CEILING)
            if need > 0:
                by_sup.setdefault(m.supplier_key, []).append((p, need))
    for key, lines in by_sup.items():
        _receive_po(w, w.suppliers[key], lines, when - timedelta(days=w.rng.choice([3, 4, 5]), hours=1), when, "Haftalık stok yenileme")


def _event_collection(w: World, customer: Customer, when: datetime, full: bool = False) -> None:
    s = w.session
    from app.services import customer_service

    bal = customer_service.balance(s, customer.id)  # type: ignore[arg-type]
    if bal <= 0:
        return
    amount = bal if full or w.rng.random() < 0.6 else max(10000, bal // 2 // 100 * 100)
    method = w.rng.choice([PaymentMethod.CASH, PaymentMethod.CASH, PaymentMethod.TRANSFER])
    pay = Payment(customer_id=customer.id, method=method, amount=amount, user_id=w.staff.id, created_at=when, updated_at=when)
    s.add(pay)
    s.flush()
    s.add(LedgerEntry(customer_id=customer.id, type=LedgerType.PAYMENT, amount=amount,  # type: ignore[arg-type]
                      description=f"Tahsilat ({customer_service.METHOD_TR[method]})", ref_type="PAYMENT", ref_id=pay.id,
                      user_id=w.staff.id, created_at=when, updated_at=when))
    s.commit()


def _event_price_raise(w: World, when: datetime) -> None:
    """Kablo tedarikçisinin zammı: sabit fiyatlı kablolarda %8 toplu fiyat artışı."""
    s = w.session
    targets = [p for p in w.products if p.pricing_mode == PricingMode.FIXED and p.unit_type == UnitType.METER]
    for p in targets:
        new = apply_rounding(round_half_up(Decimal(p.sale_price_kurus) * Decimal("1.08")), RoundingRule.END_90)
        s.add(PriceHistory(product_id=p.id, old_price=p.sale_price_kurus, new_price=new, reason=PriceReason.BULK,  # type: ignore[arg-type]
                           user_id=w.admin.id, created_at=when, updated_at=when))
        p.sale_price_kurus = new
        s.add(p)
    audit_extra = {"pct": "8", "count": len(targets), "product_ids": [p.id for p in targets]}
    from app.core import audit

    audit.record(s, w.admin, "product.bulk_price", "product", None, None, None, audit_extra, at=when)
    s.commit()


def _event_waste(w: World, when: datetime) -> None:
    candidates = [p for p in w.products if p.unit_type != UnitType.SERVICE and not p.track_serial and p.stock_qty > 2
                  and w.meta[p.id].flag != "dead"]  # type: ignore[index]
    p = w.rng.choice(candidates)
    q = Decimal(1) if p.unit_type == UnitType.PIECE else Decimal(w.rng.choice([1, 2, 3]))
    note = "Kablo kesim firesi" if p.unit_type == UnitType.METER else w.rng.choice(["Rafta kırıldı", "Ambalajı hasarlı, satılamaz", "Kutudan arızalı çıktı"])
    stock_service.apply_movement(w.session, p, MovementType.WASTE, -q, w.staff.id, ref_type="MANUAL", note=note, at=when)
    w.session.commit()


# ---------------------------------------------------------------- servis kayıtları

TICKET_PLAN = (
    [S.DELIVERED] * 9 + [S.CANCELLED] * 2 + [S.READY] * 3 + [S.IN_REPAIR] * 3 + [S.WAITING_PARTS] * 3
    + [S.WAITING_APPROVAL] * 2 + [S.DIAGNOSING] * 2 + [S.RECEIVED] * 1
)
PATHS = {
    S.RECEIVED: [],
    S.DIAGNOSING: [S.DIAGNOSING],
    S.WAITING_APPROVAL: [S.DIAGNOSING, S.WAITING_APPROVAL],
    S.WAITING_PARTS: [S.DIAGNOSING, S.WAITING_APPROVAL, S.WAITING_PARTS],
    S.IN_REPAIR: [S.DIAGNOSING, S.WAITING_APPROVAL, S.IN_REPAIR],
    S.READY: [S.DIAGNOSING, S.IN_REPAIR, S.READY],
    S.DELIVERED: [S.DIAGNOSING, S.WAITING_APPROVAL, S.IN_REPAIR, S.READY],
    S.CANCELLED: [S.DIAGNOSING, S.CANCELLED],
}
STATUS_NOTES = {
    S.DIAGNOSING: "Arıza tespiti başladı.",
    S.WAITING_APPROVAL: "Fiyat bilgisi müşteriye iletildi, onay bekleniyor.",
    S.WAITING_PARTS: "Parça siparişi verildi.",
    S.IN_REPAIR: "Müşteri onay verdi, onarıma alındı.",
    S.READY: "Onarım tamamlandı, test edildi.",
    S.CANCELLED: "Müşteri onarımı onaylamadı, cihaz onarılmadan iade edilecek.",
}


def _plan_tickets(w: World) -> None:
    rng = w.rng
    plan = TICKET_PLAN[:]
    rng.shuffle(plan)
    for i, final in enumerate(plan):
        if final in (S.DELIVERED, S.CANCELLED):
            start = rng.randint(12, 70)
        elif final in (S.WAITING_PARTS, S.IN_REPAIR) and i % 2 == 0:
            start = rng.randint(8, 14)  # 7 günü aşmış açık kayıtlar
        else:
            start = rng.randint(0, 6)
        d = w.day(start)
        if d.weekday() == 6:
            d -= timedelta(days=1)
            start += 1
        received = w.at(d, rng.randint(9, 17), rng.randint(0, 59))
        if d == w.today:
            received = min(received, datetime.now().replace(microsecond=0) - timedelta(minutes=30))
        w.schedule(received, lambda f=final, r=received, st=start: _ticket_create(w, f, r, st))


def _ticket_create(w: World, final: ServiceStatus, received: datetime, start_offset: int) -> None:
    rng, s = w.rng, w.session
    dtype = rng.choices(list(D.DEVICES), [45, 20, 12, 6, 7, 10])[0]
    brand, model = rng.choice(D.DEVICES[dtype])
    customer = rng.choice(w.customers)
    accessories = rng.sample(D.ACCESSORIES[:3], rng.randint(0, 2)) if dtype == "LAPTOP" else (["Güç kablosu"] if rng.random() < 0.5 else [])
    t = svc.create_ticket(s, w.staff, TicketCreate(
        customer_id=customer.id, device_type=dtype, brand=brand, model=model,
        serial_no="".join(rng.choice("ABCDEFGHJKLMNPRSTUVWXYZ0123456789") for _ in range(10)),
        accessories=accessories, complaint=rng.choice(D.COMPLAINTS[dtype]),
        estimated_cost=rng.choice([50000, 75000, 90000, 120000, 150000, 250000]), assigned_to=w.admin.id,
    ), at=received)
    path = PATHS[final]
    if not path:
        return
    # Açık kayıtlarda son durum değişikliği bekleme süresine uygun olsun (parça bekleyenler 3+ gün).
    span_days = max(start_offset - (rng.randint(4, 6) if final == S.WAITING_PARTS else 0), 0)
    total_minutes = max(span_days * 24 * 60, 90)
    step = total_minutes // (len(path) + (1 if final == S.DELIVERED else 0))
    when = received
    latest = datetime.now().replace(microsecond=0)
    for idx, st in enumerate(path):
        when = when + timedelta(minutes=max(step, 30))
        if when.weekday() == 6:
            when += timedelta(days=1)
        if when.hour >= 19 or when.hour < 9:
            when = datetime.combine(when.date() + timedelta(days=1 if when.hour >= 19 else 0), time(rng.randint(9, 11), rng.randint(0, 59)))
        # Bugün açılan kayıtlarda adımlar geleceğe taşmasın.
        when = max(received + timedelta(minutes=idx + 1), min(when, latest - timedelta(minutes=5 * (len(path) - idx) + 5)))
        w.schedule(when, lambda tid=t["id"], st=st, i=idx, fin=final, ln=len(path), wh=when: _ticket_step(w, tid, st, i, fin, ln, wh))
    if final == S.DELIVERED:
        deliver_at = when + timedelta(minutes=max(step, 60))
        if deliver_at.weekday() == 6:
            deliver_at += timedelta(days=1)
        if deliver_at.hour >= 19 or deliver_at.hour < 9:
            deliver_at = datetime.combine(deliver_at.date() + timedelta(days=1 if deliver_at.hour >= 19 else 0), time(rng.randint(10, 17), 5))
        if deliver_at.date() > w.today or deliver_at > datetime.now():
            deliver_at = datetime.now().replace(microsecond=0) - timedelta(minutes=5)
        w.schedule(deliver_at, lambda tid=t["id"], wh=deliver_at: _ticket_deliver(w, tid, wh))


def _ticket_step(w: World, ticket_id: int, status: ServiceStatus, idx: int, final: ServiceStatus, length: int, when: datetime) -> None:
    s, rng = w.session, w.rng
    if status == S.DIAGNOSING or (status == S.IN_REPAIR and rng.random() < 0.5):
        diag = rng.choice(["Anakart şarj entegresi arızalı.", "SSD arızalı, veri okunamıyor.", "Fan tozlanmış, termal macun kurumuş.",
                           "İşletim sistemi bozuk, format gerekli.", "RAM modülü arızalı.", "Güç soketi değişmeli."])
        svc.update_ticket(s, w.admin, ticket_id, TicketUpdate(diagnosis=diag, labor_fee=rng.choice([30000, 40000, 50000, 60000])))
    if status == S.IN_REPAIR or (status == S.READY and idx == 1):
        parts = [p for p in w.products if p.stock_qty > 0 and w.meta[p.id].flag != "dead"  # type: ignore[index]
                 and (p.category_id in (w.cat_ids["Depolama"], w.cat_ids["Bellek"], w.cat_ids["Sarf"]))]  # type: ignore[attr-defined]
        if parts and rng.random() < 0.8:
            p = rng.choice(parts)
            serial_id = None
            if p.track_serial:
                avail = stock_service.available_serials(s, p.id)  # type: ignore[arg-type]
                if avail:
                    serial_id = avail[0].id
            if not p.track_serial or serial_id:
                try:
                    svc.add_part(s, w.admin, ticket_id, PartAdd(product_id=p.id, qty=Decimal(1), serial_id=serial_id), at=when)  # type: ignore[arg-type]
                except AppError:
                    s.rollback()
    notify = status in (S.WAITING_APPROVAL, S.READY, S.WAITING_PARTS)
    try:
        svc.change_status(s, w.admin if rng.random() < 0.6 else w.staff, ticket_id, StatusChange(status=status, note=STATUS_NOTES[status],
                                                                                                  notify_customer=notify), at=when)
    except AppError:
        s.rollback()
        return
    if status == S.RECEIVED:
        return
    if rng.random() < 0.3:
        svc.add_note(s, w.staff, ticket_id, NoteCreate(body=rng.choice(["Müşteri arandı, bilgi verildi.", "Yedek alınması istendi.",
                                                                        "Şifre teslimde müşteriden alınacak."]), visibility="INTERNAL"))


def _ticket_deliver(w: World, ticket_id: int, when: datetime) -> None:
    s = w.session
    t = svc.get_ticket(s, w.admin, ticket_id)
    if t["status"] != S.READY:
        return
    total = t["total"]
    payments = []
    if total > 0:
        method = w.rng.choice([PaymentMethod.CASH, PaymentMethod.CARD, PaymentMethod.CARD])
        payments = [PaymentIn(method=method, amount=total)]
    try:
        svc.deliver(s, w.staff, ticket_id, DeliverIn(payments=payments), at=when)
    except AppError:
        s.rollback()


# ---------------------------------------------------------------- ana akış


def generate(session: Session, today: date | None = None) -> dict[str, int]:
    rng = random.Random(SEED)
    today = today or date.today()
    now_dt = datetime.now().replace(microsecond=0)
    admin = User(username="yonetici", full_name="Serkan Aydın", role=Role.ADMIN, password_hash=hash_password("Tezgah2026!"),
                 max_discount_pct=Decimal(100))
    staff = User(username="personel", full_name="Mehmet Kaya", role=Role.STAFF, password_hash=hash_password("Personel2026!"),
                 max_discount_pct=Decimal(5))
    session.add(admin)
    session.add(staff)
    session.commit()
    w = World(session=session, rng=rng, today=today, admin=Actor(user=admin, ip="127.0.0.1"), staff=Actor(user=staff, ip="192.168.1.24"))
    _setup_basics(w)

    # Kur geçmişi: 14 günde bir güncellenmiş, son güncelleme bugün sabah.
    usd, eur = Decimal("43.18"), Decimal("50.42")
    _add_rate(w, w.at(w.day(OPENING_DAYS + 4), 9, 10), usd, eur, reprice=False)
    _create_products(w)
    _customers(w)
    _opening_stock(w)

    for offset in range(HISTORY_DAYS, -1, -1):
        d = w.day(offset)
        is_today = d == today
        if offset % 14 == 0 and offset > 0:
            usd = (usd * Decimal(str(1 + rng.uniform(0.002, 0.012)))).quantize(Decimal("0.0001"))
            eur = (eur * Decimal(str(1 + rng.uniform(0.001, 0.013)))).quantize(Decimal("0.0001"))
            w.schedule(w.at(d, 9, 5), lambda a=usd, b=eur, t=w.at(d, 9, 5): _add_rate(w, t, a, b, reprice=True))
        if is_today:
            t = min(w.at(d, 9, 12), now_dt - timedelta(minutes=1))
            w.schedule(t, lambda a=Decimal("44.8515"), b=Decimal("52.3870"), t=t: _add_rate(w, t, a, b, reprice=True))
        if d.weekday() == 6 and not is_today:
            continue
        if d.weekday() == 0 and offset > 0:
            w.schedule(w.at(d, 9, 30), lambda t=w.at(d, 9, 30): _event_restock(w, t))
        count = rng.randint(15, 25) if d.weekday() == 5 else rng.randint(5, 20)
        end_min = 19 * 60 + 30
        if is_today:
            end_min = min(end_min, max(9 * 60 + 20, now_dt.hour * 60 + now_dt.minute - 2))
            count = max(3, int(count * max(0.2, (end_min - 540) / 630)))
        for minute in sorted(rng.randint(9 * 60, end_min) for _ in range(count)):
            when = w.at(d, minute // 60, minute % 60, rng.randint(0, 59))
            w.schedule(when, lambda t=when: _event_sale(w, t))
        if rng.random() < 0.18 and not is_today:
            w.schedule(w.at(d, 18, 40), lambda t=w.at(d, 18, 40): _event_waste(w, t))
        if rng.random() < 0.12 and not is_today:
            c = rng.choice(w.credit_good)
            w.schedule(w.at(d, rng.randint(10, 18), 20), lambda c=c, t=w.at(d, rng.randint(10, 18), 20): _event_collection(w, c, t))
    # Ödemeyen veresiye müşterileri: her birine 40+ gün önce bir veresiye satış (vadesi geçmiş borç).
    for i, c in enumerate(w.credit_bad):
        d = w.day(62 - i * 4)
        if d.weekday() == 6:
            d -= timedelta(days=1)
        t = w.at(d, 15, 10 + i)
        w.schedule(t, lambda c=c, t=t: _event_sale(w, t, force_customer=c, force_credit=True))
    raise_day = w.day(45)
    w.schedule(w.at(raise_day, 8, 50), lambda t=w.at(raise_day, 8, 50): _event_price_raise(w, t))
    _plan_tickets(w)

    while w.queue:
        _, _, fn = heapq.heappop(w.queue)
        fn()

    _finalize(w)
    return {
        "products": len(w.products),
        "customers": len(w.customers),
        "sales": len(w.sales_done),
    }


def _finalize(w: World) -> None:
    s, rng = w.session, w.rng
    from app.services import customer_service

    # Vadesi geçmiş borç: tam olarak 5 müşteri (kötü ödeyenler); diğerlerinin vadesi geçmiş borcu tahsil edilir.
    overdue = customer_service.overdue_amounts(s)
    bad_ids = {c.id for c in w.credit_bad}
    for cid, amount in overdue.items():
        if cid not in bad_ids:
            c = s.get(Customer, cid)
            if c is not None and amount > 0:
                _event_collection(w, c, w.at(w.day(1), 16, 30), full=True)
    # Kritik stok: tam olarak 8 ürün (işaretli olanlar); diğerlerinde min. stok mevcut stoğun altında tutulur.
    for p in w.products:
        if p.unit_type == UnitType.SERVICE:
            continue
        m = w.meta[p.id]  # type: ignore[index]
        if m.flag == "critical":
            p.min_stock = p.stock_qty + (Decimal(rng.randint(2, 5)) if p.unit_type == UnitType.PIECE else Decimal(60))
        elif p.stock_qty <= p.min_stock:
            p.min_stock = max(Decimal(0), p.stock_qty - (1 if p.unit_type == UnitType.PIECE else 10))
            if p.unit_type == UnitType.PIECE:
                p.min_stock = p.min_stock.to_integral_value()
        s.add(p)
    s.commit()

    # Açık sayım (raf A-02, kısmen sayılmış).
    loc_id = w.loc_ids["A-02"]  # type: ignore[attr-defined]
    count = count_service.create_count(s, w.staff, CountCreate(name="Haftalık raf sayımı · A-02", location_id=loc_id))
    updates = []
    for it in count["items"]:
        if rng.random() < 0.6:
            diff = rng.choice([0, 0, 0, 0, -1, 1, -2])
            updates.append(CountItemUpdate(product_id=it["product_id"], counted_qty=max(Decimal(0), Decimal(it["expected_qty"]) + diff)))
    if updates:
        count_service.update_items(s, w.staff, count["id"], CountItemsIn(items=updates))

    # İki açık satın alma siparişi: biri sipariş verilmiş, biri taslak.
    arena = w.suppliers["arena"]
    arena_products = [p for p in w.products if p.supplier_id == arena.id and w.meta[p.id].flag != "dead"][:3]  # type: ignore[index]
    po = purchase_service.create_order(s, w.admin, POCreate(
        supplier_id=arena.id, expected_at=w.today + timedelta(days=3), note="Kampanya öncesi SSD ve RAM takviyesi",
        items=[POItemIn(product_id=p.id, qty=Decimal(rng.choice([5, 10])), unit_price=p.purchase_price) for p in arena_products]))  # type: ignore[arg-type]
    purchase_service.mark_ordered(s, w.admin, po["id"])
    ozdemir = w.suppliers["ozdemir"]
    try:
        purchase_service.from_critical(s, w.admin, ozdemir.id)  # type: ignore[arg-type]
    except AppError:
        s.rollback()

    s.commit()
    assert not stock_service.ledger_mismatches(s), "Stok defteri tutarsız"
