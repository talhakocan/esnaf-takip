"""Uygulama ayarları (ortam değişkenleri: TEZGAH_*)."""

import os
import secrets
from functools import lru_cache
from pathlib import Path

from pydantic_settings import BaseSettings, SettingsConfigDict

# resolve() kullanılmaz: bazı Windows kurulumlarında klasör yönlendirmesi erişilemeyen yola çözülür.
ROOT_DIR = Path(os.path.abspath(__file__)).parents[2]
DATA_DIR = ROOT_DIR / "data"


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="TEZGAH_", env_file=ROOT_DIR / ".env", extra="ignore")

    database_url: str = f"sqlite:///{(DATA_DIR / 'tezgah.db').as_posix()}"
    secret_key: str = ""
    token_hours: int = 12
    cookie_name: str = "tezgah_token"
    cookie_secure: bool = False
    backup_dir: Path = ROOT_DIR / "backups"
    backup_keep: int = 14
    frontend_dist: Path = ROOT_DIR / "frontend" / "dist"
    enable_scheduler: bool = True
    tcmb_url: str = "https://www.tcmb.gov.tr/kurlar/today.xml"
    app_version: str = "1.0.0"


@lru_cache
def get_settings() -> Settings:
    return Settings()


def get_secret_key() -> str:
    """Ortamda anahtar yoksa data/secret.key dosyasından okur, yoksa üretir."""
    settings = get_settings()
    if settings.secret_key:
        return settings.secret_key
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    key_file = DATA_DIR / "secret.key"
    if not key_file.exists():
        key_file.write_text(secrets.token_urlsafe(48), encoding="utf-8")
    return key_file.read_text(encoding="utf-8").strip()
