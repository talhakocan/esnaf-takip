from fastapi import APIRouter, Depends, Request
from sqlmodel import Session

from app.core.deps import Actor, require
from app.core.permissions import P
from app.core.ratelimit import enforce, track_limiter
from app.db import get_session
from app.schemas.service import DeliverIn, NoteCreate, PartAdd, StatusChange, TicketCreate, TicketUpdate
from app.services import service_ticket_service as svc

router = APIRouter(tags=["Teknik servis"])


@router.get("/service-tickets")
def list_tickets(
    status: str | None = None,
    q: str | None = None,
    assigned_to: int | None = None,
    customer_id: int | None = None,
    _: Actor = Depends(require(P.SERVICE_READ)),
    session: Session = Depends(get_session),
):
    return svc.list_tickets(session, status, q, assigned_to, customer_id)


@router.post("/service-tickets")
def create_ticket(data: TicketCreate, actor: Actor = Depends(require(P.SERVICE_WRITE)), session: Session = Depends(get_session)):
    return svc.create_ticket(session, actor, data)


@router.get("/service-tickets/{ticket_id}")
def get_ticket(ticket_id: int, actor: Actor = Depends(require(P.SERVICE_READ)), session: Session = Depends(get_session)):
    return svc.get_ticket(session, actor, ticket_id)


@router.patch("/service-tickets/{ticket_id}")
def update_ticket(
    ticket_id: int, data: TicketUpdate, actor: Actor = Depends(require(P.SERVICE_WRITE)), session: Session = Depends(get_session)
):
    return svc.update_ticket(session, actor, ticket_id, data)


@router.post("/service-tickets/{ticket_id}/status")
def change_status(
    ticket_id: int, data: StatusChange, actor: Actor = Depends(require(P.SERVICE_WRITE)), session: Session = Depends(get_session)
):
    return svc.change_status(session, actor, ticket_id, data)


@router.post("/service-tickets/{ticket_id}/notes")
def add_note(ticket_id: int, data: NoteCreate, actor: Actor = Depends(require(P.SERVICE_WRITE)), session: Session = Depends(get_session)):
    return svc.add_note(session, actor, ticket_id, data)


@router.post("/service-tickets/{ticket_id}/parts")
def add_part(ticket_id: int, data: PartAdd, actor: Actor = Depends(require(P.SERVICE_WRITE)), session: Session = Depends(get_session)):
    return svc.add_part(session, actor, ticket_id, data)


@router.post("/service-tickets/{ticket_id}/parts/{part_id}/remove")
def remove_part(ticket_id: int, part_id: int, actor: Actor = Depends(require(P.SERVICE_WRITE)), session: Session = Depends(get_session)):
    return svc.remove_part(session, actor, ticket_id, part_id)


@router.post("/service-tickets/{ticket_id}/deliver")
def deliver(ticket_id: int, data: DeliverIn, actor: Actor = Depends(require(P.SERVICE_WRITE)), session: Session = Depends(get_session)):
    actor.require(P.SALE_CREATE)
    return svc.deliver(session, actor, ticket_id, data)


@router.get("/public/track/{code}", tags=["Herkese açık"])
def public_track(code: str, request: Request, session: Session = Depends(get_session)):
    """Giriş gerektirmez. Kişisel veri döndürmez."""
    enforce(track_limiter, request, "track")
    return svc.public_track(session, code)
