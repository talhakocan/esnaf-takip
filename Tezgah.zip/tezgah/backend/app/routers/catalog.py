from fastapi import APIRouter, Depends
from sqlmodel import Session

from app.core.deps import Actor, require
from app.core.permissions import P
from app.db import get_session
from app.schemas.catalog import BrandIn, CategoryIn, LocationIn
from app.services import catalog_service

router = APIRouter(tags=["Katalog"])


@router.get("/categories")
def categories(_: Actor = Depends(require(P.PRODUCT_READ)), session: Session = Depends(get_session)) -> list[dict]:
    return catalog_service.list_categories(session)


@router.post("/categories")
def create_category(data: CategoryIn, actor: Actor = Depends(require(P.CATALOG_WRITE)), session: Session = Depends(get_session)):
    return catalog_service.save_category(session, actor, data)


@router.patch("/categories/{category_id}")
def update_category(
    category_id: int, data: CategoryIn, actor: Actor = Depends(require(P.CATALOG_WRITE)), session: Session = Depends(get_session)
):
    return catalog_service.save_category(session, actor, data, category_id)


@router.get("/brands")
def brands(_: Actor = Depends(require(P.PRODUCT_READ)), session: Session = Depends(get_session)):
    return catalog_service.list_brands(session)


@router.post("/brands")
def create_brand(data: BrandIn, actor: Actor = Depends(require(P.CATALOG_WRITE)), session: Session = Depends(get_session)):
    return catalog_service.save_brand(session, actor, data)


@router.patch("/brands/{brand_id}")
def update_brand(brand_id: int, data: BrandIn, actor: Actor = Depends(require(P.CATALOG_WRITE)), session: Session = Depends(get_session)):
    return catalog_service.save_brand(session, actor, data, brand_id)


@router.get("/locations")
def locations(_: Actor = Depends(require(P.PRODUCT_READ)), session: Session = Depends(get_session)):
    return catalog_service.list_locations(session)


@router.post("/locations")
def create_location(data: LocationIn, actor: Actor = Depends(require(P.CATALOG_WRITE)), session: Session = Depends(get_session)):
    return catalog_service.save_location(session, actor, data)


@router.patch("/locations/{location_id}")
def update_location(
    location_id: int, data: LocationIn, actor: Actor = Depends(require(P.CATALOG_WRITE)), session: Session = Depends(get_session)
):
    return catalog_service.save_location(session, actor, data, location_id)
