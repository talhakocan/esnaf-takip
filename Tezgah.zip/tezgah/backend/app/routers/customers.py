from datetime import date

from fastapi import APIRouter, Depends, Query
from sqlmodel import Session

from app.core.deps import Actor, require
from app.core.permissions import P
from app.db import get_session
from app.schemas.ops import CustomerAdjustIn, CustomerIn, CustomerPaymentIn, CustomerUpdate
from app.services import customer_service

router = APIRouter(prefix="/customers", tags=["Cari"])


@router.get("")
def list_customers(
    q: str | None = None,
    filter: str | None = Query(default=None, pattern="^(debt|overdue)$"),
    active: str = Query(default="active", pattern="^(active|archived|all)$"),
    _: Actor = Depends(require(P.CUSTOMER_READ)),
    session: Session = Depends(get_session),
):
    return customer_service.list_customers(session, q, filter, active)


@router.post("")
def create_customer(data: CustomerIn, actor: Actor = Depends(require(P.CUSTOMER_WRITE)), session: Session = Depends(get_session)):
    return customer_service.save_customer(session, actor, data.model_dump())


@router.get("/{customer_id}")
def get_customer(customer_id: int, _: Actor = Depends(require(P.CUSTOMER_READ)), session: Session = Depends(get_session)):
    return customer_service.get_customer(session, customer_id)


@router.patch("/{customer_id}")
def update_customer(
    customer_id: int, data: CustomerUpdate, actor: Actor = Depends(require(P.CUSTOMER_WRITE)), session: Session = Depends(get_session)
):
    return customer_service.save_customer(session, actor, data.model_dump(exclude_unset=True), customer_id)


@router.get("/{customer_id}/statement")
def statement(
    customer_id: int,
    date_from: date | None = Query(default=None, alias="from"),
    date_to: date | None = Query(default=None, alias="to"),
    _: Actor = Depends(require(P.CUSTOMER_READ)),
    session: Session = Depends(get_session),
):
    return customer_service.statement(session, customer_id, date_from, date_to)


@router.post("/{customer_id}/payments")
def collect(
    customer_id: int, data: CustomerPaymentIn, actor: Actor = Depends(require(P.CUSTOMER_PAYMENT)), session: Session = Depends(get_session)
):
    return customer_service.collect_payment(session, actor, customer_id, data.amount, data.method, data.note)


@router.post("/{customer_id}/adjust")
def adjust(
    customer_id: int, data: CustomerAdjustIn, actor: Actor = Depends(require(P.CUSTOMER_ADJUST)), session: Session = Depends(get_session)
):
    return customer_service.adjust_balance(session, actor, customer_id, data.amount, data.description)
