from datetime import date, timedelta

from fastapi import APIRouter, Depends, Query
from fastapi.responses import Response
from sqlmodel import Session

from app.core.deps import Actor, get_actor, require
from app.core.errors import NotFound
from app.core.permissions import P
from app.db import get_session
from app.services import report_service

router = APIRouter(tags=["Raporlar"])
XLSX = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"

# rapor adı -> gereken izin
REPORTS: dict[str, P] = {
    "dashboard": P.REPORT_BASIC,
    "sales": P.REPORT_FINANCE,
    "profit": P.REPORT_FINANCE,
    "cashbox": P.REPORT_BASIC,
    "top-products": P.REPORT_BASIC,
    "dead-stock": P.REPORT_FINANCE,
    "abc": P.REPORT_FINANCE,
    "stock-value": P.REPORT_FINANCE,
    "staff": P.REPORT_FINANCE,
    "service": P.REPORT_BASIC,
    "warranty": P.REPORT_BASIC,
}


@router.get("/reports/{name}")
def report(
    name: str,
    date_from: date | None = Query(default=None, alias="from"),
    date_to: date | None = Query(default=None, alias="to"),
    group: str = Query(default="day", pattern="^(day|week|month)$"),
    days: int | None = Query(default=None, ge=1, le=730),
    format: str = Query(default="json", pattern="^(json|xlsx)$"),
    actor: Actor = Depends(get_actor),
    session: Session = Depends(get_session),
):
    perm = REPORTS.get(name)
    if perm is None:
        raise NotFound("Rapor")
    actor.require(perm)
    end = date_to or date.today()
    start = date_from or end - timedelta(days=29)
    finance = actor.can(P.REPORT_FINANCE)
    if name == "dashboard":
        data = report_service.dashboard(session, finance)
    elif name in ("sales", "profit"):
        data = report_service.report_sales(session, start, end, group, finance)
    elif name == "cashbox":
        data = report_service.report_cashbox(session, date_to or date_from or date.today())
    elif name == "top-products":
        data = report_service.report_top_products(session, start, end, finance)
    elif name == "dead-stock":
        data = report_service.report_dead_stock(session, days)
    elif name == "abc":
        data = report_service.report_abc(session, start, end)
    elif name == "stock-value":
        data = report_service.report_stock_value(session)
    elif name == "staff":
        data = report_service.report_staff(session, start, end)
    elif name == "service":
        data = report_service.report_service(session, start, end)
    else:
        data = report_service.report_warranty(session, days or 30)
    if name != "dashboard":
        data["range"] = {"from": start, "to": end}
    if format == "xlsx" and name != "dashboard":
        return Response(
            report_service.to_xlsx(data),
            media_type=XLSX,
            headers={"Content-Disposition": f'attachment; filename="tezgah-{name}-{start:%Y%m%d}-{end:%Y%m%d}.xlsx"'},
        )
    return data


@router.get("/status")
def status(_: Actor = Depends(require(P.SALE_READ)), session: Session = Depends(get_session)):
    return report_service.status_info(session)
