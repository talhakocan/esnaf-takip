from datetime import date

from fastapi import APIRouter, Depends, Query
from sqlmodel import Session

from app.core.deps import Actor, require
from app.core.permissions import P
from app.db import get_session
from app.models import SaleStatus
from app.schemas.sales import ReturnCreate, SaleCancelIn, SaleCreate
from app.services import sale_service

router = APIRouter(tags=["Satış"])


@router.get("/sales")
def list_sales(
    date_from: date | None = Query(default=None, alias="from"),
    date_to: date | None = Query(default=None, alias="to"),
    status: SaleStatus | None = None,
    user_id: int | None = None,
    customer_id: int | None = None,
    q: str | None = None,
    _: Actor = Depends(require(P.SALE_READ)),
    session: Session = Depends(get_session),
):
    return sale_service.list_sales(session, date_from, date_to, status, user_id, customer_id, q)


@router.post("/sales")
def create_sale(data: SaleCreate, actor: Actor = Depends(require(P.SALE_CREATE)), session: Session = Depends(get_session)):
    return sale_service.create_sale(session, actor, data)


@router.get("/sales/{sale_id}")
def get_sale(sale_id: int, actor: Actor = Depends(require(P.SALE_READ)), session: Session = Depends(get_session)):
    return sale_service.get_sale(session, actor, sale_id)


@router.post("/sales/{sale_id}/cancel")
def cancel_sale(sale_id: int, data: SaleCancelIn, actor: Actor = Depends(require(P.SALE_CANCEL)), session: Session = Depends(get_session)):
    return sale_service.cancel_sale(session, actor, sale_id, data.reason)


@router.post("/returns")
def create_return(data: ReturnCreate, actor: Actor = Depends(require(P.RETURN_CREATE)), session: Session = Depends(get_session)):
    return sale_service.create_return(session, actor, data)
