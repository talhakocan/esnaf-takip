from datetime import date

from fastapi import APIRouter, Depends, File, Query, UploadFile
from fastapi.responses import Response
from sqlmodel import Session

from app.core.deps import Actor, require
from app.core.errors import ValidationFailed
from app.core.permissions import P
from app.db import get_session
from app.models import MovementType, PricingMode, UnitType
from app.schemas.catalog import BulkPriceIn, BulkUpdateIn, ProductCreate, ProductUpdate, StockAdjustIn, WasteIn
from app.services import product_service, stock_service

router = APIRouter(tags=["Ürünler ve stok"])
XLSX = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
MAX_UPLOAD = 5 * 1024 * 1024


async def _read_upload(file: UploadFile) -> bytes:
    content = await file.read(MAX_UPLOAD + 1)
    if len(content) > MAX_UPLOAD:
        raise ValidationFailed("Dosya en fazla 5 MB olabilir.")
    return content


def _xlsx(content: bytes, name: str) -> Response:
    return Response(content, media_type=XLSX, headers={"Content-Disposition": f'attachment; filename="{name}"'})


@router.get("/products")
def list_products(
    q: str | None = None,
    category_id: int | None = None,
    brand_id: int | None = None,
    location_id: int | None = None,
    supplier_id: int | None = None,
    stock: str | None = Query(default=None, pattern="^(critical|out|dead|warn)$"),
    pricing_mode: PricingMode | None = None,
    unit_type: UnitType | None = None,
    active: str = Query(default="active", pattern="^(active|archived|all)$"),
    actor: Actor = Depends(require(P.PRODUCT_READ)),
    session: Session = Depends(get_session),
):
    return product_service.list_products(
        session, actor, q, category_id, brand_id, location_id, supplier_id, stock, pricing_mode, unit_type, active
    )


@router.post("/products")
def create_product(data: ProductCreate, actor: Actor = Depends(require(P.PRODUCT_WRITE)), session: Session = Depends(get_session)):
    return product_service.create_product(session, actor, data)


@router.get("/products/lookup")
def lookup(code: str, actor: Actor = Depends(require(P.PRODUCT_READ)), session: Session = Depends(get_session)):
    return product_service.lookup(session, actor, code)


@router.get("/products/next-barcode")
def next_barcode(_: Actor = Depends(require(P.PRODUCT_WRITE)), session: Session = Depends(get_session)):
    return {"barcode": product_service.next_internal_barcode(session)}


@router.get("/products/export.xlsx")
def export_products(actor: Actor = Depends(require(P.PRODUCT_READ)), session: Session = Depends(get_session)):
    return _xlsx(product_service.export_xlsx(session, actor), f"tezgah-urunler-{date.today():%Y%m%d}.xlsx")


@router.get("/products/import-template.xlsx")
def import_template(_: Actor = Depends(require(P.PRODUCT_IMPORT))):
    return _xlsx(product_service.import_template_xlsx(), "tezgah-urun-sablonu.xlsx")


@router.post("/products/import/preview")
async def import_preview(
    file: UploadFile = File(...), _: Actor = Depends(require(P.PRODUCT_IMPORT)), session: Session = Depends(get_session)
):
    return product_service.import_preview(session, await _read_upload(file))


@router.post("/products/import/apply")
async def import_apply(
    file: UploadFile = File(...), actor: Actor = Depends(require(P.PRODUCT_IMPORT)), session: Session = Depends(get_session)
):
    return product_service.import_apply(session, actor, await _read_upload(file))


@router.post("/products/bulk-price/preview")
def bulk_price_preview(data: BulkPriceIn, _: Actor = Depends(require(P.PRODUCT_BULK_PRICE)), session: Session = Depends(get_session)):
    return product_service.bulk_price_preview(session, data)


@router.post("/products/bulk-price/apply")
def bulk_price_apply(data: BulkPriceIn, actor: Actor = Depends(require(P.PRODUCT_BULK_PRICE)), session: Session = Depends(get_session)):
    return product_service.bulk_price_apply(session, actor, data)


@router.post("/products/bulk-update")
def bulk_update(data: BulkUpdateIn, actor: Actor = Depends(require(P.PRODUCT_WRITE)), session: Session = Depends(get_session)):
    if data.archive is not None:
        actor.require(P.PRODUCT_ARCHIVE)
    return product_service.bulk_update(session, actor, data)


@router.get("/products/{product_id}")
def get_product(product_id: int, actor: Actor = Depends(require(P.PRODUCT_READ)), session: Session = Depends(get_session)):
    return product_service.get_product(session, actor, product_id)


@router.patch("/products/{product_id}")
def update_product(
    product_id: int, data: ProductUpdate, actor: Actor = Depends(require(P.PRODUCT_WRITE)), session: Session = Depends(get_session)
):
    if data.is_active is not None:
        actor.require(P.PRODUCT_ARCHIVE)
    return product_service.update_product(session, actor, product_id, data)


@router.post("/products/{product_id}/archive")
def archive(product_id: int, actor: Actor = Depends(require(P.PRODUCT_ARCHIVE)), session: Session = Depends(get_session)):
    return product_service.set_active(session, actor, product_id, False)


@router.post("/products/{product_id}/restore")
def restore(product_id: int, actor: Actor = Depends(require(P.PRODUCT_ARCHIVE)), session: Session = Depends(get_session)):
    return product_service.set_active(session, actor, product_id, True)


@router.get("/products/{product_id}/movements")
def product_movements(product_id: int, actor: Actor = Depends(require(P.STOCK_READ)), session: Session = Depends(get_session)):
    return stock_service.list_movements(session, product_id=product_id, include_cost=actor.can(P.PRODUCT_COST_VIEW))


@router.get("/products/{product_id}/serials")
def product_serials(
    product_id: int, available: bool = False, _: Actor = Depends(require(P.PRODUCT_READ)), session: Session = Depends(get_session)
):
    if available:
        return [{"id": s.id, "serial_no": s.serial_no, "status": s.status} for s in stock_service.available_serials(session, product_id)]
    return product_service.list_serials(session, product_id)


@router.get("/products/{product_id}/price-history")
def product_price_history(product_id: int, _: Actor = Depends(require(P.PRODUCT_READ)), session: Session = Depends(get_session)):
    return product_service.price_history(session, product_id)


@router.get("/products/{product_id}/suppliers")
def product_suppliers(product_id: int, actor: Actor = Depends(require(P.PRODUCT_READ)), session: Session = Depends(get_session)):
    return product_service.product_suppliers(session, product_id, actor.can(P.PRODUCT_COST_VIEW))


@router.get("/stock/movements")
def movements(
    product_id: int | None = None,
    type: list[MovementType] | None = Query(default=None),
    user_id: int | None = None,
    date_from: date | None = Query(default=None, alias="from"),
    date_to: date | None = Query(default=None, alias="to"),
    ref_type: str | None = None,
    ref_id: int | None = None,
    actor: Actor = Depends(require(P.STOCK_READ)),
    session: Session = Depends(get_session),
):
    return stock_service.list_movements(
        session, product_id, type, user_id, date_from, date_to, ref_type, ref_id, include_cost=actor.can(P.PRODUCT_COST_VIEW)
    )


@router.post("/stock/adjust")
def adjust(data: StockAdjustIn, actor: Actor = Depends(require(P.STOCK_ADJUST)), session: Session = Depends(get_session)):
    m = stock_service.manual_adjust(
        session, actor, data.product_id, data.qty, data.type, data.note, data.unit_cost_kurus, data.serials, data.serial_ids
    )
    return {"movement_id": m.id if m else None, "balance_after": m.balance_after if m else None}


@router.post("/stock/waste")
def waste(data: WasteIn, actor: Actor = Depends(require(P.STOCK_ADJUST)), session: Session = Depends(get_session)):
    m = stock_service.manual_adjust(session, actor, data.product_id, data.qty, MovementType.WASTE, data.note, serial_ids=data.serial_ids)
    return {"movement_id": m.id if m else None, "balance_after": m.balance_after if m else None}
