from datetime import date

from fastapi import APIRouter, Depends, File, Query, UploadFile
from fastapi.responses import FileResponse
from sqlmodel import Session, col, select

from app.core import audit
from app.core.deps import Actor, get_actor, require
from app.core.errors import ValidationFailed
from app.core.permissions import P
from app.db import get_session
from app.models import AuditLog, User
from app.schemas.ops import FxRatesIn, SettingsUpdate, UserCreate, UserUpdate
from app.services import auth_service, backup_service, fx_service, search_service, settings_service

router = APIRouter(tags=["Sistem"])
MAX_RESTORE = 200 * 1024 * 1024


# ---------------------------------------------------------------- ayarlar


@router.get("/settings")
def get_settings(_: Actor = Depends(require(P.SETTINGS_READ)), session: Session = Depends(get_session)):
    row = settings_service.get_settings_row(session)
    session.commit()
    return row


@router.get("/public/shop")
def public_shop(session: Session = Depends(get_session)):
    """Giriş ekranı ve takip sayfası için dükkan künyesi (kişisel veri yok)."""
    row = settings_service.get_settings_row(session)
    session.commit()
    return {"shop_name": row.shop_name, "address": row.address, "phone": row.phone}


@router.patch("/settings")
def update_settings(data: SettingsUpdate, actor: Actor = Depends(require(P.SETTINGS_WRITE)), session: Session = Depends(get_session)):
    return settings_service.update_settings(session, actor, data.model_dump(exclude_unset=True))


# ---------------------------------------------------------------- kur


@router.get("/fx-rates")
def fx_rates(_: Actor = Depends(get_actor), session: Session = Depends(get_session)):
    return fx_service.current_rates(session) | {
        "history": [
            {"currency": r.currency, "rate": r.rate, "source": r.source, "fetched_at": r.fetched_at} for r in fx_service.history(session)
        ]
    }


@router.post("/fx-rates")
def set_fx_rates(data: FxRatesIn, actor: Actor = Depends(require(P.FX_WRITE)), session: Session = Depends(get_session)):
    rates = {k: v for k, v in data.model_dump().items() if v is not None}
    if not rates:
        raise ValidationFailed("En az bir kur girin.")
    updated = fx_service.set_rates(session, actor, rates, "MANUAL")
    return {"updated_products": updated, **fx_service.current_rates(session)}


@router.post("/fx-rates/fetch-tcmb")
def fetch_tcmb(actor: Actor = Depends(require(P.FX_WRITE)), session: Session = Depends(get_session)):
    rates = fx_service.fetch_tcmb()
    updated = fx_service.set_rates(session, actor, rates, "TCMB")
    return {"updated_products": updated, "fetched": rates, **fx_service.current_rates(session)}


# ---------------------------------------------------------------- kullanıcılar


@router.get("/users")
def users(actor: Actor = Depends(get_actor), session: Session = Depends(get_session)):
    rows = auth_service.list_users(session)
    if not actor.can(P.USER_MANAGE):
        return [{"id": u["id"], "full_name": u["full_name"], "is_active": u["is_active"]} for u in rows]
    return rows


@router.post("/users")
def create_user(data: UserCreate, actor: Actor = Depends(require(P.USER_MANAGE)), session: Session = Depends(get_session)):
    return auth_service.create_user(session, actor, data.model_dump())


@router.patch("/users/{user_id}")
def update_user(user_id: int, data: UserUpdate, actor: Actor = Depends(require(P.USER_MANAGE)), session: Session = Depends(get_session)):
    return auth_service.update_user(session, actor, user_id, data.model_dump(exclude_unset=True))


# ---------------------------------------------------------------- denetim kaydı


@router.get("/audit-logs")
def audit_logs(
    entity: str | None = None,
    user_id: int | None = None,
    action: str | None = None,
    date_from: date | None = Query(default=None, alias="from"),
    date_to: date | None = Query(default=None, alias="to"),
    limit: int = Query(default=500, le=5000),
    _: Actor = Depends(require(P.AUDIT_READ)),
    session: Session = Depends(get_session),
):
    from app.core.dates import day_end, day_start

    stmt = select(AuditLog, User.full_name).join(User, col(User.id) == AuditLog.user_id, isouter=True)
    if entity:
        stmt = stmt.where(AuditLog.entity == entity)
    if user_id:
        stmt = stmt.where(AuditLog.user_id == user_id)
    if action:
        stmt = stmt.where(col(AuditLog.action).like(f"{action}%"))
    if date_from:
        stmt = stmt.where(AuditLog.at >= day_start(date_from))
    if date_to:
        stmt = stmt.where(AuditLog.at <= day_end(date_to))
    rows = session.exec(stmt.order_by(col(AuditLog.at).desc(), col(AuditLog.id).desc()).limit(limit)).all()
    return [
        {
            "id": a.id,
            "at": a.at,
            "user_name": n,
            "action": a.action,
            "entity": a.entity,
            "entity_id": a.entity_id,
            "diff": a.diff,
            "ip": a.ip,
        }
        for a, n in rows
    ]


# ---------------------------------------------------------------- yedekleme


@router.get("/backups")
def list_backups(_: Actor = Depends(require(P.BACKUP_MANAGE))):
    return backup_service.list_backups()


@router.post("/backups")
def create_backup(actor: Actor = Depends(require(P.BACKUP_MANAGE)), session: Session = Depends(get_session)):
    info = backup_service.create_backup("manual")
    audit.record(session, actor, "backup.create", "backup", None, None, None, {"name": info["name"]})
    session.commit()
    return info


@router.get("/backups/{name}")
def download_backup(name: str, _: Actor = Depends(require(P.BACKUP_MANAGE))):
    return FileResponse(backup_service.backup_path(name), filename=name, media_type="application/vnd.sqlite3")


@router.post("/backups/restore")
async def restore_backup(
    file: UploadFile = File(...), actor: Actor = Depends(require(P.BACKUP_MANAGE)), session: Session = Depends(get_session)
):
    content = await file.read(MAX_RESTORE + 1)
    if len(content) > MAX_RESTORE:
        raise ValidationFailed("Yedek dosyası çok büyük.")
    session.close()
    result = backup_service.restore_from_bytes(content)
    from app.db import get_engine

    with Session(get_engine()) as s2:
        audit.record(
            s2,
            None,
            "backup.restore",
            "backup",
            None,
            None,
            None,
            {"pre_backup": result["pre_backup"], "by_user": actor.user.username, "ip": actor.ip},
        )
        s2.commit()
    return result


# ---------------------------------------------------------------- arama


@router.get("/search")
def search(
    q: str = Query(min_length=1, max_length=80), _: Actor = Depends(require(P.PRODUCT_READ)), session: Session = Depends(get_session)
):
    return search_service.search(session, q)
