from fastapi import APIRouter, Depends, Request, Response
from sqlmodel import Session

from app.config import get_settings
from app.core.deps import Actor, get_actor
from app.core.errors import Unauthorized
from app.core.permissions import ROLE_PERMISSIONS
from app.core.ratelimit import enforce, login_limiter
from app.core.security import create_token
from app.db import get_session
from app.schemas.ops import LoginIn, PasswordChangeIn
from app.services import auth_service

router = APIRouter(prefix="/auth", tags=["Kimlik"])


def me_out(actor: Actor) -> dict:
    return auth_service.user_out(actor.user) | {"permissions": sorted(p.value for p in ROLE_PERMISSIONS[actor.user.role])}


@router.post("/login")
def login(data: LoginIn, request: Request, response: Response, session: Session = Depends(get_session)) -> dict:
    enforce(login_limiter, request, "login")
    user = auth_service.authenticate(session, data.username, data.password)
    settings = get_settings()
    response.set_cookie(
        settings.cookie_name,
        create_token(user.id, user.role),  # type: ignore[arg-type]
        max_age=settings.token_hours * 3600,
        httponly=True,
        samesite="lax",
        secure=settings.cookie_secure,
        path="/",
    )
    return me_out(Actor(user=user))


@router.post("/logout")
def logout(response: Response) -> dict:
    response.delete_cookie(get_settings().cookie_name, path="/")
    return {"ok": True}


@router.get("/me")
def me(actor: Actor = Depends(get_actor)) -> dict:
    return me_out(actor)


@router.get("/session")
def session_info(request: Request, session: Session = Depends(get_session)) -> dict:
    """Oturum yoksa 401 yerine {"user": null} döner (arayüzün açılış kontrolü için)."""
    try:
        actor = get_actor(request, session)
    except Unauthorized:
        return {"user": None}
    return {"user": me_out(actor)}


@router.post("/change-password")
def change_password(data: PasswordChangeIn, actor: Actor = Depends(get_actor), session: Session = Depends(get_session)) -> dict:
    auth_service.change_own_password(session, actor, data.current_password, data.new_password)
    return {"ok": True}
