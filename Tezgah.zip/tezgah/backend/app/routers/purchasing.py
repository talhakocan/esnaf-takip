from fastapi import APIRouter, Depends, Query
from sqlmodel import Session

from app.core.deps import Actor, require
from app.core.permissions import P
from app.db import get_session
from app.schemas.ops import (
    CountCreate,
    CountItemsIn,
    CountScanIn,
    FromCriticalIn,
    POCreate,
    POUpdate,
    ReceiveIn,
    SupplierIn,
)
from app.services import count_service, purchase_service

router = APIRouter(tags=["Tedarik ve sayım"])


@router.get("/suppliers")
def list_suppliers(
    active: str = Query(default="active", pattern="^(active|all)$"),
    _: Actor = Depends(require(P.SUPPLIER_READ)),
    session: Session = Depends(get_session),
):
    return purchase_service.list_suppliers(session, active)


@router.post("/suppliers")
def create_supplier(data: SupplierIn, actor: Actor = Depends(require(P.SUPPLIER_WRITE)), session: Session = Depends(get_session)):
    return purchase_service.save_supplier(session, actor, data)


@router.get("/suppliers/{supplier_id}")
def get_supplier(supplier_id: int, actor: Actor = Depends(require(P.SUPPLIER_READ)), session: Session = Depends(get_session)):
    out = purchase_service.get_supplier(session, supplier_id)
    out["orders"] = [purchase_service.strip_prices(o, actor) for o in out["orders"]]
    return out


@router.patch("/suppliers/{supplier_id}")
def update_supplier(
    supplier_id: int, data: SupplierIn, actor: Actor = Depends(require(P.SUPPLIER_WRITE)), session: Session = Depends(get_session)
):
    return purchase_service.save_supplier(session, actor, data, supplier_id)


@router.get("/purchase-orders")
def list_orders(
    status: str | None = None,
    supplier_id: int | None = None,
    actor: Actor = Depends(require(P.PURCHASE_READ)),
    session: Session = Depends(get_session),
):
    return [purchase_service.strip_prices(o, actor) for o in purchase_service.list_orders(session, status, supplier_id)]


@router.post("/purchase-orders")
def create_order(data: POCreate, actor: Actor = Depends(require(P.PURCHASE_WRITE)), session: Session = Depends(get_session)):
    return purchase_service.create_order(session, actor, data)


@router.post("/purchase-orders/from-critical")
def from_critical(data: FromCriticalIn, actor: Actor = Depends(require(P.PURCHASE_WRITE)), session: Session = Depends(get_session)):
    return purchase_service.from_critical(session, actor, data.supplier_id)


@router.get("/purchase-orders/{order_id}")
def get_order(order_id: int, actor: Actor = Depends(require(P.PURCHASE_READ)), session: Session = Depends(get_session)):
    return purchase_service.strip_prices(purchase_service.get_order(session, actor, order_id), actor)


@router.patch("/purchase-orders/{order_id}")
def update_order(order_id: int, data: POUpdate, actor: Actor = Depends(require(P.PURCHASE_WRITE)), session: Session = Depends(get_session)):
    return purchase_service.update_order(session, actor, order_id, data)


@router.post("/purchase-orders/{order_id}/order")
def mark_ordered(order_id: int, actor: Actor = Depends(require(P.PURCHASE_WRITE)), session: Session = Depends(get_session)):
    return purchase_service.mark_ordered(session, actor, order_id)


@router.post("/purchase-orders/{order_id}/cancel")
def cancel_order(order_id: int, actor: Actor = Depends(require(P.PURCHASE_WRITE)), session: Session = Depends(get_session)):
    return purchase_service.cancel_order(session, actor, order_id)


@router.post("/purchase-orders/{order_id}/receive")
def receive(order_id: int, data: ReceiveIn, actor: Actor = Depends(require(P.PURCHASE_RECEIVE)), session: Session = Depends(get_session)):
    return purchase_service.receive(session, actor, order_id, data)


@router.get("/stock-counts")
def list_counts(_: Actor = Depends(require(P.COUNT_READ)), session: Session = Depends(get_session)):
    return count_service.list_counts(session)


@router.post("/stock-counts")
def create_count(data: CountCreate, actor: Actor = Depends(require(P.COUNT_WRITE)), session: Session = Depends(get_session)):
    return count_service.create_count(session, actor, data)


@router.get("/stock-counts/{count_id}")
def get_count(count_id: int, actor: Actor = Depends(require(P.COUNT_READ)), session: Session = Depends(get_session)):
    return count_service.get_count(session, actor, count_id)


@router.patch("/stock-counts/{count_id}/items")
def update_items(
    count_id: int, data: CountItemsIn, actor: Actor = Depends(require(P.COUNT_WRITE)), session: Session = Depends(get_session)
):
    return count_service.update_items(session, actor, count_id, data)


@router.post("/stock-counts/{count_id}/scan")
def scan(count_id: int, data: CountScanIn, actor: Actor = Depends(require(P.COUNT_WRITE)), session: Session = Depends(get_session)):
    return count_service.scan(session, actor, count_id, data)


@router.post("/stock-counts/{count_id}/apply")
def apply(count_id: int, actor: Actor = Depends(require(P.COUNT_APPLY)), session: Session = Depends(get_session)):
    return count_service.apply_count(session, actor, count_id)


@router.post("/stock-counts/{count_id}/cancel")
def cancel(count_id: int, actor: Actor = Depends(require(P.COUNT_WRITE)), session: Session = Depends(get_session)):
    return count_service.cancel_count(session, actor, count_id)
