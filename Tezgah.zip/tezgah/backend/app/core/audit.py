"""Denetim kaydı: önemli değişikliklerde önce/sonra farkı yazılır."""

from datetime import date, datetime
from decimal import Decimal
from enum import Enum
from typing import TYPE_CHECKING, Any

from sqlmodel import Session, SQLModel

from app.models import AuditLog

if TYPE_CHECKING:
    from app.core.deps import Actor

_SKIP = {"updated_at", "created_at", "password_hash"}


def _plain(value: Any) -> Any:
    if isinstance(value, Decimal):
        return str(value.normalize()) if value == value.to_integral_value() else str(value)
    if isinstance(value, (datetime, date)):
        return value.isoformat()
    if isinstance(value, Enum):
        return value.value
    if isinstance(value, (list, tuple)):
        return [_plain(v) for v in value]
    if isinstance(value, dict):
        return {k: _plain(v) for k, v in value.items()}
    return value


def snapshot(obj: SQLModel | dict | None, fields: list[str] | None = None) -> dict[str, Any]:
    if obj is None:
        return {}
    data = obj if isinstance(obj, dict) else obj.model_dump()
    keys = fields or [k for k in data if k not in _SKIP]
    return {k: _plain(data.get(k)) for k in keys if k not in _SKIP}


def record(
    session: Session,
    actor: "Actor | None",
    action: str,
    entity: str,
    entity_id: int | None,
    before: dict[str, Any] | None = None,
    after: dict[str, Any] | None = None,
    extra: dict[str, Any] | None = None,
    at: datetime | None = None,
) -> AuditLog | None:
    before = before or {}
    after = after or {}
    if before and after:
        changed = [k for k in after if before.get(k) != after.get(k)]
        if not changed and not extra:
            return None
        before = {k: before.get(k) for k in changed}
        after = {k: after.get(k) for k in changed}
    diff: dict[str, Any] = {"before": before, "after": after}
    if extra:
        diff["extra"] = _plain(extra)
    log = AuditLog(
        user_id=actor.id if actor else None,
        action=action,
        entity=entity,
        entity_id=entity_id,
        diff=diff,
        ip=actor.ip if actor else None,
    )
    if at is not None:
        log.at = log.created_at = log.updated_at = at
    session.add(log)
    return log
