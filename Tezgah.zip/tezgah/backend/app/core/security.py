"""Şifre hash (Argon2) ve JWT."""

from datetime import UTC, datetime, timedelta

import jwt
from pwdlib import PasswordHash
from pwdlib.hashers.argon2 import Argon2Hasher

from app.config import get_secret_key, get_settings

_hasher = PasswordHash((Argon2Hasher(),))
ALGORITHM = "HS256"


def hash_password(password: str) -> str:
    return _hasher.hash(password)


def verify_password(password: str, password_hash: str) -> bool:
    try:
        return _hasher.verify(password, password_hash)
    except Exception:
        return False


def create_token(user_id: int, role: str) -> str:
    now = datetime.now(UTC)
    payload = {
        "sub": str(user_id),
        "role": role,
        "iat": now,
        "exp": now + timedelta(hours=get_settings().token_hours),
    }
    return jwt.encode(payload, get_secret_key(), algorithm=ALGORITHM)


def decode_token(token: str) -> dict | None:
    try:
        return jwt.decode(token, get_secret_key(), algorithms=[ALGORITHM])
    except jwt.PyJWTError:
        return None


def validate_password_strength(password: str) -> str | None:
    if len(password) < 8:
        return "Şifre en az 8 karakter olmalıdır."
    if not any(c.isdigit() for c in password) or not any(c.isalpha() for c in password):
        return "Şifre harf ve rakam içermelidir."
    return None
