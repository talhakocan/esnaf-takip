"""Tek tip hata biçimi: {"error": {"code", "message", "fields"}}."""

import logging
from typing import Any

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from starlette.exceptions import HTTPException as StarletteHTTPException

log = logging.getLogger("tezgah")


class AppError(Exception):
    def __init__(
        self,
        code: str,
        message: str,
        status_code: int = 400,
        fields: dict[str, str] | None = None,
        extra: dict[str, Any] | None = None,
    ) -> None:
        super().__init__(message)
        self.code = code
        self.message = message
        self.status_code = status_code
        self.fields = fields or {}
        self.extra = extra or {}


class NotFound(AppError):
    def __init__(self, what: str = "Kayıt") -> None:
        super().__init__("NOT_FOUND", f"{what} bulunamadı.", 404)


class Forbidden(AppError):
    def __init__(self, message: str = "Bu işlem için yetkiniz yok.") -> None:
        super().__init__("FORBIDDEN", message, 403)


class Unauthorized(AppError):
    def __init__(self, message: str = "Oturum açmanız gerekiyor.") -> None:
        super().__init__("UNAUTHORIZED", message, 401)


class ValidationFailed(AppError):
    def __init__(self, message: str, fields: dict[str, str] | None = None, code: str = "VALIDATION") -> None:
        super().__init__(code, message, 422, fields)


class Conflict(AppError):
    def __init__(self, message: str, code: str = "CONFLICT", extra: dict[str, Any] | None = None) -> None:
        super().__init__(code, message, 409, extra=extra)


_PYDANTIC_TR = {
    "missing": "Bu alan zorunludur.",
    "string_too_short": "Değer çok kısa.",
    "string_too_long": "Değer çok uzun.",
    "int_parsing": "Tam sayı olmalıdır.",
    "int_from_float": "Tam sayı olmalıdır.",
    "decimal_parsing": "Sayı olmalıdır.",
    "float_parsing": "Sayı olmalıdır.",
    "greater_than": "Değer çok küçük.",
    "greater_than_equal": "Değer çok küçük.",
    "less_than": "Değer çok büyük.",
    "less_than_equal": "Değer çok büyük.",
    "enum": "Geçersiz seçim.",
    "literal_error": "Geçersiz seçim.",
    "date_from_datetime_parsing": "Geçersiz tarih.",
    "date_parsing": "Geçersiz tarih.",
    "datetime_parsing": "Geçersiz tarih/saat.",
    "bool_parsing": "Evet/hayır değeri olmalıdır.",
    "list_type": "Liste olmalıdır.",
    "string_pattern_mismatch": "Biçim geçersiz.",
    "value_error": "Geçersiz değer.",
    "too_short": "En az bir kayıt gerekli.",
}


def _error_body(code: str, message: str, fields: dict[str, str] | None = None, **extra: Any) -> dict:
    body: dict[str, Any] = {"code": code, "message": message, "fields": fields or {}}
    body.update(extra)
    return {"error": body}


_STATUS_TR = {
    400: ("BAD_REQUEST", "İstek geçersiz."),
    401: ("UNAUTHORIZED", "Oturum açmanız gerekiyor."),
    403: ("FORBIDDEN", "Bu işlem için yetkiniz yok."),
    404: ("NOT_FOUND", "Kayıt bulunamadı."),
    405: ("METHOD_NOT_ALLOWED", "Bu işlem desteklenmiyor."),
    429: ("RATE_LIMITED", "Çok fazla istek. Lütfen biraz sonra tekrar deneyin."),
}


def install_error_handlers(app: FastAPI) -> None:
    @app.exception_handler(AppError)
    async def _app_error(_: Request, exc: AppError) -> JSONResponse:
        return JSONResponse(_error_body(exc.code, exc.message, exc.fields, **exc.extra), exc.status_code)

    @app.exception_handler(RequestValidationError)
    async def _validation(_: Request, exc: RequestValidationError) -> JSONResponse:
        fields: dict[str, str] = {}
        for err in exc.errors():
            loc = [str(p) for p in err.get("loc", []) if p not in ("body", "query", "path")]
            key = ".".join(loc) or "_"
            msg = _PYDANTIC_TR.get(err.get("type", ""))
            if msg is None:
                raw = str(err.get("msg", ""))
                msg = raw.removeprefix("Value error, ") if raw.startswith("Value error, ") else "Geçersiz değer."
            fields.setdefault(key, msg)
        return JSONResponse(_error_body("VALIDATION", "Form alanlarını kontrol edin.", fields), 422)

    @app.exception_handler(StarletteHTTPException)
    async def _http(_: Request, exc: StarletteHTTPException) -> JSONResponse:
        code, message = _STATUS_TR.get(exc.status_code, ("HTTP_ERROR", "İstek işlenemedi."))
        if isinstance(exc.detail, str) and exc.status_code not in _STATUS_TR:
            message = exc.detail
        return JSONResponse(_error_body(code, message), exc.status_code, headers=getattr(exc, "headers", None))

    @app.exception_handler(Exception)
    async def _unhandled(_: Request, exc: Exception) -> JSONResponse:
        log.exception("Beklenmeyen hata", exc_info=exc)
        return JSONResponse(_error_body("INTERNAL", "Beklenmeyen bir hata oluştu."), 500)
