"""Tarih yardımcıları."""

import calendar
from datetime import date, datetime, time, timedelta


def add_months(d: date, months: int) -> date:
    month_index = d.month - 1 + months
    year = d.year + month_index // 12
    month = month_index % 12 + 1
    day = min(d.day, calendar.monthrange(year, month)[1])
    return date(year, month, day)


def day_start(d: date) -> datetime:
    return datetime.combine(d, time.min)


def day_end(d: date) -> datetime:
    return datetime.combine(d, time.max)


def date_range(start: date, end: date) -> list[date]:
    return [start + timedelta(days=i) for i in range((end - start).days + 1)]
