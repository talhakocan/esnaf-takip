"""Yetki tablosu. Her uç bir izin ister; roller izin kümelerine eşlenir."""

from enum import StrEnum

from app.models.common import Role


class P(StrEnum):
    PRODUCT_READ = "product.read"
    PRODUCT_WRITE = "product.write"
    PRODUCT_ARCHIVE = "product.archive"
    PRODUCT_COST_VIEW = "product.cost_view"
    PRODUCT_BULK_PRICE = "product.bulk_price"
    PRODUCT_IMPORT = "product.import"
    CATALOG_WRITE = "catalog.write"
    STOCK_READ = "stock.read"
    STOCK_ADJUST = "stock.adjust"
    SALE_CREATE = "sale.create"
    SALE_READ = "sale.read"
    SALE_CANCEL = "sale.cancel"
    RETURN_CREATE = "return.create"
    CREDIT_OVERRIDE = "credit.override"
    CUSTOMER_READ = "customer.read"
    CUSTOMER_WRITE = "customer.write"
    CUSTOMER_ARCHIVE = "customer.archive"
    CUSTOMER_PAYMENT = "customer.payment"
    CUSTOMER_ADJUST = "customer.adjust"
    SERVICE_READ = "service.read"
    SERVICE_WRITE = "service.write"
    SUPPLIER_READ = "supplier.read"
    SUPPLIER_WRITE = "supplier.write"
    PURCHASE_READ = "purchase.read"
    PURCHASE_WRITE = "purchase.write"
    PURCHASE_RECEIVE = "purchase.receive"
    COUNT_READ = "count.read"
    COUNT_WRITE = "count.write"
    COUNT_APPLY = "count.apply"
    REPORT_BASIC = "report.basic"
    REPORT_FINANCE = "report.finance"
    SETTINGS_READ = "settings.read"
    SETTINGS_WRITE = "settings.write"
    FX_WRITE = "fx.write"
    USER_MANAGE = "user.manage"
    AUDIT_READ = "audit.read"
    BACKUP_MANAGE = "backup.manage"


STAFF_PERMISSIONS: frozenset[P] = frozenset(
    {
        P.PRODUCT_READ,
        P.STOCK_READ,
        P.STOCK_ADJUST,
        P.SALE_CREATE,
        P.SALE_READ,
        P.RETURN_CREATE,
        P.CUSTOMER_READ,
        P.CUSTOMER_WRITE,
        P.CUSTOMER_PAYMENT,
        P.SERVICE_READ,
        P.SERVICE_WRITE,
        P.SUPPLIER_READ,
        P.PURCHASE_READ,
        P.COUNT_READ,
        P.COUNT_WRITE,
        P.REPORT_BASIC,
        P.SETTINGS_READ,
    }
)

ROLE_PERMISSIONS: dict[Role, frozenset[P]] = {
    Role.ADMIN: frozenset(P),
    Role.STAFF: STAFF_PERMISSIONS,
}

PERMISSION_LABELS_TR: dict[P, str] = {
    P.PRODUCT_WRITE: "Ürün oluşturma ve düzenleme",
    P.PRODUCT_ARCHIVE: "Ürün arşivleme",
    P.PRODUCT_COST_VIEW: "Alış fiyatı ve kâr görme",
    P.SALE_CANCEL: "Satış iptali",
    P.COUNT_APPLY: "Sayım onayı",
    P.CREDIT_OVERRIDE: "Kredi limiti aşımı onayı",
}


def has_permission(role: Role | str, perm: P) -> bool:
    return perm in ROLE_PERMISSIONS.get(Role(role), frozenset())
