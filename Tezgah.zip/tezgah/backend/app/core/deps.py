"""FastAPI bağımlılıkları: oturum, kullanıcı, yetki."""

from collections.abc import Callable
from dataclasses import dataclass

from fastapi import Depends, Request
from sqlmodel import Session

from app.config import get_settings
from app.core.errors import Forbidden, Unauthorized
from app.core.permissions import P, has_permission
from app.core.ratelimit import client_ip
from app.core.security import decode_token
from app.db import get_session
from app.models import Role, User


@dataclass
class Actor:
    """İşlemi yapan kullanıcı ve istek bağlamı (servislere geçirilir)."""

    user: User
    ip: str | None = None

    @property
    def id(self) -> int:
        assert self.user.id is not None
        return self.user.id

    @property
    def is_admin(self) -> bool:
        return self.user.role == Role.ADMIN

    def can(self, perm: P) -> bool:
        return has_permission(self.user.role, perm)

    def require(self, perm: P, message: str | None = None) -> None:
        if not self.can(perm):
            raise Forbidden(message or "Bu işlem için yetkiniz yok.")


def get_actor(request: Request, session: Session = Depends(get_session)) -> Actor:
    token = request.cookies.get(get_settings().cookie_name)
    if not token:
        raise Unauthorized()
    payload = decode_token(token)
    if not payload:
        raise Unauthorized("Oturumunuzun süresi doldu. Lütfen yeniden giriş yapın.")
    user = session.get(User, int(payload["sub"]))
    if not user or not user.is_active:
        raise Unauthorized("Kullanıcı bulunamadı veya pasif.")
    return Actor(user=user, ip=client_ip(request))


def require(perm: P) -> Callable[..., Actor]:
    def _dep(actor: Actor = Depends(get_actor)) -> Actor:
        actor.require(perm)
        return actor

    return _dep
