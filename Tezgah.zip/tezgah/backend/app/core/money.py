"""Para ve miktar yardımcıları. Para her zaman tam sayı kuruştur."""

from decimal import ROUND_CEILING, ROUND_HALF_UP, Decimal, InvalidOperation

from app.models.common import RoundingRule, UnitType

QTY_QUANT = Decimal("0.001")
RATE_QUANT = Decimal("0.000001")


def to_decimal(value: object) -> Decimal:
    if isinstance(value, Decimal):
        return value
    if isinstance(value, str):
        value = value.strip().replace(" ", "")
        if "," in value:
            value = value.replace(".", "").replace(",", ".")
    try:
        return Decimal(str(value))
    except (InvalidOperation, ValueError) as exc:
        raise ValueError(f"Geçersiz sayı: {value!r}") from exc


def round_half_up(value: Decimal) -> int:
    return int(value.to_integral_value(rounding=ROUND_HALF_UP))


def qty(value: object) -> Decimal:
    return to_decimal(value).quantize(QTY_QUANT, rounding=ROUND_HALF_UP)


def line_amount(quantity: Decimal, unit_price_kurus: int) -> int:
    """Miktar × birim fiyat, kuruşa yuvarlanmış."""
    return round_half_up(quantity * Decimal(unit_price_kurus))


def vat_of_gross(gross_kurus: int, vat_rate: int) -> int:
    """KDV dahil tutarın içindeki KDV (kuruş)."""
    if vat_rate <= 0:
        return 0
    net = round_half_up(Decimal(gross_kurus) * 100 / Decimal(100 + vat_rate))
    return gross_kurus - net


def tl_to_kurus(value: object) -> int:
    return round_half_up(to_decimal(value) * 100)


def kurus_to_tl(value: int) -> Decimal:
    return (Decimal(value) / 100).quantize(Decimal("0.01"))


def apply_rounding(kurus: int, rule: RoundingRule | str) -> int:
    """Satış fiyatı yuvarlama kuralı.

    NEAREST_1: en yakın TL, NEAREST_5: en yakın 5 TL, END_90: bir üstteki ,90 ile biten fiyat.
    """
    rule = RoundingRule(rule)
    if kurus <= 0:
        return max(kurus, 0)
    if rule == RoundingRule.NONE:
        return kurus
    if rule == RoundingRule.NEAREST_1:
        return round_half_up(Decimal(kurus) / 100) * 100
    if rule == RoundingRule.NEAREST_5:
        return max(500, round_half_up(Decimal(kurus) / 500) * 500)
    # END_90
    whole = int((Decimal(kurus - 90) / 100).to_integral_value(rounding=ROUND_CEILING))
    return max(whole, 0) * 100 + 90


def validate_qty_for_unit(quantity: Decimal, unit_type: UnitType | str) -> None:
    unit_type = UnitType(unit_type)
    if unit_type == UnitType.PIECE and quantity != quantity.to_integral_value():
        raise ValueError("Adet ile satılan ürünlerde miktar tam sayı olmalıdır.")


def allocate(total: int, weights: list[int]) -> list[int]:
    """Bir tutarı ağırlıklara göre kuruş kaybı olmadan dağıtır (en büyük kalan yöntemi)."""
    if not weights:
        return []
    weight_sum = sum(weights)
    if weight_sum == 0 or total == 0:
        return [0] * len(weights)
    raw = [Decimal(total) * w / weight_sum for w in weights]
    floors = [int(r) for r in raw]
    remainder = total - sum(floors)
    order = sorted(range(len(raw)), key=lambda i: raw[i] - floors[i], reverse=True)
    for i in order[:remainder]:
        floors[i] += 1
    return floors
