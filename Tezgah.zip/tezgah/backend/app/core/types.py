"""Özel sütun tipleri.

SQLite ondalık sayıları yerel olarak desteklemediği için Numeric(12,3) ve Numeric(18,6)
alanları ölçeklenmiş tam sayı olarak saklanır (ör. 12,5 m -> 12500). Böylece toplama ve
karşılaştırma yuvarlama hatası olmadan yapılır.
"""

from decimal import ROUND_HALF_UP, Decimal

from sqlalchemy import BigInteger
from sqlalchemy.types import TypeDecorator


class ScaledDecimal(TypeDecorator):
    impl = BigInteger
    cache_ok = True

    def __init__(self, scale: int = 3) -> None:
        super().__init__()
        self.scale = scale
        self.factor = 10**scale
        self.quantum = Decimal(1).scaleb(-scale)

    def process_bind_param(self, value, dialect):
        if value is None:
            return None
        d = value if isinstance(value, Decimal) else Decimal(str(value))
        return int((d * self.factor).to_integral_value(rounding=ROUND_HALF_UP))

    def process_result_value(self, value, dialect):
        if value is None:
            return None
        return (Decimal(int(value)) / self.factor).quantize(self.quantum)

    def __repr__(self) -> str:
        return f"ScaledDecimal(scale={self.scale})"
