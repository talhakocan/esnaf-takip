"""Bellek içi basit kayan pencere hız sınırı (tek süreç için yeterli)."""

import threading
import time
from collections import defaultdict, deque

from fastapi import Request

from app.core.errors import AppError


class RateLimiter:
    def __init__(self, limit: int, window_seconds: float) -> None:
        self.limit = limit
        self.window = window_seconds
        self._hits: dict[str, deque[float]] = defaultdict(deque)
        self._lock = threading.Lock()

    def hit(self, key: str) -> bool:
        now = time.monotonic()
        with self._lock:
            q = self._hits[key]
            while q and now - q[0] > self.window:
                q.popleft()
            if len(q) >= self.limit:
                return False
            q.append(now)
            return True

    def reset(self) -> None:
        with self._lock:
            self._hits.clear()


def client_ip(request: Request) -> str:
    return request.client.host if request.client else "unknown"


login_limiter = RateLimiter(limit=10, window_seconds=60)
track_limiter = RateLimiter(limit=30, window_seconds=60)


def enforce(limiter: RateLimiter, request: Request, scope: str) -> None:
    if not limiter.hit(f"{scope}:{client_ip(request)}"):
        raise AppError("RATE_LIMITED", "Çok fazla istek. Lütfen bir dakika sonra tekrar deneyin.", 429)
