from decimal import Decimal
from typing import Literal

from pydantic import Field, field_validator

from app.models import Currency, MovementType, PricingMode, UnitType
from app.schemas.common import Dec, In, Kurus

VatRate = Literal[0, 1, 10, 20]


class CategoryIn(In):
    name: str = Field(min_length=1, max_length=80)
    parent_id: int | None = None
    is_active: bool = True


class BrandIn(In):
    name: str = Field(min_length=1, max_length=80)
    is_active: bool = True


class LocationIn(In):
    code: str = Field(min_length=1, max_length=20)
    name: str = Field(default="", max_length=80)
    is_active: bool = True


class ProductBase(In):
    barcode: str | None = Field(default=None, max_length=64)
    name: str = Field(min_length=2, max_length=160)
    category_id: int | None = None
    brand_id: int | None = None
    supplier_id: int | None = None
    location_id: int | None = None
    unit_type: UnitType = UnitType.PIECE
    vat_rate: VatRate = 20
    purchase_currency: Currency = Currency.TRY
    purchase_price: Dec = Field(default=Decimal(0), ge=0, le=100_000_000)
    pricing_mode: PricingMode = PricingMode.FIXED
    markup_pct: Dec = Field(default=Decimal(0), ge=-99, le=1000)
    sale_price_kurus: Kurus = 0
    min_stock: Dec = Field(default=Decimal(0), ge=0, le=1_000_000)
    track_serial: bool = False
    warranty_months: int = Field(default=0, ge=0, le=120)
    notes: str = Field(default="", max_length=2000)

    @field_validator("barcode")
    @classmethod
    def _barcode(cls, v: str | None) -> str | None:
        return v or None


class ProductCreate(ProductBase):
    sku: str | None = Field(default=None, max_length=40)
    initial_stock: Dec = Field(default=Decimal(0), ge=0, le=1_000_000)
    initial_serials: list[str] = Field(default_factory=list)


class ProductUpdate(In):
    sku: str | None = Field(default=None, min_length=1, max_length=40)
    barcode: str | None = Field(default=None, max_length=64)
    name: str | None = Field(default=None, min_length=2, max_length=160)
    category_id: int | None = None
    brand_id: int | None = None
    supplier_id: int | None = None
    location_id: int | None = None
    unit_type: UnitType | None = None
    vat_rate: VatRate | None = None
    purchase_currency: Currency | None = None
    purchase_price: Dec | None = Field(default=None, ge=0, le=100_000_000)
    pricing_mode: PricingMode | None = None
    markup_pct: Dec | None = Field(default=None, ge=-99, le=1000)
    sale_price_kurus: Kurus | None = None
    min_stock: Dec | None = Field(default=None, ge=0, le=1_000_000)
    track_serial: bool | None = None
    warranty_months: int | None = Field(default=None, ge=0, le=120)
    notes: str | None = Field(default=None, max_length=2000)
    is_active: bool | None = None


class BulkFilter(In):
    product_ids: list[int] = Field(default_factory=list)
    category_id: int | None = None
    brand_id: int | None = None
    supplier_id: int | None = None


class BulkPriceIn(BulkFilter):
    pct: Dec = Field(ge=-90, le=500)


class BulkUpdateIn(In):
    product_ids: list[int] = Field(min_length=1)
    category_id: int | None = None
    location_id: int | None = None
    archive: bool | None = None


class StockAdjustIn(In):
    product_id: int
    qty: Dec = Field(gt=0)
    type: Literal[MovementType.ADJUST_IN, MovementType.ADJUST_OUT, MovementType.PURCHASE_IN] = MovementType.ADJUST_IN
    note: str = Field(default="", max_length=500)
    unit_cost_kurus: Kurus | None = None
    serials: list[str] = Field(default_factory=list)
    serial_ids: list[int] = Field(default_factory=list)


class WasteIn(In):
    product_id: int
    qty: Dec = Field(gt=0)
    note: str = Field(min_length=2, max_length=500)
    serial_ids: list[int] = Field(default_factory=list)


class SerialAddIn(In):
    serials: list[str] = Field(min_length=1)
