"""Cari, tedarikçi, satın alma, sayım, ayar ve kullanıcı şemaları."""

from datetime import date
from decimal import Decimal
from typing import Literal

from pydantic import Field, field_validator

from app.models import Currency, PaymentMethod, Role, RoundingRule
from app.schemas.common import Dec, In, Kurus


class CustomerIn(In):
    full_name: str = Field(min_length=2, max_length=120)
    phone: str = Field(default="", max_length=20)
    email: str = Field(default="", max_length=120)
    tax_no: str = Field(default="", max_length=20)
    address: str = Field(default="", max_length=500)
    note: str = Field(default="", max_length=1000)
    credit_limit_kurus: Kurus = 0
    kvkk_consent: bool = False

    @field_validator("email")
    @classmethod
    def _email(cls, v: str) -> str:
        if v and ("@" not in v or "." not in v.split("@")[-1]):
            raise ValueError("Geçerli bir e-posta girin.")
        return v


class CustomerUpdate(In):
    full_name: str | None = Field(default=None, min_length=2, max_length=120)
    phone: str | None = Field(default=None, max_length=20)
    email: str | None = Field(default=None, max_length=120)
    tax_no: str | None = Field(default=None, max_length=20)
    address: str | None = Field(default=None, max_length=500)
    note: str | None = Field(default=None, max_length=1000)
    credit_limit_kurus: Kurus | None = None
    kvkk_consent: bool | None = None
    is_active: bool | None = None


class CustomerPaymentIn(In):
    amount: int = Field(gt=0, le=10_000_000_00)
    method: Literal[PaymentMethod.CASH, PaymentMethod.CARD, PaymentMethod.TRANSFER] = PaymentMethod.CASH
    note: str = Field(default="", max_length=300)


class CustomerAdjustIn(In):
    amount: int = Field(ge=-10_000_000_00, le=10_000_000_00)
    description: str = Field(min_length=3, max_length=300)


class SupplierIn(In):
    name: str = Field(min_length=2, max_length=120)
    contact: str = Field(default="", max_length=120)
    phone: str = Field(default="", max_length=20)
    email: str = Field(default="", max_length=120)
    currency: Currency = Currency.TRY
    note: str = Field(default="", max_length=1000)
    is_active: bool = True


class POItemIn(In):
    product_id: int
    qty: Dec = Field(gt=0, le=1_000_000)
    unit_price: Dec = Field(ge=0, le=100_000_000)


class POCreate(In):
    supplier_id: int
    currency: Currency | None = None
    expected_at: date | None = None
    note: str = Field(default="", max_length=1000)
    items: list[POItemIn] = Field(min_length=1, max_length=500)


class POUpdate(In):
    expected_at: date | None = None
    note: str | None = Field(default=None, max_length=1000)
    items: list[POItemIn] | None = Field(default=None, min_length=1)


class ReceiveItemIn(In):
    item_id: int
    qty: Dec = Field(gt=0)
    serials: list[str] = Field(default_factory=list)


class ReceiveIn(In):
    items: list[ReceiveItemIn] = Field(min_length=1)
    fx_rate: Dec | None = Field(default=None, gt=0)
    update_purchase_price: bool = True


class FromCriticalIn(In):
    supplier_id: int


class CountCreate(In):
    name: str = Field(default="", max_length=100)
    location_id: int | None = None
    category_id: int | None = None


class CountItemUpdate(In):
    product_id: int
    counted_qty: Dec | None = Field(default=None, ge=0)


class CountItemsIn(In):
    items: list[CountItemUpdate] = Field(min_length=1)


class CountScanIn(In):
    code: str = Field(min_length=1, max_length=80)
    qty: Dec | None = Field(default=None, gt=0)


class SettingsUpdate(In):
    shop_name: str | None = Field(default=None, min_length=1, max_length=120)
    address: str | None = Field(default=None, max_length=300)
    phone: str | None = Field(default=None, max_length=30)
    email: str | None = Field(default=None, max_length=120)
    tax_office: str | None = Field(default=None, max_length=80)
    tax_no: str | None = Field(default=None, max_length=20)
    receipt_footer: str | None = Field(default=None, max_length=300)
    default_vat_rate: Literal[0, 1, 10, 20] | None = None
    rounding_rule: RoundingRule | None = None
    allow_negative_stock: bool | None = None
    default_warranty_months: int | None = Field(default=None, ge=0, le=120)
    credit_due_days: int | None = Field(default=None, ge=1, le=365)
    dead_stock_days: int | None = Field(default=None, ge=7, le=730)
    fx_stale_days: int | None = Field(default=None, ge=1, le=60)
    service_terms: str | None = Field(default=None, max_length=5000)
    kvkk_text: str | None = Field(default=None, max_length=5000)


class FxRatesIn(In):
    USD: Dec | None = Field(default=None, gt=0, le=10000)
    EUR: Dec | None = Field(default=None, gt=0, le=10000)


class UserCreate(In):
    username: str = Field(min_length=3, max_length=50, pattern=r"^[a-zA-Z0-9._-]+$")
    full_name: str = Field(min_length=2, max_length=100)
    role: Role = Role.STAFF
    password: str = Field(min_length=8, max_length=200)
    max_discount_pct: Dec = Field(default=Decimal(5), ge=0, le=100)


class UserUpdate(In):
    full_name: str | None = Field(default=None, min_length=2, max_length=100)
    role: Role | None = None
    password: str | None = Field(default=None, min_length=8, max_length=200)
    max_discount_pct: Dec | None = Field(default=None, ge=0, le=100)
    is_active: bool | None = None


class LoginIn(In):
    username: str = Field(min_length=1, max_length=50)
    password: str = Field(min_length=1, max_length=200)


class PasswordChangeIn(In):
    current_password: str = Field(min_length=1, max_length=200)
    new_password: str = Field(min_length=8, max_length=200)
