"""Ortak şema yardımcıları."""

from decimal import Decimal
from typing import Annotated

from pydantic import BaseModel, BeforeValidator, ConfigDict, Field

from app.core.money import to_decimal


def _dec(value: object) -> object:
    if value is None or value == "":
        return value
    try:
        return to_decimal(value)
    except ValueError:
        return value


Dec = Annotated[Decimal, BeforeValidator(_dec)]
Kurus = Annotated[int, Field(ge=0, le=10_000_000_00)]
Text = Annotated[str, Field(max_length=2000)]


class In(BaseModel):
    """Tüm istek şemalarının tabanı: bilinmeyen alanlar reddedilir, metinler kırpılır."""

    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)
