from pydantic import Field

from app.models import DeviceType, NoteVisibility, ServiceStatus
from app.schemas.common import Dec, In, Kurus
from app.schemas.sales import Override, PaymentIn


class QuickCustomer(In):
    full_name: str = Field(min_length=2, max_length=120)
    phone: str = Field(default="", max_length=20)
    kvkk_consent: bool = False


class TicketCreate(In):
    customer_id: int | None = None
    new_customer: QuickCustomer | None = None
    device_type: DeviceType
    brand: str = Field(default="", max_length=60)
    model: str = Field(default="", max_length=80)
    serial_no: str = Field(default="", max_length=80)
    accessories: list[str] = Field(default_factory=list, max_length=20)
    complaint: str = Field(min_length=3, max_length=2000)
    estimated_cost: Kurus = 0
    assigned_to: int | None = None


class TicketUpdate(In):
    brand: str | None = Field(default=None, max_length=60)
    model: str | None = Field(default=None, max_length=80)
    serial_no: str | None = Field(default=None, max_length=80)
    accessories: list[str] | None = None
    complaint: str | None = Field(default=None, min_length=3, max_length=2000)
    diagnosis: str | None = Field(default=None, max_length=4000)
    estimated_cost: Kurus | None = None
    labor_fee: Kurus | None = None
    assigned_to: int | None = None


class StatusChange(In):
    status: ServiceStatus
    note: str = Field(default="", max_length=1000)
    notify_customer: bool = False


class NoteCreate(In):
    body: str = Field(min_length=1, max_length=2000)
    visibility: NoteVisibility = NoteVisibility.INTERNAL


class PartAdd(In):
    product_id: int
    qty: Dec = Field(gt=0)
    unit_price: Kurus | None = None
    serial_id: int | None = None


class DeliverIn(In):
    payments: list[PaymentIn] = Field(default_factory=list)
    discount: Kurus = 0
    note: str = Field(default="", max_length=500)
    override: Override | None = None
