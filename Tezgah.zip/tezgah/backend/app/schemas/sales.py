from decimal import Decimal
from typing import Literal

from pydantic import Field

from app.models import PaymentMethod
from app.schemas.common import Dec, In, Kurus


class Override(In):
    """Yönetici onayı (kredi limiti aşımı gibi durumlarda anlık şifreyle onay)."""

    username: str = Field(min_length=1, max_length=50)
    password: str = Field(min_length=1, max_length=200)


class SaleItemIn(In):
    product_id: int
    qty: Dec = Field(gt=0, le=100_000)
    unit_price: Kurus | None = None
    discount: Kurus = 0
    serial_id: int | None = None


class PaymentIn(In):
    method: PaymentMethod
    amount: int = Field(gt=0, le=10_000_000_00)
    tendered: Kurus | None = None


class SaleCreate(In):
    customer_id: int | None = None
    items: list[SaleItemIn] = Field(min_length=1, max_length=300)
    discount: Kurus = 0
    payments: list[PaymentIn] = Field(min_length=1, max_length=6)
    note: str = Field(default="", max_length=500)
    override: Override | None = None


class SaleCancelIn(In):
    reason: str = Field(min_length=3, max_length=300)


class ReturnItemIn(In):
    sale_item_id: int
    qty: Dec = Field(gt=0)
    restock: bool = True


class ReturnCreate(In):
    sale_id: int
    items: list[ReturnItemIn] = Field(min_length=1)
    method: Literal[PaymentMethod.CASH, PaymentMethod.CARD, PaymentMethod.TRANSFER, PaymentMethod.CREDIT] = PaymentMethod.CASH
    reason: str = Field(min_length=3, max_length=300)


class QuoteItem(In):
    product_id: int
    qty: Dec = Field(gt=0)
    unit_price: Kurus | None = None
    discount: Kurus = 0


__all__ = ["Decimal", "Override", "PaymentIn", "ReturnCreate", "ReturnItemIn", "SaleCancelIn", "SaleCreate", "SaleItemIn"]
