"""Alembic migration'larını programatik olarak uygular."""

import os
from pathlib import Path

from alembic import command
from alembic.config import Config
from sqlalchemy import inspect

from app.db import get_engine

BACKEND_DIR = Path(os.path.abspath(__file__)).parents[1]


def alembic_config() -> Config:
    cfg = Config(str(BACKEND_DIR / "alembic.ini"))
    cfg.set_main_option("script_location", str(BACKEND_DIR / "alembic"))
    return cfg


def upgrade_db() -> None:
    cfg = alembic_config()
    with get_engine().connect() as connection:
        tables = set(inspect(connection).get_table_names())
        connection.rollback()
        cfg.attributes["connection"] = connection
        if "users" in tables and "alembic_version" not in tables:
            # Migration'sız (create_all ile) oluşturulmuş güncel şema: yeniden kurmak yerine işaretle.
            command.stamp(cfg, "head")
        else:
            command.upgrade(cfg, "head")


if __name__ == "__main__":
    upgrade_db()
    print("Veritabanı güncel.")
