"""Veritabanı motoru ve oturum yönetimi (SQLite, WAL modu)."""

from collections.abc import Iterator
from pathlib import Path

from fastapi import Request
from sqlalchemy import event
from sqlalchemy.engine import Engine
from sqlmodel import Session, create_engine

from app.config import get_settings


def _set_sqlite_pragmas(dbapi_connection, _record) -> None:
    # Transaction'ları kendimiz başlatıyoruz (BEGIN IMMEDIATE), sürücünün otomatik BEGIN'i kapalı.
    dbapi_connection.isolation_level = None
    cursor = dbapi_connection.cursor()
    cursor.execute("PRAGMA journal_mode=WAL")
    cursor.execute("PRAGMA foreign_keys=ON")
    cursor.execute("PRAGMA busy_timeout=10000")
    cursor.execute("PRAGMA synchronous=NORMAL")
    cursor.close()


def _begin_immediate(conn) -> None:
    # Yazma isteklerinde kilit transaction başında alınır: stok bakiyesi gibi oku-yaz
    # işlemleri eşzamanlı isteklerde birbirini ezmez. Okuma istekleri (GET) ertelenmiş
    # BEGIN kullanır; WAL modunda okuyucular yazarları bekletmez.
    deferred = conn.get_execution_options().get("tezgah_deferred", False)
    conn.exec_driver_sql("BEGIN" if deferred else "BEGIN IMMEDIATE")


def make_engine(url: str) -> Engine:
    if url.startswith("sqlite:///"):
        Path(url.removeprefix("sqlite:///")).parent.mkdir(parents=True, exist_ok=True)
    connect_args = {"check_same_thread": False, "timeout": 10} if url.startswith("sqlite") else {}
    eng = create_engine(url, connect_args=connect_args)
    if url.startswith("sqlite"):
        event.listen(eng, "connect", _set_sqlite_pragmas)
        event.listen(eng, "begin", _begin_immediate)
    return eng


engine: Engine = make_engine(get_settings().database_url)


def set_engine(new_engine: Engine) -> None:
    """Testlerde ve yedek geri yüklemede motoru değiştirmek için."""
    global engine
    engine = new_engine


def get_engine() -> Engine:
    return engine


def read_bind() -> Engine:
    """Okuma ağırlıklı oturumlar için ertelenmiş transaction başlatan motor görünümü."""
    return engine.execution_options(tezgah_deferred=True)


def get_session(request: Request) -> Iterator[Session]:
    bind = read_bind() if request.method in ("GET", "HEAD") else engine
    with Session(bind) as session:
        yield session


def db_file_path() -> Path | None:
    url = str(engine.url)
    if url.startswith("sqlite:///"):
        return Path(url.removeprefix("sqlite:///"))
    return None
