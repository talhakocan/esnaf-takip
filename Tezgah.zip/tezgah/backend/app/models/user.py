from decimal import Decimal

from sqlmodel import Field

from app.models.common import Base, Role, dec_field


class User(Base, table=True):
    __tablename__ = "users"

    username: str = Field(max_length=50, unique=True, index=True)
    full_name: str = Field(max_length=100)
    role: Role = Field(default=Role.STAFF)
    password_hash: str
    max_discount_pct: Decimal = dec_field(2)
    is_active: bool = True
