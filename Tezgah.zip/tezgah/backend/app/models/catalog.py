from datetime import date
from decimal import Decimal
from enum import StrEnum

from pydantic import NaiveDatetime
from sqlmodel import Field, UniqueConstraint

from app.models.common import Base, Currency, PricingMode, UnitType, dec_field


class Category(Base, table=True):
    __tablename__ = "categories"

    name: str = Field(max_length=80)
    parent_id: int | None = Field(default=None, foreign_key="categories.id", index=True)
    is_active: bool = True


class Brand(Base, table=True):
    __tablename__ = "brands"

    name: str = Field(max_length=80, unique=True)
    is_active: bool = True


class Location(Base, table=True):
    __tablename__ = "locations"

    code: str = Field(max_length=20, unique=True)
    name: str = Field(default="", max_length=80)
    is_active: bool = True


class Product(Base, table=True):
    __tablename__ = "products"

    sku: str = Field(max_length=40, unique=True, index=True)
    barcode: str | None = Field(default=None, max_length=64, unique=True, index=True)
    name: str = Field(max_length=160, index=True)
    category_id: int | None = Field(default=None, foreign_key="categories.id", index=True)
    brand_id: int | None = Field(default=None, foreign_key="brands.id", index=True)
    supplier_id: int | None = Field(default=None, foreign_key="suppliers.id", index=True)
    unit_type: UnitType = Field(default=UnitType.PIECE)
    vat_rate: int = 20
    purchase_currency: Currency = Field(default=Currency.TRY)
    purchase_price: Decimal = dec_field(6)
    pricing_mode: PricingMode = Field(default=PricingMode.FIXED)
    markup_pct: Decimal = dec_field(2)
    sale_price_kurus: int = 0
    min_stock: Decimal = dec_field(3)
    stock_qty: Decimal = dec_field(3)
    avg_cost_kurus: int = 0
    location_id: int | None = Field(default=None, foreign_key="locations.id", index=True)
    track_serial: bool = False
    warranty_months: int = 0
    notes: str = ""
    is_active: bool = True
    last_movement_at: NaiveDatetime | None = None
    created_by: int | None = Field(default=None, foreign_key="users.id")


class PriceReason(StrEnum):
    MANUAL = "MANUAL"
    FX_UPDATE = "FX_UPDATE"
    BULK = "BULK"
    IMPORT = "IMPORT"


class PriceHistory(Base, table=True):
    __tablename__ = "price_history"

    product_id: int = Field(foreign_key="products.id", index=True)
    old_price: int
    new_price: int
    reason: PriceReason
    user_id: int | None = Field(default=None, foreign_key="users.id")


class SerialStatus(StrEnum):
    IN_STOCK = "IN_STOCK"
    SOLD = "SOLD"
    RETURNED = "RETURNED"
    DEFECTIVE = "DEFECTIVE"


class ProductSerial(Base, table=True):
    __tablename__ = "product_serials"
    __table_args__ = (UniqueConstraint("product_id", "serial_no"),)

    product_id: int = Field(foreign_key="products.id", index=True)
    serial_no: str = Field(max_length=80, index=True)
    status: SerialStatus = Field(default=SerialStatus.IN_STOCK)
    purchase_movement_id: int | None = Field(default=None, foreign_key="stock_movements.id")
    sale_item_id: int | None = Field(default=None, foreign_key="sale_items.id")
    service_part_id: int | None = Field(default=None, foreign_key="service_parts.id")
    warranty_until: date | None = None
