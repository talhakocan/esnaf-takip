from decimal import Decimal
from enum import StrEnum

from pydantic import NaiveDatetime
from sqlmodel import Field

from app.models.common import Base, dec_field


class MovementType(StrEnum):
    PURCHASE_IN = "PURCHASE_IN"
    SALE_OUT = "SALE_OUT"
    SALE_RETURN = "SALE_RETURN"
    SERVICE_OUT = "SERVICE_OUT"
    SERVICE_RETURN = "SERVICE_RETURN"
    ADJUST_IN = "ADJUST_IN"
    ADJUST_OUT = "ADJUST_OUT"
    COUNT_ADJUST = "COUNT_ADJUST"
    WASTE = "WASTE"


class StockMovement(Base, table=True):
    """Değiştirilemez stok defteri. Kayıtlar yalnızca StockService tarafından eklenir."""

    __tablename__ = "stock_movements"

    product_id: int = Field(foreign_key="products.id", index=True)
    type: MovementType = Field(index=True)
    qty: Decimal = dec_field(3)
    unit_cost_kurus: int = 0
    ref_type: str | None = Field(default=None, max_length=30)
    ref_id: int | None = None
    note: str = ""
    user_id: int | None = Field(default=None, foreign_key="users.id", index=True)
    balance_after: Decimal = dec_field(3)


class CountStatus(StrEnum):
    OPEN = "OPEN"
    APPLIED = "APPLIED"
    CANCELLED = "CANCELLED"


class StockCount(Base, table=True):
    __tablename__ = "stock_counts"

    name: str = Field(max_length=100)
    location_id: int | None = Field(default=None, foreign_key="locations.id")
    category_id: int | None = Field(default=None, foreign_key="categories.id")
    status: CountStatus = Field(default=CountStatus.OPEN)
    note: str = ""
    created_by: int | None = Field(default=None, foreign_key="users.id")
    applied_by: int | None = Field(default=None, foreign_key="users.id")
    applied_at: NaiveDatetime | None = None


class StockCountItem(Base, table=True):
    __tablename__ = "stock_count_items"

    count_id: int = Field(foreign_key="stock_counts.id", index=True)
    product_id: int = Field(foreign_key="products.id")
    expected_qty: Decimal = dec_field(3)
    counted_qty: Decimal | None = dec_field(3, default=None, nullable=True)
    diff: Decimal | None = dec_field(3, default=None, nullable=True)
