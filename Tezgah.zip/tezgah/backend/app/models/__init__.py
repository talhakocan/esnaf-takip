"""Tüm tablolar burada içe aktarılır (Alembic metadata için)."""

from app.models.audit import AuditLog
from app.models.catalog import (
    Brand,
    Category,
    Location,
    PriceHistory,
    PriceReason,
    Product,
    ProductSerial,
    SerialStatus,
)
from app.models.common import Currency, PricingMode, Role, RoundingRule, UnitType, now
from app.models.party import Customer, LedgerEntry, LedgerType, Supplier
from app.models.purchasing import POStatus, PurchaseOrder, PurchaseOrderItem
from app.models.sales import Payment, PaymentMethod, Return, ReturnItem, Sale, SaleItem, SaleStatus
from app.models.service import (
    DeviceType,
    NoteVisibility,
    ServiceNote,
    ServicePart,
    ServiceStatus,
    ServiceStatusHistory,
    ServiceTicket,
)
from app.models.settings import ExchangeRate, ShopSettings
from app.models.stock import CountStatus, MovementType, StockCount, StockCountItem, StockMovement
from app.models.user import User

__all__ = [
    "AuditLog",
    "Brand",
    "Category",
    "CountStatus",
    "Currency",
    "Customer",
    "DeviceType",
    "ExchangeRate",
    "LedgerEntry",
    "LedgerType",
    "Location",
    "MovementType",
    "NoteVisibility",
    "POStatus",
    "Payment",
    "PaymentMethod",
    "PriceHistory",
    "PriceReason",
    "PricingMode",
    "Product",
    "ProductSerial",
    "PurchaseOrder",
    "PurchaseOrderItem",
    "Return",
    "ReturnItem",
    "Role",
    "RoundingRule",
    "Sale",
    "SaleItem",
    "SaleStatus",
    "SerialStatus",
    "ServiceNote",
    "ServicePart",
    "ServiceStatus",
    "ServiceStatusHistory",
    "ServiceTicket",
    "ShopSettings",
    "StockCount",
    "StockCountItem",
    "StockMovement",
    "Supplier",
    "UnitType",
    "User",
    "now",
]
