"""Ortak model yardımcıları."""

from datetime import datetime
from decimal import Decimal
from enum import StrEnum
from typing import Any

from pydantic import NaiveDatetime
from sqlalchemy import JSON, Column
from sqlmodel import Field, SQLModel

from app.core.types import ScaledDecimal


def now() -> datetime:
    """Dükkanın yerel saati (Türkiye UTC+3, yaz saati yok)."""
    return datetime.now().replace(microsecond=0)


def dec_field(scale: int = 3, default: Decimal | None = Decimal(0), nullable: bool = False) -> Any:
    return Field(default=default, sa_column=Column(ScaledDecimal(scale), nullable=nullable))


def json_field(default_factory=list) -> Any:
    return Field(default_factory=default_factory, sa_column=Column(JSON, nullable=False))


class Base(SQLModel):
    id: int | None = Field(default=None, primary_key=True)
    created_at: NaiveDatetime = Field(default_factory=now, index=True)
    updated_at: NaiveDatetime = Field(default_factory=now, sa_column_kwargs={"onupdate": now})


class Role(StrEnum):
    ADMIN = "ADMIN"
    STAFF = "STAFF"


class Currency(StrEnum):
    TRY = "TRY"
    USD = "USD"
    EUR = "EUR"


class UnitType(StrEnum):
    PIECE = "PIECE"
    METER = "METER"
    SERVICE = "SERVICE"


class PricingMode(StrEnum):
    FIXED = "FIXED"
    FX_LINKED = "FX_LINKED"


class RoundingRule(StrEnum):
    NONE = "NONE"
    NEAREST_1 = "NEAREST_1"
    NEAREST_5 = "NEAREST_5"
    END_90 = "END_90"
