from decimal import Decimal

from pydantic import NaiveDatetime
from sqlmodel import Field

from app.models.common import Base, Currency, RoundingRule, dec_field


class ShopSettings(Base, table=True):
    """Tekil kayıt (id=1)."""

    __tablename__ = "settings"

    shop_name: str = "Teknolife"
    address: str = ""
    phone: str = ""
    email: str = ""
    tax_office: str = ""
    tax_no: str = ""
    receipt_footer: str = "Bizi tercih ettiğiniz için teşekkür ederiz."
    default_vat_rate: int = 20
    rounding_rule: RoundingRule = Field(default=RoundingRule.NEAREST_5)
    allow_negative_stock: bool = False
    default_warranty_months: int = 24
    credit_due_days: int = 30
    dead_stock_days: int = 90
    fx_stale_days: int = 3
    service_terms: str = ""
    kvkk_text: str = ""


class ExchangeRate(Base, table=True):
    __tablename__ = "exchange_rates"

    currency: Currency = Field(index=True)
    rate: Decimal = dec_field(6)
    source: str = Field(default="MANUAL", max_length=10)
    fetched_at: NaiveDatetime = Field(index=True)
    user_id: int | None = Field(default=None, foreign_key="users.id")
