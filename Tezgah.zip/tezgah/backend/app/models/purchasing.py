from datetime import date
from decimal import Decimal
from enum import StrEnum

from pydantic import NaiveDatetime
from sqlmodel import Field

from app.models.common import Base, Currency, dec_field


class POStatus(StrEnum):
    DRAFT = "DRAFT"
    ORDERED = "ORDERED"
    PARTIAL = "PARTIAL"
    RECEIVED = "RECEIVED"
    CANCELLED = "CANCELLED"


class PurchaseOrder(Base, table=True):
    __tablename__ = "purchase_orders"

    order_no: str = Field(max_length=20, unique=True)
    supplier_id: int = Field(foreign_key="suppliers.id", index=True)
    status: POStatus = Field(default=POStatus.DRAFT, index=True)
    currency: Currency = Field(default=Currency.TRY)
    fx_rate: Decimal = dec_field(6, default=Decimal(1))
    expected_at: date | None = None
    ordered_at: NaiveDatetime | None = None
    received_at: NaiveDatetime | None = None
    note: str = ""
    created_by: int | None = Field(default=None, foreign_key="users.id")


class PurchaseOrderItem(Base, table=True):
    """unit_price sipariş para birimindedir; kabulde o günün kuruyla TL maliyete çevrilir."""

    __tablename__ = "purchase_order_items"

    order_id: int = Field(foreign_key="purchase_orders.id", index=True)
    product_id: int = Field(foreign_key="products.id")
    qty: Decimal = dec_field(3)
    received_qty: Decimal = dec_field(3)
    unit_price: Decimal = dec_field(6)
