from decimal import Decimal
from enum import StrEnum

from pydantic import NaiveDatetime
from sqlmodel import Field

from app.models.common import Base, dec_field


class SaleStatus(StrEnum):
    COMPLETED = "COMPLETED"
    CANCELLED = "CANCELLED"


class PaymentMethod(StrEnum):
    CASH = "CASH"
    CARD = "CARD"
    TRANSFER = "TRANSFER"
    CREDIT = "CREDIT"


class Sale(Base, table=True):
    __tablename__ = "sales"

    receipt_no: str = Field(max_length=20, unique=True, index=True)
    customer_id: int | None = Field(default=None, foreign_key="customers.id", index=True)
    status: SaleStatus = Field(default=SaleStatus.COMPLETED, index=True)
    subtotal: int = 0
    discount: int = 0
    vat_total: int = 0
    total: int = 0
    note: str = ""
    user_id: int | None = Field(default=None, foreign_key="users.id", index=True)
    service_ticket_id: int | None = Field(default=None, foreign_key="service_tickets.id")
    cancelled_reason: str | None = None
    cancelled_at: NaiveDatetime | None = None
    cancelled_by: int | None = Field(default=None, foreign_key="users.id")


class SaleItem(Base, table=True):
    """Satır tutarları kuruş. unit_price KDV dahildir; net_total genel indirim dağıtıldıktan sonraki tutardır."""

    __tablename__ = "sale_items"

    sale_id: int = Field(foreign_key="sales.id", index=True)
    product_id: int = Field(foreign_key="products.id", index=True)
    product_name: str = Field(max_length=160)
    qty: Decimal = dec_field(3)
    unit_price: int
    discount: int = 0
    allocated_discount: int = 0
    vat_rate: int
    vat_amount: int = 0
    line_total: int
    net_total: int
    unit_cost_snapshot: int = 0
    serial_id: int | None = Field(default=None, foreign_key="product_serials.id")
    returned_qty: Decimal = dec_field(3)


class Payment(Base, table=True):
    __tablename__ = "payments"

    sale_id: int | None = Field(default=None, foreign_key="sales.id", index=True)
    customer_id: int | None = Field(default=None, foreign_key="customers.id", index=True)
    return_id: int | None = Field(default=None, foreign_key="returns.id")
    method: PaymentMethod
    amount: int
    tendered: int | None = None
    note: str = ""
    user_id: int | None = Field(default=None, foreign_key="users.id")


class Return(Base, table=True):
    __tablename__ = "returns"

    sale_id: int = Field(foreign_key="sales.id", index=True)
    customer_id: int | None = Field(default=None, foreign_key="customers.id")
    method: PaymentMethod
    total: int = 0
    reason: str = ""
    user_id: int | None = Field(default=None, foreign_key="users.id")


class ReturnItem(Base, table=True):
    __tablename__ = "return_items"

    return_id: int = Field(foreign_key="returns.id", index=True)
    sale_item_id: int = Field(foreign_key="sale_items.id")
    product_id: int = Field(foreign_key="products.id")
    qty: Decimal = dec_field(3)
    amount: int
    restock: bool = True
