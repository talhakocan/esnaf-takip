from datetime import date
from enum import StrEnum

from pydantic import NaiveDatetime
from sqlmodel import Field

from app.models.common import Base, Currency


class Customer(Base, table=True):
    __tablename__ = "customers"

    full_name: str = Field(max_length=120, index=True)
    phone: str = Field(default="", max_length=20, index=True)
    email: str = Field(default="", max_length=120)
    tax_no: str = Field(default="", max_length=20)
    address: str = ""
    note: str = ""
    credit_limit_kurus: int = 0
    kvkk_consent_at: NaiveDatetime | None = None
    is_active: bool = True
    created_by: int | None = Field(default=None, foreign_key="users.id")


class Supplier(Base, table=True):
    __tablename__ = "suppliers"

    name: str = Field(max_length=120, index=True)
    contact: str = Field(default="", max_length=120)
    phone: str = Field(default="", max_length=20)
    email: str = Field(default="", max_length=120)
    currency: Currency = Field(default=Currency.TRY)
    note: str = ""
    is_active: bool = True


class LedgerType(StrEnum):
    DEBT = "DEBT"
    PAYMENT = "PAYMENT"
    ADJUST = "ADJUST"


class LedgerEntry(Base, table=True):
    """Cari hesap hareketi. DEBT borç (+), PAYMENT tahsilat (-), ADJUST işaretli düzeltme."""

    __tablename__ = "ledger_entries"

    customer_id: int = Field(foreign_key="customers.id", index=True)
    type: LedgerType
    amount: int
    description: str = ""
    ref_type: str | None = Field(default=None, max_length=30)
    ref_id: int | None = None
    due_date: date | None = None
    user_id: int | None = Field(default=None, foreign_key="users.id")
