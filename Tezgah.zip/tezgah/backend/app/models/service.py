from decimal import Decimal
from enum import StrEnum

from pydantic import NaiveDatetime
from sqlmodel import Field

from app.models.common import Base, dec_field, json_field


class DeviceType(StrEnum):
    LAPTOP = "LAPTOP"
    DESKTOP = "DESKTOP"
    PRINTER = "PRINTER"
    PHONE = "PHONE"
    MONITOR = "MONITOR"
    OTHER = "OTHER"


class ServiceStatus(StrEnum):
    RECEIVED = "RECEIVED"
    DIAGNOSING = "DIAGNOSING"
    WAITING_APPROVAL = "WAITING_APPROVAL"
    WAITING_PARTS = "WAITING_PARTS"
    IN_REPAIR = "IN_REPAIR"
    READY = "READY"
    DELIVERED = "DELIVERED"
    CANCELLED = "CANCELLED"


class NoteVisibility(StrEnum):
    INTERNAL = "INTERNAL"
    CUSTOMER = "CUSTOMER"


class ServiceTicket(Base, table=True):
    __tablename__ = "service_tickets"

    code: str = Field(max_length=12, unique=True, index=True)
    customer_id: int = Field(foreign_key="customers.id", index=True)
    device_type: DeviceType
    brand: str = Field(default="", max_length=60)
    model: str = Field(default="", max_length=80)
    serial_no: str = Field(default="", max_length=80)
    accessories: list[str] = json_field()
    complaint: str
    diagnosis: str = ""
    status: ServiceStatus = Field(default=ServiceStatus.RECEIVED, index=True)
    status_changed_at: NaiveDatetime | None = None
    estimated_cost: int = 0
    approved_by_customer_at: NaiveDatetime | None = None
    labor_fee: int = 0
    assigned_to: int | None = Field(default=None, foreign_key="users.id")
    received_at: NaiveDatetime
    delivered_at: NaiveDatetime | None = None
    sale_id: int | None = Field(default=None, foreign_key="sales.id")
    created_by: int | None = Field(default=None, foreign_key="users.id")


class ServiceStatusHistory(Base, table=True):
    __tablename__ = "service_status_history"

    ticket_id: int = Field(foreign_key="service_tickets.id", index=True)
    from_status: ServiceStatus | None = None
    to_status: ServiceStatus
    note: str = ""
    user_id: int | None = Field(default=None, foreign_key="users.id")
    at: NaiveDatetime


class ServiceNote(Base, table=True):
    __tablename__ = "service_notes"

    ticket_id: int = Field(foreign_key="service_tickets.id", index=True)
    body: str
    visibility: NoteVisibility = Field(default=NoteVisibility.INTERNAL)
    user_id: int | None = Field(default=None, foreign_key="users.id")


class ServicePart(Base, table=True):
    __tablename__ = "service_parts"

    ticket_id: int = Field(foreign_key="service_tickets.id", index=True)
    product_id: int = Field(foreign_key="products.id")
    qty: Decimal = dec_field(3)
    unit_price: int
    serial_id: int | None = Field(default=None, foreign_key="product_serials.id")
    unit_cost_snapshot: int = 0
    removed_at: NaiveDatetime | None = None
    user_id: int | None = Field(default=None, foreign_key="users.id")
