from typing import Any

from pydantic import NaiveDatetime
from sqlmodel import Field

from app.models.common import Base, json_field, now


class AuditLog(Base, table=True):
    __tablename__ = "audit_logs"

    user_id: int | None = Field(default=None, foreign_key="users.id", index=True)
    action: str = Field(max_length=40, index=True)
    entity: str = Field(max_length=40, index=True)
    entity_id: int | None = None
    diff: dict[str, Any] = json_field(dict)
    ip: str | None = Field(default=None, max_length=64)
    at: NaiveDatetime = Field(default_factory=now, index=True)
