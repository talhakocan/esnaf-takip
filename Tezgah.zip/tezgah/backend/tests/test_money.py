from decimal import Decimal

import pytest

from app.core.dates import add_months
from app.core.money import (
    allocate,
    apply_rounding,
    line_amount,
    qty,
    tl_to_kurus,
    to_decimal,
    validate_qty_for_unit,
    vat_of_gross,
)
from app.models import RoundingRule, UnitType


def test_to_decimal_accepts_turkish_format():
    assert to_decimal("1.234,50") == Decimal("1234.50")
    assert to_decimal("12,5") == Decimal("12.5")
    assert to_decimal(3) == Decimal(3)
    with pytest.raises(ValueError):
        to_decimal("abc")


def test_line_amount_rounds_half_up():
    assert line_amount(Decimal("12.5"), 1490) == 18625
    assert line_amount(Decimal("0.333"), 1000) == 333
    assert line_amount(Decimal("1.5"), 3) == 5  # 4,5 -> 5


def test_vat_of_gross():
    assert vat_of_gross(12000, 20) == 2000
    assert vat_of_gross(11000, 10) == 1000
    assert vat_of_gross(10100, 1) == 100
    assert vat_of_gross(5000, 0) == 0


@pytest.mark.parametrize(
    ("kurus", "rule", "expected"),
    [
        (216537, RoundingRule.NONE, 216537),
        (216537, RoundingRule.NEAREST_1, 216500),
        (216551, RoundingRule.NEAREST_1, 216600),
        (216537, RoundingRule.NEAREST_5, 216500),
        (216800, RoundingRule.NEAREST_5, 217000),
        (216537, RoundingRule.END_90, 216590),
        (216595, RoundingRule.END_90, 216690),
        (216590, RoundingRule.END_90, 216590),
        (100, RoundingRule.NEAREST_5, 500),
        (0, RoundingRule.END_90, 0),
    ],
)
def test_apply_rounding(kurus, rule, expected):
    assert apply_rounding(kurus, rule) == expected


def test_piece_requires_integer_qty():
    validate_qty_for_unit(Decimal("12.5"), UnitType.METER)
    validate_qty_for_unit(Decimal("3"), UnitType.PIECE)
    with pytest.raises(ValueError):
        validate_qty_for_unit(Decimal("1.5"), UnitType.PIECE)


def test_allocate_distributes_without_loss():
    parts = allocate(100, [3333, 3333, 3334])
    assert sum(parts) == 100
    assert allocate(0, [1, 2]) == [0, 0]
    assert allocate(50, []) == []
    assert allocate(7, [0, 0]) == [0, 0]


def test_misc_helpers():
    assert qty("2,5") == Decimal("2.500")
    assert tl_to_kurus("1.234,56") == 123456
    from datetime import date

    assert add_months(date(2026, 1, 31), 1) == date(2026, 2, 28)
    assert add_months(date(2026, 11, 15), 24) == date(2028, 11, 15)
