from decimal import Decimal
from io import BytesIO

import pytest
from openpyxl import Workbook, load_workbook
from sqlmodel import select

from app.core.errors import ValidationFailed
from app.models import Currency, PriceHistory, PriceReason, PricingMode, Product, RoundingRule, UnitType
from app.services import fx_service, pricing_service, product_service, settings_service


def test_compute_fx_price_matches_spec_example():
    raw, rounded = pricing_service.compute_fx_price(Decimal("42"), Decimal("41.23"), Decimal("25"), RoundingRule.NEAREST_5)
    assert raw == 216458  # 42 × 41,23 × 1,25 = 2.164,575
    assert rounded == 216500


def test_fx_update_reprices_linked_products_and_writes_history(session, admin_actor, rates, make_product):
    linked = make_product(
        pricing_mode=PricingMode.FX_LINKED,
        purchase_currency=Currency.USD,
        purchase_price=Decimal("42"),
        markup_pct=Decimal("25"),
        sale_price_kurus=0,
    )
    fixed = make_product(sale_price_kurus=5000)
    updated = fx_service.set_rates(session, admin_actor, {"USD": Decimal("45.00")})
    assert updated == 1
    session.refresh(linked)
    session.refresh(fixed)
    assert linked.sale_price_kurus == 236500  # 42 × 45 × 1,25 = 2.362,50 → 2.365
    assert fixed.sale_price_kurus == 5000
    hist = session.exec(select(PriceHistory).where(PriceHistory.product_id == linked.id)).all()
    assert hist[-1].reason == PriceReason.FX_UPDATE and hist[-1].new_price == 236500
    assert fx_service.current_rates(session)["rates"]["USD"]["rate"] == Decimal("45.000000")


def test_invalid_rate_rejected(session, admin_actor, rates):
    with pytest.raises(ValidationFailed):
        fx_service.set_rates(session, admin_actor, {"USD": Decimal("0")})


def test_tcmb_parser():
    xml = """<?xml version="1.0"?><Tarih_Date><Currency CrossOrder="0" Kod="USD" CurrencyCode="USD"><ForexBuying>41.1</ForexBuying>
    <ForexSelling>41.2345</ForexSelling></Currency><Currency Kod="EUR" CurrencyCode="EUR"><ForexSelling>48.0012</ForexSelling></Currency>
    <Currency Kod="GBP" CurrencyCode="GBP"><ForexSelling>55</ForexSelling></Currency></Tarih_Date>"""
    assert fx_service.parse_tcmb_xml(xml) == {"USD": Decimal("41.2345"), "EUR": Decimal("48.0012")}
    with pytest.raises(ValueError):
        fx_service.parse_tcmb_xml("<Tarih_Date></Tarih_Date>")


def test_tcmb_fetch_offline_gives_friendly_error(monkeypatch):
    import httpx

    def boom(*a, **k):
        raise httpx.ConnectError("offline")

    monkeypatch.setattr(httpx, "get", boom)
    from app.core.errors import AppError

    with pytest.raises(AppError) as exc:
        fx_service.fetch_tcmb()
    assert exc.value.code == "TCMB_UNAVAILABLE"


def test_create_product_generates_sku_and_initial_stock(session, admin_actor, rates):
    from app.schemas.catalog import ProductCreate

    out = product_service.create_product(
        session,
        admin_actor,
        ProductCreate(name="NYA 1,5 mm² kablo", unit_type=UnitType.METER, sale_price_kurus=1290, initial_stock=Decimal("250.5")),
    )
    assert out["sku"].startswith("TL-")
    assert out["stock_qty"] == Decimal("250.5")
    p = session.get(Product, out["id"])
    assert p.stock_qty == Decimal("250.500")


def test_create_fx_product_price_is_computed(session, admin_actor, rates):
    from app.schemas.catalog import ProductCreate

    out = product_service.create_product(
        session,
        admin_actor,
        ProductCreate(
            name="500 GB NVMe SSD",
            sku="ssd-500",
            purchase_currency=Currency.USD,
            purchase_price=Decimal("42"),
            pricing_mode=PricingMode.FX_LINKED,
            markup_pct=Decimal("25"),
            track_serial=True,
            warranty_months=36,
            initial_stock=Decimal(2),
            initial_serials=["S1", "S2"],
        ),
    )
    assert out["sku"] == "SSD-500"
    assert out["sale_price_kurus"] == 216500
    assert out["price_breakdown"]["raw_kurus"] == 216458


def test_serial_product_requires_serials(session, admin_actor, rates):
    from app.schemas.catalog import ProductCreate

    with pytest.raises(ValidationFailed):
        product_service.create_product(
            session,
            admin_actor,
            ProductCreate(name="RAM", sale_price_kurus=100, track_serial=True, initial_stock=Decimal(2), initial_serials=["X"]),
        )


def test_duplicate_barcode_rejected(session, admin_actor, make_product):
    from app.core.errors import Conflict
    from app.schemas.catalog import ProductCreate

    make_product(barcode="8690000000001")
    with pytest.raises(Conflict):
        product_service.create_product(session, admin_actor, ProductCreate(name="Başka", barcode="8690000000001", sale_price_kurus=100))


def test_lookup_by_barcode_sku_and_serial(session, admin_actor, make_product):
    from app.models import MovementType
    from app.services import stock_service

    p = make_product(barcode="8690000000002", track_serial=True)
    stock_service.manual_adjust(session, admin_actor, p.id, Decimal(1), MovementType.ADJUST_IN, "giriş", serials=["SN-777"])
    assert product_service.lookup(session, admin_actor, "8690000000002")["matched_by"] == "barcode"
    assert product_service.lookup(session, admin_actor, p.sku.lower())["matched_by"] == "sku"
    hit = product_service.lookup(session, admin_actor, "sn-777")
    assert hit["matched_by"] == "serial" and hit["serial"]["serial_no"] == "SN-777"


def test_next_internal_barcode(session, make_product):
    assert product_service.next_internal_barcode(session) == "TL10000001"
    make_product(barcode="TL10000041")
    assert product_service.next_internal_barcode(session) == "TL10000042"


def test_bulk_price_preview_and_apply(session, admin_actor, rates, make_product):
    from app.schemas.catalog import BulkPriceIn

    s = settings_service.get_settings_row(session)
    s.rounding_rule = RoundingRule.NONE
    session.commit()
    a = make_product(sale_price_kurus=10000)
    b = make_product(
        pricing_mode=PricingMode.FX_LINKED, purchase_currency=Currency.USD, purchase_price=Decimal("10"), markup_pct=Decimal("20")
    )
    pricing_service.reprice(session, b, admin_actor.id, PriceReason.MANUAL)
    session.commit()
    prev = product_service.bulk_price_preview(session, BulkPriceIn(product_ids=[a.id, b.id], pct=Decimal(10)))
    assert prev["count"] == 2
    row_a = next(r for r in prev["rows"] if r["id"] == a.id)
    assert row_a["new_price"] == 11000
    res = product_service.bulk_price_apply(session, admin_actor, BulkPriceIn(product_ids=[a.id, b.id], pct=Decimal(10)))
    assert res["updated"] == 2
    session.refresh(b)
    assert b.markup_pct == Decimal("32.00")
    with pytest.raises(ValidationFailed):
        product_service.bulk_price_preview(session, BulkPriceIn(pct=Decimal(5)))


def test_update_product_rules(session, admin_actor, make_product):
    from app.schemas.catalog import ProductUpdate

    p = make_product(stock=3)
    with pytest.raises(ValidationFailed):
        product_service.update_product(session, admin_actor, p.id, ProductUpdate(track_serial=True))
    session.rollback()
    out = product_service.update_product(session, admin_actor, p.id, ProductUpdate(sale_price_kurus=12345, name="Yeni ad"))
    assert out["sale_price_kurus"] == 12345 and out["name"] == "Yeni ad"
    assert product_service.price_history(session, p.id)[0]["new_price"] == 12345
    assert product_service.set_active(session, admin_actor, p.id, False)["is_active"] is False


def test_product_list_filters_and_staff_view(session, admin_actor, staff_actor, make_product):
    make_product(stock=1, min_stock=Decimal(5), name="Kritik priz")
    make_product(stock=50, min_stock=Decimal(5), name="Bol kablo")
    crit = product_service.list_products(session, admin_actor, stock="critical")
    assert [r["name"] for r in crit] == ["Kritik priz"]
    assert "purchase_price" in crit[0]
    staff_rows = product_service.list_products(session, staff_actor)
    assert all("purchase_price" not in r and "margin_pct" not in r and "avg_cost_kurus" not in r for r in staff_rows)


def _xlsx(rows):
    wb = Workbook()
    ws = wb.active
    ws.append(product_service.XLSX_COLUMNS)
    for r in rows:
        ws.append(r)
    buf = BytesIO()
    wb.save(buf)
    return buf.getvalue()


def test_import_preview_and_apply(session, admin_actor, rates, make_product):
    existing = make_product(sku="VAR-1", name="Eski ad")
    content = _xlsx(
        [
            ["VAR-1", "", "Yeni ad", "Elektrik › Kablo", "Öznur", "METRE", 20, "TRY", 9.5, "SABİT", 0, 14.9, 100, "A-01", "HAYIR", 0, 0],
            [
                "",
                "",
                "USB-C adaptör",
                "Bilgisayar › Kablo & Adaptör",
                "Ugreen",
                "ADET",
                20,
                "USD",
                8,
                "KUR",
                40,
                0,
                2,
                "B-02",
                "HAYIR",
                12,
                5,
            ],
            ["", "", "Hatalı", "", "", "KOLI", 20, "TRY", 1, "SABİT", 0, 0, 0, "", "HAYIR", 0, 0],
        ]
    )
    prev = product_service.import_preview(session, content)
    assert prev["counts"] == {"NEW": 1, "UPDATE": 1, "ERROR": 1}
    with pytest.raises(ValidationFailed):
        product_service.import_apply(session, admin_actor, content)
    session.rollback()
    res = product_service.import_apply(
        session,
        admin_actor,
        _xlsx(
            [
                ["VAR-1", "", "Yeni ad", "Elektrik › Kablo", "Öznur", "ADET", 20, "TRY", 9.5, "SABİT", 0, 14.9, 100, "A-01", "HAYIR", 0, 0],
                [
                    "",
                    "",
                    "USB-C adaptör",
                    "Bilgisayar › Kablo & Adaptör",
                    "Ugreen",
                    "ADET",
                    20,
                    "USD",
                    8,
                    "KUR",
                    40,
                    0,
                    2,
                    "B-02",
                    "HAYIR",
                    12,
                    5,
                ],
            ]
        ),
    )
    assert res == {"created": 1, "updated": 1}
    session.refresh(existing)
    assert existing.name == "Yeni ad" and existing.sale_price_kurus == 1490
    new = session.exec(select(Product).where(Product.name == "USB-C adaptör")).one()
    assert new.stock_qty == Decimal(5) and new.sale_price_kurus > 0


def test_export_xlsx_hides_cost_for_staff(session, admin_actor, staff_actor, make_product):
    make_product(stock=2)
    admin_headers = [c.value for c in load_workbook(BytesIO(product_service.export_xlsx(session, admin_actor))).active[1]]
    staff_headers = [c.value for c in load_workbook(BytesIO(product_service.export_xlsx(session, staff_actor))).active[1]]
    assert "Alış fiyatı" in admin_headers and "Alış fiyatı" not in staff_headers
    assert load_workbook(BytesIO(product_service.import_template_xlsx())).active.max_row == 2


def test_catalog_crud(session, admin_actor):
    from app.core.errors import Conflict
    from app.schemas.catalog import BrandIn, CategoryIn, LocationIn
    from app.services import catalog_service

    root = catalog_service.save_category(session, admin_actor, CategoryIn(name="Bilgisayar"))
    child = catalog_service.save_category(session, admin_actor, CategoryIn(name="Depolama", parent_id=root.id))
    assert any(c["path"] == "Bilgisayar › Depolama" for c in catalog_service.list_categories(session))
    with pytest.raises(ValidationFailed):
        catalog_service.save_category(session, admin_actor, CategoryIn(name="Bilgisayar", parent_id=child.id), root.id)
    session.rollback()
    catalog_service.save_brand(session, admin_actor, BrandIn(name="Samsung"))
    with pytest.raises(Conflict):
        catalog_service.save_brand(session, admin_actor, BrandIn(name="samsung"))
    session.rollback()
    loc = catalog_service.save_location(session, admin_actor, LocationIn(code="a-03", name="Ön raf"))
    assert loc.code == "A-03"
    assert set(catalog_service.descendant_ids(session, root.id)) == {root.id, child.id}
