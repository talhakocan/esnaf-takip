"""Cari, tedarikçi/satın alma, sayım, kullanıcı ve ayar testleri."""

from datetime import date, timedelta
from decimal import Decimal

import pytest
from sqlmodel import select

from app.core.errors import Conflict, Forbidden, ValidationFailed
from app.models import (
    AuditLog,
    CountStatus,
    Currency,
    LedgerEntry,
    MovementType,
    PaymentMethod,
    POStatus,
    PricingMode,
    ProductSerial,
    Role,
    Supplier,
    UnitType,
)
from app.schemas.ops import (
    CountCreate,
    CountItemsIn,
    CountItemUpdate,
    CountScanIn,
    POCreate,
    POItemIn,
    POUpdate,
    ReceiveIn,
    ReceiveItemIn,
    SupplierIn,
)
from app.services import (
    auth_service,
    count_service,
    customer_service,
    purchase_service,
    settings_service,
    stock_service,
)

# ---------------------------------------------------------------- cari


def test_customer_crud_and_statement(session, admin_actor, staff_actor):
    c = customer_service.save_customer(
        session, staff_actor, {"full_name": "Zeynep Arslan", "phone": "+90 532 555 44 33", "kvkk_consent": True}
    )
    assert c["phone"] == "05325554433" and c["kvkk_consent_at"] is not None
    with pytest.raises(ValidationFailed):
        customer_service.save_customer(session, staff_actor, {"full_name": "Hatalı", "phone": "123"})
    session.rollback()
    with pytest.raises(ValidationFailed):
        customer_service.save_customer(session, staff_actor, {"credit_limit_kurus": 5000}, c["id"])
    session.rollback()
    customer_service.save_customer(session, admin_actor, {"credit_limit_kurus": 500000}, c["id"])
    customer_service.add_debt(session, c["id"], 30000, "Veresiye", "SALE", 1, date.today() - timedelta(days=5), admin_actor.id)
    customer_service.add_debt(session, c["id"], 20000, "Veresiye", "SALE", 2, date.today() + timedelta(days=5), admin_actor.id)
    session.commit()
    assert customer_service.overdue_amounts(session)[c["id"]] == 30000
    res = customer_service.collect_payment(session, staff_actor, c["id"], 10000, PaymentMethod.CASH, "elden")
    assert res["balance"] == 40000
    assert customer_service.overdue_amounts(session)[c["id"]] == 20000
    with pytest.raises(ValidationFailed):
        customer_service.collect_payment(session, staff_actor, c["id"], 1000, PaymentMethod.CREDIT, "")
    session.rollback()
    customer_service.adjust_balance(session, admin_actor, c["id"], -5000, "Yuvarlama indirimi")
    st = customer_service.statement(session, c["id"])
    assert st["closing_balance"] == 35000 and st["total_debit"] == 50000 and st["total_credit"] == 15000
    assert [r["balance"] for r in st["rows"]] == [30000, 50000, 40000, 35000]
    st2 = customer_service.statement(session, c["id"], date_from=date.today() + timedelta(days=1))
    assert st2["opening_balance"] == 35000 and st2["rows"] == []
    assert [r["id"] for r in customer_service.list_customers(session, filter_="overdue")] == [c["id"]]
    assert customer_service.list_customers(session, q="555 44")[0]["id"] == c["id"]
    detail = customer_service.get_customer(session, c["id"])
    assert detail["balance"] == 35000 and detail["sales"] == []


# ---------------------------------------------------------------- satın alma


def test_purchase_order_receive_with_fx_and_serials(session, admin_actor, rates, make_product):
    sup = purchase_service.save_supplier(session, admin_actor, SupplierIn(name="Arena Bilgisayar", currency=Currency.USD))
    ssd = make_product(
        track_serial=True,
        purchase_currency=Currency.USD,
        purchase_price=Decimal("40"),
        pricing_mode=PricingMode.FX_LINKED,
        markup_pct=Decimal("25"),
        avg_cost_kurus=0,
    )
    ram = make_product(purchase_currency=Currency.USD, purchase_price=Decimal("20"), avg_cost_kurus=0)
    po = purchase_service.create_order(
        session,
        admin_actor,
        POCreate(
            supplier_id=sup["id"],
            items=[
                POItemIn(product_id=ssd.id, qty=Decimal(2), unit_price=Decimal("42")),
                POItemIn(product_id=ram.id, qty=Decimal(5), unit_price=Decimal("20")),
            ],
        ),
    )
    assert po["currency"] == Currency.USD and po["status"] == POStatus.DRAFT and po["order_no"].startswith("PO-")
    po = purchase_service.update_order(session, admin_actor, po["id"], POUpdate(note="Acil"))
    po = purchase_service.mark_ordered(session, admin_actor, po["id"])
    assert po["status"] == POStatus.ORDERED
    items = {i["product_id"]: i for i in po["items"]}
    with pytest.raises(ValidationFailed) as exc:
        purchase_service.receive(
            session, admin_actor, po["id"], ReceiveIn(items=[ReceiveItemIn(item_id=items[ssd.id]["id"], qty=Decimal(2), serials=["A"])])
        )
    assert exc.value.code == "SERIALS_REQUIRED"
    session.rollback()
    po = purchase_service.receive(
        session,
        admin_actor,
        po["id"],
        ReceiveIn(
            fx_rate=Decimal("42"),
            items=[
                ReceiveItemIn(item_id=items[ssd.id]["id"], qty=Decimal(2), serials=["NV1", "NV2"]),
                ReceiveItemIn(item_id=items[ram.id]["id"], qty=Decimal(3)),
            ],
        ),
    )
    assert po["status"] == POStatus.PARTIAL
    session.refresh(ssd)
    session.refresh(ram)
    assert ssd.stock_qty == 2 and ssd.avg_cost_kurus == 176400  # 42 USD × 42 = 1.764 TL
    assert ssd.purchase_price == Decimal("42") and ssd.sale_price_kurus > 0
    assert len(session.exec(select(ProductSerial).where(ProductSerial.product_id == ssd.id)).all()) == 2
    with pytest.raises(ValidationFailed):
        purchase_service.receive(
            session, admin_actor, po["id"], ReceiveIn(items=[ReceiveItemIn(item_id=items[ram.id]["id"], qty=Decimal(5))])
        )
    session.rollback()
    po = purchase_service.receive(
        session, admin_actor, po["id"], ReceiveIn(items=[ReceiveItemIn(item_id=items[ram.id]["id"], qty=Decimal(2))])
    )
    assert po["status"] == POStatus.RECEIVED and po["received_at"]
    with pytest.raises(ValidationFailed):
        purchase_service.cancel_order(session, admin_actor, po["id"])
    session.rollback()
    listing = purchase_service.list_suppliers(session)
    assert listing[0]["order_count"] == 1 and listing[0]["avg_lead_days"] is not None
    detail = purchase_service.get_supplier(session, sup["id"])
    assert detail["orders"][0]["status"] == POStatus.RECEIVED
    assert stock_service.ledger_mismatches(session) == []


def test_from_critical_and_staff_price_strip(session, admin_actor, staff_actor, rates, make_product):
    sup = purchase_service.save_supplier(session, admin_actor, SupplierIn(name="Elektrik Toptan", currency=Currency.TRY))
    make_product(stock=1, min_stock=Decimal(10), supplier_id=sup["id"], purchase_price=Decimal("12.5"))
    make_product(stock=0, min_stock=Decimal(4), unit_type=UnitType.METER, purchase_currency=Currency.USD, purchase_price=Decimal("1"))
    make_product(stock=50, min_stock=Decimal(4))
    po = purchase_service.from_critical(session, admin_actor, sup["id"])
    qtys = sorted(i["qty"] for i in po["items"])
    assert qtys == [Decimal(8), Decimal(19)]
    stripped = purchase_service.strip_prices(po, staff_actor)
    assert stripped["total"] is None and all(i["unit_price"] is None for i in stripped["items"])
    cancelled = purchase_service.cancel_order(session, admin_actor, po["id"])
    assert cancelled["status"] == POStatus.CANCELLED
    empty = purchase_service.save_supplier(session, admin_actor, SupplierIn(name="Boş Tedarik"))
    for p in session.exec(select(Supplier)).all():
        assert p.name
    with pytest.raises(ValidationFailed):
        purchase_service.from_critical(session, admin_actor, empty["id"] + 99)


# ---------------------------------------------------------------- sayım


def test_count_flow(session, admin_actor, staff_actor, make_product):
    from app.schemas.catalog import LocationIn
    from app.services import catalog_service

    loc = catalog_service.save_location(session, admin_actor, LocationIn(code="A-01"))
    a = make_product(stock=10, location_id=loc.id, barcode="869111")
    b = make_product(stock="50", unit_type=UnitType.METER, location_id=loc.id)
    make_product(stock=5)  # başka raf
    c = count_service.create_count(session, staff_actor, CountCreate(location_id=loc.id))
    assert len(c["items"]) == 2 and "A-01" in c["name"]
    for _ in range(8):
        res = count_service.scan(session, staff_actor, c["id"], CountScanIn(code="869111"))
    assert res["counted_qty"] == 8
    meter = count_service.scan(session, staff_actor, c["id"], CountScanIn(code=b.sku))
    assert meter["needs_qty"] is True
    c = count_service.update_items(
        session, staff_actor, c["id"], CountItemsIn(items=[CountItemUpdate(product_id=b.id, counted_qty=Decimal("52.5"))])
    )
    diffs = {i["product_id"]: i["diff"] for i in c["items"]}
    assert diffs[a.id] == -2 and diffs[b.id] == Decimal("2.5")
    assert "diff_value" not in c["items"][0]
    with pytest.raises(Forbidden):
        count_service.apply_count(session, staff_actor, c["id"])
    applied = count_service.apply_count(session, admin_actor, c["id"])
    assert applied["status"] == CountStatus.APPLIED
    session.refresh(a)
    session.refresh(b)
    assert a.stock_qty == 8 and b.stock_qty == Decimal("52.5")
    with pytest.raises(ValidationFailed) as exc:
        count_service.update_items(
            session, staff_actor, c["id"], CountItemsIn(items=[CountItemUpdate(product_id=a.id, counted_qty=Decimal(1))])
        )
    assert exc.value.code == "COUNT_LOCKED"
    session.rollback()
    assert count_service.list_counts(session)[0]["counted_count"] == 2
    moves = stock_service.list_movements(session, types=[MovementType.COUNT_ADJUST])
    assert len(moves) == 2
    c2 = count_service.create_count(session, staff_actor, CountCreate())
    assert count_service.cancel_count(session, staff_actor, c2["id"])["status"] == CountStatus.CANCELLED
    assert session.exec(select(AuditLog).where(AuditLog.action == "count.apply")).first() is not None


# ---------------------------------------------------------------- kullanıcı ve ayarlar


def test_users_and_passwords(session, admin_actor, staff):
    with pytest.raises(Conflict):
        auth_service.create_user(session, admin_actor, {"username": "Personel", "full_name": "X", "password": "abcdefg1"})
    session.rollback()
    with pytest.raises(ValidationFailed):
        auth_service.create_user(session, admin_actor, {"username": "ali", "full_name": "Ali Veli", "password": "kisa"})
    session.rollback()
    u = auth_service.create_user(
        session, admin_actor, {"username": "ali", "full_name": "Ali Veli", "password": "Guvenli123", "role": Role.STAFF}
    )
    auth_service.update_user(session, admin_actor, u["id"], {"max_discount_pct": Decimal(10), "password": "YeniSifre9"})
    assert auth_service.authenticate(session, "ALI", "YeniSifre9").username == "ali"
    with pytest.raises(ValidationFailed):
        auth_service.update_user(session, admin_actor, admin_actor.id, {"is_active": False})
    session.rollback()
    with pytest.raises(ValidationFailed):
        auth_service.change_own_password(session, admin_actor, "yanlis", "Yepyeni123")
    session.rollback()
    auth_service.change_own_password(session, admin_actor, "Tezgah2026!", "Yepyeni123")
    assert auth_service.authenticate(session, "yonetici", "Yepyeni123")
    assert len(auth_service.list_users(session)) == 3


def test_settings_update_is_audited(session, admin_actor):
    settings_service.update_settings(session, admin_actor, {"shop_name": "Teknolife Elektrik", "fx_stale_days": 5, "unknown": 1})
    row = settings_service.get_settings_row(session)
    assert row.shop_name == "Teknolife Elektrik" and row.fx_stale_days == 5
    log = session.exec(select(AuditLog).where(AuditLog.action == "settings.update")).one()
    assert log.diff["before"]["shop_name"] == "Teknolife" and log.diff["after"]["shop_name"] == "Teknolife Elektrik"


def test_ledger_entries_for_credit_are_signed(session, customer, admin_actor):
    customer_service.add_debt(session, customer.id, 1000, "x", "SALE", None, None, admin_actor.id)
    customer_service.add_adjust(session, customer.id, -300, "y", None, None, admin_actor.id)
    session.commit()
    assert customer_service.balance(session, customer.id) == 700
    assert customer_service.balances(session)[customer.id] == 700
    assert len(session.exec(select(LedgerEntry)).all()) == 2
