"""Uçtan uca API ve yetki testleri: personel doğrudan API isteği atsa bile kısıtlamalar geçerli."""

from decimal import Decimal


def test_login_logout_me(anon_client, admin):
    assert anon_client.get("/api/auth/me").status_code == 401
    r = anon_client.post("/api/auth/login", json={"username": "yonetici", "password": "yanlis"})
    assert r.status_code == 401 and r.json()["error"]["message"] == "Kullanıcı adı veya şifre hatalı."
    r = anon_client.post("/api/auth/login", json={"username": "YONETICI", "password": "Tezgah2026!"})
    assert r.status_code == 200
    cookie = r.headers["set-cookie"].lower()
    assert "httponly" in cookie and "samesite=lax" in cookie
    me = anon_client.get("/api/auth/me").json()
    assert me["role"] == "ADMIN" and "product.cost_view" in me["permissions"]
    anon_client.post("/api/auth/logout")
    assert anon_client.get("/api/auth/me").status_code == 401


def test_login_rate_limited(anon_client, admin):
    codes = [anon_client.post("/api/auth/login", json={"username": "x", "password": "y"}).status_code for _ in range(12)]
    assert codes[-1] == 429


def test_csrf_header_required(admin_client):
    r = admin_client.post("/api/customers", json={"full_name": "Deneme Kişi"}, headers={"X-Tezgah": ""})
    assert r.status_code == 403 and r.json()["error"]["code"] == "CSRF"


def test_validation_errors_are_turkish(admin_client):
    r = admin_client.post("/api/customers", json={})
    body = r.json()["error"]
    assert r.status_code == 422 and body["fields"]["full_name"] == "Bu alan zorunludur."


def test_staff_cannot_see_costs_via_api(staff_client, make_product, rates):
    p = make_product(stock=3, purchase_price=Decimal("42"))
    for url in (f"/api/products/{p.id}", "/api/products", f"/api/products/lookup?code={p.sku}"):
        text = staff_client.get(url).text
        assert "purchase_price" not in text and "avg_cost_kurus" not in text and "margin_pct" not in text, url
    moves = staff_client.get(f"/api/products/{p.id}/movements").json()
    assert all("unit_cost_kurus" not in m for m in moves)


def test_staff_forbidden_actions(staff_client, make_product, customer):
    p = make_product(stock=5, sale_price_kurus=10000)
    assert staff_client.post("/api/products", json={"name": "X ürün", "sale_price_kurus": 100}).status_code == 403
    assert staff_client.post(f"/api/products/{p.id}/archive").status_code == 403
    assert staff_client.patch(f"/api/products/{p.id}", json={"sale_price_kurus": 1}).status_code == 403
    assert staff_client.get("/api/audit-logs").status_code == 403
    assert staff_client.post("/api/fx-rates", json={"USD": "40"}).status_code == 403
    assert staff_client.get("/api/reports/sales").status_code == 403
    assert staff_client.get("/api/reports/profit").status_code == 403
    r = staff_client.post(
        "/api/sales", json={"items": [{"product_id": p.id, "qty": 1}], "discount": 2000, "payments": [{"method": "CASH", "amount": 8000}]}
    )
    assert r.status_code == 403
    ok = staff_client.post(
        "/api/sales", json={"items": [{"product_id": p.id, "qty": 1}], "payments": [{"method": "CASH", "amount": 10000}]}
    )
    assert ok.status_code == 200
    assert "profit" not in ok.json() and "unit_cost" not in ok.json()["items"][0]
    assert staff_client.post(f"/api/sales/{ok.json()['id']}/cancel", json={"reason": "deneme"}).status_code == 403
    assert staff_client.patch(f"/api/customers/{customer.id}", json={"credit_limit_kurus": 999999}).status_code == 422
    assert staff_client.post("/api/users", json={"username": "yeni", "full_name": "Yeni K", "password": "abcdef12"}).status_code == 403


def test_admin_full_flow_via_api(admin_client, rates):
    cat = admin_client.post("/api/categories", json={"name": "Elektrik"}).json()
    r = admin_client.post(
        "/api/products",
        json={
            "name": "B16 otomat sigorta",
            "category_id": cat["id"],
            "sale_price_kurus": 8990,
            "purchase_price": "45",
            "initial_stock": "20",
            "min_stock": "5",
        },
    )
    assert r.status_code == 200, r.text
    pid = r.json()["id"]
    sale = admin_client.post(
        "/api/sales", json={"items": [{"product_id": pid, "qty": 2}], "payments": [{"method": "CARD", "amount": 17980}]}
    )
    assert sale.status_code == 200
    assert admin_client.get(f"/api/sales/{sale.json()['id']}").json()["can_cancel"] is True
    assert admin_client.get("/api/reports/dashboard").status_code == 200
    for name in ("sales", "cashbox", "top-products", "dead-stock", "abc", "stock-value", "staff", "service", "warranty"):
        assert admin_client.get(f"/api/reports/{name}").status_code == 200, name
    x = admin_client.get("/api/reports/sales?format=xlsx")
    assert x.headers["content-type"].startswith("application/vnd.openxmlformats")
    assert admin_client.get("/api/reports/yok").status_code == 404
    assert admin_client.get("/api/search?q=sigorta").json()["products"][0]["id"] == pid
    assert admin_client.get("/api/status").json()["today_sales"] == 1
    assert admin_client.get("/api/stock/movements").status_code == 200
    assert admin_client.get("/api/products/export.xlsx").status_code == 200


def test_openapi_and_unknown_api(anon_client):
    assert anon_client.get("/api/openapi.json").status_code == 200
    assert anon_client.get("/api/yok-boyle").status_code == 404
    assert anon_client.get("/api/health").json()["status"] == "ok"
