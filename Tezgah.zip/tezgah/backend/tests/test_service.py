from decimal import Decimal

import pytest
from sqlmodel import select

from app.core.errors import NotFound, ValidationFailed
from app.models import MovementType, ProductSerial, Sale, SerialStatus, ServiceStatus, StockMovement, UnitType
from app.schemas.sales import PaymentIn
from app.schemas.service import DeliverIn, NoteCreate, PartAdd, QuickCustomer, StatusChange, TicketCreate, TicketUpdate
from app.services import customer_service, stock_service
from app.services import service_ticket_service as svc

S = ServiceStatus


def _ticket(session, actor, **kw):
    data = dict(
        new_customer=QuickCustomer(full_name="Hakan Demir", phone="0532 111 22 33"),
        device_type="LAPTOP",
        brand="Lenovo",
        model="IdeaPad 3",
        serial_no="pf2abc",
        accessories=["Şarj adaptörü", "Çanta"],
        complaint="Açılmıyor, fan sesi var",
        estimated_cost=90000,
    )
    data.update(kw)
    return svc.create_ticket(session, actor, TicketCreate(**data))


def test_code_format_and_alphabet(session, staff_actor):
    t = _ticket(session, staff_actor)
    code = t["code"]
    assert code.startswith("SRV-") and len(code) == 8
    assert not set(code[4:]) & set("O0I1")
    assert t["customer"]["phone"] == "05321112233"
    assert t["serial_no"] == "PF2ABC"
    assert t["timeline"][0]["to_status"] == S.RECEIVED


def test_state_machine(session, staff_actor):
    t = _ticket(session, staff_actor)
    with pytest.raises(ValidationFailed) as exc:
        svc.change_status(session, staff_actor, t["id"], StatusChange(status=S.READY))
    assert exc.value.code == "INVALID_TRANSITION"
    with pytest.raises(ValidationFailed):
        svc.change_status(session, staff_actor, t["id"], StatusChange(status=S.DELIVERED))
    for st in (S.DIAGNOSING, S.WAITING_APPROVAL, S.IN_REPAIR, S.READY):
        out = svc.change_status(session, staff_actor, t["id"], StatusChange(status=st, note="ilerledi", notify_customer=True))
    assert out["status"] == S.READY and out["approved_by_customer_at"] is not None
    assert out["next_status"] == S.DELIVERED
    assert svc.can_transition(S.READY, S.IN_REPAIR) and not svc.can_transition(S.DELIVERED, S.RECEIVED)


def test_parts_stock_and_deliver_creates_sale(session, staff_actor, admin_actor, make_product):
    ssd = make_product(track_serial=True, sale_price_kurus=150000, warranty_months=36)
    stock_service.manual_adjust(session, admin_actor, ssd.id, Decimal(1), MovementType.ADJUST_IN, "giriş", serials=["NV-01"])
    paste = make_product(stock=10, sale_price_kurus=15000)
    install = make_product(unit_type=UnitType.SERVICE, sale_price_kurus=75000, name="Format + Windows kurulumu")
    t = _ticket(session, staff_actor)
    serial = session.exec(select(ProductSerial)).one()
    with pytest.raises(ValidationFailed):
        svc.add_part(session, staff_actor, t["id"], PartAdd(product_id=ssd.id, qty=Decimal(1)))
    session.rollback()
    svc.add_part(session, staff_actor, t["id"], PartAdd(product_id=ssd.id, qty=Decimal(1), serial_id=serial.id))
    out = svc.add_part(session, staff_actor, t["id"], PartAdd(product_id=paste.id, qty=Decimal(2)))
    svc.add_part(session, staff_actor, t["id"], PartAdd(product_id=install.id, qty=Decimal(1)))
    session.refresh(paste)
    assert paste.stock_qty == 8
    paste_part = next(p for p in out["parts"] if p["product_id"] == paste.id)
    out = svc.remove_part(session, staff_actor, t["id"], paste_part["id"])
    session.refresh(paste)
    assert paste.stock_qty == 10
    assert [m.type for m in session.exec(select(StockMovement).where(StockMovement.product_id == paste.id)).all()][
        -1
    ] == MovementType.SERVICE_RETURN
    svc.update_ticket(session, staff_actor, t["id"], TicketUpdate(labor_fee=50000, diagnosis="SSD arızalı"))
    with pytest.raises(ValidationFailed) as exc:
        svc.deliver(session, staff_actor, t["id"], DeliverIn(payments=[PaymentIn(method="CASH", amount=275000)]))
    assert exc.value.code == "NOT_READY"
    session.rollback()
    for st in (S.DIAGNOSING, S.IN_REPAIR, S.READY):
        svc.change_status(session, staff_actor, t["id"], StatusChange(status=st))
    done = svc.deliver(session, staff_actor, t["id"], DeliverIn(payments=[PaymentIn(method="CASH", amount=150000 + 75000 + 50000)]))
    assert done["status"] == S.DELIVERED and done["sale_id"]
    sale = session.get(Sale, done["sale_id"])
    assert sale.total == 275000 and sale.service_ticket_id == t["id"]
    session.refresh(serial)
    assert serial.status == SerialStatus.SOLD and serial.warranty_until is not None
    ssd_moves = session.exec(select(StockMovement).where(StockMovement.product_id == ssd.id)).all()
    assert [m.type for m in ssd_moves].count(MovementType.SALE_OUT) == 0  # stok servis çıkışında düşüldü
    assert stock_service.ledger_mismatches(session) == []
    with pytest.raises(ValidationFailed):
        svc.update_ticket(session, staff_actor, t["id"], TicketUpdate(diagnosis="x"))


def test_free_delivery_and_cancel_rules(session, staff_actor, make_product):
    t = _ticket(session, staff_actor, estimated_cost=0)
    svc.change_status(session, staff_actor, t["id"], StatusChange(status=S.DIAGNOSING))
    svc.change_status(session, staff_actor, t["id"], StatusChange(status=S.READY))
    done = svc.deliver(session, staff_actor, t["id"], DeliverIn())
    assert done["status"] == S.DELIVERED and done["sale_id"] is None
    t2 = _ticket(session, staff_actor)
    p = make_product(stock=3)
    svc.add_part(session, staff_actor, t2["id"], PartAdd(product_id=p.id, qty=Decimal(1)))
    with pytest.raises(ValidationFailed):
        svc.change_status(session, staff_actor, t2["id"], StatusChange(status=S.CANCELLED))


def test_credit_delivery(session, staff_actor, make_product):
    t = _ticket(session, staff_actor)
    svc.update_ticket(session, staff_actor, t["id"], TicketUpdate(labor_fee=40000))
    svc.change_status(session, staff_actor, t["id"], StatusChange(status=S.DIAGNOSING))
    svc.change_status(session, staff_actor, t["id"], StatusChange(status=S.READY))
    cust_id = t["customer"]["id"]
    from app.models import Customer

    c = session.get(Customer, cust_id)
    c.credit_limit_kurus = 100000
    session.commit()
    svc.deliver(session, staff_actor, t["id"], DeliverIn(payments=[PaymentIn(method="CREDIT", amount=40000)]))
    assert customer_service.balance(session, cust_id) == 40000


def test_public_track_hides_personal_data(session, staff_actor, anon_client):
    t = _ticket(session, staff_actor)
    svc.add_note(session, staff_actor, t["id"], NoteCreate(body="İç not: şifre sorulacak", visibility="INTERNAL"))
    svc.add_note(session, staff_actor, t["id"], NoteCreate(body="Cihazınız incelemeye alındı.", visibility="CUSTOMER"))
    r = anon_client.get(f"/api/public/track/{t['code'].lower()}")
    assert r.status_code == 200
    text = r.text
    for secret in ("Hakan", "Demir", "0532", "05321112233", "PF2ABC", "İç not", "complaint", "customer"):
        assert secret not in text, secret
    body = r.json()
    assert body["notes"][0]["body"] == "Cihazınız incelemeye alındı."
    assert body["steps"][0]["done"] is True
    assert anon_client.get("/api/public/track/SRV-ZZZZ").status_code == 404
    assert anon_client.get(f"/api/public/track/{t['code'][4:]}").status_code == 200
    with pytest.raises(NotFound):
        svc.public_track(session, "XXXX")


def test_public_track_rate_limit(anon_client):
    codes = [anon_client.get("/api/public/track/SRV-AAAA").status_code for _ in range(32)]
    assert 429 in codes


def test_list_and_api(staff_client, session, staff_actor):
    t = _ticket(session, staff_actor)
    rows = staff_client.get("/api/service-tickets?status=open").json()
    assert rows[0]["code"] == t["code"] and rows[0]["waiting_days"] == 0
    assert staff_client.get("/api/service-tickets?q=IdeaPad").json()[0]["id"] == t["id"]
    r = staff_client.post(f"/api/service-tickets/{t['id']}/status", json={"status": "DIAGNOSING"})
    assert r.status_code == 200 and r.json()["status"] == "DIAGNOSING"
    session.commit()  # okuma anlık görüntüsünü yenile
    assert svc.status_counts(session)[S.DIAGNOSING] == 1
