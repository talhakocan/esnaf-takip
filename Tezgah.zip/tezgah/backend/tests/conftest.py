import os
import tempfile
from collections.abc import Callable, Iterator
from decimal import Decimal
from pathlib import Path

import pytest

_TMP = Path(tempfile.mkdtemp(prefix="tezgah-test-"))
os.environ.setdefault("TEZGAH_DATABASE_URL", f"sqlite:///{(_TMP / 'boot.db').as_posix()}")
os.environ["TEZGAH_ENABLE_SCHEDULER"] = "0"
os.environ["TEZGAH_SECRET_KEY"] = "test-secret-key-for-tezgah-0123456789"
os.environ["TEZGAH_BACKUP_DIR"] = str(_TMP / "backups")

from fastapi.testclient import TestClient  # noqa: E402
from sqlmodel import Session, SQLModel  # noqa: E402

from app import db  # noqa: E402
from app.core.deps import Actor  # noqa: E402
from app.core.ratelimit import login_limiter, track_limiter  # noqa: E402
from app.core.security import hash_password  # noqa: E402
from app.main import create_app  # noqa: E402
from app.models import (  # noqa: E402
    Currency,
    Customer,
    ExchangeRate,
    MovementType,
    PricingMode,
    Product,
    Role,
    UnitType,
    User,
)
from app.models import now as model_now  # noqa: E402
from app.services import settings_service, stock_service  # noqa: E402

ADMIN_PW = "Tezgah2026!"
STAFF_PW = "Personel2026!"


@pytest.fixture(autouse=True)
def engine(tmp_path: Path) -> Iterator:
    eng = db.make_engine(f"sqlite:///{(tmp_path / 'test.db').as_posix()}")
    SQLModel.metadata.create_all(eng)
    db.set_engine(eng)
    login_limiter.reset()
    track_limiter.reset()
    yield eng
    eng.dispose()


@pytest.fixture
def session(engine) -> Iterator[Session]:
    # Test oturumu okuma modunda (ertelenmiş BEGIN): API istekleriyle kilit çakışmaz.
    with Session(engine.execution_options(tezgah_deferred=True)) as s:
        settings_service.get_settings_row(s)
        s.commit()
        yield s


@pytest.fixture
def admin(session: Session) -> User:
    u = User(
        username="yonetici", full_name="Serkan Aydın", role=Role.ADMIN, password_hash=hash_password(ADMIN_PW), max_discount_pct=Decimal(100)
    )
    session.add(u)
    session.commit()
    session.refresh(u)
    return u


@pytest.fixture
def staff(session: Session) -> User:
    u = User(
        username="personel", full_name="Mehmet Kaya", role=Role.STAFF, password_hash=hash_password(STAFF_PW), max_discount_pct=Decimal(5)
    )
    session.add(u)
    session.commit()
    session.refresh(u)
    return u


@pytest.fixture
def admin_actor(admin: User) -> Actor:
    return Actor(user=admin, ip="127.0.0.1")


@pytest.fixture
def staff_actor(staff: User) -> Actor:
    return Actor(user=staff, ip="127.0.0.1")


@pytest.fixture
def rates(session: Session) -> None:
    now = model_now()
    session.add(ExchangeRate(currency=Currency.USD, rate=Decimal("41.23"), fetched_at=now))
    session.add(ExchangeRate(currency=Currency.EUR, rate=Decimal("48.10"), fetched_at=now))
    session.commit()


@pytest.fixture
def make_product(session: Session, admin: User) -> Callable[..., Product]:
    counter = {"n": 0}

    def _make(stock: Decimal | int | str = 0, **kw) -> Product:
        counter["n"] += 1
        defaults = dict(
            sku=f"T-{counter['n']:03d}",
            name=f"Test ürün {counter['n']}",
            unit_type=UnitType.PIECE,
            vat_rate=20,
            sale_price_kurus=10000,
            avg_cost_kurus=6000,
            purchase_price=Decimal("60"),
            pricing_mode=PricingMode.FIXED,
        )
        defaults.update(kw)
        p = Product(**defaults)
        session.add(p)
        session.flush()
        if Decimal(str(stock)) > 0:
            stock_service.apply_movement(session, p, MovementType.ADJUST_IN, Decimal(str(stock)), admin.id, note="test")
        session.commit()
        session.refresh(p)
        return p

    return _make


@pytest.fixture
def customer(session: Session) -> Customer:
    c = Customer(full_name="Ayşe Yılmaz", phone="05321234567", credit_limit_kurus=100000)
    session.add(c)
    session.commit()
    session.refresh(c)
    return c


def _client(username: str, password: str) -> TestClient:
    client = TestClient(create_app(run_lifespan=False))
    client.headers.update({"X-Tezgah": "1"})
    r = client.post("/api/auth/login", json={"username": username, "password": password})
    assert r.status_code == 200, r.text
    return client


@pytest.fixture
def anon_client() -> TestClient:
    c = TestClient(create_app(run_lifespan=False))
    c.headers.update({"X-Tezgah": "1"})
    return c


@pytest.fixture
def admin_client(admin: User) -> TestClient:
    return _client("yonetici", ADMIN_PW)


@pytest.fixture
def staff_client(staff: User) -> TestClient:
    return _client("personel", STAFF_PW)
