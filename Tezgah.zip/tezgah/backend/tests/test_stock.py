from decimal import Decimal

import pytest
from sqlmodel import select

from app.core.errors import ValidationFailed
from app.models import MovementType, ProductSerial, SerialStatus, StockMovement, UnitType
from app.services import settings_service, stock_service


def test_movement_updates_cache_and_balance(session, make_product, admin):
    p = make_product(stock=10)
    m = stock_service.apply_movement(session, p, MovementType.SALE_OUT, Decimal(-3), admin.id)
    session.commit()
    assert p.stock_qty == Decimal(7)
    assert m.balance_after == Decimal(7)
    assert stock_service.ledger_mismatches(session) == []


def test_meter_products_accept_decimals(session, make_product, admin):
    p = make_product(stock="100", unit_type=UnitType.METER)
    stock_service.apply_movement(session, p, MovementType.SALE_OUT, Decimal("-12.5"), admin.id)
    session.commit()
    assert p.stock_qty == Decimal("87.5")


def test_piece_rejects_decimal(session, make_product, admin):
    p = make_product(stock=5)
    with pytest.raises(ValidationFailed):
        stock_service.apply_movement(session, p, MovementType.SALE_OUT, Decimal("-1.5"), admin.id)


def test_negative_stock_blocked_by_default(session, make_product, admin):
    p = make_product(stock=2)
    with pytest.raises(ValidationFailed) as exc:
        stock_service.apply_movement(session, p, MovementType.SALE_OUT, Decimal(-3), admin.id)
    assert exc.value.code == "INSUFFICIENT_STOCK"
    session.rollback()
    s = settings_service.get_settings_row(session)
    s.allow_negative_stock = True
    session.commit()
    stock_service.apply_movement(session, p, MovementType.SALE_OUT, Decimal(-3), admin.id)
    session.commit()
    assert p.stock_qty == Decimal(-1)


def test_service_products_make_no_movement(session, make_product, admin):
    p = make_product(unit_type=UnitType.SERVICE)
    assert stock_service.apply_movement(session, p, MovementType.SALE_OUT, Decimal(-1), admin.id) is None
    assert session.exec(select(StockMovement).where(StockMovement.product_id == p.id)).first() is None


def test_sign_rules(session, make_product, admin):
    p = make_product(stock=5)
    with pytest.raises(ValidationFailed):
        stock_service.apply_movement(session, p, MovementType.PURCHASE_IN, Decimal(-1), admin.id)
    with pytest.raises(ValidationFailed):
        stock_service.apply_movement(session, p, MovementType.WASTE, Decimal(1), admin.id)
    with pytest.raises(ValidationFailed):
        stock_service.apply_movement(session, p, MovementType.ADJUST_IN, Decimal(0), admin.id)


def test_weighted_average_cost(session, make_product, admin):
    p = make_product(avg_cost_kurus=0)
    stock_service.apply_movement(session, p, MovementType.PURCHASE_IN, Decimal(10), admin.id, unit_cost_kurus=1000)
    stock_service.apply_movement(session, p, MovementType.PURCHASE_IN, Decimal(10), admin.id, unit_cost_kurus=2000)
    session.commit()
    assert p.avg_cost_kurus == 1500
    m = stock_service.apply_movement(session, p, MovementType.SALE_OUT, Decimal(-5), admin.id)
    assert m.unit_cost_kurus == 1500


def test_manual_adjust_with_serials(session, make_product, admin_actor):
    p = make_product(track_serial=True)
    with pytest.raises(ValidationFailed):
        stock_service.manual_adjust(session, admin_actor, p.id, Decimal(2), MovementType.ADJUST_IN, "giriş", serials=["A1"])
    session.rollback()
    stock_service.manual_adjust(session, admin_actor, p.id, Decimal(2), MovementType.ADJUST_IN, "giriş", serials=["a1", "A2"])
    serials = session.exec(select(ProductSerial).where(ProductSerial.product_id == p.id)).all()
    assert {s.serial_no for s in serials} == {"A1", "A2"}
    with pytest.raises(ValidationFailed):
        stock_service.manual_adjust(session, admin_actor, p.id, Decimal(1), MovementType.ADJUST_IN, "tekrar", serials=["A1"])
    session.rollback()
    sid = serials[0].id
    stock_service.manual_adjust(session, admin_actor, p.id, Decimal(1), MovementType.WASTE, "kırık", serial_ids=[sid])
    assert session.get(ProductSerial, sid).status == SerialStatus.DEFECTIVE
    assert session.get(type(p), p.id).stock_qty == Decimal(1)


def test_manual_adjust_requires_note_and_hides_cost_from_staff(session, make_product, staff_actor):
    p = make_product(stock=1)
    with pytest.raises(ValidationFailed):
        stock_service.manual_adjust(session, staff_actor, p.id, Decimal(1), MovementType.ADJUST_IN, "")
    m = stock_service.manual_adjust(session, staff_actor, p.id, Decimal(1), MovementType.ADJUST_IN, "bulundu", unit_cost_kurus=1)
    assert m.unit_cost_kurus == p.avg_cost_kurus


def test_list_movements_filters(session, make_product, admin):
    p = make_product(stock=4)
    stock_service.apply_movement(session, p, MovementType.WASTE, Decimal(-1), admin.id, note="kırık")
    session.commit()
    rows = stock_service.list_movements(session, product_id=p.id, types=[MovementType.WASTE])
    assert len(rows) == 1 and rows[0]["label"] == "FİRE"
    assert stock_service.fmt_qty(Decimal("12.500"), UnitType.METER) == "12,5 m"
