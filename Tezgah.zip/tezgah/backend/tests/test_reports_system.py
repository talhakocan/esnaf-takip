"""Raporlar, pano, yedekleme, arama ve migration testleri."""

from datetime import date, datetime, timedelta
from decimal import Decimal
from io import BytesIO

from openpyxl import load_workbook
from sqlmodel import select

from app.models import MovementType, Product, Sale
from app.schemas.sales import PaymentIn, ReturnCreate, ReturnItemIn, SaleCreate, SaleItemIn
from app.services import backup_service, report_service, sale_service, search_service, stock_service


def _sell(session, actor, product, qty, method="CASH", customer_id=None):
    total = product.sale_price_kurus * qty
    return sale_service.create_sale(
        session,
        actor,
        SaleCreate(
            items=[SaleItemIn(product_id=product.id, qty=qty)], payments=[PaymentIn(method=method, amount=total)], customer_id=customer_id
        ),
    )


def test_sales_report_profit_and_returns(session, admin_actor, make_product):
    p = make_product(stock=10, sale_price_kurus=12000, avg_cost_kurus=5000, vat_rate=20)
    s = _sell(session, admin_actor, p, 2)
    sale_service.create_return(
        session,
        admin_actor,
        ReturnCreate(sale_id=s["id"], items=[ReturnItemIn(sale_item_id=s["items"][0]["id"], qty=Decimal(1))], reason="iade"),
    )
    today = date.today()
    rep = report_service.report_sales(session, today, today)
    kpi = {k["label"]: k["value"] for k in rep["kpis"]}
    assert kpi["Ciro"] == 12000  # 24.000 satış − 12.000 iade
    assert kpi["Brüt kâr"] == 10000 - 5000
    assert kpi["İadeler"] == 12000
    assert rep["tables"][1]["rows"][0]["label"] == "Nakit"
    staff_rep = report_service.report_sales(session, today, today, finance=False)
    assert "Brüt kâr" not in {k["label"] for k in staff_rep["kpis"]}
    x = load_workbook(BytesIO(report_service.to_xlsx(rep)))
    assert "Özet" in x.sheetnames and "Dönemler" in x.sheetnames


def test_cashbox_excludes_cancelled_and_counts_refunds(session, admin_actor, make_product, customer):
    p = make_product(stock=10, sale_price_kurus=10000)
    _sell(session, admin_actor, p, 1)
    s2 = _sell(session, admin_actor, p, 1)
    sale_service.cancel_sale(session, admin_actor, s2["id"], "hata")
    s3 = _sell(session, admin_actor, p, 1, "CARD")
    sale_service.create_return(
        session,
        admin_actor,
        ReturnCreate(
            sale_id=s3["id"], items=[ReturnItemIn(sale_item_id=s3["items"][0]["id"], qty=Decimal(1))], method="CARD", reason="iade"
        ),
    )
    from app.models import PaymentMethod
    from app.services import customer_service

    customer_service.add_debt(session, customer.id, 5000, "x", "SALE", None, None, admin_actor.id)
    session.commit()
    customer_service.collect_payment(session, admin_actor, customer.id, 5000, PaymentMethod.CASH, "")
    rep = report_service.report_cashbox(session, date.today())
    methods = {r["label"]: r for r in rep["tables"][0]["rows"]}
    assert methods["Nakit"]["sales"] == 10000 and methods["Nakit"]["collections"] == 5000
    assert methods["Kart"]["net"] == 0
    assert len(rep["tables"][2]["rows"]) == 1
    assert "mali Z raporu değildir" in rep["notes"][0]


def test_top_abc_dead_value_staff_service_warranty(session, admin_actor, make_product):
    a = make_product(stock=20, sale_price_kurus=50000, name="Pahalı")
    b = make_product(stock=20, sale_price_kurus=1000, name="Ucuz")
    dead = make_product(stock=3, name="Ölü ürün")
    dead.last_movement_at = datetime.now() - timedelta(days=120)
    session.add(dead)
    session.commit()
    _sell(session, admin_actor, a, 2)
    _sell(session, admin_actor, b, 10)
    today = date.today()
    top = report_service.report_top_products(session, today, today)
    assert top["tables"][0]["rows"][0]["name"] == "Pahalı"
    assert top["tables"][1]["rows"][0]["name"] == "Ucuz"
    abc = report_service.report_abc(session, today, today)
    classes = {r["name"]: r["cls"] for r in abc["tables"][0]["rows"]}
    assert classes["Pahalı"] == "A" and classes["Ucuz"] == "B"
    d = report_service.report_dead_stock(session, 90)
    assert [r["name"] for r in d["tables"][0]["rows"]] == ["Ölü ürün"]
    sv = report_service.report_stock_value(session)
    assert sv["tables"][0]["totals"]["items"] == 3
    st = report_service.report_staff(session, today, today)
    assert st["tables"][0]["rows"][0]["count"] == 2
    assert report_service.report_service(session, today, today)["kpis"][0]["value"] == 0
    assert report_service.report_warranty(session)["kpis"][0]["value"] == 0


def test_dashboard_contents(session, admin_actor, make_product):
    p = make_product(stock=2, min_stock=Decimal(5), sale_price_kurus=10000, avg_cost_kurus=4000)
    _sell(session, admin_actor, p, 1)
    dash = report_service.dashboard(session, finance=True)
    kpis = {k["key"]: k for k in dash["kpis"]}
    assert kpis["revenue"]["value"] == 10000 and kpis["count"]["value"] == 1
    assert kpis["critical"]["value"] == 1
    assert "profit" in kpis
    assert len(dash["series"]) == 30
    kinds = {a["kind"] for a in dash["attention"]}
    assert {"stock", "fx"} <= kinds  # kur girilmemiş → uyarı
    staff_dash = report_service.dashboard(session, finance=False)
    assert "profit" not in {k["key"] for k in staff_dash["kpis"]}
    assert all("profit" not in r for r in staff_dash["series"])


def test_search(session, admin_actor, make_product, customer):
    p = make_product(stock=2, name="Kablosuz mouse", track_serial=False)
    s = _sell(session, admin_actor, p, 1)
    res = search_service.search(session, "mouse")
    assert res["products"][0]["id"] == p.id
    assert search_service.search(session, "532 123")["customers"][0]["id"] == customer.id
    assert search_service.search(session, s["receipt_no"])["sales"][0]["id"] == s["id"]
    assert search_service.search(session, "a")["products"] == []


def test_backup_create_list_restore(session, admin_actor, make_product, admin_client, tmp_path):
    make_product(stock=1, name="Yedek öncesi")
    info = backup_service.create_backup("manual")
    assert info["kind"] == "manual"
    make_product(stock=1, name="Yedek sonrası")
    assert any(b["name"] == info["name"] for b in admin_client.get("/api/backups").json())
    dl = admin_client.get(f"/api/backups/{info['name']}")
    assert dl.status_code == 200 and dl.content[:15] == b"SQLite format 3"
    assert admin_client.get("/api/backups/../../secret.key").status_code == 404
    bad = admin_client.post("/api/backups/restore", files={"file": ("x.db", b"bozuk dosya", "application/octet-stream")})
    assert bad.status_code == 422
    session.close()
    ok = admin_client.post("/api/backups/restore", files={"file": ("y.db", dl.content, "application/octet-stream")})
    assert ok.status_code == 200, ok.text
    from sqlmodel import Session

    from app.db import get_engine

    with Session(get_engine()) as s:
        names = {p.name for p in s.exec(select(Product)).all()}
    assert "Yedek öncesi" in names and "Yedek sonrası" not in names
    assert any(b["kind"] == "pre-restore" for b in backup_service.list_backups())
    assert backup_service.last_backup_time() is not None


def test_fx_endpoints_and_audit(admin_client, monkeypatch):
    r = admin_client.post("/api/fx-rates", json={"USD": "41,50", "EUR": "48.2"})
    assert r.status_code == 200 and r.json()["rates"]["USD"]["rate"] == 41.5
    assert admin_client.post("/api/fx-rates", json={}).status_code == 422
    from app.services import fx_service

    monkeypatch.setattr(fx_service, "fetch_tcmb", lambda: {"USD": Decimal("42"), "EUR": Decimal("49")})
    r = admin_client.post("/api/fx-rates/fetch-tcmb")
    assert r.status_code == 200 and r.json()["rates"]["USD"]["source"] == "TCMB"
    logs = admin_client.get("/api/audit-logs?entity=exchange_rates").json()
    assert len(logs) == 2 and logs[0]["diff"]["after"]["USD"] == "42"
    assert admin_client.get("/api/fx-rates").json()["history"][0]["source"] == "TCMB"


def test_migrations_match_models(tmp_path, monkeypatch):
    from alembic import command
    from alembic.autogenerate import compare_metadata
    from alembic.migration import MigrationContext
    from sqlmodel import SQLModel

    from app import db
    from app.migrations import alembic_config

    eng = db.make_engine(f"sqlite:///{(tmp_path / 'mig.db').as_posix()}")
    db.set_engine(eng)
    cfg = alembic_config()
    with eng.connect() as conn:
        cfg.attributes["connection"] = conn
        command.upgrade(cfg, "head")
    with eng.connect() as conn:
        diff = compare_metadata(MigrationContext.configure(conn), SQLModel.metadata)
    assert diff == []


def test_ledger_consistency_after_mixed_operations(session, admin_actor, make_product):
    p = make_product(stock=10)
    _sell(session, admin_actor, p, 3)
    stock_service.manual_adjust(session, admin_actor, p.id, Decimal(2), MovementType.WASTE, "kırık")
    stock_service.manual_adjust(session, admin_actor, p.id, Decimal(5), MovementType.ADJUST_IN, "bulundu")
    assert stock_service.ledger_mismatches(session) == []
    assert session.exec(select(Sale)).first() is not None
