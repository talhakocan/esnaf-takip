from datetime import datetime, timedelta
from decimal import Decimal

import pytest
from sqlmodel import select

from app.core.errors import Conflict, Forbidden, ValidationFailed
from app.models import (
    LedgerEntry,
    MovementType,
    Payment,
    PaymentMethod,
    ProductSerial,
    Sale,
    SaleStatus,
    SerialStatus,
    StockMovement,
    UnitType,
)
from app.schemas.sales import Override, PaymentIn, ReturnCreate, ReturnItemIn, SaleCreate, SaleItemIn
from app.services import customer_service, sale_service, stock_service
from tests.conftest import ADMIN_PW, STAFF_PW


def _sale(items, payments, **kw):
    return SaleCreate(items=[SaleItemIn(**i) for i in items], payments=[PaymentIn(**p) for p in payments], **kw)


def test_cash_sale_is_atomic_and_consistent(session, admin_actor, make_product):
    a = make_product(stock=10, sale_price_kurus=12000, vat_rate=20)
    b = make_product(stock="100", unit_type=UnitType.METER, sale_price_kurus=1490, vat_rate=20)
    out = sale_service.create_sale(
        session,
        admin_actor,
        _sale(
            [{"product_id": a.id, "qty": 2}, {"product_id": b.id, "qty": "12.5"}],
            [{"method": "CASH", "amount": 24000 + 18625, "tendered": 50000}],
        ),
    )
    assert out["receipt_no"].startswith(f"TL-{datetime.now().year}-")
    assert out["total"] == 42625
    assert out["vat_total"] == 4000 + 3104
    assert out["payments"][0]["change"] == 50000 - 42625
    session.refresh(a)
    session.refresh(b)
    assert a.stock_qty == 8 and b.stock_qty == Decimal("87.5")
    assert stock_service.ledger_mismatches(session) == []


def test_payment_mismatch_rolls_back(session, admin_actor, make_product):
    a = make_product(stock=5)
    with pytest.raises(ValidationFailed) as exc:
        sale_service.create_sale(session, admin_actor, _sale([{"product_id": a.id, "qty": 1}], [{"method": "CASH", "amount": 5000}]))
    assert exc.value.code == "PAYMENT_MISMATCH"
    session.rollback()
    session.refresh(a)
    assert a.stock_qty == 5
    assert session.exec(select(Sale)).first() is None


def test_general_discount_is_allocated(session, admin_actor, make_product):
    a = make_product(stock=5, sale_price_kurus=10000, vat_rate=20)
    b = make_product(stock=5, sale_price_kurus=5000, vat_rate=10)
    out = sale_service.create_sale(
        session,
        admin_actor,
        _sale(
            [{"product_id": a.id, "qty": 1}, {"product_id": b.id, "qty": 1, "discount": 500}],
            [{"method": "CARD", "amount": 13500}],
            discount=1000,
        ),
    )
    assert out["subtotal"] == 14500 and out["total"] == 13500
    assert sum(i["allocated_discount"] for i in out["items"]) == 1000
    assert sum(i["net_total"] for i in out["items"]) == 13500
    assert {v["rate"] for v in out["vat_breakdown"]} == {10, 20}


def test_staff_discount_limit(session, staff_actor, make_product):
    a = make_product(stock=5, sale_price_kurus=10000)
    sale_service.create_sale(
        session, staff_actor, _sale([{"product_id": a.id, "qty": 1, "discount": 500}], [{"method": "CASH", "amount": 9500}])
    )
    with pytest.raises(Forbidden):
        sale_service.create_sale(
            session, staff_actor, _sale([{"product_id": a.id, "qty": 1}], [{"method": "CASH", "amount": 9000}], discount=1000)
        )
    session.rollback()
    with pytest.raises(Forbidden):
        sale_service.create_sale(
            session, staff_actor, _sale([{"product_id": a.id, "qty": 1, "unit_price": 5000}], [{"method": "CASH", "amount": 5000}])
        )


def test_credit_sale_requires_customer_and_writes_ledger(session, admin_actor, make_product, customer):
    a = make_product(stock=5, sale_price_kurus=30000)
    with pytest.raises(ValidationFailed):
        sale_service.create_sale(session, admin_actor, _sale([{"product_id": a.id, "qty": 1}], [{"method": "CREDIT", "amount": 30000}]))
    session.rollback()
    sale_service.create_sale(
        session,
        admin_actor,
        _sale(
            [{"product_id": a.id, "qty": 1}],
            [{"method": "CASH", "amount": 10000}, {"method": "CREDIT", "amount": 20000}],
            customer_id=customer.id,
        ),
    )
    assert customer_service.balance(session, customer.id) == 20000
    entry = session.exec(select(LedgerEntry)).one()
    assert entry.due_date is not None


def test_credit_limit_needs_admin_override(session, staff_actor, admin, make_product, customer):
    a = make_product(stock=5, sale_price_kurus=150000)
    data = _sale([{"product_id": a.id, "qty": 1}], [{"method": "CREDIT", "amount": 150000}], customer_id=customer.id)
    with pytest.raises(Conflict) as exc:
        sale_service.create_sale(session, staff_actor, data)
    assert exc.value.code == "ADMIN_APPROVAL_REQUIRED"
    session.rollback()
    data.override = Override(username="personel", password=STAFF_PW)
    with pytest.raises(Forbidden):
        sale_service.create_sale(session, staff_actor, data)
    session.rollback()
    data.override = Override(username="yonetici", password="yanlis")
    with pytest.raises(Forbidden):
        sale_service.create_sale(session, staff_actor, data)
    session.rollback()
    data.override = Override(username="yonetici", password=ADMIN_PW)
    out = sale_service.create_sale(session, staff_actor, data)
    assert out["total"] == 150000


def test_serial_sale_sets_warranty(session, admin_actor, make_product):
    p = make_product(track_serial=True, warranty_months=24)
    stock_service.manual_adjust(session, admin_actor, p.id, Decimal(1), MovementType.ADJUST_IN, "giriş", serials=["SSD-1"])
    serial = session.exec(select(ProductSerial)).one()
    with pytest.raises(ValidationFailed):
        sale_service.create_sale(session, admin_actor, _sale([{"product_id": p.id, "qty": 1}], [{"method": "CASH", "amount": 10000}]))
    session.rollback()
    out = sale_service.create_sale(
        session, admin_actor, _sale([{"product_id": p.id, "qty": 1, "serial_id": serial.id}], [{"method": "CASH", "amount": 10000}])
    )
    session.refresh(serial)
    assert serial.status == SerialStatus.SOLD and serial.warranty_until is not None
    assert out["items"][0]["serial_no"] == "SSD-1"


def test_cancel_same_day_only_admin(session, admin_actor, staff_actor, make_product, customer):
    a = make_product(stock=5, sale_price_kurus=10000)
    out = sale_service.create_sale(
        session, staff_actor, _sale([{"product_id": a.id, "qty": 2}], [{"method": "CREDIT", "amount": 20000}], customer_id=customer.id)
    )
    with pytest.raises(Forbidden):
        sale_service.cancel_sale(session, staff_actor, out["id"], "yanlış ürün")
    res = sale_service.cancel_sale(session, admin_actor, out["id"], "yanlış ürün")
    assert res["status"] == SaleStatus.CANCELLED
    session.refresh(a)
    assert a.stock_qty == 5
    assert customer_service.balance(session, customer.id) == 0
    with pytest.raises(ValidationFailed):
        sale_service.cancel_sale(session, admin_actor, out["id"], "tekrar")
    session.rollback()
    out2 = sale_service.create_sale(session, admin_actor, _sale([{"product_id": a.id, "qty": 1}], [{"method": "CASH", "amount": 10000}]))
    sale = session.get(Sale, out2["id"])
    sale.created_at = datetime.now() - timedelta(days=1)
    session.commit()
    with pytest.raises(ValidationFailed) as exc:
        sale_service.cancel_sale(session, admin_actor, out2["id"], "dün")
    assert exc.value.code == "CANCEL_NOT_TODAY"


def test_partial_return_restock_and_waste(session, admin_actor, make_product):
    a = make_product(stock=10, sale_price_kurus=10000)
    out = sale_service.create_sale(session, admin_actor, _sale([{"product_id": a.id, "qty": 3}], [{"method": "CASH", "amount": 30000}]))
    item_id = out["items"][0]["id"]
    r1 = sale_service.create_return(
        session, admin_actor, ReturnCreate(sale_id=out["id"], items=[ReturnItemIn(sale_item_id=item_id, qty=Decimal(1))], reason="vazgeçti")
    )
    assert r1["total"] == 10000
    r2 = sale_service.create_return(
        session,
        admin_actor,
        ReturnCreate(sale_id=out["id"], items=[ReturnItemIn(sale_item_id=item_id, qty=Decimal(1), restock=False)], reason="arızalı"),
    )
    assert r2["total"] == 10000
    session.refresh(a)
    assert a.stock_qty == 8  # 10 - 3 + 1 (sağlam) ; arızalı iade stoğa girip fire olarak çıktı
    types = [m.type for m in session.exec(select(StockMovement).where(StockMovement.product_id == a.id)).all()]
    assert types.count(MovementType.WASTE) == 1
    refunds = session.exec(select(Payment).where(Payment.amount < 0)).all()
    assert sum(p.amount for p in refunds) == -20000
    with pytest.raises(ValidationFailed):
        sale_service.create_return(
            session,
            admin_actor,
            ReturnCreate(sale_id=out["id"], items=[ReturnItemIn(sale_item_id=item_id, qty=Decimal(2))], reason="fazla"),
        )
    session.rollback()
    with pytest.raises(ValidationFailed):
        sale_service.cancel_sale(session, admin_actor, out["id"], "iadeli")
    assert stock_service.ledger_mismatches(session) == []


def test_return_to_credit_reduces_debt(session, admin_actor, make_product, customer):
    a = make_product(stock=5, sale_price_kurus=10000)
    out = sale_service.create_sale(
        session, admin_actor, _sale([{"product_id": a.id, "qty": 1}], [{"method": "CREDIT", "amount": 10000}], customer_id=customer.id)
    )
    sale_service.create_return(
        session,
        admin_actor,
        ReturnCreate(
            sale_id=out["id"],
            items=[ReturnItemIn(sale_item_id=out["items"][0]["id"], qty=Decimal(1))],
            method=PaymentMethod.CREDIT,
            reason="iade",
        ),
    )
    assert customer_service.balance(session, customer.id) == 0


def test_list_sales(session, admin_actor, make_product):
    a = make_product(stock=5)
    sale_service.create_sale(session, admin_actor, _sale([{"product_id": a.id, "qty": 1}], [{"method": "CASH", "amount": 10000}]))
    rows = sale_service.list_sales(session, q="TL-")
    assert len(rows) == 1 and rows[0]["methods"] == ["CASH"] and rows[0]["item_count"] == 1


def test_service_products_do_not_touch_stock(session, staff_actor, make_product):
    s = make_product(unit_type=UnitType.SERVICE, sale_price_kurus=0, name="Format + Windows kurulumu")
    out = sale_service.create_sale(
        session, staff_actor, _sale([{"product_id": s.id, "qty": 1, "unit_price": 75000}], [{"method": "CASH", "amount": 75000}])
    )
    assert out["total"] == 75000
    assert session.exec(select(StockMovement).where(StockMovement.product_id == s.id)).first() is None
