# Tezgâh — Teknolife Dükkan Yönetim Sistemi

Elektrik malzemesi ve bilgisayar satış/servis dükkanı için stok, hızlı satış (POS), teknik servis,
cari hesap, satın alma, sayım ve raporlama uygulaması. Tek bilgisayarda çalışır; aynı ağdaki
tablet ve telefonlardan tarayıcıyla kullanılabilir. Okul projesi olarak geliştirilmiştir.

## Hızlı başlangıç (Windows)

1. **Python 3.12** kurun → <https://www.python.org/downloads/>
   (kurulumda *"Add python.exe to PATH"* kutusunu işaretleyin).
2. **Node.js 22 LTS** kurun → <https://nodejs.org> (yalnızca ilk derleme için gerekir).
3. Zip'i **kısa bir yola** çıkarın, örneğin `C:\tezgah`.
   Masaüstü/OneDrive gibi uzun yollar Windows'un 260 karakter sınırına takılabilir.
4. `baslat.bat` dosyasına çift tıklayın.

İlk çalıştırmada betik sırasıyla şunları yapar:

- Python sanal ortamını (`backend\.venv`) kurar ve paketleri yükler.
- Arayüzü derler (`frontend\dist`).
- Veritabanını oluşturur ve boşsa **demo verisini** yükler. Bu adım yaklaşık 1 dakika sürer.
- Uygulamayı `http://localhost:8000` adresinde açar.

Sonraki açılışlar birkaç saniye sürer.

Linux/macOS için: `chmod +x baslat.sh && ./baslat.sh`

### Demo kullanıcılar

| Kullanıcı | Şifre | Rol |
|---|---|---|
| `yonetici` | `Tezgah2026!` | Yönetici (Serkan Aydın) |
| `personel` | `Personel2026!` | Personel (Mehmet Kaya, en fazla %5 indirim) |

> **Gerçek kullanımda ilk iş bu şifreleri değiştirin** (sağ üstteki kullanıcı menüsü › *Şifremi değiştir*,
> kullanıcı eklemek için *Ayarlar › Kullanıcılar*).

Demo verisini sıfırdan yüklemek için uygulamayı kapatın ve şunu çalıştırın:

```bat
cd backend
.venv\Scripts\python -m app.seed --reset
```

### Yerel ağdan erişim

Uygulama `0.0.0.0:8000` üzerinde dinler. Aynı Wi-Fi'daki cihazlardan `http://<bu bilgisayarın IP'si>:8000`
adresiyle girilebilir. IP'yi `ipconfig` komutuyla öğrenebilirsiniz. İlk açılışta Windows Güvenlik Duvarı
izin isterse *Özel ağlar* için izin verin.

## Modüller

| Modül | İçerik |
|---|---|
| Pano | Günün cirosu, kâr, kritik stok, açık servis, veresiye alacağı, "Dikkat" listesi |
| Hızlı Satış (F2) | Barkodla satış, bölünmüş ödeme, veresiye, para üstü, 80 mm fiş / A4 özet |
| Ürünler (F3) | Adet / metre / hizmet ürünleri, seri no + garanti, kura bağlı fiyat, toplu fiyat, Excel içe/dışa aktarma |
| Stok Defteri | Her stok değişikliğinin değiştirilemez kaydı, kaynak belgeye bağlantı |
| Teknik Servis (F4) | Cihaz kabul, durum takibi, parça/işçilik, A5 kabul fişi + QR, teslimde satışa dönüştürme |
| Servis takip | `/takip/SRV-XXXX` — müşteri girişsiz takip eder, kişisel veri gösterilmez |
| Cari hesaplar | Müşteri kartı, veresiye, tahsilat, hesap ekstresi (A4) |
| Tedarikçi & Satın alma | Sipariş, kritik stoktan sipariş, mal kabul (dövizli, seri no'lu) |
| Sayım | Raf/kategori sayımı, barkodla sayma, fark raporu, yönetici onayıyla uygulama |
| Raporlar | Satış & kâr, gün sonu kasa, en çok satanlar, ölü stok, ABC, stok değeri, personel, servis, garanti |
| Etiket basımı | A4 3×8 veya 40×30 mm termal barkodlu etiket |
| Ayarlar | Dükkan bilgisi, kur (elle / TCMB), KDV, kullanıcılar, metinler, yedekleme, denetim kaydı, görünüm |

Klavye: `Ctrl+K` genel arama · `F2` satış · `F3` ürün ara · `F4` yeni servis · `F6` stok girişi ·
`F9` ödemeyi al · `?` tüm kısayollar.

## Teknoloji

- **Backend:** Python 3.11+ · FastAPI · SQLModel (SQLAlchemy 2) · SQLite (WAL) · Alembic ·
  JWT (httpOnly çerez) · Argon2 · openpyxl · httpx
- **Frontend:** React 19 · TypeScript (strict) · Vite · Tailwind CSS v4 (yalnızca proje tokenları) ·
  TanStack Query/Table · React Hook Form + Zod · Radix UI · cmdk · Recharts · JsBarcode · ZXing
- Fontlar (IBM Plex Sans / Condensed / Mono) uygulamayla birlikte gelir; internet gerekmez.

## Geliştirme

```bash
# backend
cd backend
python -m venv .venv && .venv/Scripts/pip install -r requirements-dev.txt   # Linux: .venv/bin/pip
.venv/Scripts/python -m app.seed
.venv/Scripts/python -m uvicorn app.main:app --reload            # http://127.0.0.1:8000/api/docs

# frontend (ayrı terminal) — /api istekleri 8000 portuna yönlenir
cd frontend
npm install
npm run dev                                                       # http://localhost:5173
```

Testler:

```bash
cd backend && .venv/Scripts/python -m pytest --cov=app     # 87 test, servis katmanı kapsamı ≥ %81
cd frontend && npm test                                     # Vitest
cd frontend && npm run typecheck && npm run lint
```

## Klasör yapısı

```
tezgah/
├─ backend/
│  ├─ app/           models · schemas · services (iş kuralları) · routers · core · seed
│  ├─ alembic/       veritabanı migration'ları
│  └─ tests/
├─ frontend/src/     app (iskelet) · design (tasarım sistemi) · features (ekranlar) · lib · pages/public
├─ data/             veritabanı ve gizli anahtar (otomatik oluşur, paylaşmayın)
├─ backups/          otomatik yedekler (her gece 03:00, son 14 yedek)
├─ baslat.bat / baslat.sh
└─ README.md
```

## Yedekleme

Uygulama açıkken her gece 03:00'te ve açılışta (son yedek 24 saatten eskiyse) `backups/` klasörüne yedek
alınır. *Ayarlar › Yedekleme* ekranından elle yedek alınabilir, yedek indirilebilir veya geri yüklenebilir.
Geri yüklemeden önce otomatik bir ön-yedek alınır. Yedekleri düzenli olarak harici bir diske kopyalayın.

## Bilinen sınırlamalar

- Fişler **bilgi fişidir**. e-Fatura/e-Arşiv ve ÖKC (yazar kasa) entegrasyonu kapsam dışıdır.
- Tarayıcılar kameraya yalnızca **HTTPS** veya `localhost` üzerinden izin verir. Yerel ağdan `http://` ile
  açılan telefonlarda kamerayla barkod okuma çalışmaz; USB barkod okuyucu her durumda çalışır.
  Yerel HTTPS için [mkcert](https://github.com/FiloSottile/mkcert) ile sertifika üretip uvicorn'u
  `--ssl-keyfile` / `--ssl-certfile` parametreleriyle başlatabilirsiniz.
- SQLite tek dükkan ve birkaç eşzamanlı kullanıcı için uygundur. Çoklu şube için PostgreSQL'e geçilmesi
  önerilir; bunun için `TEZGAH_DATABASE_URL` ortam değişkeni ile bağlantı dizesini değiştirmek yeterlidir.
- Müşteri telefon/adres bilgileri kişisel veridir (KVKK). Ayarlardaki aydınlatma metni örnektir; dükkan
  sahibi tarafından hukuki olarak gözden geçirilmelidir.
- Demo verisindeki dükkan adresi, telefon ve vergi numarası örnektir; *Ayarlar › Dükkan* ekranından
  gerçek bilgilerle değiştirin.

## Proje durumu

Çalışan ve testli: backend (tüm iş kuralları, 87 test) ve tüm ekranlar.
Devam eden: Playwright uçtan uca testleri, otomatik ekran görüntüleri ve `docs/` altındaki
okul projesi belgeleri (proje raporu, mimari, ER diyagramı, kullanım kılavuzu).
