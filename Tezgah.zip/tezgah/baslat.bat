@echo off
setlocal EnableExtensions
chcp 65001 >nul
title Tezgah - Teknolife
cd /d "%~dp0"

echo.
echo  TEKNOLIFE  tezgah  -  dukkan yonetim sistemi
echo  ------------------------------------------------
echo.

rem ---------------------------------------------------------------- Python
set "PY="
py -3.12 -c "import sys" >nul 2>&1 && set "PY=py -3.12"
if not defined PY py -3.13 -c "import sys" >nul 2>&1 && set "PY=py -3.13"
if not defined PY py -3.11 -c "import sys" >nul 2>&1 && set "PY=py -3.11"
if not defined PY python -c "import sys; sys.exit(0 if sys.version_info >= (3, 11) else 1)" >nul 2>&1 && set "PY=python"
if not defined PY (
  echo [HATA] Python 3.11 veya uzeri bulunamadi.
  echo        https://www.python.org/downloads/ adresinden Python 3.12 kurun.
  echo        Kurulumda "Add python.exe to PATH" kutusunu isaretleyin.
  goto :hata
)

rem ---------------------------------------------------------------- sanal ortam
if not exist "backend\.venv\Scripts\python.exe" (
  echo [1/4] Python sanal ortami olusturuluyor...
  %PY% -m venv "backend\.venv" || goto :hata
)
set "VPY=%~dp0backend\.venv\Scripts\python.exe"

fc /b "backend\requirements.txt" "backend\.venv\kurulu-gereksinimler.txt" >nul 2>&1
if errorlevel 1 (
  echo [2/4] Python paketleri yukleniyor - ilk seferde birkac dakika surebilir...
  "%VPY%" -m pip install --disable-pip-version-check -q --upgrade pip
  "%VPY%" -m pip install --disable-pip-version-check -q -r "backend\requirements.txt" || goto :hata
  copy /y "backend\requirements.txt" "backend\.venv\kurulu-gereksinimler.txt" >nul
) else (
  echo [2/4] Python paketleri hazir.
)

rem ---------------------------------------------------------------- arayuz
if not exist "frontend\dist\index.html" (
  where npm >nul 2>&1
  if errorlevel 1 (
    echo [HATA] Node.js bulunamadi. Arayuzu derlemek icin https://nodejs.org adresinden
    echo        Node.js 22 LTS kurun ve bu dosyayi yeniden calistirin.
    goto :hata
  )
  echo [3/4] Arayuz derleniyor - ilk seferde birkac dakika surebilir...
  pushd frontend
  if exist package-lock.json (call npm ci --no-audit --no-fund) else (call npm install --no-audit --no-fund)
  if errorlevel 1 ( popd & goto :hata )
  call npm run build
  if errorlevel 1 ( popd & goto :hata )
  popd
) else (
  echo [3/4] Arayuz hazir.
)

rem ---------------------------------------------------------------- veritabani
echo [4/4] Veritabani guncelleniyor (bossa demo verisi yuklenir)...
pushd backend
"%VPY%" -m app.seed || ( popd & goto :hata )

echo.
echo  Uygulama baslatiliyor:  http://localhost:8000
echo  Ayni agdaki telefon/bilgisayardan:  http://BU-BILGISAYARIN-IP-ADRESI:8000
echo  Kapatmak icin bu pencerede Ctrl+C'ye basin.
echo.
if not defined TEZGAH_NO_BROWSER start "" /b cmd /c "timeout /t 3 >nul & start http://localhost:8000"
"%VPY%" -m uvicorn app.main:app --host 0.0.0.0 --port 8000
popd
goto :eof

:hata
echo.
echo Kurulum tamamlanamadi. Yukaridaki hata mesajina bakin.
pause
exit /b 1
