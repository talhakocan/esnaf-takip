import { useEffect, useRef } from "react";

/** Klavye kısayolları. Anahtar biçimi: "F2", "Ctrl+K", "Alt+1", "/", "?", "Escape". */
export type HotkeyMap = Record<string, (e: KeyboardEvent) => void>;

export function eventKey(e: KeyboardEvent): string {
  const parts: string[] = [];
  if (e.ctrlKey || e.metaKey) parts.push("Ctrl");
  if (e.altKey) parts.push("Alt");
  let key = e.key;
  if (e.altKey && /^Digit\d$/.test(e.code)) key = e.code.slice(5);
  if (key.length === 1) key = key.toUpperCase();
  if (e.shiftKey && key.length > 1 && key !== "Shift") parts.push("Shift");
  parts.push(key === "?" ? "?" : key);
  return parts.join("+");
}

export function isTyping(target: EventTarget | null): boolean {
  const el = target as HTMLElement | null;
  if (!el) return false;
  const tag = el.tagName;
  return tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT" || el.isContentEditable;
}

/** Yazı yazarken tetiklenmemesi gereken tek karakterlik kısayollar. */
const TYPING_SENSITIVE = new Set(["/", "?", "+", "-", "Delete"]);

export function useHotkeys(map: HotkeyMap, enabled = true): void {
  const ref = useRef(map);
  ref.current = map;
  useEffect(() => {
    if (!enabled) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.defaultPrevented) return;
      const key = eventKey(e);
      const handler = ref.current[key] ?? (key.length === 1 ? ref.current[key.toLowerCase()] : undefined);
      if (!handler) return;
      const plain = key.replace(/^Shift\+/, "");
      if (TYPING_SENSITIVE.has(plain) && isTyping(e.target)) return;
      e.preventDefault();
      handler(e);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [enabled]);
}

export const GLOBAL_SHORTCUTS: { keys: string; label: string }[] = [
  { keys: "Ctrl+K", label: "Komut paleti / genel arama" },
  { keys: "F2", label: "Hızlı satış" },
  { keys: "F3", label: "Ürün ara" },
  { keys: "F4", label: "Yeni servis kaydı" },
  { keys: "F6", label: "Stok girişi" },
  { keys: "/", label: "Sayfadaki aramaya odaklan" },
  { keys: "?", label: "Kısayol listesi" },
];

export const POS_SHORTCUTS: { keys: string; label: string }[] = [
  { keys: "F7", label: "Müşteri seç" },
  { keys: "F9", label: "Ödemeyi al" },
  { keys: "Alt+1…9", label: "Sık satılan ürünü ekle" },
  { keys: "+ / −", label: "Seçili satırın miktarını değiştir" },
  { keys: "↑ / ↓", label: "Satır seç" },
  { keys: "Delete", label: "Seçili satırı sil" },
  { keys: "Escape", label: "Sepeti temizle (onaylı)" },
];
