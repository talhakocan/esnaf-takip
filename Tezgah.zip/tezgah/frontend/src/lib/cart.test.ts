import { describe, expect, it } from "vitest";
import { allocate, cartTotals, lineGross, vatOfGross } from "./cart";

describe("cart", () => {
  it("allocates without losing kuruş", () => {
    const parts = allocate(100, [3333, 3333, 3334]);
    expect(parts.reduce((a, b) => a + b, 0)).toBe(100);
    expect(allocate(0, [1, 2])).toEqual([0, 0]);
  });
  it("computes gross for decimal quantities", () => {
    expect(lineGross({ qty: 12.5, unit_price: 1490, discount: 0, vat_rate: 20 })).toBe(18625);
    expect(vatOfGross(12000, 20)).toBe(2000);
  });
  it("matches backend example: general discount allocation and VAT split", () => {
    const t = cartTotals(
      [
        { qty: 1, unit_price: 10000, discount: 0, vat_rate: 20 },
        { qty: 1, unit_price: 5000, discount: 500, vat_rate: 10 },
      ],
      1000,
    );
    expect(t.subtotal).toBe(14500);
    expect(t.total).toBe(13500);
    expect(t.vat.map((v) => v.rate)).toEqual([10, 20]);
    expect(t.discountPct).toBeCloseTo(10);
  });
  it("caps general discount at subtotal", () => {
    expect(cartTotals([{ qty: 1, unit_price: 1000, discount: 0, vat_rate: 20 }], 5000).total).toBe(0);
  });
});
