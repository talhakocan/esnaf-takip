import type { ReactNode } from "react";
import { flushSync } from "react-dom";
import { createRoot } from "react-dom/client";

export type PageKind = "receipt80" | "a4" | "a5" | "label-a4" | "label-thermal";

const PAGE_CSS: Record<PageKind, string> = {
  receipt80: "@page { size: 80mm auto; margin: 3mm 2mm; }",
  a4: "@page { size: A4; margin: 14mm 12mm; }",
  a5: "@page { size: A5; margin: 10mm; }",
  "label-a4": "@page { size: A4; margin: 0; }",
  "label-thermal": "@page { size: 40mm 30mm; margin: 0; }",
};

let busy = false;

/**
 * Verilen içeriği #print-root içine çizer ve tarayıcının yazdırma penceresini açar.
 * Uygulama ekranı yazdırma sırasında gizlenir (tokens.css › @media print).
 */
export function printNode(node: ReactNode, kind: PageKind): void {
  if (busy) return;
  const host = document.getElementById("print-root");
  if (!host) return;
  busy = true;
  const style = document.createElement("style");
  style.id = "tz-page-style";
  style.textContent = PAGE_CSS[kind];
  document.head.appendChild(style);
  const root = createRoot(host);
  flushSync(() => root.render(node));
  document.body.classList.add("tz-printing");
  const cleanup = () => {
    window.removeEventListener("afterprint", cleanup);
    document.body.classList.remove("tz-printing");
    style.remove();
    root.unmount();
    busy = false;
  };
  window.addEventListener("afterprint", cleanup);
  requestAnimationFrame(() =>
    requestAnimationFrame(() => {
      window.print();
      // Bazı tarayıcılar afterprint tetiklemez.
      setTimeout(() => busy && cleanup(), 1500);
    }),
  );
}
