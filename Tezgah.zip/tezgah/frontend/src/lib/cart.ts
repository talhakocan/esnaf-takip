/** Sepet hesapları — backend'deki sale_service ile aynı kurallar (ekran önizlemesi için). */

export interface CartLineInput {
  qty: number;
  unit_price: number;
  discount: number;
  vat_rate: number;
}

export function lineGross(l: CartLineInput): number {
  return Math.round(l.qty * l.unit_price);
}

/** Tutarı ağırlıklara göre kuruş kaybı olmadan dağıtır (en büyük kalan yöntemi). */
export function allocate(total: number, weights: number[]): number[] {
  const sum = weights.reduce((a, b) => a + b, 0);
  if (!weights.length || sum === 0 || total === 0) return weights.map(() => 0);
  const raw = weights.map((w) => (total * w) / sum);
  const floors = raw.map(Math.floor);
  let rest = total - floors.reduce((a, b) => a + b, 0);
  const order = raw.map((r, i) => [r - floors[i], i] as const).sort((a, b) => b[0] - a[0]);
  for (const [, i] of order) {
    if (rest <= 0) break;
    floors[i] += 1;
    rest -= 1;
  }
  return floors;
}

export function vatOfGross(gross: number, rate: number): number {
  if (rate <= 0) return 0;
  return gross - Math.round((gross * 100) / (100 + rate));
}

export interface CartTotals {
  gross: number;
  lineDiscounts: number;
  subtotal: number;
  discount: number;
  total: number;
  vat: { rate: number; base: number; vat: number }[];
  vatTotal: number;
  discountPct: number;
}

export function cartTotals(lines: CartLineInput[], generalDiscount: number): CartTotals {
  const lineTotals = lines.map((l) => lineGross(l) - l.discount);
  const gross = lines.reduce((s, l) => s + lineGross(l), 0);
  const lineDiscounts = lines.reduce((s, l) => s + l.discount, 0);
  const subtotal = lineTotals.reduce((a, b) => a + b, 0);
  const discount = Math.min(Math.max(generalDiscount, 0), Math.max(subtotal, 0));
  const alloc = allocate(discount, lineTotals.map((t) => Math.max(t, 0)));
  const byRate = new Map<number, { rate: number; base: number; vat: number }>();
  lines.forEach((l, i) => {
    const net = lineTotals[i] - alloc[i];
    const v = vatOfGross(net, l.vat_rate);
    const r = byRate.get(l.vat_rate) ?? { rate: l.vat_rate, base: 0, vat: 0 };
    r.vat += v;
    r.base += net - v;
    byRate.set(l.vat_rate, r);
  });
  const vat = [...byRate.values()].sort((a, b) => a.rate - b.rate);
  return {
    gross,
    lineDiscounts,
    subtotal,
    discount,
    total: subtotal - discount,
    vat,
    vatTotal: vat.reduce((s, v) => s + v.vat, 0),
    discountPct: gross > 0 ? ((lineDiscounts + discount) / gross) * 100 : 0,
  };
}
