import type { DeviceType, MovementType, PaymentMethod, POStatus, RoundingRule, ServiceStatus, StockStatus } from "./types";

export type Tone = "ok" | "warn" | "crit" | "info" | "neutral" | "signal";

export const SERVICE_STATUS_TR: Record<ServiceStatus, string> = {
  RECEIVED: "Teslim alındı",
  DIAGNOSING: "İnceleniyor",
  WAITING_APPROVAL: "Onay bekleniyor",
  WAITING_PARTS: "Parça bekleniyor",
  IN_REPAIR: "Onarımda",
  READY: "Teslime hazır",
  DELIVERED: "Teslim edildi",
  CANCELLED: "İptal / onarılamadı",
};

export const SERVICE_STATUS_TONE: Record<ServiceStatus, Tone> = {
  RECEIVED: "neutral",
  DIAGNOSING: "info",
  WAITING_APPROVAL: "warn",
  WAITING_PARTS: "warn",
  IN_REPAIR: "info",
  READY: "ok",
  DELIVERED: "neutral",
  CANCELLED: "crit",
};

export const SERVICE_ORDER: ServiceStatus[] = [
  "RECEIVED",
  "DIAGNOSING",
  "WAITING_APPROVAL",
  "WAITING_PARTS",
  "IN_REPAIR",
  "READY",
  "DELIVERED",
  "CANCELLED",
];

export const OPEN_SERVICE: ServiceStatus[] = ["RECEIVED", "DIAGNOSING", "WAITING_APPROVAL", "WAITING_PARTS", "IN_REPAIR", "READY"];

export const DEVICE_TR: Record<DeviceType, string> = {
  LAPTOP: "Dizüstü",
  DESKTOP: "Masaüstü",
  PRINTER: "Yazıcı",
  PHONE: "Telefon",
  MONITOR: "Monitör",
  OTHER: "Diğer",
};

export const METHOD_TR: Record<PaymentMethod, string> = {
  CASH: "Nakit",
  CARD: "Kart",
  TRANSFER: "Havale/EFT",
  CREDIT: "Veresiye",
};

export const MOVEMENT_TONE: Record<MovementType, Tone> = {
  PURCHASE_IN: "ok",
  ADJUST_IN: "ok",
  SALE_OUT: "info",
  SALE_RETURN: "warn",
  SERVICE_OUT: "signal",
  SERVICE_RETURN: "warn",
  ADJUST_OUT: "neutral",
  COUNT_ADJUST: "neutral",
  WASTE: "crit",
};

export const MOVEMENT_TR: Record<MovementType, string> = {
  PURCHASE_IN: "Mal kabul",
  SALE_OUT: "Satış",
  SALE_RETURN: "İade / iptal",
  SERVICE_OUT: "Servis çıkışı",
  SERVICE_RETURN: "Servis iadesi",
  ADJUST_IN: "Stok girişi",
  ADJUST_OUT: "Stok çıkışı",
  COUNT_ADJUST: "Sayım farkı",
  WASTE: "Fire",
};

export const STOCK_STATUS_TR: Record<StockStatus, string> = {
  service: "Hizmet",
  out: "Tükendi",
  critical: "Kritik",
  warn: "Azalıyor",
  ok: "Yeterli",
};

export const STOCK_STATUS_TONE: Record<StockStatus, Tone> = {
  service: "neutral",
  out: "crit",
  critical: "crit",
  warn: "warn",
  ok: "ok",
};

export const PO_STATUS_TR: Record<POStatus, string> = {
  DRAFT: "Taslak",
  ORDERED: "Sipariş verildi",
  PARTIAL: "Kısmi teslim",
  RECEIVED: "Teslim alındı",
  CANCELLED: "İptal",
};

export const PO_STATUS_TONE: Record<POStatus, Tone> = {
  DRAFT: "neutral",
  ORDERED: "info",
  PARTIAL: "warn",
  RECEIVED: "ok",
  CANCELLED: "crit",
};

export const ROUNDING_TR: Record<RoundingRule, string> = {
  NONE: "Yuvarlama yok",
  NEAREST_1: "En yakın 1 TL",
  NEAREST_5: "En yakın 5 TL",
  END_90: ",90 ile bitir",
};

export const PRICE_REASON_TR: Record<string, string> = {
  MANUAL: "Elle",
  FX_UPDATE: "Kur güncellemesi",
  BULK: "Toplu güncelleme",
  IMPORT: "Excel içe aktarma",
};

export const ENTITY_TR: Record<string, string> = {
  product: "Ürün",
  settings: "Ayarlar",
  exchange_rates: "Döviz kuru",
  sale: "Satış",
  customer: "Müşteri",
  user: "Kullanıcı",
  supplier: "Tedarikçi",
  purchase_order: "Satın alma",
  stock_count: "Sayım",
  category: "Kategori",
  brand: "Marka",
  location: "Konum",
  backup: "Yedek",
};

export const ACTION_TR: Record<string, string> = {
  "product.create": "Ürün oluşturuldu",
  "product.update": "Ürün güncellendi",
  "product.archive": "Ürün arşivlendi",
  "product.restore": "Ürün geri alındı",
  "product.bulk_price": "Toplu fiyat güncellemesi",
  "product.bulk_update": "Toplu ürün güncellemesi",
  "product.import_create": "Excel'den ürün eklendi",
  "product.import_update": "Excel'den ürün güncellendi",
  "stock.adjust_in": "Stok girişi",
  "stock.adjust_out": "Stok çıkışı",
  "stock.purchase_in": "Stok girişi (alış)",
  "stock.waste": "Fire kaydı",
  "sale.cancel": "Satış iptali",
  "sale.return": "İade",
  "sale.credit_override": "Kredi limiti aşım onayı",
  "fx.update": "Kur güncellemesi",
  "settings.update": "Ayarlar değişti",
  "user.create": "Kullanıcı oluşturuldu",
  "user.update": "Kullanıcı güncellendi",
  "user.password": "Şifre değiştirildi",
  "customer.create": "Müşteri oluşturuldu",
  "customer.update": "Müşteri güncellendi",
  "customer.payment": "Tahsilat",
  "customer.adjust": "Bakiye düzeltme",
  "count.apply": "Sayım onaylandı",
  "count.cancel": "Sayım iptal edildi",
  "purchase.create": "Sipariş oluşturuldu",
  "purchase.order": "Sipariş verildi",
  "purchase.receive": "Mal kabul",
  "purchase.cancel": "Sipariş iptal",
  "supplier.create": "Tedarikçi eklendi",
  "supplier.update": "Tedarikçi güncellendi",
  "backup.create": "Manuel yedek",
  "backup.restore": "Yedekten geri yükleme",
  "category.create": "Kategori eklendi",
  "category.update": "Kategori güncellendi",
  "brand.save": "Marka kaydedildi",
  "location.save": "Konum kaydedildi",
};

export const ACCESSORY_OPTIONS = ["Şarj adaptörü", "Çanta", "Güç kablosu", "Pil", "Mouse", "USB kablo", "Kutu", "Kılıf"];
