import type { UnitType } from "./format";

export type { UnitType };
export type Role = "ADMIN" | "STAFF";
export type Currency = "TRY" | "USD" | "EUR";
export type PricingMode = "FIXED" | "FX_LINKED";
export type PaymentMethod = "CASH" | "CARD" | "TRANSFER" | "CREDIT";
export type StockStatus = "service" | "out" | "critical" | "warn" | "ok";
export type RoundingRule = "NONE" | "NEAREST_1" | "NEAREST_5" | "END_90";
export type ServiceStatus =
  | "RECEIVED"
  | "DIAGNOSING"
  | "WAITING_APPROVAL"
  | "WAITING_PARTS"
  | "IN_REPAIR"
  | "READY"
  | "DELIVERED"
  | "CANCELLED";
export type DeviceType = "LAPTOP" | "DESKTOP" | "PRINTER" | "PHONE" | "MONITOR" | "OTHER";
export type MovementType =
  | "PURCHASE_IN"
  | "SALE_OUT"
  | "SALE_RETURN"
  | "SERVICE_OUT"
  | "SERVICE_RETURN"
  | "ADJUST_IN"
  | "ADJUST_OUT"
  | "COUNT_ADJUST"
  | "WASTE";

export interface Me {
  id: number;
  username: string;
  full_name: string;
  role: Role;
  max_discount_pct: number;
  is_active: boolean;
  permissions: string[];
}

export interface Product {
  id: number;
  sku: string;
  barcode: string | null;
  name: string;
  category_id: number | null;
  category_path: string | null;
  brand_id: number | null;
  brand_name: string | null;
  supplier_id: number | null;
  supplier_name: string | null;
  location_id: number | null;
  location_code: string | null;
  unit_type: UnitType;
  vat_rate: number;
  pricing_mode: PricingMode;
  sale_price_kurus: number;
  min_stock: number;
  stock_qty: number;
  track_serial: boolean;
  warranty_months: number;
  notes: string;
  is_active: boolean;
  last_movement_at: string | null;
  created_at: string;
  updated_at: string;
  stock_status: StockStatus;
  is_dead: boolean;
  // yalnızca yetkili kullanıcılar
  purchase_currency?: Currency;
  purchase_price?: number;
  markup_pct?: number;
  avg_cost_kurus?: number;
  cost_kurus?: number;
  margin_pct?: number | null;
  price_breakdown?: {
    purchase_price: number;
    currency: Currency;
    rate: number;
    markup_pct: number;
    raw_kurus: number;
    rounded_kurus: number;
    rounding_rule: RoundingRule;
  } | null;
  serial_counts?: Record<string, number>;
}

export interface Lookup {
  matched_by: "barcode" | "sku" | "serial";
  product: Product;
  serial: { id: number; serial_no: string; status: string } | null;
}

export interface Category {
  id: number;
  name: string;
  parent_id: number | null;
  path: string;
  is_active: boolean;
  product_count: number;
}
export interface Brand {
  id: number;
  name: string;
  is_active: boolean;
}
export interface Location {
  id: number;
  code: string;
  name: string;
  is_active: boolean;
}

export interface Movement {
  id: number;
  at: string;
  type: MovementType;
  label: string;
  product_id: number;
  product_name: string;
  sku: string;
  unit_type: UnitType;
  qty: number;
  balance_after: number;
  ref_type: string | null;
  ref_id: number | null;
  ref_label: string | null;
  ref_link: string | null;
  note: string;
  user_name: string | null;
  unit_cost_kurus?: number;
}

export interface Serial {
  id: number;
  serial_no: string;
  status: "IN_STOCK" | "SOLD" | "RETURNED" | "DEFECTIVE";
  warranty_until?: string | null;
  created_at?: string;
  sale_id?: number | null;
  receipt_no?: string | null;
  sold_at?: string | null;
}

export interface PriceHistoryRow {
  id: number;
  at: string;
  old_price: number;
  new_price: number;
  reason: "MANUAL" | "FX_UPDATE" | "BULK" | "IMPORT";
  user_name: string | null;
}

export interface SaleListRow {
  id: number;
  receipt_no: string;
  created_at: string;
  customer_id: number | null;
  customer_name: string | null;
  user_name: string | null;
  item_count: number;
  total: number;
  discount: number;
  status: "COMPLETED" | "CANCELLED";
  methods: PaymentMethod[];
  returned_total: number;
  service_ticket_id: number | null;
}

export interface SaleItem {
  id: number;
  product_id: number;
  product_name: string;
  sku: string;
  unit_type: UnitType;
  qty: number;
  unit_price: number;
  discount: number;
  allocated_discount: number;
  vat_rate: number;
  vat_amount: number;
  line_total: number;
  net_total: number;
  returned_qty: number;
  serial_id: number | null;
  serial_no: string | null;
  warranty_until: string | null;
  unit_cost?: number;
  profit?: number;
}

export interface SaleDetail {
  id: number;
  receipt_no: string;
  created_at: string;
  status: "COMPLETED" | "CANCELLED";
  subtotal: number;
  discount: number;
  vat_total: number;
  total: number;
  note: string;
  cancelled_reason: string | null;
  cancelled_at: string | null;
  service_ticket_id: number | null;
  customer: { id: number; full_name: string; phone: string } | null;
  user_name: string | null;
  items: SaleItem[];
  vat_breakdown: { rate: number; base: number; vat: number; total: number }[];
  payments: { id: number; method: PaymentMethod; amount: number; tendered: number | null; change: number | null }[];
  returns: { id: number; at: string; total: number; method: PaymentMethod; reason: string }[];
  can_cancel: boolean;
  profit?: number;
}

export interface Customer {
  id: number;
  full_name: string;
  phone: string;
  email: string;
  tax_no: string;
  address: string;
  note: string;
  credit_limit_kurus: number;
  kvkk_consent_at: string | null;
  is_active: boolean;
  created_at: string;
  balance: number;
  overdue: number;
}

export interface CustomerDetail extends Customer {
  sales: { id: number; receipt_no: string; at: string; total: number; status: string; user_name: string | null }[];
  service_tickets: {
    id: number;
    code: string;
    device_type: DeviceType;
    brand: string;
    model: string;
    status: ServiceStatus;
    received_at: string;
    delivered_at: string | null;
  }[];
  serials: {
    serial_no: string;
    product_name: string;
    receipt_no: string;
    sold_at: string;
    sale_id: number;
    warranty_until: string | null;
    status: string;
    under_warranty: boolean;
  }[];
}

export interface StatementRow {
  id: number;
  at: string;
  type: "DEBT" | "PAYMENT" | "ADJUST";
  description: string;
  ref_type: string | null;
  ref_id: number | null;
  due_date: string | null;
  debit: number;
  credit: number;
  balance: number;
  user_name: string | null;
}

export interface Statement {
  customer: Customer;
  opening_balance: number;
  rows: StatementRow[];
  closing_balance: number;
  total_debit: number;
  total_credit: number;
}

export interface TicketListRow {
  id: number;
  code: string;
  device_type: DeviceType;
  brand: string;
  model: string;
  customer_id: number;
  customer_name: string;
  customer_phone: string;
  status: ServiceStatus;
  status_changed_at: string | null;
  received_at: string;
  delivered_at: string | null;
  waiting_days: number;
  assigned_to: number | null;
  assigned_name: string | null;
  estimated_cost: number;
  complaint: string;
}

export interface TimelineEvent {
  kind: "status" | "note";
  at: string;
  from_status?: ServiceStatus | null;
  to_status?: ServiceStatus;
  note?: string;
  id?: number;
  body?: string;
  visibility?: "INTERNAL" | "CUSTOMER";
  user_name: string | null;
}

export interface TicketDetail {
  id: number;
  code: string;
  device_type: DeviceType;
  brand: string;
  model: string;
  serial_no: string;
  accessories: string[];
  complaint: string;
  diagnosis: string;
  status: ServiceStatus;
  status_label: string;
  status_changed_at: string | null;
  estimated_cost: number;
  approved_by_customer_at: string | null;
  labor_fee: number;
  assigned_to: number | null;
  assigned_name: string | null;
  received_at: string;
  delivered_at: string | null;
  sale_id: number | null;
  waiting_days: number;
  customer: { id: number; full_name: string; phone: string } | null;
  timeline: TimelineEvent[];
  parts: {
    id: number;
    product_id: number;
    product_name: string;
    sku: string;
    unit_type: UnitType;
    qty: number;
    unit_price: number;
    total: number;
    serial_no: string | null;
    removed_at: string | null;
    added_at: string;
    unit_cost?: number;
  }[];
  parts_total: number;
  total: number;
  allowed_transitions: ServiceStatus[];
  next_status: ServiceStatus | null;
  parts_cost?: number;
}

export interface PublicTrack {
  code: string;
  status: ServiceStatus;
  status_label: string;
  device_type: DeviceType;
  brand: string;
  model: string;
  received_at: string;
  delivered_at: string | null;
  updated_at: string | null;
  estimated_cost: number;
  cancelled: boolean;
  steps: { status: ServiceStatus; label: string; at: string | null; done: boolean; current: boolean }[];
  notes: { at: string; body: string }[];
  shop: { name: string; phone: string; address: string };
}

export interface Supplier {
  id: number;
  name: string;
  contact: string;
  phone: string;
  email: string;
  currency: Currency;
  note: string;
  is_active: boolean;
  created_at: string;
  order_count?: number;
  open_orders?: number;
  avg_lead_days?: number | null;
  product_count?: number;
  last_order_at?: string | null;
}

export type POStatus = "DRAFT" | "ORDERED" | "PARTIAL" | "RECEIVED" | "CANCELLED";

export interface OrderSummary {
  id: number;
  order_no: string;
  supplier_id: number;
  supplier_name?: string;
  status: POStatus;
  status_label: string;
  currency: Currency;
  total: number | null;
  item_count: number;
  created_at: string;
  ordered_at: string | null;
  expected_at: string | null;
  received_at: string | null;
}

export interface OrderDetail extends OrderSummary {
  note: string;
  fx_rate: number | null;
  current_rate: number | null;
  created_by_name: string | null;
  items: {
    id: number;
    product_id: number;
    sku: string;
    name: string;
    unit_type: UnitType;
    track_serial: boolean;
    qty: number;
    received_qty: number;
    remaining: number;
    unit_price: number | null;
    line_total: number | null;
    stock_qty: number;
  }[];
}

export interface CountSummary {
  id: number;
  name: string;
  status: "OPEN" | "APPLIED" | "CANCELLED";
  created_at: string;
  applied_at: string | null;
  location_code: string | null;
  category_path: string | null;
  item_count: number;
  counted_count: number;
  created_by_name: string | null;
}

export interface CountDetail {
  id: number;
  name: string;
  status: "OPEN" | "APPLIED" | "CANCELLED";
  note: string;
  created_at: string;
  applied_at: string | null;
  items: {
    id: number;
    product_id: number;
    sku: string;
    barcode: string | null;
    name: string;
    unit_type: UnitType;
    location_code: string | null;
    expected_qty: number;
    counted_qty: number | null;
    diff: number | null;
    diff_value?: number | null;
  }[];
  counted_count: number;
  diff_count: number;
  diff_value_total?: number;
}

export interface Settings {
  shop_name: string;
  address: string;
  phone: string;
  email: string;
  tax_office: string;
  tax_no: string;
  receipt_footer: string;
  default_vat_rate: number;
  rounding_rule: RoundingRule;
  allow_negative_stock: boolean;
  default_warranty_months: number;
  credit_due_days: number;
  dead_stock_days: number;
  fx_stale_days: number;
  service_terms: string;
  kvkk_text: string;
}

export interface FxInfo {
  rates: Partial<Record<"USD" | "EUR", { rate: number; source: string; fetched_at: string }>>;
  stale: boolean;
  fetched_at: string | null;
  stale_days: number;
  history?: { currency: string; rate: number; source: string; fetched_at: string }[];
}

export interface StatusInfo {
  today_sales: number;
  last_backup_at: string | null;
  fx: FxInfo;
}

export interface ReportColumn {
  key: string;
  label: string;
  type: "text" | "money" | "int" | "qty" | "pct" | "date" | "datetime" | "code";
}

export interface ReportTable {
  key: string;
  title: string;
  columns: ReportColumn[];
  rows: Record<string, unknown>[];
  totals?: Record<string, unknown>;
  bar?: string;
}

export interface Report {
  title: string;
  kpis?: { label: string; value: number | string | null; type: string }[];
  notes?: string[];
  chart?: { type: "line" | "pareto"; x: string; series: { key: string; label: string }[]; rows: Record<string, unknown>[] };
  tables: ReportTable[];
  range?: { from: string; to: string };
}

export interface Dashboard {
  kpis: {
    key: string;
    label: string;
    value: number;
    type: "money" | "int";
    delta?: number;
    delta_type?: "money" | "int";
    sub?: string;
    sub_amount?: number;
    link: string;
    tone?: "crit" | null;
  }[];
  series: { date: string; label: string; revenue: number; profit?: number }[];
  recent_movements: Movement[];
  attention: { kind: string; tone: "crit" | "warn" | "info" | "ok"; title: string; detail: string; amount?: number; link: string }[];
  generated_at: string;
}

export interface SearchResult {
  products: { id: number; name: string; sku: string; stock_qty: number; unit_type: UnitType; sale_price_kurus: number }[];
  customers: { id: number; full_name: string; phone: string }[];
  tickets: { id: number; code: string; model: string; customer_name: string; status: ServiceStatus; status_label: string }[];
  serials: {
    id: number;
    serial_no: string;
    product_id: number;
    product_name: string;
    status: string;
    receipt_no: string | null;
    sale_id: number | null;
    sold_at: string | null;
    warranty_until: string | null;
    under_warranty: boolean;
  }[];
  sales: { id: number; receipt_no: string; total: number; created_at: string; status: string }[];
}

export interface UserRow {
  id: number;
  username?: string;
  full_name: string;
  role?: Role;
  max_discount_pct?: number;
  is_active: boolean;
  created_at?: string;
}

export interface AuditRow {
  id: number;
  at: string;
  user_name: string | null;
  action: string;
  entity: string;
  entity_id: number | null;
  diff: { before?: Record<string, unknown>; after?: Record<string, unknown>; extra?: Record<string, unknown> };
  ip: string | null;
}

export interface BackupRow {
  name: string;
  size: number;
  created_at: string;
  kind: "auto" | "manual" | "pre-restore";
}
