/** Biçimlendirme: para tr-TR (₺ 1.234,50), tarih 29.09.2026 14:05, miktar birimli. */

export type UnitType = "PIECE" | "METER" | "SERVICE";

const nf2 = new Intl.NumberFormat("tr-TR", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const nf0 = new Intl.NumberFormat("tr-TR", { maximumFractionDigits: 0 });
const nfQty = new Intl.NumberFormat("tr-TR", { maximumFractionDigits: 3 });
const nfRate = new Intl.NumberFormat("tr-TR", { minimumFractionDigits: 2, maximumFractionDigits: 4 });
const nfPct = new Intl.NumberFormat("tr-TR", { maximumFractionDigits: 1 });

export const MINUS = "−";

/** Kuruş → "₺ 1.234,50". Negatif: "−₺ 1.234,50". */
export function money(kurus: number | null | undefined, opts: { plusSign?: boolean } = {}): string {
  if (kurus === null || kurus === undefined || Number.isNaN(kurus)) return "—";
  const abs = nf2.format(Math.abs(kurus) / 100);
  if (kurus < 0) return `${MINUS}₺ ${abs}`;
  return `${opts.plusSign && kurus > 0 ? "+" : ""}₺ ${abs}`;
}

/** Kuruş → "1.234,50" (para simgesi olmadan). */
export function moneyPlain(kurus: number | null | undefined): string {
  if (kurus === null || kurus === undefined) return "—";
  return (kurus < 0 ? MINUS : "") + nf2.format(Math.abs(kurus) / 100);
}

/** Kısa para: ₺ 12,4 B / ₺ 1,2 Mn (grafik eksenleri için). */
export function moneyShort(kurus: number): string {
  const tl = kurus / 100;
  if (Math.abs(tl) >= 1_000_000) return `₺ ${nfPct.format(tl / 1_000_000)} Mn`;
  if (Math.abs(tl) >= 1_000) return `₺ ${nfPct.format(tl / 1_000)} B`;
  return `₺ ${nf0.format(tl)}`;
}

/**
 * Kullanıcı girişini sayıya çevirir. Türkçe biçim ("1.234,50") ve nokta ondalıklı ("12.5")
 * desteklenir. Geçersiz girişte null döner.
 */
export function parseDecimal(input: string | number | null | undefined): number | null {
  if (input === null || input === undefined) return null;
  if (typeof input === "number") return Number.isFinite(input) ? input : null;
  let s = input.trim().replace(/\s|₺|TL/gi, "");
  if (!s) return null;
  const neg = s.startsWith("-") || s.startsWith(MINUS);
  s = s.replace(/^[-−+]/, "");
  if (s.includes(",")) {
    s = s.replace(/\./g, "").replace(",", ".");
  } else if (/^\d{1,3}(\.\d{3})+$/.test(s)) {
    s = s.replace(/\./g, "");
  }
  if (!/^\d*\.?\d+$|^\d+\.$/.test(s)) return null;
  const n = Number(s);
  if (!Number.isFinite(n)) return null;
  return neg ? -n : n;
}

/** "1.234,50" → 123450 kuruş. */
export function parseMoney(input: string | number | null | undefined): number | null {
  const n = parseDecimal(input);
  return n === null ? null : Math.round(n * 100);
}

/** Kuruş → input alanı için "1234,50". */
export function moneyInput(kurus: number | null | undefined): string {
  if (kurus === null || kurus === undefined) return "";
  return (kurus / 100).toFixed(2).replace(".", ",");
}

export function decimalInput(value: number | string | null | undefined): string {
  if (value === null || value === undefined || value === "") return "";
  const n = typeof value === "number" ? value : Number(value);
  if (!Number.isFinite(n)) return "";
  return String(n).replace(".", ",");
}

function toDate(value: string | Date | null | undefined): Date | null {
  if (!value) return null;
  if (value instanceof Date) return value;
  // Sunucu yerel saat döndürür (saat dilimi eki yok) → yerel saat olarak yorumlanır.
  const d = new Date(value.length === 10 ? `${value}T00:00:00` : value);
  return Number.isNaN(d.getTime()) ? null : d;
}

const p2 = (n: number) => String(n).padStart(2, "0");

/** "29.09.2026 14:05" */
export function dateTime(value: string | Date | null | undefined): string {
  const d = toDate(value);
  if (!d) return "—";
  return `${p2(d.getDate())}.${p2(d.getMonth() + 1)}.${d.getFullYear()} ${p2(d.getHours())}:${p2(d.getMinutes())}`;
}

/** "29.09.2026" */
export function dateOnly(value: string | Date | null | undefined): string {
  const d = toDate(value);
  if (!d) return "—";
  return `${p2(d.getDate())}.${p2(d.getMonth() + 1)}.${d.getFullYear()}`;
}

/** "14:05" */
export function timeOnly(value: string | Date | null | undefined): string {
  const d = toDate(value);
  if (!d) return "—";
  return `${p2(d.getHours())}:${p2(d.getMinutes())}`;
}

/** Yerel tarih → "2026-09-29" (API parametresi). */
export function isoDate(d: Date): string {
  return `${d.getFullYear()}-${p2(d.getMonth() + 1)}-${p2(d.getDate())}`;
}

export function addDays(d: Date, days: number): Date {
  const x = new Date(d);
  x.setDate(x.getDate() + days);
  return x;
}

/** Bugünden itibaren kaç gün önce: "bugün", "dün", "5 gün önce". */
export function relativeDays(value: string | null | undefined): string {
  const d = toDate(value);
  if (!d) return "—";
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const that = new Date(d);
  that.setHours(0, 0, 0, 0);
  const diff = Math.round((today.getTime() - that.getTime()) / 86_400_000);
  if (diff === 0) return "bugün";
  if (diff === 1) return "dün";
  if (diff < 0) return `${-diff} gün sonra`;
  return `${diff} gün önce`;
}

export const UNIT_SHORT: Record<UnitType, string> = { PIECE: "ad", METER: "m", SERVICE: "" };
export const UNIT_LABEL: Record<UnitType, string> = { PIECE: "Adet", METER: "Metre", SERVICE: "Hizmet" };

/** 12.5, METER → "12,5 m" · hizmette "—". */
export function qty(value: number | string | null | undefined, unit: UnitType = "PIECE"): string {
  if (unit === "SERVICE") return "—";
  if (value === null || value === undefined || value === "") return "—";
  const n = typeof value === "number" ? value : Number(value);
  const text = (n < 0 ? MINUS : "") + nfQty.format(Math.abs(n));
  return `${text} ${UNIT_SHORT[unit]}`.trim();
}

export function num(value: number | null | undefined, digits = 0): string {
  if (value === null || value === undefined) return "—";
  return new Intl.NumberFormat("tr-TR", { maximumFractionDigits: digits, minimumFractionDigits: digits }).format(value);
}

export function rate(value: number | string | null | undefined): string {
  if (value === null || value === undefined || value === "") return "—";
  return nfRate.format(Number(value));
}

/** 12.5 → "%12,5" */
export function pct(value: number | string | null | undefined): string {
  if (value === null || value === undefined || value === "") return "—";
  const n = Number(value);
  return `${n < 0 ? MINUS : ""}%${nfPct.format(Math.abs(n))}`;
}

/** Türkçe büyük harf (i → İ). */
export function trUpper(s: string): string {
  return s.toLocaleUpperCase("tr-TR");
}

export function phone(value: string | null | undefined): string {
  if (!value) return "—";
  const d = value.replace(/\D/g, "");
  if (d.length === 11) return `${d.slice(0, 4)} ${d.slice(4, 7)} ${d.slice(7, 9)} ${d.slice(9)}`;
  return value;
}

export function fileSize(bytes: number): string {
  if (bytes >= 1024 * 1024) return `${nfPct.format(bytes / 1024 / 1024)} MB`;
  return `${nf0.format(bytes / 1024)} KB`;
}
