/** API istemcisi. Oturum httpOnly çerezde; durum değiştiren isteklerde CSRF başlığı gönderilir. */

export class ApiError extends Error {
  code: string;
  status: number;
  fields: Record<string, string>;
  extra: Record<string, unknown>;

  constructor(status: number, code: string, message: string, fields: Record<string, string> = {}, extra: Record<string, unknown> = {}) {
    super(message);
    this.status = status;
    this.code = code;
    this.fields = fields;
    this.extra = extra;
  }
}

type Query = Record<string, string | number | boolean | null | undefined | (string | number)[]>;

export function buildQuery(query?: Query): string {
  if (!query) return "";
  const params = new URLSearchParams();
  for (const [k, v] of Object.entries(query)) {
    if (v === null || v === undefined || v === "") continue;
    if (Array.isArray(v)) v.forEach((x) => params.append(k, String(x)));
    else params.set(k, String(v));
  }
  const s = params.toString();
  return s ? `?${s}` : "";
}

async function parseError(res: Response): Promise<ApiError> {
  try {
    const body = await res.json();
    const e = body?.error ?? {};
    const { code, message, fields, ...extra } = e;
    return new ApiError(res.status, code ?? "HTTP_ERROR", message ?? "İstek işlenemedi.", fields ?? {}, extra);
  } catch {
    return new ApiError(res.status, "HTTP_ERROR", res.status >= 500 ? "Sunucu hatası." : "İstek işlenemedi.");
  }
}

export const UNAUTHORIZED_EVENT = "tezgah:unauthorized";

export async function request<T>(path: string, init: { method?: string; body?: unknown; query?: Query; form?: FormData } = {}): Promise<T> {
  const method = init.method ?? "GET";
  const headers: Record<string, string> = { Accept: "application/json" };
  let body: BodyInit | undefined;
  if (method !== "GET") headers["X-Tezgah"] = "1";
  if (init.form) {
    body = init.form;
  } else if (init.body !== undefined) {
    headers["Content-Type"] = "application/json";
    body = JSON.stringify(init.body);
  }
  let res: Response;
  try {
    res = await fetch(`/api${path}${buildQuery(init.query)}`, { method, headers, body, credentials: "same-origin" });
  } catch {
    throw new ApiError(0, "NETWORK", "Sunucuya ulaşılamıyor. Bağlantıyı kontrol edin.");
  }
  if (!res.ok) {
    const err = await parseError(res);
    if (res.status === 401 && !path.startsWith("/auth/")) window.dispatchEvent(new CustomEvent(UNAUTHORIZED_EVENT));
    throw err;
  }
  if (res.status === 204) return undefined as T;
  return (await res.json()) as T;
}

export const api = {
  get: <T>(path: string, query?: Query) => request<T>(path, { query }),
  post: <T>(path: string, body?: unknown) => request<T>(path, { method: "POST", body: body ?? {} }),
  patch: <T>(path: string, body: unknown) => request<T>(path, { method: "PATCH", body }),
  upload: <T>(path: string, file: File) => {
    const form = new FormData();
    form.append("file", file);
    return request<T>(path, { method: "POST", form });
  },
};

/** Dosya indirir (xlsx, yedek). */
export async function download(path: string, query?: Query, fallbackName = "tezgah-indirme"): Promise<void> {
  const res = await fetch(`/api${path}${buildQuery(query)}`, { credentials: "same-origin" });
  if (!res.ok) throw await parseError(res);
  const blob = await res.blob();
  const disposition = res.headers.get("Content-Disposition") ?? "";
  const match = /filename="?([^";]+)"?/.exec(disposition);
  const name = match?.[1] ?? fallbackName;
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = name;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

export function errorMessage(e: unknown): string {
  if (e instanceof ApiError) return e.message;
  if (e instanceof Error) return e.message;
  return "Beklenmeyen bir hata oluştu.";
}
