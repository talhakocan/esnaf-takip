import { describe, expect, it } from "vitest";
import {
  dateOnly,
  dateTime,
  isoDate,
  money,
  moneyInput,
  moneyPlain,
  moneyShort,
  parseDecimal,
  parseMoney,
  pct,
  phone,
  qty,
  rate,
  relativeDays,
  timeOnly,
  trUpper,
} from "./format";

describe("money", () => {
  it("formats kuruş as tr-TR currency", () => {
    expect(money(123450)).toBe("₺ 1.234,50");
    expect(money(0)).toBe("₺ 0,00");
    expect(money(5)).toBe("₺ 0,05");
    expect(money(-9900)).toBe("−₺ 99,00");
    expect(money(null)).toBe("—");
    expect(money(1500, { plusSign: true })).toBe("+₺ 15,00");
    expect(moneyPlain(216500)).toBe("2.165,00");
    expect(moneyShort(1_240_000)).toBe("₺ 12,4 B");
    expect(moneyInput(123450)).toBe("1234,50");
  });
});

describe("parse", () => {
  it("parses Turkish and dotted input", () => {
    expect(parseDecimal("1.234,50")).toBe(1234.5);
    expect(parseDecimal("12,5")).toBe(12.5);
    expect(parseDecimal("12.5")).toBe(12.5);
    expect(parseDecimal("1.234")).toBe(1234);
    expect(parseDecimal("₺ 99")).toBe(99);
    expect(parseDecimal("-3")).toBe(-3);
    expect(parseDecimal("abc")).toBeNull();
    expect(parseDecimal("")).toBeNull();
    expect(parseMoney("1.234,56")).toBe(123456);
    expect(parseMoney("0,1")).toBe(10);
  });
});

describe("dates", () => {
  it("formats local timestamps", () => {
    expect(dateTime("2026-09-29T14:05:33")).toBe("29.09.2026 14:05");
    expect(dateOnly("2026-01-02")).toBe("02.01.2026");
    expect(timeOnly("2026-09-29T09:07:00")).toBe("09:07");
    expect(dateTime(null)).toBe("—");
    expect(isoDate(new Date(2026, 8, 29))).toBe("2026-09-29");
    expect(relativeDays(isoDate(new Date()))).toBe("bugün");
  });
});

describe("quantities and misc", () => {
  it("formats quantities with units", () => {
    expect(qty(12.5, "METER")).toBe("12,5 m");
    expect(qty(3, "PIECE")).toBe("3 ad");
    expect(qty(-2, "PIECE")).toBe("−2 ad");
    expect(qty(4, "SERVICE")).toBe("—");
    expect(pct(12.5)).toBe("%12,5");
    expect(pct(-3)).toBe("−%3");
    expect(rate(41.2345)).toBe("41,2345");
    expect(phone("05321234567")).toBe("0532 123 45 67");
  });
  it("uppercases Turkish correctly", () => {
    expect(trUpper("iğne ışık")).toBe("İĞNE IŞIK");
  });
});
