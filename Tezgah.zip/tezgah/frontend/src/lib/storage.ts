/** Tarayıcı depolaması: her erişim try/catch içinde (gizli pencere, engellenmiş site verisi). */

function store(kind: "local" | "session"): Storage | null {
  try {
    return kind === "local" ? window.localStorage : window.sessionStorage;
  } catch {
    return null;
  }
}

export function readStore<T>(key: string, fallback: T, kind: "local" | "session" = "local"): T {
  try {
    const raw = store(kind)?.getItem(key);
    return raw === null || raw === undefined ? fallback : (JSON.parse(raw) as T);
  } catch {
    return fallback;
  }
}

export function writeStore(key: string, value: unknown, kind: "local" | "session" = "local"): void {
  try {
    if (value === undefined || value === null) store(kind)?.removeItem(key);
    else store(kind)?.setItem(key, JSON.stringify(value));
  } catch {
    /* depolama kullanılamıyor — sessizce yok say */
  }
}

export function readRaw(key: string): string | null {
  try {
    return store("local")?.getItem(key) ?? null;
  } catch {
    return null;
  }
}

export function writeRaw(key: string, value: string | null): void {
  try {
    if (value === null) store("local")?.removeItem(key);
    else store("local")?.setItem(key, value);
  } catch {
    /* yok say */
  }
}
