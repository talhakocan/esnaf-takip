import { useQuery } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { api } from "./api";
import type { Brand, Category, Location, Settings, Supplier, UserRow } from "./types";

export function useDebounced<T>(value: T, ms = 200): T {
  const [v, setV] = useState(value);
  useEffect(() => {
    const t = window.setTimeout(() => setV(value), ms);
    return () => window.clearTimeout(t);
  }, [value, ms]);
  return v;
}

const LONG = { staleTime: 5 * 60_000 };

export const useCategories = () => useQuery({ queryKey: ["categories"], queryFn: () => api.get<Category[]>("/categories"), ...LONG });
export const useBrands = () => useQuery({ queryKey: ["brands"], queryFn: () => api.get<Brand[]>("/brands"), ...LONG });
export const useLocations = () => useQuery({ queryKey: ["locations"], queryFn: () => api.get<Location[]>("/locations"), ...LONG });
export const useSuppliers = () => useQuery({ queryKey: ["suppliers", "active"], queryFn: () => api.get<Supplier[]>("/suppliers"), ...LONG });
export const useUsers = () => useQuery({ queryKey: ["users"], queryFn: () => api.get<UserRow[]>("/users"), ...LONG });
export const useSettings = () => useQuery({ queryKey: ["settings"], queryFn: () => api.get<Settings>("/settings"), ...LONG });

/** Arama parametresi: URL'deki ?q= ile eşlenmiş metin. */
export function useTitle(title: string): void {
  useEffect(() => {
    document.title = `${title} · Tezgâh`;
  }, [title]);
}
