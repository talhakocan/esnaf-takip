import { describe, expect, it } from "vitest";
import { applyRounding, cashSuggestions, computeFxPrice, marginPct } from "./pricing";

describe("pricing", () => {
  it("matches backend rounding rules", () => {
    expect(applyRounding(216537, "NONE")).toBe(216537);
    expect(applyRounding(216537, "NEAREST_1")).toBe(216500);
    expect(applyRounding(216537, "NEAREST_5")).toBe(216500);
    expect(applyRounding(216800, "NEAREST_5")).toBe(217000);
    expect(applyRounding(216537, "END_90")).toBe(216590);
    expect(applyRounding(216595, "END_90")).toBe(216690);
    expect(applyRounding(0, "END_90")).toBe(0);
  });
  it("computes FX-linked price like the spec example", () => {
    expect(computeFxPrice(42, 41.23, 25, "NEAREST_5")).toEqual([216458, 216500]);
  });
  it("computes margin excluding VAT", () => {
    expect(marginPct(12000, 5000, 20)).toBeCloseTo(50);
    expect(marginPct(0, 100, 20)).toBeNull();
  });
  it("suggests cash amounts", () => {
    expect(cashSuggestions(18625)).toEqual([18625, 19000, 20000, 50000]);
    expect(cashSuggestions(20000)).toEqual([20000, 50000]);
    expect(cashSuggestions(5000)[0]).toBe(5000);
  });
});
