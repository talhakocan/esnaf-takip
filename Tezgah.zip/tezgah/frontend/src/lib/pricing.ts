import type { RoundingRule } from "./types";

/** Backend'deki core/money.apply_rounding ile aynı kural (önizleme için). */
export function applyRounding(kurus: number, rule: RoundingRule): number {
  if (kurus <= 0) return Math.max(kurus, 0);
  switch (rule) {
    case "NONE":
      return kurus;
    case "NEAREST_1":
      return Math.round(kurus / 100) * 100;
    case "NEAREST_5":
      return Math.max(500, Math.round(kurus / 500) * 500);
    case "END_90":
      return Math.max(Math.ceil((kurus - 90) / 100), 0) * 100 + 90;
  }
}

/** alış × kur × (1 + marj) → [yuvarlanmamış, yuvarlanmış] kuruş. */
export function computeFxPrice(purchase: number, rate: number, markupPct: number, rule: RoundingRule): [number, number] {
  const raw = Math.round(purchase * rate * (1 + markupPct / 100) * 100);
  return [raw, applyRounding(raw, rule)];
}

/** Satış fiyatından (KDV dahil) ve maliyetten (KDV hariç) marj yüzdesi. */
export function marginPct(salePriceKurus: number, costKurus: number, vatRate: number): number | null {
  if (salePriceKurus <= 0) return null;
  const net = (salePriceKurus * 100) / (100 + vatRate);
  return ((net - costKurus) / net) * 100;
}

/** Nakit için hızlı tutar önerileri: tam tutar, üste yuvarla (10 TL), 100/200/500'lük banknotlarla ödeme. */
export function cashSuggestions(totalKurus: number): number[] {
  const out = new Set<number>([totalKurus]);
  const tl = totalKurus / 100;
  for (const step of [10, 100, 200, 500]) {
    const up = Math.ceil(tl / step) * step * 100;
    if (up > totalKurus) out.add(up);
  }
  return [...out].sort((a, b) => a - b).slice(0, 5);
}
