import { useEffect, useRef, useState } from "react";
import { Dialog } from "@/design/Dialog";

/** Kamerayla barkod okuma (@zxing/browser). Tarayıcılar yalnızca HTTPS veya localhost'ta kamera izni verir. */
export function CameraScanner({ open, onOpenChange, onCode }: { open: boolean; onOpenChange: (v: boolean) => void; onCode: (code: string) => void }) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [error, setError] = useState<string | null>(null);
  const [videoEl, setVideoEl] = useState<HTMLVideoElement | null>(null);

  useEffect(() => {
    if (!open || !videoEl) return;
    let stop: (() => void) | null = null;
    let cancelled = false;
    setError(null);
    if (!window.isSecureContext || !navigator.mediaDevices?.getUserMedia) {
      setError("Kamera yalnızca HTTPS veya localhost üzerinden kullanılabilir. USB barkod okuyucu her durumda çalışır.");
      return;
    }
    (async () => {
      try {
        const { BrowserMultiFormatReader } = await import("@zxing/browser");
        const reader = new BrowserMultiFormatReader();
        const controls = await reader.decodeFromConstraints({ video: { facingMode: "environment" } }, videoEl, (result) => {
          if (result && !cancelled) {
            cancelled = true;
            controls.stop();
            onCode(result.getText());
            onOpenChange(false);
          }
        });
        stop = () => controls.stop();
        if (cancelled) stop();
      } catch {
        setError("Kameraya erişilemedi. Tarayıcı izinlerini kontrol edin.");
      }
    })();
    return () => {
      cancelled = true;
      stop?.();
    };
  }, [open, videoEl, onCode, onOpenChange]);

  return (
    <Dialog open={open} onOpenChange={onOpenChange} title="Kamerayla barkod oku" width={520}>
      {error ? (
        <p className="text-13 text-crit">{error}</p>
      ) : (
        <div className="flex flex-col gap-2">
          <video
            ref={(el) => {
              videoRef.current = el;
              setVideoEl(el);
            }}
            className="w-full aspect-video bg-ink object-cover"
            muted
            playsInline
          />
          <p className="text-12 text-ink-2">Barkodu çerçevenin ortasına getirin; okununca otomatik eklenir.</p>
        </div>
      )}
    </Dialog>
  );
}
