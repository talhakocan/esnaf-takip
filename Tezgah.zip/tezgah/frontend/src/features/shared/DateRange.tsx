import { addDays, isoDate } from "@/lib/format";
import { cx } from "@/design/cx";

export type Preset = "today" | "week" | "month" | "lastMonth" | "last30" | "custom";

export const PRESET_TR: Record<Preset, string> = {
  today: "Bugün",
  week: "Bu hafta",
  month: "Bu ay",
  lastMonth: "Geçen ay",
  last30: "Son 30 gün",
  custom: "Özel",
};

export function presetRange(p: Preset): { from: string; to: string } {
  const now = new Date();
  const today = isoDate(now);
  switch (p) {
    case "today":
      return { from: today, to: today };
    case "week": {
      const day = (now.getDay() + 6) % 7;
      return { from: isoDate(addDays(now, -day)), to: today };
    }
    case "month":
      return { from: isoDate(new Date(now.getFullYear(), now.getMonth(), 1)), to: today };
    case "lastMonth":
      return {
        from: isoDate(new Date(now.getFullYear(), now.getMonth() - 1, 1)),
        to: isoDate(new Date(now.getFullYear(), now.getMonth(), 0)),
      };
    default:
      return { from: isoDate(addDays(now, -29)), to: today };
  }
}

/** Tarih aralığı seçici: hazır aralıklar + özel tarih. */
export function DateRangePicker({
  preset,
  from,
  to,
  onChange,
  presets = ["today", "week", "month", "lastMonth", "last30", "custom"],
}: {
  preset: Preset;
  from: string;
  to: string;
  onChange: (v: { preset: Preset; from: string; to: string }) => void;
  presets?: Preset[];
}) {
  return (
    <div className="flex flex-wrap items-center gap-2">
      <div className="inline-flex border border-rule-strong rounded-ctl overflow-hidden" role="group" aria-label="Tarih aralığı">
        {presets.map((p) => (
          <button
            key={p}
            type="button"
            aria-pressed={preset === p}
            onClick={() => onChange(p === "custom" ? { preset: p, from, to } : { preset: p, ...presetRange(p) })}
            className={cx(
              "h-8 px-2.5 text-12 border-r border-rule-strong last:border-r-0 cursor-pointer",
              preset === p ? "bg-ink text-paper" : "bg-surface text-ink-2 hover:bg-surface-2",
            )}
          >
            {PRESET_TR[p]}
          </button>
        ))}
      </div>
      {preset === "custom" && (
        <span className="inline-flex items-center gap-1.5">
          <input
            type="date"
            aria-label="Başlangıç"
            value={from}
            onChange={(e) => onChange({ preset, from: e.target.value, to })}
            className="h-8 px-2 border border-rule-strong rounded-ctl bg-surface num text-12"
          />
          <span className="text-ink-3">–</span>
          <input
            type="date"
            aria-label="Bitiş"
            value={to}
            onChange={(e) => onChange({ preset, from, to: e.target.value })}
            className="h-8 px-2 border border-rule-strong rounded-ctl bg-surface num text-12"
          />
        </span>
      )}
    </div>
  );
}
