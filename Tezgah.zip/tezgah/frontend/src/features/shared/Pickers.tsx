import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Plus, Search, UserRound } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { Button } from "@/design/Button";
import { cx } from "@/design/cx";
import { Dialog } from "@/design/Dialog";
import { Checkbox, Field, Input } from "@/design/Input";
import { useToast } from "@/design/Toast";
import { ApiError, api } from "@/lib/api";
import { money, phone as fmtPhone, qty } from "@/lib/format";
import { useDebounced } from "@/lib/hooks";
import type { Customer, Product } from "@/lib/types";

/** Ürün arama kutusu (açılır liste). Barkod/SKU tam eşleşmesi Enter ile seçilir. */
export function ProductSearch({
  onPick,
  placeholder = "Ürün ara: ad, SKU veya barkod…",
  autoFocus,
  filter,
  className,
}: {
  onPick: (p: Product) => void;
  placeholder?: string;
  autoFocus?: boolean;
  filter?: (p: Product) => boolean;
  className?: string;
}) {
  const [q, setQ] = useState("");
  const [open, setOpen] = useState(false);
  const [idx, setIdx] = useState(0);
  const dq = useDebounced(q.trim(), 150);
  const res = useQuery({
    queryKey: ["product-search", dq],
    queryFn: () => api.get<Product[]>("/products", { q: dq }),
    enabled: dq.length >= 2,
    staleTime: 15_000,
  });
  const items = (res.data ?? []).filter((p) => (filter ? filter(p) : true)).slice(0, 12);
  useEffect(() => setIdx(0), [dq]);
  const pick = (p: Product) => {
    onPick(p);
    setQ("");
    setOpen(false);
  };
  const onKey = async (e: React.KeyboardEvent) => {
    if (e.key === "ArrowDown") {
      e.preventDefault();
      setIdx((i) => Math.min(i + 1, items.length - 1));
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      setIdx((i) => Math.max(i - 1, 0));
    } else if (e.key === "Enter") {
      e.preventDefault();
      if (items[idx] && open) return pick(items[idx]);
      const code = q.trim();
      if (!code) return;
      try {
        const hit = await api.get<{ product: Product }>("/products/lookup", { code });
        if (!filter || filter(hit.product)) pick(hit.product);
      } catch {
        setOpen(true);
      }
    } else if (e.key === "Escape") {
      setOpen(false);
    }
  };
  return (
    <div className={cx("relative", className)}>
      <Search size={14} strokeWidth={1.5} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-ink-3 pointer-events-none" aria-hidden />
      <Input
        value={q}
        onChange={(e) => {
          setQ(e.target.value);
          setOpen(true);
        }}
        onFocus={() => setOpen(true)}
        onBlur={() => window.setTimeout(() => setOpen(false), 150)}
        onKeyDown={onKey}
        placeholder={placeholder}
        autoFocus={autoFocus}
        className="pl-8"
        role="combobox"
        aria-expanded={open && items.length > 0}
        aria-autocomplete="list"
      />
      {open && dq.length >= 2 && (
        <ul className="absolute z-30 mt-1 w-full max-h-72 overflow-y-auto scroll-thin bg-surface border border-rule shadow-pop" role="listbox">
          {items.length === 0 && <li className="px-3 py-2 text-13 text-ink-2">{res.isFetching ? "Aranıyor…" : "Sonuç yok."}</li>}
          {items.map((p, i) => (
            <li
              key={p.id}
              role="option"
              aria-selected={i === idx}
              onMouseDown={(e) => {
                e.preventDefault();
                pick(p);
              }}
              onMouseEnter={() => setIdx(i)}
              className={cx("flex items-center gap-3 px-3 h-9 text-13 cursor-pointer", i === idx && "bg-surface-2 shadow-[inset_2px_0_0_var(--signal)]")}
            >
              <span className="num text-12 text-ink-3 w-24 shrink-0 truncate">{p.sku}</span>
              <span className="truncate flex-1">{p.name}</span>
              <span className="num text-12 text-ink-2">{qty(p.stock_qty, p.unit_type)}</span>
              <span className="num text-12 w-24 text-right">{money(p.sale_price_kurus)}</span>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

/** Müşteri seçme dialog'u: arama + hızlı ekleme. */
export function CustomerPickerDialog({
  open,
  onOpenChange,
  onPick,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  onPick: (c: Customer) => void;
}) {
  const [q, setQ] = useState("");
  const [idx, setIdx] = useState(0);
  const [adding, setAdding] = useState(false);
  const dq = useDebounced(q.trim(), 150);
  const inputRef = useRef<HTMLInputElement>(null);
  const res = useQuery({ queryKey: ["customers", "pick", dq], queryFn: () => api.get<Customer[]>("/customers", { q: dq || undefined }), enabled: open });
  const items = (res.data ?? []).slice(0, 30);
  useEffect(() => {
    if (open) {
      setQ("");
      setAdding(false);
    }
  }, [open]);
  useEffect(() => setIdx(0), [dq]);
  const pick = (c: Customer) => {
    onPick(c);
    onOpenChange(false);
  };
  return (
    <Dialog open={open} onOpenChange={onOpenChange} title={adding ? "Yeni müşteri" : "Müşteri seç"} width={560}>
      {adding ? (
        <QuickCustomerForm
          initialName={q}
          onDone={(c) => pick(c)}
          onCancel={() => {
            setAdding(false);
            window.setTimeout(() => inputRef.current?.focus(), 30);
          }}
        />
      ) : (
        <div className="flex flex-col gap-3">
          <div className="flex gap-2">
            <Input
              ref={inputRef}
              autoFocus
              placeholder="Ad veya telefon…"
              value={q}
              onChange={(e) => setQ(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "ArrowDown") {
                  e.preventDefault();
                  setIdx((i) => Math.min(i + 1, items.length - 1));
                } else if (e.key === "ArrowUp") {
                  e.preventDefault();
                  setIdx((i) => Math.max(i - 1, 0));
                } else if (e.key === "Enter" && items[idx]) {
                  e.preventDefault();
                  pick(items[idx]);
                }
              }}
            />
            <Button icon={Plus} onClick={() => setAdding(true)}>
              Yeni müşteri
            </Button>
          </div>
          <ul className="border border-rule max-h-80 overflow-y-auto scroll-thin" role="listbox" aria-label="Müşteriler">
            {items.length === 0 && <li className="px-3 py-3 text-13 text-ink-2">{res.isLoading ? "Yükleniyor…" : "Müşteri bulunamadı."}</li>}
            {items.map((c, i) => (
              <li
                key={c.id}
                role="option"
                aria-selected={i === idx}
                onClick={() => pick(c)}
                onMouseEnter={() => setIdx(i)}
                className={cx("flex items-center gap-3 px-3 h-9 text-13 cursor-pointer border-b border-rule last:border-b-0", i === idx && "bg-surface-2")}
              >
                <UserRound size={14} strokeWidth={1.5} className="text-ink-3" aria-hidden />
                <span className="flex-1 truncate">{c.full_name}</span>
                <span className="num text-12 text-ink-3">{fmtPhone(c.phone)}</span>
                <span className={cx("num text-12 w-28 text-right", c.balance > 0 ? "text-crit" : "text-ink-3")}>{c.balance ? money(c.balance) : "—"}</span>
              </li>
            ))}
          </ul>
        </div>
      )}
    </Dialog>
  );
}

export function QuickCustomerForm({ initialName = "", onDone, onCancel }: { initialName?: string; onDone: (c: Customer) => void; onCancel: () => void }) {
  const qc = useQueryClient();
  const toast = useToast();
  const [name, setName] = useState(/^\d/.test(initialName) ? "" : initialName);
  const [tel, setTel] = useState(/^\d/.test(initialName) ? initialName : "");
  const [kvkk, setKvkk] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [busy, setBusy] = useState(false);
  const save = async () => {
    setBusy(true);
    try {
      const c = await api.post<Customer>("/customers", { full_name: name, phone: tel, kvkk_consent: kvkk });
      await qc.invalidateQueries({ queryKey: ["customers"] });
      toast({ title: "Müşteri eklendi", message: c.full_name });
      onDone(c);
    } catch (e) {
      if (e instanceof ApiError) setErrors({ ...e.fields, _: e.message });
    } finally {
      setBusy(false);
    }
  };
  return (
    <form
      className="flex flex-col gap-3"
      onSubmit={(e) => {
        e.preventDefault();
        void save();
      }}
    >
      <Field label="Ad soyad / firma" error={errors.full_name} required>
        {(id) => <Input id={id} autoFocus value={name} onChange={(e) => setName(e.target.value)} />}
      </Field>
      <Field label="Telefon" error={errors.phone} hint="05xx xxx xx xx">
        {(id) => <Input id={id} mono inputMode="tel" value={tel} onChange={(e) => setTel(e.target.value)} />}
      </Field>
      <Checkbox label="KVKK aydınlatma metni müşteriye okundu, onay alındı" checked={kvkk} onChange={(e) => setKvkk(e.target.checked)} />
      {errors._ && !errors.full_name && !errors.phone && <p className="text-12 text-crit">{errors._}</p>}
      <div className="flex justify-end gap-2">
        <Button variant="ghost" onClick={onCancel}>
          Geri
        </Button>
        <Button type="submit" variant="primary" loading={busy} disabled={name.trim().length < 2}>
          Kaydet ve seç
        </Button>
      </div>
    </form>
  );
}
