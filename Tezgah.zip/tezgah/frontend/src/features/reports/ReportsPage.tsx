import { useQuery } from "@tanstack/react-query";
import { Download, Printer } from "lucide-react";
import { type ReactNode, useEffect, useMemo, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { useCan } from "@/app/auth";
import { Button } from "@/design/Button";
import { BarList, LineSeries } from "@/design/Charts";
import { cx } from "@/design/cx";
import { type ColumnDef, DataTable } from "@/design/DataTable";
import { EmptyState, ErrorState, Loading } from "@/design/Feedback";
import { Money } from "@/design/Indicators";
import { Input } from "@/design/Input";
import { SectionLabel, SideNav } from "@/design/Page";
import { useToast } from "@/design/Toast";
import { api, download, errorMessage } from "@/lib/api";
import { dateOnly, dateTime, isoDate, money, num, pct } from "@/lib/format";
import { useSettings, useTitle } from "@/lib/hooks";
import { printNode } from "@/lib/print";
import type { Report, ReportColumn, ReportTable, Settings } from "@/lib/types";
import { DateRangePicker, type Preset, presetRange } from "../shared/DateRange";

interface Def {
  key: string;
  api: string;
  label: string;
  finance?: boolean;
  range?: "range" | "day" | "days" | "none";
  group?: boolean;
}

const REPORTS: Def[] = [
  { key: "satis", api: "sales", label: "Satış & Kâr", finance: true, range: "range", group: true },
  { key: "kasa", api: "cashbox", label: "Gün sonu kasa", range: "day" },
  { key: "cok-satanlar", api: "top-products", label: "En çok satanlar", range: "range" },
  { key: "olu-stok", api: "dead-stock", label: "Ölü stok", finance: true, range: "days" },
  { key: "abc", api: "abc", label: "ABC analizi", finance: true, range: "range" },
  { key: "stok-degeri", api: "stock-value", label: "Stok değeri", finance: true, range: "none" },
  { key: "personel", api: "staff", label: "Personel", finance: true, range: "range" },
  { key: "servis", api: "service", label: "Servis", range: "range" },
  { key: "garanti", api: "warranty", label: "Garanti bitişleri", range: "days" },
];

function formatCell(v: unknown, type: ReportColumn["type"]): ReactNode {
  if (v === null || v === undefined || v === "") return <span className="text-ink-3">—</span>;
  switch (type) {
    case "money":
      return <Money value={Number(v)} />;
    case "int":
      return <span className="num">{num(Number(v))}</span>;
    case "qty":
      return <span className="num">{num(Number(v), Number.isInteger(Number(v)) ? 0 : 2)}</span>;
    case "pct":
      return <span className="num">{pct(Number(v))}</span>;
    case "date":
      return <span className="num">{dateOnly(String(v))}</span>;
    case "datetime":
      return <span className="num">{dateTime(String(v))}</span>;
    case "code":
      return <span className="num text-12">{String(v)}</span>;
    default:
      return String(v);
  }
}

function plain(v: unknown, type: ReportColumn["type"]): string | number {
  if (v === null || v === undefined) return "";
  if (type === "money") return (Number(v) / 100).toFixed(2);
  if (type === "date") return dateOnly(String(v));
  if (type === "datetime") return dateTime(String(v));
  return v as string | number;
}

function ReportTableView({ table, onRow }: { table: ReportTable; onRow: (link: string) => void }) {
  const columns = useMemo<ColumnDef<Record<string, unknown>, any>[]>(
    () =>
      table.columns.map((c) => ({
        id: c.key,
        accessorFn: (r) => r[c.key],
        header: c.label,
        meta: {
          align: ["money", "int", "qty", "pct"].includes(c.type) ? ("right" as const) : undefined,
          exportValue: (r: Record<string, unknown>) => plain(r[c.key], c.type),
        },
        cell: ({ getValue }) => formatCell(getValue(), c.type),
      })),
    [table],
  );
  const barCol = table.columns.find((c) => c.key === table.bar);
  const labelCol = table.columns.find((c) => c.type === "text" || c.key === "name") ?? table.columns[0];
  return (
    <section className="bg-surface border-y border-rule">
      <SectionLabel>{table.title}</SectionLabel>
      {barCol && table.rows.length > 0 && (
        <BarList
          className="border-b border-rule"
          rows={table.rows.slice(0, 10).map((r) => ({ label: String(r[labelCol.key] ?? "—"), value: Number(r[barCol.key] ?? 0) }))}
          format={(v) => (barCol.type === "money" ? money(v) : num(v))}
        />
      )}
      <DataTable
        data={table.rows}
        columns={columns}
        className="border-y-0"
        exportName={`rapor-${table.key}`}
        hideFooter={table.rows.length <= 50}
        maxHeight="none"
        onRowClick={table.rows.some((r) => r.link) ? (r) => r.link && onRow(String(r.link)) : undefined}
        empty={<EmptyState icon="circuit" title="Bu aralıkta veri yok." />}
      />
      {table.totals && (
        <div className="flex flex-wrap justify-end gap-x-6 gap-y-1 px-4 md:px-6 py-2 border-t border-rule-strong text-13">
          {table.columns
            .filter((c) => table.totals![c.key] !== undefined && c.type !== "text")
            .map((c) => (
              <span key={c.key} className="flex gap-2">
                <span className="text-ink-3">{c.label}</span>
                {formatCell(table.totals![c.key], c.type)}
              </span>
            ))}
        </div>
      )}
    </section>
  );
}

function ReportPrint({ report, settings }: { report: Report; settings: Settings }) {
  const cell = { padding: "3px 5px", borderBottom: "1px solid #999", fontSize: "9pt" } as const;
  return (
    <div style={{ fontFamily: "'IBM Plex Sans'", color: "#000" }}>
      <div style={{ borderBottom: "2px solid #000", paddingBottom: 6, marginBottom: 8, display: "flex", justifyContent: "space-between" }}>
        <div style={{ fontFamily: "'IBM Plex Sans Condensed'", fontWeight: 600, fontSize: "14pt" }}>{report.title}</div>
        <div style={{ fontFamily: "'IBM Plex Mono'", fontSize: "9pt", textAlign: "right" }}>
          {settings.shop_name}
          <br />
          {report.range ? `${dateOnly(report.range.from)} – ${dateOnly(report.range.to)}` : dateOnly(new Date())}
        </div>
      </div>
      {report.kpis && (
        <div style={{ display: "flex", flexWrap: "wrap", gap: 18, marginBottom: 10 }}>
          {report.kpis.map((k) => (
            <div key={k.label}>
              <div style={{ fontSize: "8pt", textTransform: "uppercase" }}>{k.label}</div>
              <div style={{ fontFamily: "'IBM Plex Mono'", fontSize: "12pt" }}>
                {k.type === "money" ? money(Number(k.value)) : k.type === "pct" ? pct(k.value as number) : String(k.value ?? "—")}
              </div>
            </div>
          ))}
        </div>
      )}
      {report.tables.map((t) => (
        <div key={t.key} style={{ marginBottom: 12, breakInside: "avoid-page" }}>
          <div style={{ fontWeight: 600, margin: "6px 0 3px" }}>{t.title}</div>
          <table style={{ width: "100%", borderCollapse: "collapse" }}>
            <thead>
              <tr>
                {t.columns.map((c) => (
                  <th key={c.key} style={{ ...cell, textAlign: ["money", "int", "qty", "pct"].includes(c.type) ? "right" : "left" }}>
                    {c.label}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {t.rows.map((r, i) => (
                <tr key={i}>
                  {t.columns.map((c) => (
                    <td key={c.key} style={{ ...cell, textAlign: ["money", "int", "qty", "pct"].includes(c.type) ? "right" : "left", fontFamily: c.type === "text" ? undefined : "'IBM Plex Mono'" }}>
                      {c.type === "money" ? money(Number(r[c.key] ?? 0)) : c.type === "pct" ? pct(r[c.key] as number) : String(plain(r[c.key], c.type))}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ))}
      {report.notes?.map((n) => (
        <p key={n} style={{ fontSize: "8.5pt" }}>
          {n}
        </p>
      ))}
    </div>
  );
}

export default function ReportsPage() {
  const { rapor = "satis" } = useParams();
  const navigate = useNavigate();
  const toast = useToast();
  const settings = useSettings();
  const finance = useCan("report.finance");
  const available = REPORTS.filter((r) => finance || !r.finance);
  const def = available.find((r) => r.key === rapor) ?? available[0];
  useTitle(`Rapor · ${def.label}`);
  const [range, setRange] = useState<{ preset: Preset; from: string; to: string }>({ preset: "last30", ...presetRange("last30") });
  const [day, setDay] = useState(isoDate(new Date()));
  const [days, setDays] = useState(def.key === "garanti" ? "30" : "90");
  const [group, setGroup] = useState<"day" | "week" | "month">("day");
  useEffect(() => setDays(def.key === "garanti" ? "30" : "90"), [def.key]);

  const params = useMemo(() => {
    const p: Record<string, string> = {};
    if (def.range === "range") Object.assign(p, { from: range.from, to: range.to });
    if (def.range === "day") Object.assign(p, { from: day, to: day });
    if (def.range === "days") p.days = days;
    if (def.group) p.group = group;
    return p;
  }, [def, range, day, days, group]);

  const q = useQuery({ queryKey: ["report", def.api, params], queryFn: () => api.get<Report>(`/reports/${def.api}`, params) });
  const r = q.data;

  return (
    <div className="grid md:grid-cols-[200px_1fr] min-h-full">
      <aside className="md:border-r border-rule bg-surface md:py-4 print:hidden">
        <div className="label-caps px-3 pb-2 hidden md:block">Raporlar</div>
        <SideNav items={available.map((x) => ({ key: x.key, label: x.label }))} active={def.key} onSelect={(k) => navigate(`/raporlar/${k}`)} />
      </aside>
      <div className="min-w-0 pb-10">
        <div className="flex flex-wrap items-end justify-between gap-3 px-4 md:px-6 pt-5 pb-3">
          <div>
            <h1 className="font-cond text-20 font-semibold">{r?.title ?? def.label}</h1>
            {r?.range && def.range === "range" && (
              <div className="num text-12 text-ink-3">
                {dateOnly(r.range.from)} – {dateOnly(r.range.to)}
              </div>
            )}
          </div>
          <div className="flex gap-2">
            <Button icon={Printer} onClick={() => r && settings.data && printNode(<ReportPrint report={r} settings={settings.data} />, "a4")} disabled={!r}>
              Yazdır
            </Button>
            <Button
              icon={Download}
              onClick={() => download(`/reports/${def.api}`, { ...params, format: "xlsx" }).catch((e) => toast({ tone: "crit", title: "İndirilemedi", message: errorMessage(e) }))}
            >
              Excel
            </Button>
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-3 px-4 md:px-6 py-2 border-y border-rule bg-surface">
          {def.range === "range" && <DateRangePicker {...range} onChange={setRange} />}
          {def.range === "day" && (
            <label className="flex items-center gap-2 text-13">
              Gün
              <Input type="date" mono className="w-40" value={day} onChange={(e) => setDay(e.target.value)} />
            </label>
          )}
          {def.range === "days" && (
            <label className="flex items-center gap-2 text-13">
              {def.key === "garanti" ? "Önümüzdeki" : "Hareketsiz"}
              <Input mono align="right" className="w-20" value={days} onChange={(e) => setDays(e.target.value.replace(/\D/g, "") || "1")} />
              gün
            </label>
          )}
          {def.group && (
            <div className="inline-flex border border-rule-strong rounded-ctl overflow-hidden" role="group" aria-label="Gruplama">
              {(["day", "week", "month"] as const).map((g) => (
                <button
                  key={g}
                  type="button"
                  aria-pressed={group === g}
                  onClick={() => setGroup(g)}
                  className={cx("h-8 px-2.5 text-12 border-r border-rule-strong last:border-r-0 cursor-pointer", group === g ? "bg-ink text-paper" : "bg-surface text-ink-2 hover:bg-surface-2")}
                >
                  {{ day: "Günlük", week: "Haftalık", month: "Aylık" }[g]}
                </button>
              ))}
            </div>
          )}
          {def.range === "none" && <span className="text-13 text-ink-2">Anlık değer</span>}
        </div>

        {q.isLoading ? (
          <Loading />
        ) : q.isError || !r ? (
          <ErrorState error={q.error} onRetry={() => q.refetch()} />
        ) : (
          <div className="flex flex-col gap-4 mt-4">
            {r.kpis && r.kpis.length > 0 && (
              <div className="grid grid-cols-2 md:grid-cols-4 xl:grid-cols-6 bg-surface border-y border-rule">
                {r.kpis.map((k, i) => (
                  <div key={k.label} className={cx("px-4 md:px-5 py-3 border-rule", i > 0 && "border-l")}>
                    <div className="label-caps" lang="tr">
                      {k.label.toLocaleUpperCase("tr-TR")}
                    </div>
                    <div className="num text-20 mt-1">
                      {k.type === "money" ? money(Number(k.value)) : k.type === "int" ? num(Number(k.value)) : k.type === "pct" ? pct(k.value as number) : String(k.value ?? "—")}
                    </div>
                  </div>
                ))}
              </div>
            )}
            {r.chart && r.chart.rows.length > 0 && (
              <section className="bg-surface border-y border-rule">
                <SectionLabel>{r.chart.type === "pareto" ? "Kümülatif ciro payı" : "Seyir"}</SectionLabel>
                <LineSeries
                  data={r.chart.rows}
                  x={r.chart.x}
                  series={r.chart.series.map((s, i) => ({ ...s, accent: i === 1 }))}
                  kind={r.chart.type === "pareto" ? "pct" : "money"}
                  height={240}
                />
              </section>
            )}
            {r.tables.map((t) => (
              <ReportTableView key={t.key} table={t} onRow={(link) => navigate(link)} />
            ))}
            {r.notes?.map((n) => (
              <p key={n} className="px-4 md:px-6 text-12 text-ink-3">
                {n}
              </p>
            ))}
            {def.key === "kasa" && (
              <p className="px-4 md:px-6 text-12 text-ink-3">
                Satış detayları için <Link to="/satislar" className="underline">Satışlar</Link> ekranını kullanın.
              </p>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
