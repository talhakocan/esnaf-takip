import { useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { Button } from "@/design/Button";
import { Dialog } from "@/design/Dialog";
import { Checkbox, Field, Input, Select, Textarea } from "@/design/Input";
import { useToast } from "@/design/Toast";
import { ApiError, api } from "@/lib/api";
import type { Supplier } from "@/lib/types";

export function SupplierDialog({ supplier, onClose, onSaved }: { supplier: Supplier | null; onClose: () => void; onSaved: (s: Supplier) => void }) {
  const qc = useQueryClient();
  const toast = useToast();
  const [v, setV] = useState({
    name: supplier?.name ?? "",
    contact: supplier?.contact ?? "",
    phone: supplier?.phone ?? "",
    email: supplier?.email ?? "",
    currency: supplier?.currency ?? "TRY",
    note: supplier?.note ?? "",
    is_active: supplier?.is_active ?? true,
  });
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const save = async () => {
    setBusy(true);
    try {
      const s = supplier ? await api.patch<Supplier>(`/suppliers/${supplier.id}`, v) : await api.post<Supplier>("/suppliers", v);
      await qc.invalidateQueries({ queryKey: ["suppliers"] });
      await qc.invalidateQueries({ queryKey: ["supplier", String(s.id)] });
      toast({ title: supplier ? "Tedarikçi güncellendi" : "Tedarikçi eklendi", message: s.name });
      onSaved(s);
    } catch (e) {
      setError(e instanceof ApiError ? e.message : "Kaydedilemedi.");
    } finally {
      setBusy(false);
    }
  };
  return (
    <Dialog
      open
      onOpenChange={(o) => !o && onClose()}
      title={supplier ? "Tedarikçiyi düzenle" : "Yeni tedarikçi"}
      width={520}
      footer={
        <>
          <Button variant="ghost" onClick={onClose}>
            Vazgeç
          </Button>
          <Button variant="primary" onClick={save} loading={busy} disabled={v.name.trim().length < 2}>
            Kaydet
          </Button>
        </>
      }
    >
      <div className="grid sm:grid-cols-2 gap-3">
        <Field label="Firma adı" required className="sm:col-span-2" error={error ?? undefined}>
          {(id) => <Input id={id} autoFocus value={v.name} onChange={(e) => setV({ ...v, name: e.target.value })} />}
        </Field>
        <Field label="Yetkili">{(id) => <Input id={id} value={v.contact} onChange={(e) => setV({ ...v, contact: e.target.value })} />}</Field>
        <Field label="Telefon">{(id) => <Input id={id} mono value={v.phone} onChange={(e) => setV({ ...v, phone: e.target.value })} />}</Field>
        <Field label="E-posta">{(id) => <Input id={id} value={v.email} onChange={(e) => setV({ ...v, email: e.target.value })} />}</Field>
        <Field label="Çalışma para birimi">
          {(id) => (
            <Select id={id} value={v.currency} onChange={(e) => setV({ ...v, currency: e.target.value as Supplier["currency"] })}>
              <option value="TRY">TRY</option>
              <option value="USD">USD</option>
              <option value="EUR">EUR</option>
            </Select>
          )}
        </Field>
        <Field label="Not" className="sm:col-span-2">
          {(id) => <Textarea id={id} rows={2} value={v.note} onChange={(e) => setV({ ...v, note: e.target.value })} />}
        </Field>
        {supplier && <Checkbox label="Aktif" checked={v.is_active} onChange={(e) => setV({ ...v, is_active: e.target.checked })} />}
      </div>
    </Dialog>
  );
}
