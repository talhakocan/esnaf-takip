import { useQuery } from "@tanstack/react-query";
import { Plus } from "lucide-react";
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useCan } from "@/app/auth";
import { Button } from "@/design/Button";
import { type ColumnDef, DataTable } from "@/design/DataTable";
import { EmptyState, ErrorState, Loading } from "@/design/Feedback";
import { Tag } from "@/design/Indicators";
import { PageHeader } from "@/design/Page";
import { api } from "@/lib/api";
import { dateOnly, num, phone } from "@/lib/format";
import { useTitle } from "@/lib/hooks";
import type { Supplier } from "@/lib/types";
import { SupplierDialog } from "./SupplierDialog";

export default function SuppliersPage() {
  useTitle("Tedarikçiler");
  const navigate = useNavigate();
  const canWrite = useCan("supplier.write");
  const [adding, setAdding] = useState(false);
  const q = useQuery({ queryKey: ["suppliers", "all"], queryFn: () => api.get<Supplier[]>("/suppliers", { active: "all" }) });
  const columns: ColumnDef<Supplier, any>[] = [
    { accessorKey: "name", header: "Tedarikçi", cell: ({ row }) => <span className="font-medium">{row.original.name}</span> },
    { accessorKey: "contact", header: "Yetkili" },
    { accessorKey: "phone", header: "Telefon", meta: { mono: true, className: "text-12" }, cell: ({ getValue }) => phone(getValue()) },
    { accessorKey: "currency", header: "Para birimi", cell: ({ getValue }) => <Tag>{getValue()}</Tag> },
    { accessorKey: "product_count", header: "Ürün", meta: { align: "right", mono: true } },
    { accessorKey: "order_count", header: "Sipariş", meta: { align: "right", mono: true } },
    { accessorKey: "open_orders", header: "Açık", meta: { align: "right", mono: true } },
    {
      accessorKey: "avg_lead_days",
      header: "Ort. teslim",
      meta: { align: "right", mono: true },
      cell: ({ getValue }) => (getValue() === null || getValue() === undefined ? "—" : `${num(getValue(), 1)} gün`),
    },
    { accessorKey: "last_order_at", header: "Son sipariş", meta: { mono: true, className: "text-12" }, cell: ({ getValue }) => dateOnly(getValue()) },
  ];
  return (
    <div>
      <PageHeader
        title="Tedarikçiler"
        count={q.data?.length}
        actions={
          canWrite && (
            <Button variant="primary" icon={Plus} onClick={() => setAdding(true)}>
              Yeni tedarikçi
            </Button>
          )
        }
      />
      {q.isLoading ? (
        <Loading />
      ) : q.isError ? (
        <ErrorState error={q.error} onRetry={() => q.refetch()} />
      ) : (
        <DataTable
          data={q.data ?? []}
          columns={columns}
          onRowClick={(s) => navigate(`/tedarikciler/${s.id}`)}
          exportName="tezgah-tedarikciler"
          rowClassName={(s) => (!s.is_active ? "opacity-60" : undefined)}
          empty={<EmptyState icon="connector" title="Tedarikçi eklenmemiş." />}
        />
      )}
      {adding && <SupplierDialog supplier={null} onClose={() => setAdding(false)} onSaved={(s) => navigate(`/tedarikciler/${s.id}`)} />}
    </div>
  );
}
