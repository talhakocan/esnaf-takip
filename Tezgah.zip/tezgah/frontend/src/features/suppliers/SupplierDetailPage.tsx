import { useQuery } from "@tanstack/react-query";
import { ClipboardList, Pencil, Plus } from "lucide-react";
import { useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { useCan } from "@/app/auth";
import { useCrumb } from "@/app/crumbs";
import { Button, ButtonLink } from "@/design/Button";
import { DataTable } from "@/design/DataTable";
import { EmptyState, ErrorState, Loading } from "@/design/Feedback";
import { Led, Qty } from "@/design/Indicators";
import { KeyValues, Panel, SectionLabel } from "@/design/Page";
import { useToast } from "@/design/Toast";
import { api, errorMessage } from "@/lib/api";
import { dateOnly, num, phone, rate } from "@/lib/format";
import { PO_STATUS_TONE, PO_STATUS_TR } from "@/lib/labels";
import type { OrderDetail, OrderSummary, Supplier, UnitType } from "@/lib/types";
import { SupplierDialog } from "./SupplierDialog";

interface SupplierDetail extends Supplier {
  orders: OrderSummary[];
  products: { id: number; sku: string; name: string; stock_qty: number; min_stock: number; unit_type: UnitType }[];
}

export default function SupplierDetailPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const toast = useToast();
  const canWrite = useCan("supplier.write");
  const canOrder = useCan("purchase.write");
  const [editing, setEditing] = useState(false);
  const [busy, setBusy] = useState(false);
  const q = useQuery({ queryKey: ["supplier", id], queryFn: () => api.get<SupplierDetail>(`/suppliers/${id}`) });
  const s = q.data;
  useCrumb(s?.name);
  if (q.isLoading) return <Loading />;
  if (q.isError || !s) return <ErrorState error={q.error} onRetry={() => q.refetch()} />;
  const critical = s.products.filter((p) => p.min_stock > 0 && p.stock_qty <= p.min_stock);

  const fromCritical = async () => {
    setBusy(true);
    try {
      const po = await api.post<OrderDetail>("/purchase-orders/from-critical", { supplier_id: s.id });
      toast({ title: "Taslak sipariş oluşturuldu", message: `${po.order_no} · ${po.items.length} kalem` });
      navigate(`/siparisler/${po.id}`);
    } catch (e) {
      toast({ tone: "warn", title: "Sipariş oluşturulamadı", message: errorMessage(e) });
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="pb-10">
      <div className="px-4 md:px-6 pt-5 pb-4 flex flex-wrap justify-between gap-4">
        <div>
          <h1 className="font-cond text-20 font-semibold">{s.name}</h1>
          <div className="text-13 text-ink-2">
            {s.contact || "—"} · <span className="num">{phone(s.phone)}</span> · {s.currency}
          </div>
        </div>
        <div className="flex flex-wrap gap-2">
          {canWrite && (
            <Button icon={Pencil} onClick={() => setEditing(true)}>
              Düzenle
            </Button>
          )}
          {canOrder && (
            <>
              <Button icon={ClipboardList} onClick={fromCritical} loading={busy}>
                Kritik stoklardan sipariş ({critical.length})
              </Button>
              <ButtonLink to={`/siparisler/yeni?tedarikci=${s.id}`} variant="primary" icon={Plus}>
                Yeni sipariş
              </ButtonLink>
            </>
          )}
        </div>
      </div>
      <div className="grid xl:grid-cols-[1fr_320px] gap-4 xl:pr-6">
        <div className="flex flex-col gap-4 min-w-0">
          <div className="bg-surface border-y border-rule xl:border-r">
            <SectionLabel>Sipariş geçmişi</SectionLabel>
            <DataTable
              data={s.orders}
              className="border-y-0"
              onRowClick={(o) => navigate(`/siparisler/${o.id}`)}
              columns={[
                { accessorKey: "order_no", header: "Sipariş", meta: { mono: true, className: "text-12" } },
                { accessorKey: "created_at", header: "Tarih", meta: { mono: true, className: "text-12" }, cell: ({ getValue }) => dateOnly(getValue()) },
                { accessorKey: "status", header: "Durum", cell: ({ row }) => <Led tone={PO_STATUS_TONE[row.original.status]}>{PO_STATUS_TR[row.original.status]}</Led> },
                { accessorKey: "item_count", header: "Kalem", meta: { align: "right", mono: true } },
                {
                  accessorKey: "total",
                  header: "Tutar",
                  meta: { align: "right", mono: true },
                  cell: ({ row }) => (row.original.total === null ? "—" : `${rate(row.original.total)} ${row.original.currency}`),
                },
                { accessorKey: "received_at", header: "Teslim", meta: { mono: true, className: "text-12" }, cell: ({ getValue }) => dateOnly(getValue()) },
              ]}
              empty={<EmptyState icon="connector" title="Henüz sipariş yok." />}
            />
          </div>
          <div className="bg-surface border-y border-rule xl:border-r">
            <SectionLabel right={<span className="num text-12 text-ink-3">{s.products.length}</span>}>Bu tedarikçiden alınan ürünler</SectionLabel>
            <DataTable
              data={s.products}
              className="border-y-0"
              onRowClick={(p) => navigate(`/urunler/${p.id}`)}
              columns={[
                { accessorKey: "sku", header: "SKU", meta: { mono: true, className: "text-12" } },
                { accessorKey: "name", header: "Ürün" },
                {
                  accessorKey: "stock_qty",
                  header: "Stok",
                  meta: { align: "right" },
                  cell: ({ row }) => (
                    <span className={row.original.min_stock > 0 && row.original.stock_qty <= row.original.min_stock ? "text-crit" : undefined}>
                      <Qty value={row.original.stock_qty} unit={row.original.unit_type} />
                    </span>
                  ),
                },
                { accessorKey: "min_stock", header: "Min.", meta: { align: "right" }, cell: ({ row }) => <Qty value={row.original.min_stock} unit={row.original.unit_type} /> },
              ]}
              empty={<EmptyState icon="resistor" title="Varsayılan tedarikçisi bu firma olan ürün yok." />}
            />
          </div>
        </div>
        <aside className="px-4 xl:px-0">
          <Panel title="Bilgiler">
            <KeyValues
              rows={[
                ["Yetkili", s.contact || null],
                ["Telefon", s.phone ? <span className="num">{phone(s.phone)}</span> : null],
                ["E-posta", s.email || null],
                ["Para birimi", s.currency],
                ["Ort. teslim süresi", s.avg_lead_days !== null && s.avg_lead_days !== undefined ? <span className="num">{num(s.avg_lead_days, 1)} gün</span> : "—"],
                ["Durum", s.is_active ? <Led tone="ok">Aktif</Led> : <Led tone="neutral">Pasif</Led>],
                ["Not", s.note || null],
              ]}
            />
          </Panel>
        </aside>
      </div>
      {editing && <SupplierDialog supplier={s} onClose={() => setEditing(false)} onSaved={() => (setEditing(false), void q.refetch())} />}
    </div>
  );
}
