import { useQuery, useQueryClient } from "@tanstack/react-query";
import { ChevronDown, ChevronRight, CloudDownload, Download, Plus, RefreshCw, Upload } from "lucide-react";
import { Fragment, useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { useCan, useMe } from "@/app/auth";
import { THEME_LABEL, type ThemeMode, useTheme } from "@/app/theme";
import { Button } from "@/design/Button";
import { cx } from "@/design/cx";
import { DataTable } from "@/design/DataTable";
import { Dialog, useConfirm } from "@/design/Dialog";
import { EmptyState, ErrorState, Loading } from "@/design/Feedback";
import { Led, Tag } from "@/design/Indicators";
import { Checkbox, Field, Input, Radio, Select, Textarea } from "@/design/Input";
import { Panel, SideNav } from "@/design/Page";
import { useToast } from "@/design/Toast";
import { ApiError, api, download, errorMessage } from "@/lib/api";
import { dateTime, decimalInput, fileSize, parseDecimal, rate } from "@/lib/format";
import { useBrands, useCategories, useLocations, useSettings, useTitle, useUsers } from "@/lib/hooks";
import { ACTION_TR, ENTITY_TR, ROUNDING_TR } from "@/lib/labels";
import { readStore, writeStore } from "@/lib/storage";
import type { AuditRow, BackupRow, FxInfo, Role, RoundingRule, Settings, UserRow } from "@/lib/types";

/* ---------------------------------------------------------------- ortak kaydetme */

function useSaveSettings() {
  const qc = useQueryClient();
  const toast = useToast();
  return async (patch: Partial<Settings>, message = "Ayarlar kaydedildi") => {
    try {
      await api.patch("/settings", patch);
      await qc.invalidateQueries({ queryKey: ["settings"] });
      await qc.invalidateQueries({ queryKey: ["public-shop"] });
      toast({ title: message });
      return true;
    } catch (e) {
      toast({ tone: "crit", title: "Kaydedilemedi", message: errorMessage(e) });
      return false;
    }
  };
}

function SettingsForm<K extends keyof Settings>({ keys, render }: { keys: K[]; render: (v: Pick<Settings, K>, set: (k: K, val: Settings[K]) => void) => React.ReactNode }) {
  const settings = useSettings();
  const save = useSaveSettings();
  const canWrite = useCan("settings.write");
  const [v, setV] = useState<Pick<Settings, K> | null>(null);
  useEffect(() => {
    if (settings.data) setV(Object.fromEntries(keys.map((k) => [k, settings.data![k]])) as Pick<Settings, K>);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [settings.data]);
  if (!v) return <Loading />;
  const dirty = keys.some((k) => settings.data && v[k] !== settings.data[k]);
  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        void save(v as Partial<Settings>);
      }}
    >
      <fieldset disabled={!canWrite} className="contents">
        {render(v, (k, val) => setV((s) => ({ ...(s as Pick<Settings, K>), [k]: val })))}
      </fieldset>
      {canWrite && (
        <div className="flex justify-end gap-2 px-4 pb-4">
          <Button type="submit" variant="primary" disabled={!dirty}>
            Kaydet
          </Button>
        </div>
      )}
    </form>
  );
}

/* ---------------------------------------------------------------- sekmeler */

function ShopTab() {
  return (
    <div className="flex flex-col gap-4">
      <Panel title="Dükkan bilgileri (fiş ve belgelerde görünür)">
        <SettingsForm
          keys={["shop_name", "address", "phone", "email", "tax_office", "tax_no", "receipt_footer"]}
          render={(v, set) => (
            <div className="grid sm:grid-cols-2 gap-3 p-4">
              <Field label="Dükkan adı">{(id) => <Input id={id} value={v.shop_name} onChange={(e) => set("shop_name", e.target.value)} />}</Field>
              <Field label="Telefon">{(id) => <Input id={id} value={v.phone} onChange={(e) => set("phone", e.target.value)} />}</Field>
              <Field label="Adres" className="sm:col-span-2">
                {(id) => <Input id={id} value={v.address} onChange={(e) => set("address", e.target.value)} />}
              </Field>
              <Field label="E-posta">{(id) => <Input id={id} value={v.email} onChange={(e) => set("email", e.target.value)} />}</Field>
              <div className="grid grid-cols-2 gap-3">
                <Field label="Vergi dairesi">{(id) => <Input id={id} value={v.tax_office} onChange={(e) => set("tax_office", e.target.value)} />}</Field>
                <Field label="Vergi no">{(id) => <Input id={id} mono value={v.tax_no} onChange={(e) => set("tax_no", e.target.value)} />}</Field>
              </div>
              <Field label="Fiş alt yazısı" className="sm:col-span-2">
                {(id) => <Textarea id={id} rows={2} value={v.receipt_footer} onChange={(e) => set("receipt_footer", e.target.value)} />}
              </Field>
            </div>
          )}
        />
      </Panel>
      <Panel title="İşleyiş">
        <SettingsForm
          keys={["allow_negative_stock", "dead_stock_days", "credit_due_days", "default_warranty_months"]}
          render={(v, set) => (
            <div className="grid sm:grid-cols-3 gap-3 p-4">
              <Checkbox
                className="sm:col-span-3"
                label="Negatif stoğa izin ver (stok yetersizken de satış yapılabilir)"
                checked={v.allow_negative_stock}
                onChange={(e) => set("allow_negative_stock", e.target.checked)}
              />
              <Field label="Ölü stok eşiği (gün)">
                {(id) => <Input id={id} mono align="right" value={v.dead_stock_days} onChange={(e) => set("dead_stock_days", Number(e.target.value.replace(/\D/g, "")) || 0)} />}
              </Field>
              <Field label="Veresiye vadesi (gün)">
                {(id) => <Input id={id} mono align="right" value={v.credit_due_days} onChange={(e) => set("credit_due_days", Number(e.target.value.replace(/\D/g, "")) || 0)} />}
              </Field>
              <Field label="Varsayılan garanti (ay)" hint="Seri takipli üründe süre girilmemişse">
                {(id) => (
                  <Input id={id} mono align="right" value={v.default_warranty_months} onChange={(e) => set("default_warranty_months", Number(e.target.value.replace(/\D/g, "")) || 0)} />
                )}
              </Field>
            </div>
          )}
        />
      </Panel>
    </div>
  );
}

function FxTab() {
  const qc = useQueryClient();
  const toast = useToast();
  const canFx = useCan("fx.write");
  const fx = useQuery({ queryKey: ["fx"], queryFn: () => api.get<FxInfo>("/fx-rates") });
  const [usd, setUsd] = useState("");
  const [eur, setEur] = useState("");
  const [busy, setBusy] = useState<"manual" | "tcmb" | null>(null);
  const [error, setError] = useState<string | null>(null);
  useEffect(() => {
    if (fx.data) {
      setUsd(decimalInput(fx.data.rates.USD?.rate));
      setEur(decimalInput(fx.data.rates.EUR?.rate));
    }
  }, [fx.data]);
  const after = async (r: { updated_products: number }, source: string) => {
    await Promise.all(["fx", "status", "products", "dashboard"].map((k) => qc.invalidateQueries({ queryKey: [k] })));
    toast({ title: `Kur güncellendi (${source})`, message: `${r.updated_products} kura bağlı ürünün fiyatı yeniden hesaplandı` });
  };
  const saveManual = async () => {
    setBusy("manual");
    setError(null);
    try {
      await after(await api.post<{ updated_products: number }>("/fx-rates", { USD: parseDecimal(usd), EUR: parseDecimal(eur) }), "elle");
    } catch (e) {
      setError(errorMessage(e));
    } finally {
      setBusy(null);
    }
  };
  const fetchTcmb = async () => {
    setBusy("tcmb");
    setError(null);
    try {
      await after(await api.post<{ updated_products: number }>("/fx-rates/fetch-tcmb"), "TCMB");
    } catch (e) {
      setError(e instanceof ApiError ? e.message : "TCMB'ye ulaşılamadı.");
    } finally {
      setBusy(null);
    }
  };
  if (fx.isLoading) return <Loading />;
  if (fx.isError || !fx.data) return <ErrorState error={fx.error} />;
  return (
    <div className="flex flex-col gap-4">
      <Panel title="Döviz kurları" right={fx.data.stale ? <Led tone="warn">{fx.data.stale_days} günden eski</Led> : <Led tone="ok">Güncel</Led>}>
        <div className="grid sm:grid-cols-2 gap-0 border-b border-rule">
          {(["USD", "EUR"] as const).map((c, i) => (
            <div key={c} className={cx("px-4 py-3", i > 0 && "sm:border-l border-rule")}>
              <div className="label-caps">{c} / TRY · satış</div>
              <div className="num text-28">{rate(fx.data.rates[c]?.rate)}</div>
              <div className="num text-12 text-ink-3">
                {fx.data.rates[c] ? `${fx.data.rates[c]!.source === "TCMB" ? "TCMB" : "elle"} · ${dateTime(fx.data.rates[c]!.fetched_at)}` : "tanımlı değil"}
              </div>
            </div>
          ))}
        </div>
        {canFx ? (
          <form
            className="p-4 flex flex-wrap items-end gap-3"
            onSubmit={(e) => {
              e.preventDefault();
              void saveManual();
            }}
          >
            <Field label="USD">{(id) => <Input id={id} mono align="right" className="w-32" value={usd} onChange={(e) => setUsd(e.target.value)} />}</Field>
            <Field label="EUR">{(id) => <Input id={id} mono align="right" className="w-32" value={eur} onChange={(e) => setEur(e.target.value)} />}</Field>
            <Button type="submit" variant="primary" loading={busy === "manual"}>
              Kaydet ve fiyatları güncelle
            </Button>
            <Button icon={CloudDownload} onClick={fetchTcmb} loading={busy === "tcmb"}>
              TCMB'den çek
            </Button>
            {error && <p className="w-full text-13 text-crit">{error}</p>}
            <p className="w-full text-12 text-ink-3">
              TCMB "today.xml" dosyasındaki döviz satış (ForexSelling) değeri kullanılır. İnternet yoksa kuru elle girebilirsiniz.
            </p>
          </form>
        ) : (
          <p className="p-4 text-13 text-ink-2">Kuru yalnızca yönetici güncelleyebilir.</p>
        )}
      </Panel>
      <Panel title="Fiyat yuvarlama">
        <SettingsForm
          keys={["rounding_rule", "fx_stale_days"]}
          render={(v, set) => (
            <div className="p-4 grid sm:grid-cols-2 gap-3">
              <fieldset className="flex flex-col gap-1.5">
                <legend className="text-12 text-ink-2 mb-1">Kura bağlı fiyatlarda yuvarlama</legend>
                {(Object.keys(ROUNDING_TR) as RoundingRule[]).map((r) => (
                  <Radio key={r} name="rounding" label={ROUNDING_TR[r]} checked={v.rounding_rule === r} onChange={() => set("rounding_rule", r)} />
                ))}
              </fieldset>
              <Field label="Kur eskime uyarısı (gün)" hint="Bu süreden eski kurda panoda uyarı çıkar">
                {(id) => <Input id={id} mono align="right" className="w-24" value={v.fx_stale_days} onChange={(e) => set("fx_stale_days", Number(e.target.value.replace(/\D/g, "")) || 1)} />}
              </Field>
            </div>
          )}
        />
      </Panel>
      <Panel title="Kur geçmişi">
        <DataTable
          data={fx.data.history ?? []}
          className="border-y-0"
          hideFooter
          maxHeight="360px"
          columns={[
            { accessorKey: "fetched_at", header: "Tarih", meta: { mono: true, className: "text-12" }, cell: ({ getValue }) => dateTime(getValue()) },
            { accessorKey: "currency", header: "Döviz", cell: ({ getValue }) => <Tag>{getValue()}</Tag> },
            { accessorKey: "rate", header: "Kur", meta: { align: "right", mono: true }, cell: ({ getValue }) => rate(getValue()) },
            { accessorKey: "source", header: "Kaynak", cell: ({ getValue }) => (getValue() === "TCMB" ? "TCMB" : "Elle") },
          ]}
        />
      </Panel>
    </div>
  );
}

function VatTab() {
  return (
    <Panel title="KDV">
      <SettingsForm
        keys={["default_vat_rate"]}
        render={(v, set) => (
          <div className="p-4 flex flex-col gap-3">
            <Field label="Yeni ürünlerde varsayılan KDV oranı">
              {(id) => (
                <Select id={id} className="w-40" value={v.default_vat_rate} onChange={(e) => set("default_vat_rate", Number(e.target.value))}>
                  {[20, 10, 1, 0].map((r) => (
                    <option key={r} value={r}>
                      %{r}
                    </option>
                  ))}
                </Select>
              )}
            </Field>
            <p className="text-13 text-ink-2 max-w-[70ch]">
              Satış fiyatları KDV dahil girilir; fişte ve raporlarda KDV oranlara göre (%1, %10, %20) ayrıştırılır. Alış fiyatları ve maliyetler KDV hariç tutulur;
              brüt kâr KDV hariç ciro üzerinden hesaplanır.
            </p>
          </div>
        )}
      />
    </Panel>
  );
}

function TextsTab() {
  return (
    <Panel title="Servis şartları ve KVKK aydınlatma metni">
      <SettingsForm
        keys={["service_terms", "kvkk_text"]}
        render={(v, set) => (
          <div className="p-4 grid lg:grid-cols-2 gap-4">
            <Field label="Servis şartları (kabul fişinde basılır)">
              {(id) => <Textarea id={id} rows={12} value={v.service_terms} onChange={(e) => set("service_terms", e.target.value)} />}
            </Field>
            <Field label="KVKK aydınlatma metni" hint="Hukuki olarak gözden geçirilmelidir.">
              {(id) => <Textarea id={id} rows={12} value={v.kvkk_text} onChange={(e) => set("kvkk_text", e.target.value)} />}
            </Field>
          </div>
        )}
      />
    </Panel>
  );
}

function UserDialog({ user, onClose }: { user: UserRow | null; onClose: () => void }) {
  const qc = useQueryClient();
  const toast = useToast();
  const [v, setV] = useState({
    username: user?.username ?? "",
    full_name: user?.full_name ?? "",
    role: (user?.role ?? "STAFF") as Role,
    max_discount_pct: decimalInput(user?.max_discount_pct ?? 5),
    is_active: user?.is_active ?? true,
    password: "",
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const save = async () => {
    const body: Record<string, unknown> = { full_name: v.full_name, role: v.role, max_discount_pct: parseDecimal(v.max_discount_pct) ?? 0 };
    if (v.password) body.password = v.password;
    try {
      if (user) await api.patch(`/users/${user.id}`, { ...body, is_active: v.is_active });
      else await api.post("/users", { ...body, username: v.username });
      await qc.invalidateQueries({ queryKey: ["users"] });
      toast({ title: user ? "Kullanıcı güncellendi" : "Kullanıcı eklendi", message: v.full_name });
      onClose();
    } catch (e) {
      if (e instanceof ApiError) setErrors({ ...e.fields, _: e.message });
    }
  };
  return (
    <Dialog
      open
      onOpenChange={(o) => !o && onClose()}
      title={user ? "Kullanıcıyı düzenle" : "Yeni kullanıcı"}
      width={480}
      footer={
        <>
          <Button variant="ghost" onClick={onClose}>
            Vazgeç
          </Button>
          <Button variant="primary" onClick={save}>
            Kaydet
          </Button>
        </>
      }
    >
      <div className="grid sm:grid-cols-2 gap-3">
        <Field label="Kullanıcı adı" error={errors.username}>
          {(id) => <Input id={id} mono disabled={!!user} value={v.username} onChange={(e) => setV({ ...v, username: e.target.value.toLowerCase() })} />}
        </Field>
        <Field label="Ad soyad" error={errors.full_name}>
          {(id) => <Input id={id} value={v.full_name} onChange={(e) => setV({ ...v, full_name: e.target.value })} />}
        </Field>
        <Field label="Rol">
          {(id) => (
            <Select id={id} value={v.role} onChange={(e) => setV({ ...v, role: e.target.value as Role })}>
              <option value="STAFF">Personel</option>
              <option value="ADMIN">Yönetici</option>
            </Select>
          )}
        </Field>
        <Field label="Maks. indirim %" hint="Personelin satırda/genelde yapabileceği en yüksek indirim">
          {(id) => <Input id={id} mono align="right" value={v.max_discount_pct} onChange={(e) => setV({ ...v, max_discount_pct: e.target.value })} />}
        </Field>
        <Field label={user ? "Yeni şifre (boş: değişmez)" : "Şifre"} error={errors.password} hint="En az 8 karakter, harf ve rakam" className="sm:col-span-2">
          {(id) => <Input id={id} type="password" autoComplete="new-password" value={v.password} onChange={(e) => setV({ ...v, password: e.target.value })} />}
        </Field>
        {user && <Checkbox label="Aktif" checked={v.is_active} onChange={(e) => setV({ ...v, is_active: e.target.checked })} />}
        {errors._ && <p className="sm:col-span-2 text-12 text-crit">{errors._}</p>}
      </div>
    </Dialog>
  );
}

function UsersTab() {
  const users = useUsers();
  const me = useMe();
  const [editing, setEditing] = useState<UserRow | null | "new">(null);
  return (
    <Panel
      title="Kullanıcılar"
      right={
        <Button size="sm" icon={Plus} onClick={() => setEditing("new")}>
          Yeni kullanıcı
        </Button>
      }
    >
      <DataTable
        data={users.data ?? []}
        className="border-y-0"
        hideFooter
        onRowClick={(u) => setEditing(u)}
        columns={[
          { accessorKey: "full_name", header: "Ad soyad", cell: ({ row }) => <span>{row.original.full_name}{row.original.id === me.id && <span className="text-12 text-ink-3"> (siz)</span>}</span> },
          { accessorKey: "username", header: "Kullanıcı adı", meta: { mono: true } },
          { accessorKey: "role", header: "Rol", cell: ({ getValue }) => (getValue() === "ADMIN" ? <Tag>YÖNETİCİ</Tag> : <Tag>PERSONEL</Tag>) },
          { accessorKey: "max_discount_pct", header: "Maks. indirim", meta: { align: "right", mono: true }, cell: ({ getValue }) => `%${getValue()}` },
          { accessorKey: "is_active", header: "Durum", cell: ({ getValue }) => (getValue() ? <Led tone="ok">Aktif</Led> : <Led tone="neutral">Pasif</Led>) },
        ]}
      />
      <p className="px-4 py-3 text-12 text-ink-3 border-t border-rule">
        Personel alış fiyatı ve kârı göremez, belirlenen orandan fazla indirim yapamaz, satış iptali ve arşivleme yapamaz. Kurallar sunucu tarafında uygulanır.
      </p>
      {editing && <UserDialog user={editing === "new" ? null : editing} onClose={() => setEditing(null)} />}
    </Panel>
  );
}

function CatalogTab() {
  const qc = useQueryClient();
  const toast = useToast();
  const categories = useCategories();
  const brands = useBrands();
  const locations = useLocations();
  const [cat, setCat] = useState({ name: "", parent: "" });
  const [brand, setBrand] = useState("");
  const [loc, setLoc] = useState({ code: "", name: "" });
  const run = async (fn: () => Promise<unknown>, key: string, msg: string) => {
    try {
      await fn();
      await qc.invalidateQueries({ queryKey: [key] });
      toast({ title: msg });
      return true;
    } catch (e) {
      toast({ tone: "crit", title: "Kaydedilemedi", message: errorMessage(e) });
      return false;
    }
  };
  return (
    <div className="grid xl:grid-cols-3 gap-4">
      <Panel title="Kategoriler">
        <form
          className="p-3 flex flex-col gap-2 border-b border-rule"
          onSubmit={async (e) => {
            e.preventDefault();
            if (await run(() => api.post("/categories", { name: cat.name, parent_id: cat.parent ? Number(cat.parent) : null }), "categories", "Kategori eklendi"))
              setCat({ name: "", parent: "" });
          }}
        >
          <Input placeholder="Kategori adı" aria-label="Kategori adı" value={cat.name} onChange={(e) => setCat({ ...cat, name: e.target.value })} />
          <div className="flex gap-2">
            <Select value={cat.parent} onChange={(e) => setCat({ ...cat, parent: e.target.value })} className="flex-1" aria-label="Üst kategori">
              <option value="">(Ana kategori)</option>
              {categories.data?.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.path}
                </option>
              ))}
            </Select>
            <Button type="submit" icon={Plus} disabled={!cat.name.trim()}>
              Ekle
            </Button>
          </div>
        </form>
        <ul className="max-h-[420px] overflow-y-auto scroll-thin">
          {categories.data?.map((c) => (
            <li key={c.id} className="flex items-center justify-between px-3 h-8 border-b border-rule text-13">
              <span className={cx("truncate", !c.is_active && "text-ink-3 line-through")}>{c.path}</span>
              <span className="num text-12 text-ink-3">{c.product_count}</span>
            </li>
          ))}
        </ul>
      </Panel>
      <Panel title="Markalar">
        <form
          className="p-3 flex gap-2 border-b border-rule"
          onSubmit={async (e) => {
            e.preventDefault();
            if (await run(() => api.post("/brands", { name: brand }), "brands", "Marka eklendi")) setBrand("");
          }}
        >
          <Input placeholder="Marka adı" aria-label="Marka adı" value={brand} onChange={(e) => setBrand(e.target.value)} />
          <Button type="submit" icon={Plus} disabled={!brand.trim()}>
            Ekle
          </Button>
        </form>
        <ul className="max-h-[420px] overflow-y-auto scroll-thin">
          {brands.data?.map((b) => (
            <li key={b.id} className="px-3 h-8 flex items-center border-b border-rule text-13">
              {b.name}
            </li>
          ))}
        </ul>
      </Panel>
      <Panel title="Raflar / konumlar">
        <form
          className="p-3 flex gap-2 border-b border-rule"
          onSubmit={async (e) => {
            e.preventDefault();
            if (await run(() => api.post("/locations", { code: loc.code, name: loc.name }), "locations", "Konum eklendi")) setLoc({ code: "", name: "" });
          }}
        >
          <Input mono placeholder="A-04" aria-label="Raf kodu" className="w-24" value={loc.code} onChange={(e) => setLoc({ ...loc, code: e.target.value.toUpperCase() })} />
          <Input placeholder="Açıklama" aria-label="Açıklama" value={loc.name} onChange={(e) => setLoc({ ...loc, name: e.target.value })} />
          <Button type="submit" icon={Plus} disabled={!loc.code.trim()}>
            Ekle
          </Button>
        </form>
        <ul>
          {locations.data?.map((l) => (
            <li key={l.id} className="px-3 h-8 flex items-center gap-3 border-b border-rule text-13">
              <span className="num w-16">{l.code}</span>
              <span className="text-ink-2 truncate">{l.name}</span>
            </li>
          ))}
        </ul>
      </Panel>
    </div>
  );
}

function BackupTab() {
  const qc = useQueryClient();
  const toast = useToast();
  const confirm = useConfirm();
  const q = useQuery({ queryKey: ["backups"], queryFn: () => api.get<BackupRow[]>("/backups") });
  const [busy, setBusy] = useState(false);
  const create = async () => {
    setBusy(true);
    try {
      const b = await api.post<BackupRow>("/backups");
      toast({ title: "Yedek alındı", message: b.name });
      await qc.invalidateQueries({ queryKey: ["backups"] });
      await qc.invalidateQueries({ queryKey: ["status"] });
    } catch (e) {
      toast({ tone: "crit", title: "Yedek alınamadı", message: errorMessage(e) });
    } finally {
      setBusy(false);
    }
  };
  const restore = async (file: File) => {
    const ok = await confirm({
      title: "Yedekten geri yüklensin mi?",
      message: `"${file.name}" yüklenecek; mevcut tüm veriler bu yedekteki verilerle değişecek. İşlemden önce otomatik ön-yedek alınır.`,
      confirmLabel: "Geri yükle",
      danger: true,
      requireText: "GERİ YÜKLE",
    });
    if (!ok) return;
    setBusy(true);
    try {
      const r = await api.upload<{ pre_backup: string }>("/backups/restore", file);
      toast({ tone: "warn", title: "Geri yükleme tamamlandı", message: `Ön-yedek: ${r.pre_backup}. Sayfa yenileniyor…` });
      window.setTimeout(() => window.location.reload(), 1200);
    } catch (e) {
      toast({ tone: "crit", title: "Geri yüklenemedi", message: errorMessage(e) });
    } finally {
      setBusy(false);
    }
  };
  return (
    <Panel
      title="Yedekleme"
      right={
        <div className="flex gap-2">
          <label className={cx("inline-flex items-center gap-1.5 h-7 px-2 text-12 border border-rule-strong rounded-ctl bg-surface hover:bg-surface-2 cursor-pointer", busy && "opacity-50 pointer-events-none")}>
            <Upload size={14} strokeWidth={1.5} aria-hidden /> Geri yükle
            <input type="file" accept=".db" className="sr-only" onChange={(e) => e.target.files?.[0] && void restore(e.target.files[0])} />
          </label>
          <Button size="sm" variant="primary" icon={RefreshCw} onClick={create} loading={busy}>
            Şimdi yedek al
          </Button>
        </div>
      }
    >
      <p className="px-4 py-3 text-13 text-ink-2 border-b border-rule">
        Uygulama açıkken her gece 03:00'te ve açılışta (son yedek 24 saatten eskiyse) otomatik yedek alınır; son 14 yedek saklanır. Yedekleri düzenli olarak harici
        bir diske kopyalayın.
      </p>
      {q.isLoading ? (
        <Loading />
      ) : (
        <DataTable
          data={q.data ?? []}
          className="border-y-0"
          hideFooter
          columns={[
            { accessorKey: "name", header: "Dosya", meta: { mono: true, className: "text-12" } },
            {
              accessorKey: "kind",
              header: "Tür",
              cell: ({ getValue }) => <Tag>{{ auto: "OTOMATİK", manual: "MANUEL", "pre-restore": "ÖN-YEDEK" }[getValue() as BackupRow["kind"]]}</Tag>,
            },
            { accessorKey: "created_at", header: "Tarih", meta: { mono: true, className: "text-12" }, cell: ({ getValue }) => dateTime(getValue()) },
            { accessorKey: "size", header: "Boyut", meta: { align: "right", mono: true }, cell: ({ getValue }) => fileSize(getValue()) },
            {
              id: "_actions",
              header: "",
              meta: { align: "right" },
              cell: ({ row }) => (
                <Button
                  size="sm"
                  variant="ghost"
                  icon={Download}
                  onClick={() => download(`/backups/${row.original.name}`, undefined, row.original.name).catch((e) => toast({ tone: "crit", title: "İndirilemedi", message: errorMessage(e) }))}
                >
                  İndir
                </Button>
              ),
            },
          ]}
          empty={<EmptyState icon="ground" title="Henüz yedek yok." />}
        />
      )}
    </Panel>
  );
}

function DiffView({ diff }: { diff: AuditRow["diff"] }) {
  const keys = Array.from(new Set([...Object.keys(diff.before ?? {}), ...Object.keys(diff.after ?? {})]));
  const show = (v: unknown) => (v === null || v === undefined || v === "" ? "—" : typeof v === "object" ? JSON.stringify(v) : String(v));
  return (
    <div className="grid md:grid-cols-2 gap-3 p-3 bg-paper">
      {(["before", "after"] as const).map((side) => (
        <div key={side}>
          <div className="label-caps mb-1">{side === "before" ? "Önce" : "Sonra"}</div>
          <dl className="text-12 num border border-rule bg-surface">
            {keys.length === 0 && <div className="px-2 py-1 text-ink-3">—</div>}
            {keys.map((k) => (
              <div key={k} className="grid grid-cols-[140px_1fr] border-b border-rule last:border-b-0">
                <dt className="px-2 py-1 text-ink-3 font-sans">{k}</dt>
                <dd className={cx("px-2 py-1 break-all", side === "after" && show(diff.before?.[k]) !== show(diff.after?.[k]) && "text-signal-ink")}>
                  {show(diff[side]?.[k])}
                </dd>
              </div>
            ))}
          </dl>
        </div>
      ))}
      {diff.extra && (
        <div className="md:col-span-2 text-12">
          <span className="label-caps mr-2">Ek bilgi</span>
          <span className="num break-all">{JSON.stringify(diff.extra)}</span>
        </div>
      )}
    </div>
  );
}

function AuditTab() {
  const [entity, setEntity] = useState("");
  const [open, setOpen] = useState<number | null>(null);
  const q = useQuery({ queryKey: ["audit", entity], queryFn: () => api.get<AuditRow[]>("/audit-logs", { entity: entity || undefined, limit: 500 }) });
  return (
    <Panel
      title="Denetim kaydı"
      right={
        <Select value={entity} onChange={(e) => setEntity(e.target.value)} className="w-44" aria-label="Kayıt türü">
          <option value="">Tüm kayıtlar</option>
          {Object.entries(ENTITY_TR).map(([k, v]) => (
            <option key={k} value={k}>
              {v}
            </option>
          ))}
        </Select>
      }
    >
      {q.isLoading ? (
        <Loading />
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full text-13">
            <thead>
              <tr className="border-b border-rule-strong font-cond text-11 uppercase tracking-[.06em] text-ink-3 text-left" lang="tr">
                <th className="w-8" />
                <th className="py-1.5 pr-3 font-medium">Zaman</th>
                <th className="pr-3 font-medium">Kullanıcı</th>
                <th className="pr-3 font-medium">İşlem</th>
                <th className="pr-3 font-medium">Kayıt</th>
                <th className="pr-4 font-medium">IP</th>
              </tr>
            </thead>
            <tbody>
              {(q.data ?? []).map((a) => (
                <Fragment key={a.id}>
                  <tr
                    className="border-b border-rule hover:bg-surface-2 cursor-pointer"
                    style={{ height: "var(--row-h)" }}
                    onClick={() => setOpen(open === a.id ? null : a.id)}
                    aria-expanded={open === a.id}
                    tabIndex={0}
                    onKeyDown={(e) => e.key === "Enter" && setOpen(open === a.id ? null : a.id)}
                  >
                    <td className="pl-3 text-ink-3">{open === a.id ? <ChevronDown size={14} /> : <ChevronRight size={14} />}</td>
                    <td className="pr-3 num text-12 whitespace-nowrap">{dateTime(a.at)}</td>
                    <td className="pr-3">{a.user_name ?? "sistem"}</td>
                    <td className="pr-3">{ACTION_TR[a.action] ?? a.action}</td>
                    <td className="pr-3 text-ink-2">
                      {ENTITY_TR[a.entity] ?? a.entity}
                      {a.entity_id && <span className="num text-12"> #{a.entity_id}</span>}
                    </td>
                    <td className="pr-4 num text-12 text-ink-3">{a.ip ?? "—"}</td>
                  </tr>
                  {open === a.id && (
                    <tr className="border-b border-rule">
                      <td colSpan={6}>
                        <DiffView diff={a.diff} />
                      </td>
                    </tr>
                  )}
                </Fragment>
              ))}
            </tbody>
          </table>
          {q.data?.length === 0 && <EmptyState icon="circuit" title="Kayıt yok." />}
        </div>
      )}
    </Panel>
  );
}

function AppearanceTab() {
  const [theme, setTheme] = useTheme();
  const [density, setDensity] = useState<"normal" | "compact">(() => readStore("tezgah.density", "normal"));
  const applyDensity = (d: "normal" | "compact") => {
    setDensity(d);
    writeStore("tezgah.density", d);
    if (d === "compact") document.documentElement.setAttribute("data-density", "compact");
    else document.documentElement.removeAttribute("data-density");
  };
  return (
    <Panel title="Görünüm (bu cihazda saklanır)">
      <div className="p-4 grid sm:grid-cols-2 gap-6">
        <fieldset className="flex flex-col gap-1.5">
          <legend className="text-12 text-ink-2 mb-1">Tema</legend>
          {(["system", "light", "dark"] as ThemeMode[]).map((m) => (
            <Radio key={m} name="theme" label={THEME_LABEL[m] + (m === "system" ? " (işletim sistemine göre)" : m === "dark" ? " — gece vardiyası" : "")} checked={theme === m} onChange={() => setTheme(m)} />
          ))}
        </fieldset>
        <fieldset className="flex flex-col gap-1.5">
          <legend className="text-12 text-ink-2 mb-1">Tablo yoğunluğu</legend>
          <Radio name="density" label="Normal (36 px satır)" checked={density === "normal"} onChange={() => applyDensity("normal")} />
          <Radio name="density" label="Sıkı mod (30 px satır)" checked={density === "compact"} onChange={() => applyDensity("compact")} />
        </fieldset>
      </div>
    </Panel>
  );
}

const TABS = [
  { key: "dukkan", label: "Dükkan", perm: "settings.read" },
  { key: "kur", label: "Fiyat & Kur", perm: "settings.read" },
  { key: "kdv", label: "KDV", perm: "settings.write" },
  { key: "kullanicilar", label: "Kullanıcılar", perm: "user.manage" },
  { key: "metinler", label: "Servis şartları & KVKK", perm: "settings.write" },
  { key: "katalog", label: "Kategori, marka, raf", perm: "catalog.write" },
  { key: "yedek", label: "Yedekleme", perm: "backup.manage" },
  { key: "denetim", label: "Denetim kaydı", perm: "audit.read" },
  { key: "gorunum", label: "Görünüm", perm: null },
];

export default function SettingsPage() {
  const { sekme = "dukkan" } = useParams();
  const navigate = useNavigate();
  const me = useMe();
  const visible = TABS.filter((t) => !t.perm || me.permissions.includes(t.perm));
  const active = visible.find((t) => t.key === sekme) ?? visible[0];
  useTitle(`Ayarlar · ${active.label}`);
  return (
    <div className="grid md:grid-cols-[220px_1fr] min-h-full">
      <aside className="md:border-r border-rule bg-surface md:py-4">
        <div className="label-caps px-3 pb-2 hidden md:block">Ayarlar</div>
        <SideNav items={visible.map((t) => ({ key: t.key, label: t.label }))} active={active.key} onSelect={(k) => navigate(`/ayarlar/${k}`)} />
      </aside>
      <div className="min-w-0 p-4 md:p-6">
        <h1 className="font-cond text-20 font-semibold mb-4">{active.label}</h1>
        {active.key === "dukkan" && <ShopTab />}
        {active.key === "kur" && <FxTab />}
        {active.key === "kdv" && <VatTab />}
        {active.key === "kullanicilar" && <UsersTab />}
        {active.key === "metinler" && <TextsTab />}
        {active.key === "katalog" && <CatalogTab />}
        {active.key === "yedek" && <BackupTab />}
        {active.key === "denetim" && <AuditTab />}
        {active.key === "gorunum" && <AppearanceTab />}
      </div>
    </div>
  );
}
