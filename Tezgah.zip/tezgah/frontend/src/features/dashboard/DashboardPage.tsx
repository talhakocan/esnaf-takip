import { useQuery } from "@tanstack/react-query";
import { ChevronRight } from "lucide-react";
import { Link } from "react-router-dom";
import { useCan } from "@/app/auth";
import { LineSeries } from "@/design/Charts";
import { cx } from "@/design/cx";
import { EmptyState, ErrorState, Loading } from "@/design/Feedback";
import { Delta, Led, Money, Qty } from "@/design/Indicators";
import { SectionLabel } from "@/design/Page";
import { api } from "@/lib/api";
import { money, num, timeOnly } from "@/lib/format";
import { useTitle } from "@/lib/hooks";
import { MOVEMENT_TONE } from "@/lib/labels";
import type { Dashboard } from "@/lib/types";

const KIND_LABEL: Record<string, string> = {
  stock: "Kritik stok",
  service: "Parça bekleyen servis",
  credit: "Vadesi geçmiş veresiye",
  fx: "Döviz kuru",
  dead: "Ölü stok",
};

export default function DashboardPage() {
  useTitle("Pano");
  const finance = useCan("report.finance");
  const q = useQuery({ queryKey: ["dashboard"], queryFn: () => api.get<Dashboard>("/reports/dashboard"), refetchInterval: 60_000 });
  if (q.isLoading) return <Loading />;
  if (q.isError || !q.data) return <ErrorState error={q.error} onRetry={() => q.refetch()} />;
  const d = q.data;

  return (
    <div className="pb-8">
      <div className="flex items-end justify-between px-4 md:px-6 pt-5 pb-3">
        <h1 className="font-cond text-20 font-semibold">Pano</h1>
        <span className="num text-12 text-ink-3">güncelleme {timeOnly(d.generated_at)}</span>
      </div>

      {/* KPI şeridi: kartsız, dikey ayraçlı tek satır */}
      <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-6 bg-surface border-y border-rule">
        {d.kpis.map((k, i) => (
          <Link
            key={k.key}
            to={k.link}
            className={cx(
              "block px-4 md:px-5 py-3 border-rule hover:bg-surface-2",
              i > 0 && "xl:border-l",
              i % 2 === 1 && "border-l md:border-l-0",
              i % 3 !== 0 && "md:border-l",
              i >= 2 && "border-t md:border-t-0",
              i >= 3 && "md:border-t xl:border-t-0",
            )}
          >
            <div className="label-caps" lang="tr">
              {k.label.toLocaleUpperCase("tr-TR")}
            </div>
            <div className={cx("num text-28 mt-1 leading-tight", k.tone === "crit" && k.value > 0 && "text-crit")}>
              {k.type === "money" ? money(k.value) : num(k.value)}
            </div>
            <div className="mt-0.5 min-h-[18px]">
              {k.delta !== undefined ? (
                <Delta value={k.delta} format={(v) => (k.delta_type === "money" ? money(v) : num(v))} />
              ) : (
                <span className="num text-12 text-ink-3">
                  {k.sub}
                  {k.sub_amount !== undefined && <span className={k.sub_amount > 0 ? "text-crit ml-1" : "ml-1"}>{money(k.sub_amount)}</span>}
                </span>
              )}
            </div>
          </Link>
        ))}
      </div>

      <div className="grid xl:grid-cols-12 gap-4 px-4 md:px-6 mt-4">
        <div className="xl:col-span-8 flex flex-col gap-4 min-w-0">
          <section className="bg-surface border border-rule">
            <SectionLabel right={<Link to="/raporlar/satis" className="text-12 text-ink-2 hover:text-ink">Satış raporu →</Link>}>
              Son 30 gün
            </SectionLabel>
            <LineSeries
              data={d.series}
              x="label"
              series={[{ key: "revenue", label: "Ciro" }, ...(finance ? [{ key: "profit", label: "Brüt kâr", accent: true }] : [])]}
              height={240}
            />
          </section>
          <section className="bg-surface border border-rule">
            <SectionLabel right={<Link to="/stok" className="text-12 text-ink-2 hover:text-ink">Stok defteri →</Link>}>Son hareketler</SectionLabel>
            {d.recent_movements.length === 0 ? (
              <EmptyState icon="circuit" title="Henüz stok hareketi yok." />
            ) : (
              <table className="w-full text-13">
                <tbody>
                  {d.recent_movements.map((m) => (
                    <tr key={m.id} className="border-b border-rule last:border-b-0 hover:bg-surface-2" style={{ height: "var(--row-h)" }}>
                      <td className="pl-4 pr-3 num text-12 text-ink-3 w-16">{timeOnly(m.at)}</td>
                      <td className="px-3 w-28">
                        <Led tone={MOVEMENT_TONE[m.type]}>
                          <span className="font-cond text-12 tracking-wide">{m.label}</span>
                        </Led>
                      </td>
                      <td className="px-3 truncate max-w-0 w-full">
                        <Link to={`/urunler/${m.product_id}`} className="hover:underline">
                          {m.product_name}
                        </Link>
                      </td>
                      <td className="px-3 text-right whitespace-nowrap">
                        <span className={m.qty > 0 ? "text-ok" : undefined}>
                          {m.qty > 0 ? "+" : ""}
                          <Qty value={m.qty} unit={m.unit_type} />
                        </span>
                      </td>
                      <td className="pl-3 pr-4 text-12 text-ink-2 whitespace-nowrap hidden sm:table-cell">{m.user_name ?? "—"}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </section>
        </div>

        <aside className="xl:col-span-4">
          <section className="bg-surface border border-rule">
            <SectionLabel right={<span className="num text-12 text-ink-3">{d.attention.length}</span>}>Dikkat</SectionLabel>
            {d.attention.length === 0 ? (
              <EmptyState icon="ground" title="Her şey yolunda: kritik stok, geciken servis veya vadesi geçmiş borç yok." />
            ) : (
              <ul>
                {d.attention.map((a, i) => (
                  <li key={i} className="border-b border-rule last:border-b-0">
                    <Link to={a.link} className="flex items-center gap-3 px-4 py-2 hover:bg-surface-2">
                      <Led tone={a.tone} />
                      <div className="flex-1 min-w-0">
                        <div className="text-13 truncate">{a.title}</div>
                        <div className="text-12 text-ink-3 truncate">
                          <span className="label-caps mr-1.5" lang="tr">
                            {KIND_LABEL[a.kind]?.toLocaleUpperCase("tr-TR")}
                          </span>
                          {a.detail}
                        </div>
                      </div>
                      {a.amount !== undefined && <Money value={a.amount} className="text-13" />}
                      <ChevronRight size={14} strokeWidth={1.5} className="text-ink-3 shrink-0" aria-hidden />
                    </Link>
                  </li>
                ))}
              </ul>
            )}
          </section>
        </aside>
      </div>
    </div>
  );
}
