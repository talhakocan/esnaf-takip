import { useQuery } from "@tanstack/react-query";
import { Plus } from "lucide-react";
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useCan } from "@/app/auth";
import { ButtonLink } from "@/design/Button";
import { type ColumnDef, DataTable } from "@/design/DataTable";
import { EmptyState, ErrorState, Loading } from "@/design/Feedback";
import { Led } from "@/design/Indicators";
import { Select } from "@/design/Input";
import { PageHeader } from "@/design/Page";
import { api } from "@/lib/api";
import { dateOnly, rate } from "@/lib/format";
import { useTitle } from "@/lib/hooks";
import { PO_STATUS_TONE, PO_STATUS_TR } from "@/lib/labels";
import type { OrderSummary, POStatus } from "@/lib/types";

export default function OrdersPage() {
  useTitle("Satın Alma");
  const navigate = useNavigate();
  const canWrite = useCan("purchase.write");
  const [status, setStatus] = useState("open");
  const q = useQuery({ queryKey: ["orders", status], queryFn: () => api.get<OrderSummary[]>("/purchase-orders", { status: status || undefined }) });
  const columns: ColumnDef<OrderSummary, any>[] = [
    { accessorKey: "order_no", header: "Sipariş", meta: { mono: true } },
    { accessorKey: "supplier_name", header: "Tedarikçi" },
    {
      accessorKey: "status",
      header: "Durum",
      meta: { exportValue: (o) => PO_STATUS_TR[o.status] },
      cell: ({ row }) => <Led tone={PO_STATUS_TONE[row.original.status]}>{PO_STATUS_TR[row.original.status]}</Led>,
    },
    { accessorKey: "item_count", header: "Kalem", meta: { align: "right", mono: true } },
    {
      accessorKey: "total",
      header: "Tutar",
      meta: { align: "right", mono: true },
      cell: ({ row }) => (row.original.total === null ? "—" : `${rate(row.original.total)} ${row.original.currency}`),
    },
    { accessorKey: "created_at", header: "Oluşturma", meta: { mono: true, className: "text-12" }, cell: ({ getValue }) => dateOnly(getValue()) },
    { accessorKey: "expected_at", header: "Beklenen", meta: { mono: true, className: "text-12" }, cell: ({ getValue }) => dateOnly(getValue()) },
    { accessorKey: "received_at", header: "Teslim", meta: { mono: true, className: "text-12" }, cell: ({ getValue }) => dateOnly(getValue()) },
  ];
  return (
    <div>
      <PageHeader
        title="Satın Alma"
        count={q.data?.length}
        actions={
          canWrite && (
            <ButtonLink to="/siparisler/yeni" variant="primary" icon={Plus}>
              Yeni sipariş
            </ButtonLink>
          )
        }
      />
      {q.isLoading ? (
        <Loading />
      ) : q.isError ? (
        <ErrorState error={q.error} onRetry={() => q.refetch()} />
      ) : (
        <DataTable
          data={q.data ?? []}
          columns={columns}
          onRowClick={(o) => navigate(`/siparisler/${o.id}`)}
          exportName="tezgah-siparisler"
          toolbar={
            <Select value={status} onChange={(e) => setStatus(e.target.value)} className="w-48" aria-label="Durum">
              <option value="open">Açık siparişler</option>
              <option value="">Tümü</option>
              {(Object.keys(PO_STATUS_TR) as POStatus[]).map((s) => (
                <option key={s} value={s}>
                  {PO_STATUS_TR[s]}
                </option>
              ))}
            </Select>
          }
          empty={<EmptyState icon="connector" title="Bu filtrede sipariş yok." />}
        />
      )}
    </div>
  );
}
