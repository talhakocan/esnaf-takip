import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Trash2 } from "lucide-react";
import { useEffect, useState } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { Button, IconButton } from "@/design/Button";
import { Field, Input, Select, Textarea } from "@/design/Input";
import { PageHeader, Panel } from "@/design/Page";
import { useToast } from "@/design/Toast";
import { ApiError, api } from "@/lib/api";
import { decimalInput, parseDecimal, qty as fmtQty, rate } from "@/lib/format";
import { useSuppliers, useTitle } from "@/lib/hooks";
import type { Currency, FxInfo, OrderDetail, Product } from "@/lib/types";
import { ProductSearch } from "../shared/Pickers";

interface Line {
  product: Product;
  qty: string;
  price: string;
}

export default function OrderFormPage() {
  useTitle("Yeni sipariş");
  const [params] = useSearchParams();
  const navigate = useNavigate();
  const qc = useQueryClient();
  const toast = useToast();
  const suppliers = useSuppliers();
  const fx = useQuery({ queryKey: ["fx"], queryFn: () => api.get<FxInfo>("/fx-rates") });
  const [supplierId, setSupplierId] = useState(params.get("tedarikci") ?? "");
  const [currency, setCurrency] = useState<Currency>("TRY");
  const [expected, setExpected] = useState("");
  const [note, setNote] = useState("");
  const [lines, setLines] = useState<Line[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    const s = suppliers.data?.find((x) => String(x.id) === supplierId);
    if (s) setCurrency(s.currency);
  }, [supplierId, suppliers.data]);

  const rateOf = (c: Currency | undefined) => (c === "TRY" || !c ? 1 : fx.data?.rates[c]?.rate ?? 1);
  const addLine = (p: Product) => {
    if (lines.some((l) => l.product.id === p.id)) return;
    const price = p.purchase_currency === currency ? p.purchase_price ?? 0 : ((p.purchase_price ?? 0) * rateOf(p.purchase_currency)) / rateOf(currency);
    const need = Math.max(1, Math.ceil(p.min_stock * 2 - p.stock_qty));
    setLines((ls) => [...ls, { product: p, qty: String(need), price: decimalInput(Math.round(price * 100) / 100) }]);
  };
  const total = lines.reduce((s, l) => s + (parseDecimal(l.qty) ?? 0) * (parseDecimal(l.price) ?? 0), 0);

  const save = async () => {
    setBusy(true);
    setError(null);
    try {
      const po = await api.post<OrderDetail>("/purchase-orders", {
        supplier_id: Number(supplierId),
        currency,
        expected_at: expected || null,
        note,
        items: lines.map((l) => ({ product_id: l.product.id, qty: parseDecimal(l.qty) ?? 0, unit_price: parseDecimal(l.price) ?? 0 })),
      });
      await qc.invalidateQueries({ queryKey: ["orders"] });
      toast({ title: "Taslak sipariş oluşturuldu", message: po.order_no });
      navigate(`/siparisler/${po.id}`);
    } catch (e) {
      setError(e instanceof ApiError ? e.message : "Kaydedilemedi.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="pb-10">
      <PageHeader
        title="Yeni satın alma siparişi"
        sub="Sipariş taslak olarak kaydedilir; ardından 'Sipariş verildi' olarak işaretleyip mal kabul yapılır."
        actions={
          <>
            <Button variant="ghost" onClick={() => navigate(-1)}>
              Vazgeç
            </Button>
            <Button variant="primary" onClick={save} loading={busy} disabled={!supplierId || !lines.length}>
              Taslağı kaydet
            </Button>
          </>
        }
      />
      {error && <p className="mx-4 md:mx-6 mb-3 text-13 text-crit border-l-2 border-crit pl-2">{error}</p>}
      <div className="grid xl:grid-cols-[320px_1fr] gap-4 px-4 md:px-6">
        <Panel title="Sipariş">
          <div className="p-4 flex flex-col gap-3">
            <Field label="Tedarikçi" required>
              {(id) => (
                <Select id={id} value={supplierId} onChange={(e) => setSupplierId(e.target.value)}>
                  <option value="">Seçin…</option>
                  {suppliers.data?.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.name}
                    </option>
                  ))}
                </Select>
              )}
            </Field>
            <Field label="Para birimi" hint={currency !== "TRY" ? `Güncel kur ${rate(rateOf(currency))}` : undefined}>
              {(id) => (
                <Select id={id} value={currency} onChange={(e) => setCurrency(e.target.value as Currency)}>
                  <option value="TRY">TRY</option>
                  <option value="USD">USD</option>
                  <option value="EUR">EUR</option>
                </Select>
              )}
            </Field>
            <Field label="Beklenen teslim">{(id) => <Input id={id} type="date" mono value={expected} onChange={(e) => setExpected(e.target.value)} />}</Field>
            <Field label="Not">{(id) => <Textarea id={id} rows={2} value={note} onChange={(e) => setNote(e.target.value)} />}</Field>
          </div>
        </Panel>
        <Panel title="Kalemler" right={<span className="num text-13">{rate(total)} {currency}</span>}>
          <div className="p-3 border-b border-rule">
            <ProductSearch placeholder="Ürün ekle: ad, SKU veya barkod…" onPick={addLine} filter={(p) => p.unit_type !== "SERVICE"} />
          </div>
          {lines.length === 0 ? (
            <p className="px-4 py-6 text-13 text-ink-2">Ürün arayarak kalem ekleyin. Miktar varsayılan olarak min. stoğun iki katını tamamlayacak şekilde önerilir.</p>
          ) : (
            <table className="w-full text-13">
              <thead>
                <tr className="border-b border-rule-strong font-cond text-11 uppercase tracking-[.06em] text-ink-3 text-left" lang="tr">
                  <th className="pl-4 py-1.5 font-medium">Ürün</th>
                  <th className="px-2 font-medium text-right">Stok</th>
                  <th className="px-2 font-medium text-right w-28">Miktar</th>
                  <th className="px-2 font-medium text-right w-32">Birim fiyat ({currency})</th>
                  <th className="px-2 font-medium text-right">Tutar</th>
                  <th className="w-10" />
                </tr>
              </thead>
              <tbody>
                {lines.map((l, i) => (
                  <tr key={l.product.id} className="border-b border-rule" style={{ height: "var(--row-h)" }}>
                    <td className="pl-4">
                      {l.product.name}
                      <div className="num text-11 text-ink-3">{l.product.sku}</div>
                    </td>
                    <td className="px-2 text-right num text-12 text-ink-2">{fmtQty(l.product.stock_qty, l.product.unit_type)}</td>
                    <td className="px-2">
                      <Input
                        mono
                        align="right"
                        className="h-7"
                        aria-label="Miktar"
                        value={l.qty}
                        onChange={(e) => setLines((ls) => ls.map((x, j) => (j === i ? { ...x, qty: e.target.value } : x)))}
                      />
                    </td>
                    <td className="px-2">
                      <Input
                        mono
                        align="right"
                        className="h-7"
                        aria-label="Birim fiyat"
                        value={l.price}
                        onChange={(e) => setLines((ls) => ls.map((x, j) => (j === i ? { ...x, price: e.target.value } : x)))}
                      />
                    </td>
                    <td className="px-2 text-right num">{rate((parseDecimal(l.qty) ?? 0) * (parseDecimal(l.price) ?? 0))}</td>
                    <td className="pr-2 text-right">
                      <IconButton icon={Trash2} label="Kalemi sil" size={26} onClick={() => setLines((ls) => ls.filter((_, j) => j !== i))} />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </Panel>
      </div>
    </div>
  );
}
