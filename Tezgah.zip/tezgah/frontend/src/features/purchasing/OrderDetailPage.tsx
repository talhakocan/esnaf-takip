import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Ban, PackageOpen, Send } from "lucide-react";
import { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { useCan } from "@/app/auth";
import { useCrumb } from "@/app/crumbs";
import { Button } from "@/design/Button";
import { useConfirm } from "@/design/Dialog";
import { ErrorState, Loading } from "@/design/Feedback";
import { Led, Qty } from "@/design/Indicators";
import { Checkbox, Field, Input, Textarea } from "@/design/Input";
import { KeyValues, Panel } from "@/design/Page";
import { useToast } from "@/design/Toast";
import { ApiError, api, errorMessage } from "@/lib/api";
import { dateOnly, dateTime, decimalInput, money, parseDecimal, rate } from "@/lib/format";
import { PO_STATUS_TONE, PO_STATUS_TR } from "@/lib/labels";
import type { OrderDetail } from "@/lib/types";

export default function OrderDetailPage() {
  const { id } = useParams();
  const qc = useQueryClient();
  const toast = useToast();
  const confirm = useConfirm();
  const canWrite = useCan("purchase.write");
  const canReceive = useCan("purchase.receive");
  const q = useQuery({ queryKey: ["order", id], queryFn: () => api.get<OrderDetail>(`/purchase-orders/${id}`) });
  const o = q.data;
  useCrumb(o?.order_no);
  const [recv, setRecv] = useState<Record<number, { qty: string; serials: string }>>({});
  const [fxRate, setFxRate] = useState("");
  const [updatePrice, setUpdatePrice] = useState(true);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!o) return;
    setRecv(Object.fromEntries(o.items.map((i) => [i.id, { qty: i.remaining > 0 ? decimalInput(i.remaining) : "", serials: "" }])));
    setFxRate(o.current_rate ? decimalInput(o.current_rate) : "");
  }, [o]);

  if (q.isLoading) return <Loading />;
  if (q.isError || !o) return <ErrorState error={q.error} onRetry={() => q.refetch()} />;
  const refresh = async () => {
    await qc.invalidateQueries({ queryKey: ["order", id] });
    await qc.invalidateQueries({ queryKey: ["orders"] });
    await qc.invalidateQueries({ queryKey: ["products"] });
  };
  const action = async (path: string, msg: string) => {
    try {
      await api.post(`/purchase-orders/${o.id}/${path}`);
      toast({ title: msg });
      await refresh();
    } catch (e) {
      toast({ tone: "crit", title: "İşlem yapılamadı", message: errorMessage(e) });
    }
  };
  const receivable = ["DRAFT", "ORDERED", "PARTIAL"].includes(o.status) && o.items.some((i) => i.remaining > 0);
  const receive = async () => {
    const items = o.items
      .map((i) => ({ item: i, qty: parseDecimal(recv[i.id]?.qty ?? "") ?? 0, serials: (recv[i.id]?.serials ?? "").split(/\s*[\n,;]\s*/).filter(Boolean) }))
      .filter((x) => x.qty > 0);
    if (!items.length) return;
    setBusy(true);
    setErrors({});
    try {
      await api.post(`/purchase-orders/${o.id}/receive`, {
        items: items.map((x) => ({ item_id: x.item.id, qty: x.qty, serials: x.serials })),
        fx_rate: o.currency === "TRY" ? null : parseDecimal(fxRate),
        update_purchase_price: updatePrice,
      });
      toast({ title: "Mal kabul yapıldı", message: `${items.length} kalem stoğa girdi` });
      await refresh();
    } catch (e) {
      if (e instanceof ApiError) {
        const fieldErrors: Record<string, string> = { _: e.message };
        Object.entries(e.fields).forEach(([k, v]) => {
          const m = /^items\.(\d+)\./.exec(k);
          if (m) fieldErrors[String(items[Number(m[1])].item.id)] = v;
        });
        setErrors(fieldErrors);
      }
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="pb-10">
      <div className="px-4 md:px-6 pt-5 pb-4 flex flex-wrap justify-between gap-4">
        <div>
          <Led tone={PO_STATUS_TONE[o.status]}>{PO_STATUS_TR[o.status]}</Led>
          <h1 className="font-cond text-20 font-semibold num mt-1">{o.order_no}</h1>
          <div className="text-13 text-ink-2">
            <Link to={`/tedarikciler/${o.supplier_id}`} className="underline decoration-rule-strong">
              {o.supplier_name}
            </Link>{" "}
            · {o.currency} · oluşturan {o.created_by_name ?? "—"}
          </div>
        </div>
        <div className="flex flex-wrap gap-2 items-start">
          {canWrite && (o.status === "DRAFT" || o.status === "ORDERED") && (
            <Button
              variant="danger"
              icon={Ban}
              onClick={async () => {
                if (await confirm({ title: "Sipariş iptal edilsin mi?", confirmLabel: "İptal et", danger: true })) void action("cancel", "Sipariş iptal edildi");
              }}
            >
              İptal
            </Button>
          )}
          {canWrite && o.status === "DRAFT" && (
            <Button variant="primary" icon={Send} onClick={() => void action("order", "Sipariş verildi olarak işaretlendi")}>
              Sipariş verildi
            </Button>
          )}
        </div>
      </div>

      <div className="grid xl:grid-cols-[1fr_320px] gap-4 px-4 md:px-6">
        <Panel title={receivable && canReceive ? "Kalemler ve mal kabul" : "Kalemler"} right={o.total !== null ? <span className="num text-13">{rate(o.total)} {o.currency}</span> : undefined}>
          <div className="overflow-x-auto">
            <table className="w-full text-13">
              <thead>
                <tr className="border-b border-rule-strong font-cond text-11 uppercase tracking-[.06em] text-ink-3 text-left" lang="tr">
                  <th className="pl-4 py-1.5 font-medium">Ürün</th>
                  <th className="px-2 font-medium text-right">Sipariş</th>
                  <th className="px-2 font-medium text-right">Gelen</th>
                  {o.items[0]?.unit_price !== null && <th className="px-2 font-medium text-right">Birim ({o.currency})</th>}
                  {receivable && canReceive && <th className="px-2 font-medium text-right w-40">Şimdi gelen</th>}
                </tr>
              </thead>
              <tbody>
                {o.items.map((i) => (
                  <tr key={i.id} className="border-b border-rule align-top">
                    <td className="pl-4 py-2">
                      <Link to={`/urunler/${i.product_id}`} className="hover:underline">
                        {i.name}
                      </Link>
                      <div className="num text-11 text-ink-3">{i.sku}</div>
                      {errors[String(i.id)] && <div className="text-12 text-crit">{errors[String(i.id)]}</div>}
                    </td>
                    <td className="px-2 py-2 text-right">
                      <Qty value={i.qty} unit={i.unit_type} />
                    </td>
                    <td className="px-2 py-2 text-right">
                      <Qty value={i.received_qty} unit={i.unit_type} className={i.remaining <= 0 ? "text-ok" : undefined} />
                    </td>
                    {i.unit_price !== null && <td className="px-2 py-2 text-right num">{rate(i.unit_price)}</td>}
                    {receivable && canReceive && (
                      <td className="px-2 py-2">
                        {i.remaining > 0 && (
                          <div className="flex flex-col gap-1.5 items-end">
                            <Input
                              mono
                              align="right"
                              className="h-7 w-24"
                              aria-label={`${i.name} gelen miktar`}
                              value={recv[i.id]?.qty ?? ""}
                              onChange={(e) => setRecv((r) => ({ ...r, [i.id]: { ...r[i.id], qty: e.target.value } }))}
                            />
                            {i.track_serial && (
                              <Textarea
                                className="font-mono text-12 w-40 min-h-16"
                                rows={3}
                                aria-label={`${i.name} seri numaraları`}
                                placeholder="Seri no (satır başına bir)"
                                value={recv[i.id]?.serials ?? ""}
                                onChange={(e) => setRecv((r) => ({ ...r, [i.id]: { ...r[i.id], serials: e.target.value } }))}
                              />
                            )}
                          </div>
                        )}
                      </td>
                    )}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          {receivable && canReceive && (
            <div className="p-4 border-t border-rule flex flex-wrap items-end gap-4">
              {o.currency !== "TRY" && (
                <Field label={`Kabul kuru (${o.currency}/TRY)`} hint="Birim maliyet bu kurla TL'ye çevrilir">
                  {(fid) => <Input id={fid} mono align="right" className="w-32" value={fxRate} onChange={(e) => setFxRate(e.target.value)} />}
                </Field>
              )}
              <Checkbox label="Ürün kartlarındaki alış fiyatını güncelle" checked={updatePrice} onChange={(e) => setUpdatePrice(e.target.checked)} />
              {errors._ && <p className="text-13 text-crit w-full">{errors._}</p>}
              <Button variant="primary" icon={PackageOpen} className="ml-auto" onClick={receive} loading={busy}>
                Mal kabul et
              </Button>
            </div>
          )}
        </Panel>
        <aside>
          <Panel title="Bilgiler">
            <KeyValues
              rows={[
                ["Oluşturma", <span className="num">{dateTime(o.created_at)}</span>],
                ["Sipariş tarihi", o.ordered_at ? <span className="num">{dateTime(o.ordered_at)}</span> : "—"],
                ["Beklenen", o.expected_at ? <span className="num">{dateOnly(o.expected_at)}</span> : "—"],
                ["Teslim", o.received_at ? <span className="num">{dateTime(o.received_at)}</span> : "—"],
                ["Sipariş kuru", o.fx_rate !== null && o.currency !== "TRY" ? <span className="num">{rate(o.fx_rate)}</span> : "—"],
                ["TL karşılığı", o.total !== null && o.current_rate ? <span className="num">{money(Math.round(o.total * o.current_rate * 100))}</span> : "—"],
                ["Not", o.note || null],
              ]}
            />
          </Panel>
        </aside>
      </div>
    </div>
  );
}
