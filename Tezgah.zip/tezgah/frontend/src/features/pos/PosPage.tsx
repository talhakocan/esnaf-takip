import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Camera, Minus, Plus, ScanBarcode, Trash2, UserRound, X } from "lucide-react";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Link } from "react-router-dom";
import { useCan, useMe } from "@/app/auth";
import { Button, IconButton } from "@/design/Button";
import { cx } from "@/design/cx";
import { useConfirm } from "@/design/Dialog";
import { EmptyState } from "@/design/Feedback";
import { Money } from "@/design/Indicators";
import { Kbd } from "@/design/Kbd";
import { useToast } from "@/design/Toast";
import { ApiError, api } from "@/lib/api";
import { cartTotals, lineGross } from "@/lib/cart";
import { addDays, isoDate, money, moneyInput, parseDecimal, parseMoney, pct, phone, qty as fmtQty } from "@/lib/format";
import { useDebounced, useSettings, useTitle } from "@/lib/hooks";
import { printNode } from "@/lib/print";
import { useHotkeys } from "@/lib/shortcuts";
import { readStore, writeStore } from "@/lib/storage";
import type { Customer, Lookup, Product, Report, SaleDetail } from "@/lib/types";
import { CameraScanner } from "../shared/CameraScanner";
import { CustomerPickerDialog } from "../shared/Pickers";
import { Receipt80, SaleSummaryA4 } from "../sales/Receipt";
import { DoneDialog, PaymentDialog } from "./PaymentDialog";
import { SerialPickerDialog } from "./SerialPicker";

export interface CartLine {
  key: string;
  product_id: number;
  name: string;
  sku: string;
  unit_type: Product["unit_type"];
  unit_price: number;
  list_price: number;
  vat_rate: number;
  qty: number;
  qtyText?: string;
  discount: number;
  serial_id?: number;
  serial_no?: string;
  stock_qty: number;
}

interface CartState {
  lines: CartLine[];
  customer: Customer | null;
  discount: number;
}

const EMPTY_CART: CartState = { lines: [], customer: null, discount: 0 };
const CART_KEY = "tezgah.cart";

function beep(ok: boolean) {
  try {
    const ctx = new AudioContext();
    const o = ctx.createOscillator();
    const g = ctx.createGain();
    o.frequency.value = ok ? 1320 : 220;
    g.gain.value = 0.04;
    o.connect(g).connect(ctx.destination);
    o.start();
    o.stop(ctx.currentTime + (ok ? 0.06 : 0.2));
    o.onended = () => void ctx.close();
  } catch {
    /* ses çalınamıyorsa yok say */
  }
}

export default function PosPage() {
  useTitle("Hızlı Satış");
  const me = useMe();
  const canEditPrice = useCan("product.write");
  const toast = useToast();
  const confirm = useConfirm();
  const qc = useQueryClient();
  const settings = useSettings();
  const inputRef = useRef<HTMLInputElement>(null);
  const [cart, setCart] = useState<CartState>(() => readStore(CART_KEY, EMPTY_CART, "session"));
  const [selected, setSelected] = useState(() => Math.max(0, cart.lines.length - 1));
  const [code, setCode] = useState("");
  const [searchIdx, setSearchIdx] = useState(-1);
  const [serialFor, setSerialFor] = useState<Product | null>(null);
  const [customerOpen, setCustomerOpen] = useState(false);
  const [payOpen, setPayOpen] = useState(false);
  const [cameraOpen, setCameraOpen] = useState(false);
  const [done, setDone] = useState<{ sale: SaleDetail; change: number | null } | null>(null);
  const [discountText, setDiscountText] = useState(cart.discount ? moneyInput(cart.discount) : "");

  useEffect(() => writeStore(CART_KEY, cart, "session"), [cart]);
  const focusInput = useCallback(() => window.setTimeout(() => inputRef.current?.focus(), 30), []);
  const anyDialog = serialFor || customerOpen || payOpen || cameraOpen || done;
  useEffect(() => {
    if (!anyDialog) focusInput();
  }, [anyDialog, focusInput]);

  const today = new Date();
  const frequent = useQuery({
    queryKey: ["pos-frequent"],
    queryFn: () => api.get<Report>("/reports/top-products", { from: isoDate(addDays(today, -30)), to: isoDate(today) }),
    staleTime: 10 * 60_000,
  });
  const favorites = (frequent.data?.tables.find((t) => t.key === "by_qty")?.rows ?? []).slice(0, 9) as { sku: string; name: string }[];

  const dq = useDebounced(code.trim(), 180);
  const search = useQuery({
    queryKey: ["pos-search", dq],
    queryFn: () => api.get<Product[]>("/products", { q: dq }),
    enabled: dq.length >= 2 && !/^\d{6,}$/.test(dq),
    staleTime: 15_000,
  });
  const results = useMemo(() => (code.trim().length >= 2 ? (search.data ?? []).slice(0, 8) : []), [code, search.data]);

  const totals = useMemo(() => cartTotals(cart.lines, cart.discount), [cart.lines, cart.discount]);
  const overLimit = me.role !== "ADMIN" && totals.discountPct > me.max_discount_pct + 1e-9;

  const updateLine = (idx: number, patch: Partial<CartLine>) =>
    setCart((c) => ({ ...c, lines: c.lines.map((l, i) => (i === idx ? { ...l, ...patch } : l)) }));
  const removeLine = (idx: number) => {
    setCart((c) => ({ ...c, lines: c.lines.filter((_, i) => i !== idx) }));
    setSelected((s) => Math.max(0, Math.min(s, cart.lines.length - 2)));
  };

  const addProduct = useCallback(
    (p: Product, serial?: { id: number; serial_no: string; status: string } | null) => {
      if (!p.is_active) {
        toast({ tone: "crit", title: "Ürün arşivde", message: p.name });
        beep(false);
        return;
      }
      if (p.track_serial) {
        if (serial && (serial.status === "IN_STOCK" || serial.status === "RETURNED")) {
          if (cart.lines.some((l) => l.serial_id === serial.id)) {
            toast({ tone: "warn", title: "Bu seri numarası zaten sepette", message: serial.serial_no });
            return;
          }
          setCart((c) => ({
            ...c,
            lines: [
              ...c.lines,
              {
                key: `${p.id}-${serial.id}`,
                product_id: p.id,
                name: p.name,
                sku: p.sku,
                unit_type: p.unit_type,
                unit_price: p.sale_price_kurus,
                list_price: p.sale_price_kurus,
                vat_rate: p.vat_rate,
                qty: 1,
                discount: 0,
                serial_id: serial.id,
                serial_no: serial.serial_no,
                stock_qty: p.stock_qty,
              },
            ],
          }));
          setSelected(cart.lines.length);
          beep(true);
          return;
        }
        setSerialFor(p);
        return;
      }
      const idx = cart.lines.findIndex((l) => l.product_id === p.id && !l.serial_id);
      if (p.unit_type !== "SERVICE" && p.stock_qty <= (idx >= 0 ? cart.lines[idx].qty : 0)) {
        toast({ tone: "warn", title: "Stok yetersiz", message: `${p.name} · stok ${fmtQty(p.stock_qty, p.unit_type)}` });
      }
      if (idx >= 0) {
        updateLine(idx, { qty: cart.lines[idx].qty + 1, qtyText: undefined });
        setSelected(idx);
      } else {
        setCart((c) => ({
          ...c,
          lines: [
            ...c.lines,
            {
              key: `${p.id}-${Date.now()}`,
              product_id: p.id,
              name: p.name,
              sku: p.sku,
              unit_type: p.unit_type,
              unit_price: p.sale_price_kurus,
              list_price: p.sale_price_kurus,
              vat_rate: p.vat_rate,
              qty: 1,
              discount: 0,
              stock_qty: p.stock_qty,
            },
          ],
        }));
        setSelected(cart.lines.length);
      }
      beep(true);
    },
    [cart.lines, toast],
  );

  const handleCode = useCallback(
    async (raw: string) => {
      const value = raw.trim();
      if (!value) return;
      try {
        const hit = await api.get<Lookup>("/products/lookup", { code: value });
        addProduct(hit.product, hit.serial);
        setCode("");
        setSearchIdx(-1);
      } catch (e) {
        if (e instanceof ApiError && e.status === 404) {
          const pick = results[searchIdx >= 0 ? searchIdx : 0];
          if (pick && !/^\d{6,}$/.test(value)) {
            addProduct(pick);
            setCode("");
            setSearchIdx(-1);
            return;
          }
          beep(false);
          toast({ tone: "crit", title: "Ürün bulunamadı", message: value });
        } else {
          toast({ tone: "crit", title: "Arama yapılamadı", message: e instanceof Error ? e.message : undefined });
        }
      }
    },
    [addProduct, results, searchIdx, toast],
  );

  const clearCart = async (ask = true) => {
    if (ask && cart.lines.length) {
      const ok = await confirm({ title: "Sepet temizlensin mi?", message: `${cart.lines.length} kalem silinecek.`, confirmLabel: "Temizle", danger: true });
      if (!ok) return;
    }
    setCart(EMPTY_CART);
    setDiscountText("");
    setSelected(0);
    focusInput();
  };

  const openPayment = () => {
    if (!cart.lines.length) {
      toast({ tone: "warn", title: "Sepet boş", message: "Önce ürün okutun." });
      return;
    }
    if (cart.lines.some((l) => !l.qty || l.qty <= 0)) {
      toast({ tone: "warn", title: "Miktarı sıfır olan satır var" });
      return;
    }
    setPayOpen(true);
  };

  useHotkeys(
    {
      F7: () => setCustomerOpen(true),
      F9: openPayment,
      Escape: () => {
        if (!document.querySelector("[role=dialog]")) void clearCart();
      },
      ...Object.fromEntries(
        favorites.map((f, i) => [
          `Alt+${i + 1}`,
          () => {
            void handleCode(f.sku);
          },
        ]),
      ),
    },
    !anyDialog,
  );

  const onInputKey = (e: React.KeyboardEvent<HTMLInputElement>) => {
    const empty = code === "";
    if (e.key === "Enter") {
      e.preventDefault();
      if (empty) return;
      void handleCode(code);
    } else if (e.key === "ArrowDown") {
      e.preventDefault();
      if (results.length && !empty) setSearchIdx((i) => Math.min(i + 1, results.length - 1));
      else setSelected((s) => Math.min(s + 1, cart.lines.length - 1));
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      if (results.length && !empty) setSearchIdx((i) => Math.max(i - 1, 0));
      else setSelected((s) => Math.max(s - 1, 0));
    } else if (empty && (e.key === "+" || e.key === "-") && cart.lines[selected]) {
      e.preventDefault();
      const l = cart.lines[selected];
      if (l.serial_id) return;
      const next = Math.max(l.unit_type === "METER" ? 0.5 : 1, l.qty + (e.key === "+" ? 1 : -1));
      updateLine(selected, { qty: next, qtyText: undefined });
    } else if (empty && e.key === "Delete" && cart.lines[selected]) {
      e.preventDefault();
      removeLine(selected);
    }
  };

  const onPaid = async (sale: SaleDetail, change: number | null) => {
    setPayOpen(false);
    setCart(EMPTY_CART);
    setDiscountText("");
    setSelected(0);
    setDone({ sale, change });
    await Promise.all([
      qc.invalidateQueries({ queryKey: ["status"] }),
      qc.invalidateQueries({ queryKey: ["products"] }),
      qc.invalidateQueries({ queryKey: ["dashboard"] }),
      qc.invalidateQueries({ queryKey: ["sales"] }),
    ]);
  };

  const printReceipt = (kind: "receipt80" | "a4") => {
    if (!done || !settings.data) return;
    printNode(kind === "receipt80" ? <Receipt80 sale={done.sale} settings={settings.data} /> : <SaleSummaryA4 sale={done.sale} settings={settings.data} />, kind);
  };

  return (
    <div className="min-h-full lg:h-full grid lg:grid-cols-[1fr_360px]">
      {/* Sol: okutma + sepet */}
      <div className="flex flex-col min-h-0 min-w-0">
        <div className="px-4 md:px-6 pt-4 pb-3 bg-surface border-b border-rule">
          <div className="flex gap-2">
            <div className="relative flex-1">
              <ScanBarcode size={18} strokeWidth={1.5} className="absolute left-3 top-1/2 -translate-y-1/2 text-ink-3 pointer-events-none" aria-hidden />
              <input
                ref={inputRef}
                autoFocus
                value={code}
                onChange={(e) => {
                  setCode(e.target.value);
                  setSearchIdx(-1);
                }}
                onKeyDown={onInputKey}
                data-page-search
                placeholder="Barkod okutun veya ürün adı / SKU yazın…"
                aria-label="Barkod veya ürün ara"
                className="w-full h-10 pl-10 pr-3 rounded-ctl border border-ink bg-paper font-mono text-16 placeholder:font-sans placeholder:text-14 placeholder:text-ink-3 focus-visible:outline-2 focus-visible:outline-signal"
                autoComplete="off"
                spellCheck={false}
              />
              {results.length > 0 && (
                <ul className="absolute z-30 mt-1 w-full bg-surface border border-rule shadow-pop" role="listbox" aria-label="Ürün önerileri">
                  {results.map((p, i) => (
                    <li
                      key={p.id}
                      role="option"
                      aria-selected={i === searchIdx}
                      onMouseDown={(e) => {
                        e.preventDefault();
                        addProduct(p);
                        setCode("");
                      }}
                      className={cx(
                        "flex items-center gap-3 px-3 h-9 text-13 cursor-pointer hover:bg-surface-2",
                        i === searchIdx && "bg-surface-2 shadow-[inset_2px_0_0_var(--signal)]",
                      )}
                    >
                      <span className="num text-12 text-ink-3 w-24 truncate">{p.sku}</span>
                      <span className="flex-1 truncate">{p.name}</span>
                      <span className="num text-12 text-ink-2">{fmtQty(p.stock_qty, p.unit_type)}</span>
                      <span className="num w-24 text-right">{money(p.sale_price_kurus)}</span>
                    </li>
                  ))}
                </ul>
              )}
            </div>
            <Button size="lg" icon={Camera} onClick={() => setCameraOpen(true)} aria-label="Kamerayla oku">
              <span className="hidden sm:inline">Kamerayla oku</span>
            </Button>
          </div>
          {favorites.length > 0 && (
            <div className="flex flex-wrap gap-1.5 mt-2.5" aria-label="Sık satılanlar">
              {favorites.map((f, i) => (
                <button
                  key={f.sku}
                  type="button"
                  onClick={() => void handleCode(f.sku)}
                  title={`${f.name} (Alt+${i + 1})`}
                  className="flex items-center gap-2 h-8 pl-1 pr-2.5 max-w-[190px] rounded-ctl border border-rule-strong bg-surface hover:bg-surface-2 cursor-pointer text-12"
                >
                  <span className="inline-flex items-center justify-center size-6 border border-rule-strong rounded-ctl bg-paper num text-12 shadow-[inset_0_-2px_0_var(--rule)]">
                    {i + 1}
                  </span>
                  <span className="truncate">{f.name}</span>
                </button>
              ))}
            </div>
          )}
        </div>

        <div className="flex-1 min-h-[240px] overflow-y-auto scroll-thin bg-surface">
          {cart.lines.length === 0 ? (
            <EmptyState
              icon="connector"
              title="Sepet boş. Barkod okutun, ürün adı yazın ya da sık satılanlardan seçin."
              action={
                <div className="flex flex-wrap gap-3 text-12 text-ink-3">
                  <span>
                    <Kbd>F7</Kbd> müşteri
                  </span>
                  <span>
                    <Kbd>F9</Kbd> ödeme
                  </span>
                  <span>
                    <Kbd>Alt+1…9</Kbd> sık satılan
                  </span>
                </div>
              }
            />
          ) : (
            <table className="w-full text-13">
              <thead className="sticky top-0 bg-surface z-10">
                <tr className="border-b border-rule-strong font-cond text-11 uppercase tracking-[.06em] text-ink-3" lang="tr">
                  <th className="w-10 pl-4 md:pl-6 text-left font-medium h-8">#</th>
                  <th className="text-left font-medium px-2">Ürün</th>
                  <th className="text-left font-medium px-2 hidden xl:table-cell">SKU</th>
                  <th className="text-right font-medium px-2 w-36">Miktar</th>
                  <th className="text-right font-medium px-2 w-32">Birim fiyat</th>
                  <th className="text-right font-medium px-2 w-28">İndirim</th>
                  <th className="text-right font-medium px-2 w-32">Tutar</th>
                  <th className="w-10 pr-4" />
                </tr>
              </thead>
              <tbody>
                {cart.lines.map((l, i) => {
                  const total = lineGross(l) - l.discount;
                  const priceEditable = l.unit_type === "SERVICE" || canEditPrice;
                  return (
                    <tr
                      key={l.key}
                      onClick={() => setSelected(i)}
                      className={cx(
                        "border-b border-rule cursor-default",
                        i === selected ? "bg-surface-2 shadow-[inset_2px_0_0_var(--signal)]" : "hover:bg-surface-2",
                      )}
                      style={{ height: "var(--row-h)" }}
                      aria-selected={i === selected}
                    >
                      <td className="pl-4 md:pl-6 num text-12 text-ink-3">{i + 1}</td>
                      <td className="px-2 py-1">
                        <div className="truncate max-w-[320px]">{l.name}</div>
                        {l.serial_no && <div className="num text-11 text-ink-2">SN {l.serial_no}</div>}
                      </td>
                      <td className="px-2 num text-12 text-ink-3 hidden xl:table-cell">{l.sku}</td>
                      <td className="px-2">
                        <div className="flex items-center justify-end gap-1">
                          {!l.serial_id && (
                            <IconButton
                              icon={Minus}
                              label="Azalt"
                              size={24}
                              tabIndex={-1}
                              onClick={() => updateLine(i, { qty: Math.max(l.unit_type === "METER" ? 0.5 : 1, l.qty - 1), qtyText: undefined })}
                            />
                          )}
                          <input
                            aria-label={`${l.name} miktar`}
                            className="w-16 h-7 text-right num border border-rule-strong rounded-ctl bg-surface px-1.5 disabled:border-transparent disabled:bg-transparent"
                            value={l.qtyText ?? String(l.qty).replace(".", ",")}
                            disabled={!!l.serial_id}
                            inputMode="decimal"
                            onFocus={() => setSelected(i)}
                            onChange={(e) => {
                              const n = parseDecimal(e.target.value);
                              updateLine(i, { qtyText: e.target.value, qty: n !== null && n > 0 ? (l.unit_type === "PIECE" ? Math.round(n) : n) : 0 });
                            }}
                            onBlur={() => updateLine(i, { qtyText: undefined })}
                            onKeyDown={(e) => e.key === "Enter" && focusInput()}
                          />
                          <span className="text-11 text-ink-3 w-4">{l.unit_type === "METER" ? "m" : l.unit_type === "PIECE" ? "ad" : ""}</span>
                          {!l.serial_id && (
                            <IconButton icon={Plus} label="Artır" size={24} tabIndex={-1} onClick={() => updateLine(i, { qty: l.qty + 1, qtyText: undefined })} />
                          )}
                        </div>
                      </td>
                      <td className="px-2 text-right">
                        {priceEditable ? (
                          <input
                            aria-label={`${l.name} birim fiyat`}
                            className="w-24 h-7 text-right num border border-rule-strong rounded-ctl bg-surface px-1.5"
                            defaultValue={moneyInput(l.unit_price)}
                            key={`p-${l.key}-${l.unit_price}`}
                            onBlur={(e) => {
                              const v = parseMoney(e.target.value);
                              if (v !== null && v >= 0) updateLine(i, { unit_price: v });
                            }}
                          />
                        ) : (
                          <Money value={l.unit_price} />
                        )}
                        {l.unit_price !== l.list_price && <div className="num text-11 text-ink-3 line-through">{money(l.list_price)}</div>}
                      </td>
                      <td className="px-2 text-right">
                        <input
                          aria-label={`${l.name} indirim`}
                          className="w-20 h-7 text-right num border border-rule-strong rounded-ctl bg-surface px-1.5"
                          defaultValue={l.discount ? moneyInput(l.discount) : ""}
                          key={`d-${l.key}-${l.discount}`}
                          placeholder="0,00"
                          onBlur={(e) => {
                            const v = parseMoney(e.target.value) ?? 0;
                            updateLine(i, { discount: Math.min(Math.max(v, 0), lineGross(l)) });
                          }}
                        />
                      </td>
                      <td className="px-2 text-right">
                        <Money value={total} strong />
                      </td>
                      <td className="pr-4 text-right">
                        <IconButton icon={Trash2} label="Satırı sil" size={26} tabIndex={-1} onClick={() => removeLine(i)} />
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          )}
        </div>
        <div className="hidden lg:flex items-center gap-4 px-4 md:px-6 h-8 border-t border-rule bg-surface text-12 text-ink-3">
          <span>
            <Kbd>↑↓</Kbd> satır seç
          </span>
          <span>
            <Kbd>+</Kbd>
            <Kbd className="ml-0.5">−</Kbd> miktar
          </span>
          <span>
            <Kbd>Del</Kbd> sil
          </span>
          <span>
            <Kbd>Esc</Kbd> sepeti temizle
          </span>
          <span className="ml-auto num">{cart.lines.length} kalem</span>
        </div>
      </div>

      {/* Sağ: müşteri, toplam, ödeme */}
      <aside className="flex flex-col bg-surface border-t lg:border-t-0 lg:border-l border-rule" aria-label="Satış özeti">
        <div className="p-4 border-b border-rule">
          <div className="flex items-center justify-between mb-2">
            <span className="label-caps">Müşteri</span>
            <Kbd>F7</Kbd>
          </div>
          {cart.customer ? (
            <div className="flex items-start gap-2">
              <UserRound size={16} strokeWidth={1.5} className="mt-0.5 text-ink-3" aria-hidden />
              <div className="flex-1 min-w-0">
                <Link to={`/cari/${cart.customer.id}`} className="text-14 font-medium truncate block hover:underline">
                  {cart.customer.full_name}
                </Link>
                <div className="num text-12 text-ink-2">{phone(cart.customer.phone)}</div>
                <div className="num text-12 mt-0.5">
                  Bakiye <Money value={cart.customer.balance} className={cart.customer.balance > 0 ? "text-crit" : undefined} />
                  {cart.customer.credit_limit_kurus > 0 && <span className="text-ink-3"> / limit {money(cart.customer.credit_limit_kurus)}</span>}
                </div>
              </div>
              <IconButton icon={X} label="Müşteriyi kaldır" onClick={() => setCart((c) => ({ ...c, customer: null }))} />
            </div>
          ) : (
            <Button className="w-full" icon={UserRound} onClick={() => setCustomerOpen(true)}>
              Müşteri seç (isteğe bağlı)
            </Button>
          )}
        </div>

        <div className="p-4 flex flex-col gap-1.5 text-13 border-b border-rule">
          <div className="flex justify-between">
            <span className="text-ink-2">Ara toplam</span>
            <Money value={totals.gross} />
          </div>
          {totals.lineDiscounts > 0 && (
            <div className="flex justify-between">
              <span className="text-ink-2">Satır indirimleri</span>
              <Money value={-totals.lineDiscounts} />
            </div>
          )}
          <div className="flex justify-between items-center gap-3">
            <label htmlFor="pos-discount" className="text-ink-2">
              Genel indirim (₺)
            </label>
            <input
              id="pos-discount"
              className="w-28 h-7 text-right num border border-rule-strong rounded-ctl bg-surface px-1.5"
              value={discountText}
              placeholder="0,00"
              inputMode="decimal"
              onChange={(e) => setDiscountText(e.target.value)}
              onBlur={() => {
                const v = parseMoney(discountText) ?? 0;
                setCart((c) => ({ ...c, discount: Math.max(0, v) }));
                setDiscountText(v ? moneyInput(v) : "");
              }}
              onKeyDown={(e) => e.key === "Enter" && (e.currentTarget.blur(), focusInput())}
            />
          </div>
          {(totals.lineDiscounts > 0 || totals.discount > 0) && (
            <div className={cx("flex justify-between text-12", overLimit ? "text-crit" : "text-ink-3")}>
              <span>Toplam indirim oranı</span>
              <span className="num">
                {pct(totals.discountPct)}
                {overLimit && ` · yetki sınırı %${me.max_discount_pct}`}
              </span>
            </div>
          )}
          <div className="border-t border-rule mt-1.5 pt-1.5 flex flex-col gap-0.5">
            {totals.vat.map((v) => (
              <div key={v.rate} className="flex justify-between text-12 text-ink-2">
                <span>
                  KDV %{v.rate} <span className="text-ink-3">(matrah {money(v.base)})</span>
                </span>
                <span className="num">{money(v.vat)}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="p-4 mt-auto">
          <div className="label-caps">Toplam</div>
          <div className="num text-40 font-semibold leading-none mt-1 mb-4 break-all" data-testid="pos-total">
            {money(totals.total)}
          </div>
          <Button variant="signal" size="lg" className="w-full h-12 text-16" kbd="F9" onClick={openPayment} disabled={!cart.lines.length || overLimit}>
            Ödemeyi Al
          </Button>
          <Button variant="ghost" className="w-full mt-2" onClick={() => void clearCart()} disabled={!cart.lines.length} kbd="Esc">
            Sepeti temizle
          </Button>
        </div>
      </aside>

      <SerialPickerDialog
        product={serialFor}
        exclude={cart.lines.filter((l) => l.serial_id).map((l) => l.serial_id!)}
        onClose={() => setSerialFor(null)}
        onPick={(serial) => {
          if (serialFor) addProduct(serialFor, { ...serial, status: serial.status });
          setSerialFor(null);
        }}
      />
      <CustomerPickerDialog open={customerOpen} onOpenChange={setCustomerOpen} onPick={(c) => setCart((s) => ({ ...s, customer: c }))} />
      <CameraScanner open={cameraOpen} onOpenChange={setCameraOpen} onCode={(c) => void handleCode(c)} />
      {payOpen && (
        <PaymentDialog
          total={totals.total}
          customer={cart.customer}
          onSubmit={(payload) =>
            api.post<SaleDetail>("/sales", {
              customer_id: cart.customer?.id ?? null,
              discount: cart.discount,
              items: cart.lines.map((l) => ({
                product_id: l.product_id,
                qty: l.qty,
                unit_price: l.unit_price,
                discount: l.discount,
                serial_id: l.serial_id ?? null,
              })),
              ...payload,
            })
          }
          onClose={() => setPayOpen(false)}
          onPaid={onPaid}
        />
      )}
      {done && <DoneDialog sale={done.sale} change={done.change} onPrint={printReceipt} onClose={() => setDone(null)} />}
    </div>
  );
}
