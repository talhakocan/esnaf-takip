import { useQuery } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { cx } from "@/design/cx";
import { Dialog } from "@/design/Dialog";
import { Input } from "@/design/Input";
import { api } from "@/lib/api";
import type { Product, Serial } from "@/lib/types";

/** Seri takipli ürün için stoktaki seri numarasını seçtirir (seri no okutulabilir). */
export function SerialPickerDialog({
  product,
  exclude,
  onClose,
  onPick,
}: {
  product: Product | null;
  exclude: number[];
  onClose: () => void;
  onPick: (s: Serial) => void;
}) {
  const [q, setQ] = useState("");
  const [idx, setIdx] = useState(0);
  const serials = useQuery({
    queryKey: ["serials-available", product?.id],
    queryFn: () => api.get<Serial[]>(`/products/${product!.id}/serials`, { available: true }),
    enabled: !!product,
    staleTime: 0,
  });
  useEffect(() => {
    setQ("");
    setIdx(0);
  }, [product]);
  if (!product) return null;
  const list = (serials.data ?? []).filter((s) => !exclude.includes(s.id)).filter((s) => !q || s.serial_no.includes(q.trim().toUpperCase()));
  const exact = list.find((s) => s.serial_no === q.trim().toUpperCase());
  return (
    <Dialog open onOpenChange={(o) => !o && onClose()} title="Seri numarası seçin" description={product.name} width={460}>
      <div className="flex flex-col gap-3">
        <Input
          autoFocus
          mono
          placeholder="Seri numarasını okutun veya yazın…"
          value={q}
          onChange={(e) => {
            setQ(e.target.value);
            setIdx(0);
          }}
          onKeyDown={(e) => {
            if (e.key === "ArrowDown") {
              e.preventDefault();
              setIdx((i) => Math.min(i + 1, list.length - 1));
            } else if (e.key === "ArrowUp") {
              e.preventDefault();
              setIdx((i) => Math.max(i - 1, 0));
            } else if (e.key === "Enter") {
              e.preventDefault();
              const pick = exact ?? list[idx];
              if (pick) onPick(pick);
            }
          }}
          aria-label="Seri numarası"
        />
        <ul className="border border-rule max-h-72 overflow-y-auto scroll-thin" role="listbox" aria-label="Stoktaki seri numaraları">
          {serials.isLoading && <li className="px-3 py-2 text-13 text-ink-2">Yükleniyor…</li>}
          {!serials.isLoading && list.length === 0 && <li className="px-3 py-2 text-13 text-crit">Stokta uygun seri numarası yok.</li>}
          {list.map((s, i) => (
            <li
              key={s.id}
              role="option"
              aria-selected={i === idx}
              onClick={() => onPick(s)}
              className={cx("flex justify-between px-3 h-9 items-center cursor-pointer border-b border-rule last:border-b-0 num text-13", i === idx && "bg-surface-2")}
            >
              {s.serial_no}
              {s.status === "RETURNED" && <span className="font-sans text-11 text-warn">iade edilmiş</span>}
            </li>
          ))}
        </ul>
      </div>
    </Dialog>
  );
}
