import { Printer, ShieldCheck } from "lucide-react";
import { useMemo, useRef, useState } from "react";
import { Link } from "react-router-dom";
import { Button } from "@/design/Button";
import { cx } from "@/design/cx";
import { Dialog } from "@/design/Dialog";
import { Field, Input } from "@/design/Input";
import { Kbd } from "@/design/Kbd";
import { ApiError } from "@/lib/api";
import { money, moneyInput, parseMoney } from "@/lib/format";
import { METHOD_TR } from "@/lib/labels";
import { cashSuggestions } from "@/lib/pricing";
import type { Customer, PaymentMethod, SaleDetail } from "@/lib/types";

export interface PaymentPayload {
  payments: { method: PaymentMethod; amount: number; tendered: number | null }[];
  override: { username: string; password: string } | null;
}

const METHODS: PaymentMethod[] = ["CASH", "CARD", "TRANSFER", "CREDIT"];

/** Ödeme alma: bölünmüş ödeme, nakitte para üstü, kredi limiti aşımında yönetici onayı. */
export function PaymentDialog({
  total,
  customer,
  submitLabel = "Satışı tamamla",
  onSubmit,
  onClose,
  onPaid,
}: {
  total: number;
  customer: Customer | { id: number; full_name: string } | null;
  submitLabel?: string;
  onSubmit: (payload: PaymentPayload) => Promise<SaleDetail>;
  onClose: () => void;
  onPaid: (sale: SaleDetail, change: number | null) => void;
}) {
  const [amounts, setAmounts] = useState<Record<PaymentMethod, string>>({ CASH: moneyInput(total), CARD: "", TRANSFER: "", CREDIT: "" });
  const [tendered, setTendered] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [approval, setApproval] = useState<string | null>(null);
  const [adminUser, setAdminUser] = useState("");
  const [adminPass, setAdminPass] = useState("");
  const tenderedRef = useRef<HTMLInputElement>(null);

  const parsed = useMemo(() => Object.fromEntries(METHODS.map((m) => [m, parseMoney(amounts[m]) ?? 0])) as Record<PaymentMethod, number>, [amounts]);
  const paid = METHODS.reduce((s, m) => s + parsed[m], 0);
  const remaining = total - paid;
  const cash = parsed.CASH;
  const tenderedValue = parseMoney(tendered);
  const change = cash > 0 && tenderedValue !== null && tenderedValue >= cash ? tenderedValue - cash : null;
  const cashShort = cash > 0 && tenderedValue !== null && tenderedValue < cash;

  const setOnly = (m: PaymentMethod) => {
    setAmounts({ CASH: "", CARD: "", TRANSFER: "", CREDIT: "", [m]: moneyInput(total) });
    setTendered("");
  };

  const submit = async () => {
    if (remaining !== 0) {
      setError(remaining > 0 ? `Eksik ödeme: ${money(remaining)}` : `Fazla ödeme: ${money(-remaining)}`);
      return;
    }
    if (cashShort) {
      setError("Alınan nakit, nakit tutarından az olamaz.");
      return;
    }
    if (parsed.CREDIT > 0 && !customer) {
      setError("Veresiye için önce müşteri seçin (F7).");
      return;
    }
    setBusy(true);
    setError(null);
    try {
      const sale = await onSubmit({
        payments: METHODS.filter((m) => parsed[m] > 0).map((m) => ({
          method: m,
          amount: parsed[m],
          tendered: m === "CASH" && tenderedValue !== null ? tenderedValue : null,
        })),
        override: approval ? { username: adminUser, password: adminPass } : null,
      });
      onPaid(sale, change);
    } catch (e) {
      if (e instanceof ApiError && e.code === "ADMIN_APPROVAL_REQUIRED") {
        setApproval(e.message);
      } else {
        setError(e instanceof ApiError ? e.message : "Satış kaydedilemedi.");
      }
    } finally {
      setBusy(false);
    }
  };

  return (
    <Dialog
      open
      onOpenChange={(o) => !o && onClose()}
      title="Ödeme"
      width={560}
      footer={
        <>
          <Button variant="ghost" onClick={onClose}>
            Vazgeç
          </Button>
          <Button variant="signal" size="lg" onClick={() => void submit()} loading={busy} disabled={remaining !== 0} kbd="Enter">
            {approval ? "Onayla ve tamamla" : submitLabel}
          </Button>
        </>
      }
    >
      <form
        onSubmit={(e) => {
          e.preventDefault();
          void submit();
        }}
        className="flex flex-col gap-4"
      >
        <div className="flex items-end justify-between border-b border-rule pb-3">
          <div>
            <div className="label-caps">Ödenecek</div>
            <div className="num text-40 font-semibold leading-none mt-1">{money(total)}</div>
          </div>
          <div className="text-right">
            <div className="label-caps">Kalan</div>
            <div className={cx("num text-20 mt-1", remaining === 0 ? "text-ok" : "text-crit")}>{money(remaining)}</div>
          </div>
        </div>

        <div className="flex flex-wrap gap-1.5">
          {METHODS.map((m) => (
            <Button key={m} size="sm" onClick={() => setOnly(m)} disabled={m === "CREDIT" && !customer}>
              Tümü {METHOD_TR[m].toLocaleLowerCase("tr-TR")}
            </Button>
          ))}
        </div>

        <div className="grid grid-cols-2 gap-3">
          {METHODS.map((m) => (
            <Field key={m} label={METHOD_TR[m]} hint={m === "CREDIT" && !customer ? "Müşteri seçilmedi" : undefined}>
              {(id) => (
                <Input
                  id={id}
                  mono
                  align="right"
                  inputMode="decimal"
                  autoFocus={m === "CASH"}
                  placeholder="0,00"
                  value={amounts[m]}
                  disabled={m === "CREDIT" && !customer}
                  onFocus={(e) => e.currentTarget.select()}
                  onChange={(e) => setAmounts((a) => ({ ...a, [m]: e.target.value }))}
                />
              )}
            </Field>
          ))}
        </div>

        {cash > 0 && (
          <div className="border border-rule p-3 flex flex-col gap-2">
            <div className="flex items-end gap-3">
              <Field label="Alınan nakit" className="flex-1">
                {(id) => (
                  <Input
                    ref={tenderedRef}
                    id={id}
                    mono
                    align="right"
                    inputMode="decimal"
                    placeholder={moneyInput(cash)}
                    value={tendered}
                    onChange={(e) => setTendered(e.target.value)}
                    invalid={cashShort}
                  />
                )}
              </Field>
              <div className="text-right min-w-[160px]">
                <div className="label-caps">Para üstü</div>
                <div className="num text-28 font-semibold leading-tight">{change !== null ? money(change) : "—"}</div>
              </div>
            </div>
            <div className="flex flex-wrap gap-1.5">
              {cashSuggestions(cash).map((v, i) => (
                <Button
                  key={v}
                  size="sm"
                  onClick={() => {
                    setTendered(moneyInput(v));
                    tenderedRef.current?.focus();
                  }}
                >
                  <span className="num">{i === 0 ? "Tam tutar" : money(v)}</span>
                </Button>
              ))}
            </div>
          </div>
        )}

        {approval && (
          <div className="border-l-2 border-warn pl-3 flex flex-col gap-2">
            <p className="text-13 flex items-start gap-2">
              <ShieldCheck size={16} strokeWidth={1.5} className="text-warn shrink-0 mt-0.5" aria-hidden />
              {approval}
            </p>
            <div className="grid grid-cols-2 gap-2">
              <Field label="Yönetici kullanıcı adı">
                {(id) => <Input id={id} autoFocus autoComplete="off" value={adminUser} onChange={(e) => setAdminUser(e.target.value)} />}
              </Field>
              <Field label="Yönetici şifresi">
                {(id) => <Input id={id} type="password" autoComplete="off" value={adminPass} onChange={(e) => setAdminPass(e.target.value)} />}
              </Field>
            </div>
          </div>
        )}

        {error && (
          <p className="text-13 text-crit" role="alert">
            {error}
          </p>
        )}
        <p className="text-12 text-ink-3">
          <Kbd>Enter</Kbd> satışı tamamlar · <Kbd>Esc</Kbd> geri döner
        </p>
        <button type="submit" className="hidden" />
      </form>
    </Dialog>
  );
}

export function DoneDialog({
  sale,
  change,
  onPrint,
  onClose,
}: {
  sale: SaleDetail;
  change: number | null;
  onPrint: (kind: "receipt80" | "a4") => void;
  onClose: () => void;
}) {
  return (
    <Dialog
      open
      onOpenChange={(o) => !o && onClose()}
      title="Satış tamamlandı"
      width={460}
      footer={
        <>
          <Button icon={Printer} onClick={() => onPrint("a4")}>
            A4 özet
          </Button>
          <Button icon={Printer} onClick={() => onPrint("receipt80")}>
            Fiş (80 mm)
          </Button>
          <Button variant="primary" onClick={onClose} autoFocus kbd="Enter">
            Yeni satış
          </Button>
        </>
      }
    >
      <div className="flex flex-col gap-3" data-testid="sale-done">
        <div className="flex justify-between items-baseline">
          <span className="text-13 text-ink-2">Fiş no</span>
          <Link to={`/satislar/${sale.id}`} className="num text-14 underline decoration-rule-strong">
            {sale.receipt_no}
          </Link>
        </div>
        <div className="flex justify-between items-baseline">
          <span className="text-13 text-ink-2">Tutar</span>
          <span className="num text-20">{money(sale.total)}</span>
        </div>
        {change !== null && (
          <div className="flex justify-between items-baseline border-t border-rule pt-3">
            <span className="text-14">Para üstü</span>
            <span className="num text-40 font-semibold leading-none">{money(change)}</span>
          </div>
        )}
      </div>
    </Dialog>
  );
}
