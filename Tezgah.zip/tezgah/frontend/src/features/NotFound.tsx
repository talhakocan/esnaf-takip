import { ButtonLink } from "@/design/Button";
import { EmptyState } from "@/design/Feedback";

export default function NotFound() {
  return (
    <div className="px-2 md:px-4 py-8">
      <h1 className="font-cond text-20 font-semibold px-5">Sayfa bulunamadı</h1>
      <EmptyState
        icon="switch"
        title="Aradığınız ekran taşınmış veya hiç var olmamış olabilir. Menüden devam edebilirsiniz."
        action={
          <ButtonLink to="/" variant="primary">
            Panoya dön
          </ButtonLink>
        }
      />
    </div>
  );
}
