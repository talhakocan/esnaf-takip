import { Barcode } from "@/design/Codes";
import { dateOnly, dateTime, money, moneyPlain, qty } from "@/lib/format";
import { METHOD_TR } from "@/lib/labels";
import type { SaleDetail, Settings } from "@/lib/types";

const INFO_NOTE = "Bu belge bilgi fişidir, mali değeri yoktur.";

/** 80 mm termal fiş (yazdırma için siyah-beyaz, mono). */
export function Receipt80({ sale, settings }: { sale: SaleDetail; settings: Settings }) {
  const s = { fontFamily: "'IBM Plex Mono', monospace", fontSize: "11px", lineHeight: 1.35, color: "#000", width: "72mm" } as const;
  const row = "flex justify-between gap-2";
  return (
    <div style={s}>
      <div style={{ textAlign: "center" }}>
        <div style={{ fontFamily: "'IBM Plex Sans Condensed', sans-serif", fontWeight: 600, fontSize: "16px", letterSpacing: ".08em" }}>
          {settings.shop_name.toLocaleUpperCase("tr-TR")}
        </div>
        {settings.address && <div>{settings.address}</div>}
        {settings.phone && <div>Tel: {settings.phone}</div>}
        {settings.tax_no && (
          <div>
            {settings.tax_office} VD · {settings.tax_no}
          </div>
        )}
        <div style={{ margin: "6px 0 2px", fontWeight: 600 }}>BİLGİ FİŞİ</div>
      </div>
      <div style={{ borderTop: "1px dashed #000", margin: "4px 0" }} />
      <div className={row}>
        <span>Fiş no</span>
        <span>{sale.receipt_no}</span>
      </div>
      <div className={row}>
        <span>Tarih</span>
        <span>{dateTime(sale.created_at)}</span>
      </div>
      {sale.user_name && (
        <div className={row}>
          <span>Kasiyer</span>
          <span>{sale.user_name}</span>
        </div>
      )}
      {sale.customer && (
        <div className={row}>
          <span>Müşteri</span>
          <span>{sale.customer.full_name}</span>
        </div>
      )}
      {sale.status === "CANCELLED" && <div style={{ textAlign: "center", fontWeight: 600, margin: "4px 0" }}>*** İPTAL EDİLDİ ***</div>}
      <div style={{ borderTop: "1px dashed #000", margin: "4px 0" }} />
      {sale.items.map((it) => (
        <div key={it.id} style={{ marginBottom: 3 }}>
          <div>{it.product_name}</div>
          <div className={row}>
            <span>
              {qty(it.qty, it.unit_type === "SERVICE" ? "PIECE" : it.unit_type)} × {moneyPlain(it.unit_price)}
            </span>
            <span>{moneyPlain(it.line_total + it.discount)}</span>
          </div>
          {it.discount > 0 && (
            <div className={row}>
              <span> İndirim</span>
              <span>-{moneyPlain(it.discount)}</span>
            </div>
          )}
          {it.serial_no && (
            <div>
              {" "}SN: {it.serial_no}
              {it.warranty_until && ` · Garanti: ${dateOnly(it.warranty_until)}`}
            </div>
          )}
        </div>
      ))}
      <div style={{ borderTop: "1px dashed #000", margin: "4px 0" }} />
      <div className={row}>
        <span>Ara toplam</span>
        <span>{moneyPlain(sale.subtotal)}</span>
      </div>
      {sale.discount > 0 && (
        <div className={row}>
          <span>Genel indirim</span>
          <span>-{moneyPlain(sale.discount)}</span>
        </div>
      )}
      <div className={row} style={{ fontSize: "15px", fontWeight: 600, margin: "3px 0" }}>
        <span>TOPLAM</span>
        <span>{money(sale.total)}</span>
      </div>
      {sale.vat_breakdown.map((v) => (
        <div key={v.rate} className={row}>
          <span>
            KDV %{v.rate} (matrah {moneyPlain(v.base)})
          </span>
          <span>{moneyPlain(v.vat)}</span>
        </div>
      ))}
      <div style={{ borderTop: "1px dashed #000", margin: "4px 0" }} />
      {sale.payments.map((p) => (
        <div key={p.id}>
          <div className={row}>
            <span>{METHOD_TR[p.method]}</span>
            <span>{moneyPlain(p.amount)}</span>
          </div>
          {p.tendered !== null && p.change !== null && (
            <>
              <div className={row}>
                <span> Alınan</span>
                <span>{moneyPlain(p.tendered)}</span>
              </div>
              <div className={row}>
                <span> Para üstü</span>
                <span>{moneyPlain(p.change)}</span>
              </div>
            </>
          )}
        </div>
      ))}
      <div style={{ borderTop: "1px dashed #000", margin: "4px 0" }} />
      {settings.receipt_footer && <div style={{ textAlign: "center", margin: "4px 0" }}>{settings.receipt_footer}</div>}
      <div style={{ display: "flex", justifyContent: "center", margin: "6px 0 2px" }}>
        <Barcode value={sale.receipt_no} height={28} width={1.1} fontSize={10} color="#000" />
      </div>
      <div style={{ textAlign: "center", fontSize: "9.5px", marginTop: 4 }}>{INFO_NOTE}</div>
    </div>
  );
}

/** A4 "Satış Özeti" çıktısı. */
export function SaleSummaryA4({ sale, settings }: { sale: SaleDetail; settings: Settings }) {
  const cell = { padding: "4px 6px", borderBottom: "1px solid #999" } as const;
  const num = { ...cell, textAlign: "right" as const, fontFamily: "'IBM Plex Mono', monospace" };
  return (
    <div style={{ fontFamily: "'IBM Plex Sans', sans-serif", fontSize: "11pt", color: "#000" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", borderBottom: "2px solid #000", paddingBottom: 8 }}>
        <div>
          <div style={{ fontFamily: "'IBM Plex Sans Condensed'", fontWeight: 600, fontSize: "18pt", letterSpacing: ".08em" }}>
            {settings.shop_name.toLocaleUpperCase("tr-TR")}
          </div>
          <div>{settings.address}</div>
          <div>
            {settings.phone} {settings.email && `· ${settings.email}`}
          </div>
          {settings.tax_no && (
            <div>
              {settings.tax_office} VD · {settings.tax_no}
            </div>
          )}
        </div>
        <div style={{ textAlign: "right" }}>
          <div style={{ fontFamily: "'IBM Plex Sans Condensed'", fontWeight: 600, fontSize: "14pt" }}>SATIŞ ÖZETİ</div>
          <div style={{ fontFamily: "'IBM Plex Mono'" }}>{sale.receipt_no}</div>
          <div style={{ fontFamily: "'IBM Plex Mono'" }}>{dateTime(sale.created_at)}</div>
        </div>
      </div>
      {sale.customer && (
        <div style={{ margin: "10px 0" }}>
          <strong>Müşteri:</strong> {sale.customer.full_name} {sale.customer.phone && `· ${sale.customer.phone}`}
        </div>
      )}
      <table style={{ width: "100%", borderCollapse: "collapse", marginTop: 12 }}>
        <thead>
          <tr style={{ textAlign: "left" }}>
            <th style={cell}>Ürün</th>
            <th style={cell}>SKU</th>
            <th style={{ ...num, fontFamily: "inherit" }}>Miktar</th>
            <th style={{ ...num, fontFamily: "inherit" }}>Birim fiyat</th>
            <th style={{ ...num, fontFamily: "inherit" }}>İndirim</th>
            <th style={{ ...num, fontFamily: "inherit" }}>KDV</th>
            <th style={{ ...num, fontFamily: "inherit" }}>Tutar</th>
          </tr>
        </thead>
        <tbody>
          {sale.items.map((it) => (
            <tr key={it.id}>
              <td style={cell}>
                {it.product_name}
                {it.serial_no && (
                  <div style={{ fontSize: "9pt", fontFamily: "'IBM Plex Mono'" }}>
                    SN {it.serial_no}
                    {it.warranty_until && ` · garanti ${dateOnly(it.warranty_until)}`}
                  </div>
                )}
              </td>
              <td style={{ ...cell, fontFamily: "'IBM Plex Mono'" }}>{it.sku}</td>
              <td style={num}>{qty(it.qty, it.unit_type === "SERVICE" ? "PIECE" : it.unit_type)}</td>
              <td style={num}>{moneyPlain(it.unit_price)}</td>
              <td style={num}>{it.discount ? moneyPlain(it.discount) : "—"}</td>
              <td style={num}>%{it.vat_rate}</td>
              <td style={num}>{moneyPlain(it.line_total)}</td>
            </tr>
          ))}
        </tbody>
      </table>
      <div style={{ display: "flex", justifyContent: "flex-end", marginTop: 12 }}>
        <table style={{ borderCollapse: "collapse", minWidth: 280 }}>
          <tbody>
            <tr>
              <td style={cell}>Ara toplam</td>
              <td style={num}>{money(sale.subtotal)}</td>
            </tr>
            {sale.discount > 0 && (
              <tr>
                <td style={cell}>Genel indirim</td>
                <td style={num}>-{money(sale.discount)}</td>
              </tr>
            )}
            {sale.vat_breakdown.map((v) => (
              <tr key={v.rate}>
                <td style={cell}>KDV %{v.rate}</td>
                <td style={num}>{money(v.vat)}</td>
              </tr>
            ))}
            <tr>
              <td style={{ ...cell, fontWeight: 600, borderBottom: "2px solid #000" }}>TOPLAM</td>
              <td style={{ ...num, fontWeight: 600, borderBottom: "2px solid #000" }}>{money(sale.total)}</td>
            </tr>
            {sale.payments.map((p) => (
              <tr key={p.id}>
                <td style={cell}>{METHOD_TR[p.method]}</td>
                <td style={num}>{money(p.amount)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {settings.receipt_footer && <p style={{ marginTop: 18 }}>{settings.receipt_footer}</p>}
      <p style={{ marginTop: 6, fontSize: "9pt" }}>{INFO_NOTE}</p>
    </div>
  );
}
