import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Ban, Printer, Undo2 } from "lucide-react";
import { useState } from "react";
import { Link, useParams } from "react-router-dom";
import { useCan } from "@/app/auth";
import { useCrumb } from "@/app/crumbs";
import { Button } from "@/design/Button";
import { type ColumnDef, DataTable } from "@/design/DataTable";
import { Dialog } from "@/design/Dialog";
import { ErrorState, Loading } from "@/design/Feedback";
import { Led, Money, Qty } from "@/design/Indicators";
import { Checkbox, Field, Input, Select, Textarea } from "@/design/Input";
import { Panel } from "@/design/Page";
import { useToast } from "@/design/Toast";
import { ApiError, api } from "@/lib/api";
import { dateOnly, dateTime, money, parseDecimal } from "@/lib/format";
import { useSettings } from "@/lib/hooks";
import { METHOD_TR } from "@/lib/labels";
import { printNode } from "@/lib/print";
import type { PaymentMethod, SaleDetail, SaleItem } from "@/lib/types";
import { Receipt80, SaleSummaryA4 } from "./Receipt";

function CancelDialog({ sale, onClose, onDone }: { sale: SaleDetail; onClose: () => void; onDone: () => void }) {
  const [reason, setReason] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const submit = async () => {
    setBusy(true);
    try {
      await api.post(`/sales/${sale.id}/cancel`, { reason });
      onDone();
    } catch (e) {
      setError(e instanceof ApiError ? e.message : "İptal edilemedi.");
    } finally {
      setBusy(false);
    }
  };
  return (
    <Dialog
      open
      onOpenChange={(o) => !o && onClose()}
      title="Satışı iptal et"
      description={`${sale.receipt_no} · ${money(sale.total)}`}
      width={460}
      footer={
        <>
          <Button variant="ghost" onClick={onClose}>
            Vazgeç
          </Button>
          <Button variant="danger" onClick={submit} loading={busy} disabled={reason.trim().length < 3}>
            İptal et
          </Button>
        </>
      }
    >
      <p className="text-13 text-ink-2 mb-3">
        Stoklar geri alınır, veresiye tutarı cari hesaptan düşülür. İşlem denetim kaydına yazılır ve geri alınamaz.
      </p>
      <Field label="İptal nedeni" error={error ?? undefined}>
        {(id) => <Textarea id={id} rows={2} autoFocus value={reason} onChange={(e) => setReason(e.target.value)} />}
      </Field>
    </Dialog>
  );
}

function ReturnDialog({ sale, onClose, onDone }: { sale: SaleDetail; onClose: () => void; onDone: (total: number) => void }) {
  const returnable = sale.items.filter((i) => i.qty - i.returned_qty > 0);
  const [qtys, setQtys] = useState<Record<number, string>>({});
  const [restock, setRestock] = useState<Record<number, boolean>>({});
  const [method, setMethod] = useState<PaymentMethod>(sale.payments.some((p) => p.method === "CREDIT") ? "CREDIT" : "CASH");
  const [reason, setReason] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const selected = returnable
    .map((i) => ({ item: i, qty: parseDecimal(qtys[i.id] ?? "") ?? 0 }))
    .filter((x) => x.qty > 0);
  const estimate = selected.reduce((s, x) => s + Math.round((x.item.net_total * x.qty) / x.item.qty), 0);
  const submit = async () => {
    setBusy(true);
    setError(null);
    try {
      const r = await api.post<{ total: number }>("/returns", {
        sale_id: sale.id,
        method,
        reason,
        items: selected.map((x) => ({ sale_item_id: x.item.id, qty: x.qty, restock: restock[x.item.id] ?? true })),
      });
      onDone(r.total);
    } catch (e) {
      setError(e instanceof ApiError ? e.message : "İade kaydedilemedi.");
    } finally {
      setBusy(false);
    }
  };
  return (
    <Dialog
      open
      onOpenChange={(o) => !o && onClose()}
      title="İade al"
      description={sale.receipt_no}
      width={680}
      footer={
        <>
          <span className="mr-auto num text-14">İade tutarı ≈ {money(estimate)}</span>
          <Button variant="ghost" onClick={onClose}>
            Vazgeç
          </Button>
          <Button variant="primary" onClick={submit} loading={busy} disabled={!selected.length || reason.trim().length < 3}>
            İadeyi kaydet
          </Button>
        </>
      }
    >
      <table className="w-full text-13 mb-4">
        <thead>
          <tr className="border-b border-rule-strong font-cond text-11 uppercase tracking-[.06em] text-ink-3 text-left" lang="tr">
            <th className="py-1.5 font-medium">Ürün</th>
            <th className="py-1.5 font-medium text-right">Kalan</th>
            <th className="py-1.5 font-medium text-right w-24">İade</th>
            <th className="py-1.5 font-medium pl-3">Durum</th>
          </tr>
        </thead>
        <tbody>
          {returnable.map((i) => (
            <tr key={i.id} className="border-b border-rule">
              <td className="py-1.5 pr-2">
                {i.product_name}
                {i.serial_no && <div className="num text-11 text-ink-3">SN {i.serial_no}</div>}
              </td>
              <td className="py-1.5 text-right">
                <Qty value={i.qty - i.returned_qty} unit={i.unit_type === "SERVICE" ? "PIECE" : i.unit_type} />
              </td>
              <td className="py-1.5 text-right">
                <Input
                  mono
                  align="right"
                  className="w-20 h-7"
                  inputMode="decimal"
                  aria-label={`${i.product_name} iade miktarı`}
                  value={qtys[i.id] ?? ""}
                  placeholder="0"
                  onChange={(e) => setQtys((q) => ({ ...q, [i.id]: e.target.value }))}
                />
              </td>
              <td className="py-1.5 pl-3">
                {i.unit_type !== "SERVICE" && (
                  <Checkbox label="Sağlam, stoğa al" checked={restock[i.id] ?? true} onChange={(e) => setRestock((r) => ({ ...r, [i.id]: e.target.checked }))} />
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      <div className="grid sm:grid-cols-2 gap-3">
        <Field label="Geri ödeme">
          {(id) => (
            <Select id={id} value={method} onChange={(e) => setMethod(e.target.value as PaymentMethod)}>
              <option value="CASH">Nakit iade</option>
              <option value="CARD">Karta iade</option>
              <option value="TRANSFER">Havale ile iade</option>
              {sale.customer && <option value="CREDIT">Cari hesaba alacak</option>}
            </Select>
          )}
        </Field>
        <Field label="İade nedeni" error={error ?? undefined}>
          {(id) => <Input id={id} value={reason} onChange={(e) => setReason(e.target.value)} placeholder="Örn. arızalı çıktı" />}
        </Field>
      </div>
      <p className="text-12 text-ink-3 mt-3">Kusurlu ürünler stoğa girip fire olarak düşülür; seri numarası "arızalı" olarak işaretlenir.</p>
    </Dialog>
  );
}

export default function SaleDetailPage() {
  const { id } = useParams();
  const qc = useQueryClient();
  const toast = useToast();
  const settings = useSettings();
  const canCost = useCan("product.cost_view");
  const canReturn = useCan("return.create");
  const [dialog, setDialog] = useState<"cancel" | "return" | null>(null);
  const q = useQuery({ queryKey: ["sale", id], queryFn: () => api.get<SaleDetail>(`/sales/${id}`) });
  const s = q.data;
  useCrumb(s?.receipt_no);
  if (q.isLoading) return <Loading />;
  if (q.isError || !s) return <ErrorState error={q.error} onRetry={() => q.refetch()} />;

  const refresh = async () => {
    await qc.invalidateQueries({ queryKey: ["sale", id] });
    await qc.invalidateQueries({ queryKey: ["sales"] });
    await qc.invalidateQueries({ queryKey: ["status"] });
  };
  const print = (kind: "receipt80" | "a4") => {
    if (!settings.data) return;
    printNode(kind === "receipt80" ? <Receipt80 sale={s} settings={settings.data} /> : <SaleSummaryA4 sale={s} settings={settings.data} />, kind);
  };
  const returnable = s.status === "COMPLETED" && s.items.some((i) => i.qty - i.returned_qty > 0);

  const cols: ColumnDef<SaleItem, any>[] = [
    {
      accessorKey: "product_name",
      header: "Ürün",
      cell: ({ row }) => (
        <div>
          <Link to={`/urunler/${row.original.product_id}`} className="hover:underline">
            {row.original.product_name}
          </Link>
          {row.original.serial_no && (
            <div className="num text-11 text-ink-3">
              SN {row.original.serial_no}
              {row.original.warranty_until && ` · garanti ${dateOnly(row.original.warranty_until)}`}
            </div>
          )}
        </div>
      ),
    },
    { accessorKey: "sku", header: "SKU", meta: { mono: true, className: "text-12 text-ink-3" } },
    {
      accessorKey: "qty",
      header: "Miktar",
      meta: { align: "right" },
      cell: ({ row }) => (
        <span>
          <Qty value={row.original.qty} unit={row.original.unit_type === "SERVICE" ? "PIECE" : row.original.unit_type} />
          {row.original.returned_qty > 0 && (
            <div className="num text-11 text-warn">
              iade <Qty value={row.original.returned_qty} unit={row.original.unit_type === "SERVICE" ? "PIECE" : row.original.unit_type} />
            </div>
          )}
        </span>
      ),
    },
    { accessorKey: "unit_price", header: "Birim fiyat", meta: { align: "right" }, cell: ({ getValue }) => <Money value={getValue()} /> },
    {
      accessorKey: "discount",
      header: "İndirim",
      meta: { align: "right" },
      cell: ({ row }) => {
        const d = row.original.discount + row.original.allocated_discount;
        return d ? <Money value={-d} /> : <span className="text-ink-3">—</span>;
      },
    },
    { accessorKey: "vat_rate", header: "KDV", meta: { align: "right", mono: true }, cell: ({ getValue }) => `%${getValue()}` },
    { accessorKey: "net_total", header: "Tutar", meta: { align: "right" }, cell: ({ getValue }) => <Money value={getValue()} strong /> },
    ...(canCost
      ? ([
          { accessorKey: "unit_cost", header: "Maliyet", meta: { align: "right" }, cell: ({ getValue }) => <Money value={getValue()} className="text-ink-2" /> },
          { accessorKey: "profit", header: "Kâr", meta: { align: "right" }, cell: ({ getValue }) => <Money value={getValue()} /> },
        ] as ColumnDef<SaleItem, any>[])
      : []),
  ];

  return (
    <div className="pb-8">
      <div className="px-4 md:px-6 pt-5 pb-4 flex flex-wrap justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            {s.status === "CANCELLED" ? <Led tone="crit">İptal edildi</Led> : s.returns.length ? <Led tone="warn">Kısmi iade</Led> : <Led tone="ok">Tamamlandı</Led>}
          </div>
          <h1 className="font-cond text-20 font-semibold num">{s.receipt_no}</h1>
          <div className="text-13 text-ink-2">
            <span className="num">{dateTime(s.created_at)}</span> · {s.user_name ?? "—"}
            {s.customer && (
              <>
                {" "}·{" "}
                <Link to={`/cari/${s.customer.id}`} className="underline decoration-rule-strong">
                  {s.customer.full_name}
                </Link>
              </>
            )}
            {s.service_ticket_id && (
              <>
                {" "}·{" "}
                <Link to={`/servis/${s.service_ticket_id}`} className="underline decoration-rule-strong">
                  servis kaydı
                </Link>
              </>
            )}
          </div>
          {s.cancelled_reason && <p className="text-13 text-crit mt-1">İptal nedeni: {s.cancelled_reason}</p>}
        </div>
        <div className="flex flex-wrap gap-2 items-start">
          <Button icon={Printer} onClick={() => print("receipt80")}>
            Fiş (80 mm)
          </Button>
          <Button icon={Printer} onClick={() => print("a4")}>
            A4 özet
          </Button>
          {canReturn && returnable && (
            <Button icon={Undo2} onClick={() => setDialog("return")}>
              İade al
            </Button>
          )}
          {s.can_cancel && (
            <Button variant="danger" icon={Ban} onClick={() => setDialog("cancel")}>
              İptal et
            </Button>
          )}
        </div>
      </div>
      <div className="grid lg:grid-cols-[1fr_320px] gap-4 lg:pr-6">
        <DataTable data={s.items} columns={cols} hideFooter className="lg:border-r" />
        <aside className="flex flex-col gap-4 px-4 lg:px-0">
          <Panel title="Tutar">
            <div className="p-4 flex flex-col gap-1.5 text-13">
              <div className="flex justify-between">
                <span className="text-ink-2">Ara toplam</span>
                <Money value={s.subtotal} />
              </div>
              {s.discount > 0 && (
                <div className="flex justify-between">
                  <span className="text-ink-2">Genel indirim</span>
                  <Money value={-s.discount} />
                </div>
              )}
              {s.vat_breakdown.map((v) => (
                <div key={v.rate} className="flex justify-between text-12 text-ink-2">
                  <span>KDV %{v.rate}</span>
                  <span className="num">{money(v.vat)}</span>
                </div>
              ))}
              <div className="flex justify-between border-t border-rule pt-1.5 mt-1">
                <span className="font-medium">Toplam</span>
                <span className="num text-20 font-semibold">{money(s.total)}</span>
              </div>
              {canCost && s.profit !== undefined && (
                <div className="flex justify-between text-12 text-ink-2">
                  <span>Brüt kâr (KDV hariç)</span>
                  <Money value={s.profit} />
                </div>
              )}
            </div>
          </Panel>
          <Panel title="Ödemeler">
            <ul className="p-4 flex flex-col gap-1.5 text-13">
              {s.payments.map((p) => (
                <li key={p.id} className="flex justify-between">
                  <span>
                    {METHOD_TR[p.method]}
                    {p.tendered !== null && p.change !== null && (
                      <span className="text-12 text-ink-3"> · alınan {money(p.tendered)}, üstü {money(p.change)}</span>
                    )}
                  </span>
                  <Money value={p.amount} />
                </li>
              ))}
            </ul>
          </Panel>
          {s.returns.length > 0 && (
            <Panel title="İadeler">
              <ul className="p-4 flex flex-col gap-2 text-13">
                {s.returns.map((r) => (
                  <li key={r.id}>
                    <div className="flex justify-between">
                      <span className="num text-12">{dateTime(r.at)}</span>
                      <Money value={-r.total} />
                    </div>
                    <div className="text-12 text-ink-2">
                      {r.method === "CREDIT" ? "Cari hesaba" : METHOD_TR[r.method]} · {r.reason}
                    </div>
                  </li>
                ))}
              </ul>
            </Panel>
          )}
        </aside>
      </div>
      {dialog === "cancel" && (
        <CancelDialog
          sale={s}
          onClose={() => setDialog(null)}
          onDone={async () => {
            setDialog(null);
            toast({ tone: "warn", title: "Satış iptal edildi", message: s.receipt_no });
            await refresh();
          }}
        />
      )}
      {dialog === "return" && (
        <ReturnDialog
          sale={s}
          onClose={() => setDialog(null)}
          onDone={async (total) => {
            setDialog(null);
            toast({ title: "İade kaydedildi", message: money(total) });
            await refresh();
          }}
        />
      )}
    </div>
  );
}
