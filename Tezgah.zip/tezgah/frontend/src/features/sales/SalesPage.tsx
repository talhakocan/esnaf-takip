import { useQuery } from "@tanstack/react-query";
import { ScanBarcode, Search } from "lucide-react";
import { useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { ButtonLink } from "@/design/Button";
import { type ColumnDef, DataTable } from "@/design/DataTable";
import { EmptyState, ErrorState, Loading } from "@/design/Feedback";
import { Led, Money, Tag } from "@/design/Indicators";
import { Input, Select } from "@/design/Input";
import { PageHeader } from "@/design/Page";
import { api } from "@/lib/api";
import { dateTime, money } from "@/lib/format";
import { useTitle, useUsers } from "@/lib/hooks";
import { METHOD_TR } from "@/lib/labels";
import type { SaleListRow } from "@/lib/types";
import { DateRangePicker, type Preset, presetRange } from "../shared/DateRange";

export default function SalesPage() {
  useTitle("Satışlar");
  const navigate = useNavigate();
  const users = useUsers();
  const [range, setRange] = useState<{ preset: Preset; from: string; to: string }>({ preset: "last30", ...presetRange("last30") });
  const [status, setStatus] = useState("");
  const [userId, setUserId] = useState("");
  const [q, setQ] = useState("");
  const query = useQuery({
    queryKey: ["sales", range.from, range.to, status, userId],
    queryFn: () => api.get<SaleListRow[]>("/sales", { from: range.from, to: range.to, status: status || undefined, user_id: userId || undefined }),
  });
  const rows = useMemo(() => {
    const needle = q.trim().toLocaleLowerCase("tr-TR");
    return (query.data ?? []).filter((s) => !needle || `${s.receipt_no} ${s.customer_name ?? ""}`.toLocaleLowerCase("tr-TR").includes(needle));
  }, [query.data, q]);
  const completed = rows.filter((r) => r.status === "COMPLETED");
  const sum = completed.reduce((s, r) => s + r.total - r.returned_total, 0);

  const columns: ColumnDef<SaleListRow, any>[] = [
    { accessorKey: "receipt_no", header: "Fiş no", meta: { mono: true, className: "text-12" } },
    {
      accessorKey: "created_at",
      header: "Tarih",
      meta: { mono: true, className: "text-12 whitespace-nowrap", exportValue: (s) => dateTime(s.created_at) },
      cell: ({ getValue }) => dateTime(getValue()),
    },
    { accessorKey: "customer_name", header: "Müşteri" },
    { accessorKey: "item_count", header: "Kalem", meta: { align: "right", mono: true } },
    {
      id: "methods",
      header: "Ödeme",
      accessorFn: (s) => s.methods.map((m) => METHOD_TR[m]).join(" + "),
      cell: ({ row }) => (
        <span className="flex gap-1">
          {row.original.methods.map((m) => (
            <Tag key={m} tone={m === "CREDIT" ? "warn" : undefined}>
              {METHOD_TR[m].toLocaleUpperCase("tr-TR")}
            </Tag>
          ))}
          {row.original.service_ticket_id && <Tag tone="info">SERVİS</Tag>}
        </span>
      ),
    },
    { accessorKey: "user_name", header: "Personel", meta: { className: "text-12 text-ink-2" } },
    {
      accessorKey: "status",
      header: "Durum",
      meta: { exportValue: (s) => (s.status === "CANCELLED" ? "İptal" : s.returned_total ? "Kısmi iade" : "Tamam") },
      cell: ({ row }) =>
        row.original.status === "CANCELLED" ? (
          <Led tone="crit">İptal</Led>
        ) : row.original.returned_total ? (
          <Led tone="warn">İade {money(row.original.returned_total)}</Led>
        ) : (
          <Led tone="ok">Tamam</Led>
        ),
    },
    {
      accessorKey: "total",
      header: "Tutar",
      meta: { align: "right", exportValue: (s) => (s.total / 100).toFixed(2) },
      cell: ({ row }) => <Money value={row.original.total} className={row.original.status === "CANCELLED" ? "line-through text-ink-3" : undefined} />,
    },
  ];

  return (
    <div>
      <PageHeader
        title="Satışlar"
        count={rows.length}
        sub={
          <span>
            Net ciro <span className="num text-ink">{money(sum)}</span> · {completed.length} tamamlanan satış
          </span>
        }
        actions={
          <ButtonLink to="/satis" variant="primary" icon={ScanBarcode} kbd="F2">
            Hızlı satış
          </ButtonLink>
        }
      />
      {query.isLoading ? (
        <Loading />
      ) : query.isError ? (
        <ErrorState error={query.error} onRetry={() => query.refetch()} />
      ) : (
        <DataTable
          data={rows}
          columns={columns}
          getRowId={(s) => String(s.id)}
          onRowClick={(s) => navigate(`/satislar/${s.id}`)}
          exportName={`tezgah-satislar-${range.from}-${range.to}`}
          storageKey="sales"
          toolbar={
            <>
              <div className="relative w-full sm:w-56">
                <Search size={14} strokeWidth={1.5} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-ink-3 pointer-events-none" aria-hidden />
                <Input data-page-search value={q} onChange={(e) => setQ(e.target.value)} placeholder="Fiş no, müşteri…" className="pl-8" aria-label="Satış ara" />
              </div>
              <DateRangePicker {...range} onChange={setRange} />
              <Select value={status} onChange={(e) => setStatus(e.target.value)} className="w-32" aria-label="Durum">
                <option value="">Tüm durumlar</option>
                <option value="COMPLETED">Tamamlanan</option>
                <option value="CANCELLED">İptal</option>
              </Select>
              <Select value={userId} onChange={(e) => setUserId(e.target.value)} className="w-40" aria-label="Personel">
                <option value="">Tüm personel</option>
                {users.data?.map((u) => (
                  <option key={u.id} value={u.id}>
                    {u.full_name}
                  </option>
                ))}
              </Select>
            </>
          }
          empty={<EmptyState icon="circuit" title="Bu aralıkta satış yok." />}
        />
      )}
    </div>
  );
}
