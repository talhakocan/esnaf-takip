import { Link } from "react-router-dom";
import type { ColumnDef } from "@/design/DataTable";
import { Led, Money, Qty } from "@/design/Indicators";
import { dateTime } from "@/lib/format";
import { MOVEMENT_TONE, MOVEMENT_TR } from "@/lib/labels";
import type { Movement } from "@/lib/types";

/** Stok defteri sütunları (ürün detayında ve genel defterde ortak). */
export function movementColumns({ withProduct, withCost }: { withProduct: boolean; withCost: boolean }): ColumnDef<Movement, any>[] {
  const cols: ColumnDef<Movement, any>[] = [
    {
      accessorKey: "at",
      header: "Tarih",
      meta: { mono: true, className: "text-12 whitespace-nowrap w-36", exportValue: (m) => dateTime(m.at) },
      cell: ({ getValue }) => dateTime(getValue()),
    },
    {
      accessorKey: "type",
      header: "Tip",
      meta: { exportValue: (m) => m.label },
      cell: ({ row }) => (
        <Led tone={MOVEMENT_TONE[row.original.type]} title={MOVEMENT_TR[row.original.type]}>
          <span className="font-cond text-12 tracking-wide">{row.original.label}</span>
        </Led>
      ),
    },
  ];
  if (withProduct) {
    cols.push({
      accessorKey: "product_name",
      header: "Ürün",
      cell: ({ row }) => (
        <Link to={`/urunler/${row.original.product_id}`} className="hover:underline" onClick={(e) => e.stopPropagation()}>
          <span className="num text-12 text-ink-3 mr-2">{row.original.sku}</span>
          {row.original.product_name}
        </Link>
      ),
    });
  }
  cols.push(
    {
      accessorKey: "qty",
      header: "Miktar",
      meta: { align: "right", exportValue: (m) => m.qty },
      cell: ({ row }) => (
        <span className={row.original.qty > 0 ? "text-ok" : undefined}>
          {row.original.qty > 0 ? "+" : ""}
          <Qty value={row.original.qty} unit={row.original.unit_type} />
        </span>
      ),
    },
    {
      accessorKey: "balance_after",
      header: "Bakiye",
      meta: { align: "right", exportValue: (m) => m.balance_after },
      cell: ({ row }) => <Qty value={row.original.balance_after} unit={row.original.unit_type} />,
    },
  );
  if (withCost) {
    cols.push({
      accessorKey: "unit_cost_kurus",
      header: "Birim maliyet",
      meta: { align: "right", exportValue: (m) => ((m.unit_cost_kurus ?? 0) / 100).toFixed(2) },
      cell: ({ getValue }) => <Money value={getValue()} className="text-12 text-ink-2" />,
    });
  }
  cols.push(
    {
      id: "ref",
      accessorFn: (m) => m.ref_label ?? "",
      header: "Belge",
      meta: { mono: true, className: "text-12" },
      cell: ({ row }) =>
        row.original.ref_link ? (
          <Link to={row.original.ref_link} className="underline decoration-rule-strong hover:decoration-ink" onClick={(e) => e.stopPropagation()}>
            {row.original.ref_label}
          </Link>
        ) : (
          <span className="text-ink-3">{row.original.ref_type === "MANUAL" ? "elle" : "—"}</span>
        ),
    },
    { accessorKey: "note", header: "Açıklama", meta: { className: "text-12 text-ink-2 max-w-[260px] truncate" } },
    { accessorKey: "user_name", header: "Kullanıcı", meta: { className: "text-12 text-ink-2 whitespace-nowrap" } },
  );
  return cols;
}
