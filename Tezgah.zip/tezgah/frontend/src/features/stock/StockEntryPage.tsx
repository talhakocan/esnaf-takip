import { useQuery, useQueryClient } from "@tanstack/react-query";
import { X } from "lucide-react";
import { useState } from "react";
import { Link, useSearchParams } from "react-router-dom";
import { useCan } from "@/app/auth";
import { Button, IconButton } from "@/design/Button";
import { Checkbox, Field, Input, Radio, Textarea } from "@/design/Input";
import { Led, StockMeter } from "@/design/Indicators";
import { PageHeader, Panel } from "@/design/Page";
import { useToast } from "@/design/Toast";
import { ApiError, api } from "@/lib/api";
import { parseDecimal, parseMoney, qty as fmtQty, timeOnly } from "@/lib/format";
import { useTitle } from "@/lib/hooks";
import type { Product, Serial } from "@/lib/types";
import { ProductSearch } from "../shared/Pickers";

type Kind = "ADJUST_IN" | "PURCHASE_IN" | "ADJUST_OUT" | "WASTE";
const KIND_LABEL: Record<Kind, string> = {
  ADJUST_IN: "Stok girişi (elle)",
  PURCHASE_IN: "Mal kabul (siparişsiz alış)",
  ADJUST_OUT: "Stok çıkışı (elle)",
  WASTE: "Fire / hasar",
};

interface Done {
  at: Date;
  product: string;
  product_id: number;
  kind: Kind;
  qty: string;
  balance: number;
  unit: Product["unit_type"];
}

export default function StockEntryPage() {
  useTitle("Stok Girişi");
  const [params] = useSearchParams();
  const qc = useQueryClient();
  const toast = useToast();
  const isAdmin = useCan("product.cost_view");
  const [productId, setProductId] = useState<number | null>(params.get("urun") ? Number(params.get("urun")) : null);
  const [kind, setKind] = useState<Kind>("ADJUST_IN");
  const [qtyText, setQtyText] = useState("");
  const [cost, setCost] = useState("");
  const [note, setNote] = useState("");
  const [serialText, setSerialText] = useState("");
  const [serialIds, setSerialIds] = useState<number[]>([]);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [busy, setBusy] = useState(false);
  const [log, setLog] = useState<Done[]>([]);

  const product = useQuery({ queryKey: ["product", String(productId)], queryFn: () => api.get<Product>(`/products/${productId}`), enabled: !!productId });
  const p = product.data;
  const inbound = kind === "ADJUST_IN" || kind === "PURCHASE_IN";
  const serials = useQuery({
    queryKey: ["serials-available", productId],
    queryFn: () => api.get<Serial[]>(`/products/${productId}/serials`, { available: true }),
    enabled: !!p?.track_serial && !inbound,
  });
  const serialList = serialText.split(/\s*[\n,;]\s*/).filter(Boolean);
  const qtyValue = p?.track_serial ? (inbound ? serialList.length : serialIds.length) : parseDecimal(qtyText) ?? 0;

  const reset = () => {
    setQtyText("");
    setCost("");
    setNote("");
    setSerialText("");
    setSerialIds([]);
    setErrors({});
  };

  const submit = async () => {
    if (!p) return;
    setBusy(true);
    setErrors({});
    try {
      const path = kind === "WASTE" ? "/stock/waste" : "/stock/adjust";
      const body: Record<string, unknown> = { product_id: p.id, qty: qtyValue, note };
      if (kind !== "WASTE") body.type = kind;
      if (p.track_serial && inbound) body.serials = serialList;
      if (p.track_serial && !inbound) body.serial_ids = serialIds;
      if (isAdmin && inbound && cost) body.unit_cost_kurus = parseMoney(cost);
      const r = await api.post<{ balance_after: number }>(path, body);
      setLog((l) => [{ at: new Date(), product: p.name, product_id: p.id, kind, qty: fmtQty(qtyValue, p.unit_type), balance: r.balance_after, unit: p.unit_type }, ...l].slice(0, 12));
      toast({ title: "Stok hareketi kaydedildi", message: `${p.name} · yeni bakiye ${fmtQty(r.balance_after, p.unit_type)}` });
      reset();
      await qc.invalidateQueries({ queryKey: ["product", String(p.id)] });
      await qc.invalidateQueries({ queryKey: ["products"] });
      await qc.invalidateQueries({ queryKey: ["serials-available", p.id] });
    } catch (e) {
      if (e instanceof ApiError) setErrors({ ...e.fields, _: e.message });
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="pb-10">
      <PageHeader title="Stok girişi / çıkışı" sub="Siparişli alımlar için Satın Alma › Mal kabul ekranını kullanın." />
      <div className="grid xl:grid-cols-[1fr_380px] gap-4 px-4 md:px-6">
        <Panel title="Hareket">
          <form
            className="p-4 flex flex-col gap-4"
            onSubmit={(e) => {
              e.preventDefault();
              void submit();
            }}
          >
            {p ? (
              <div className="flex items-center gap-3 border border-rule px-3 py-2">
                <div className="flex-1 min-w-0">
                  <Link to={`/urunler/${p.id}`} className="font-medium hover:underline truncate block">
                    {p.name}
                  </Link>
                  <div className="num text-12 text-ink-3">
                    {p.sku} · raf {p.location_code ?? "—"}
                  </div>
                </div>
                <StockMeter qty={p.stock_qty} min={p.min_stock} unit={p.unit_type} status={p.stock_status} />
                <IconButton icon={X} label="Ürünü değiştir" onClick={() => setProductId(null)} />
              </div>
            ) : (
              <Field label="Ürün">
                {() => <ProductSearch autoFocus onPick={(x) => setProductId(x.id)} filter={(x) => x.unit_type !== "SERVICE"} />}
              </Field>
            )}
            <fieldset className="flex flex-wrap gap-x-5 gap-y-2">
              <legend className="text-12 text-ink-2 mb-1">Hareket tipi</legend>
              {(Object.keys(KIND_LABEL) as Kind[]).map((k) => (
                <Radio key={k} name="kind" label={KIND_LABEL[k]} checked={kind === k} onChange={() => setKind(k)} />
              ))}
            </fieldset>
            {p && (
              <>
                {!p.track_serial && (
                  <div className="grid sm:grid-cols-2 gap-3">
                    <Field label={`Miktar (${p.unit_type === "METER" ? "metre" : "adet"})`} error={errors.qty}>
                      {(id) => <Input id={id} mono align="right" inputMode="decimal" autoFocus value={qtyText} onChange={(e) => setQtyText(e.target.value)} />}
                    </Field>
                    {isAdmin && inbound && (
                      <Field label="Birim maliyet (₺, KDV hariç)" hint="Boş bırakılırsa ortalama maliyet kullanılır">
                        {(id) => <Input id={id} mono align="right" inputMode="decimal" value={cost} onChange={(e) => setCost(e.target.value)} />}
                      </Field>
                    )}
                  </div>
                )}
                {p.track_serial && inbound && (
                  <Field label={`Seri numaraları — ${serialList.length} adet`} error={errors.serials} hint="Okuyucuyla ardışık okutun; her satıra bir seri no.">
                    {(id) => <Textarea id={id} className="font-mono" rows={5} autoFocus value={serialText} onChange={(e) => setSerialText(e.target.value)} />}
                  </Field>
                )}
                {p.track_serial && !inbound && (
                  <div>
                    <div className="text-12 text-ink-2 mb-1">Çıkacak seri numaraları ({serialIds.length})</div>
                    <div className="border border-rule max-h-48 overflow-y-auto scroll-thin p-2 grid sm:grid-cols-2 gap-1">
                      {(serials.data ?? []).map((s) => (
                        <Checkbox
                          key={s.id}
                          label={<span className="num">{s.serial_no}</span>}
                          checked={serialIds.includes(s.id)}
                          onChange={(e) => setSerialIds((ids) => (e.target.checked ? [...ids, s.id] : ids.filter((x) => x !== s.id)))}
                        />
                      ))}
                      {serials.data?.length === 0 && <span className="text-13 text-ink-2">Stokta seri numarası yok.</span>}
                    </div>
                    {errors.serial_ids && <p className="text-12 text-crit mt-1">{errors.serial_ids}</p>}
                  </div>
                )}
                <Field label={kind === "PURCHASE_IN" ? "Açıklama (isteğe bağlı)" : "Açıklama / neden"} error={errors.note}>
                  {(id) => (
                    <Input
                      id={id}
                      value={note}
                      onChange={(e) => setNote(e.target.value)}
                      placeholder={kind === "WASTE" ? "Örn. rafta kırıldı" : kind === "ADJUST_OUT" ? "Örn. numune verildi" : "Örn. depoda bulundu"}
                    />
                  )}
                </Field>
                {errors._ && (
                  <p className="text-13 text-crit" role="alert">
                    {errors._}
                  </p>
                )}
                <div className="flex justify-end gap-2">
                  <Button variant="ghost" onClick={reset}>
                    Temizle
                  </Button>
                  <Button type="submit" variant="primary" loading={busy} disabled={!qtyValue}>
                    Kaydet
                  </Button>
                </div>
              </>
            )}
          </form>
        </Panel>
        <Panel title="Bu oturumdaki kayıtlar">
          {log.length === 0 ? (
            <p className="px-4 py-4 text-13 text-ink-2">Henüz kayıt yok.</p>
          ) : (
            <ul>
              {log.map((l, i) => (
                <li key={i} className="px-4 py-2 border-b border-rule last:border-b-0 text-13">
                  <div className="flex justify-between gap-2">
                    <Link to={`/urunler/${l.product_id}`} className="truncate hover:underline">
                      {l.product}
                    </Link>
                    <span className="num text-12 text-ink-3">{timeOnly(l.at)}</span>
                  </div>
                  <div className="flex justify-between text-12 text-ink-2">
                    <Led tone={l.kind === "WASTE" ? "crit" : l.kind === "ADJUST_OUT" ? "neutral" : "ok"}>{KIND_LABEL[l.kind]}</Led>
                    <span className="num">
                      {l.kind === "WASTE" || l.kind === "ADJUST_OUT" ? "−" : "+"}
                      {l.qty} → {fmtQty(l.balance, l.unit)}
                    </span>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </Panel>
      </div>
    </div>
  );
}
