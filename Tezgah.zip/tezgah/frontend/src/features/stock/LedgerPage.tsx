import { useQuery } from "@tanstack/react-query";
import { ArrowDownToLine, Search } from "lucide-react";
import { useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useCan } from "@/app/auth";
import { ButtonLink } from "@/design/Button";
import { DataTable } from "@/design/DataTable";
import { EmptyState, ErrorState, Loading } from "@/design/Feedback";
import { Input, Select } from "@/design/Input";
import { PageHeader } from "@/design/Page";
import { api } from "@/lib/api";
import { useTitle, useUsers } from "@/lib/hooks";
import type { Movement, MovementType } from "@/lib/types";
import { DateRangePicker, type Preset, presetRange } from "../shared/DateRange";
import { movementColumns } from "./movementColumns";

const TYPE_GROUPS: { value: string; label: string; types: MovementType[] }[] = [
  { value: "in", label: "Giriş (alış, elle)", types: ["PURCHASE_IN", "ADJUST_IN"] },
  { value: "sale", label: "Satış", types: ["SALE_OUT"] },
  { value: "return", label: "İade / iptal", types: ["SALE_RETURN"] },
  { value: "service", label: "Servis", types: ["SERVICE_OUT", "SERVICE_RETURN"] },
  { value: "waste", label: "Fire", types: ["WASTE"] },
  { value: "count", label: "Sayım farkı", types: ["COUNT_ADJUST"] },
  { value: "out", label: "Elle çıkış", types: ["ADJUST_OUT"] },
];

export default function LedgerPage() {
  useTitle("Stok Defteri");
  const navigate = useNavigate();
  const canCost = useCan("product.cost_view");
  const users = useUsers();
  const [range, setRange] = useState<{ preset: Preset; from: string; to: string }>({ preset: "week", ...presetRange("week") });
  const [group, setGroup] = useState("");
  const [userId, setUserId] = useState("");
  const [q, setQ] = useState("");
  const types = TYPE_GROUPS.find((g) => g.value === group)?.types;
  const query = useQuery({
    queryKey: ["movements", range.from, range.to, group, userId],
    queryFn: () => api.get<Movement[]>("/stock/movements", { from: range.from, to: range.to, type: types, user_id: userId || undefined }),
  });
  const rows = useMemo(() => {
    const needle = q.trim().toLocaleLowerCase("tr-TR");
    return (query.data ?? []).filter((m) => !needle || `${m.product_name} ${m.sku} ${m.ref_label ?? ""} ${m.note}`.toLocaleLowerCase("tr-TR").includes(needle));
  }, [query.data, q]);
  const columns = useMemo(() => movementColumns({ withProduct: true, withCost: canCost }), [canCost]);

  return (
    <div>
      <PageHeader
        title="Stok Defteri"
        count={rows.length}
        sub="Her stok değişikliğinin değiştirilemez kaydı. Satırlar kaynak belgeye bağlantılıdır."
        actions={
          <ButtonLink to="/stok/giris" variant="primary" icon={ArrowDownToLine} kbd="F6">
            Stok girişi
          </ButtonLink>
        }
      />
      {query.isLoading ? (
        <Loading />
      ) : query.isError ? (
        <ErrorState error={query.error} onRetry={() => query.refetch()} />
      ) : (
        <DataTable
          data={rows}
          columns={columns}
          getRowId={(m) => String(m.id)}
          onRowClick={(m) => navigate(m.ref_link ?? `/urunler/${m.product_id}`)}
          exportName={`tezgah-stok-defteri-${range.from}-${range.to}`}
          storageKey="ledger"
          toolbar={
            <>
              <div className="relative w-full sm:w-56">
                <Search size={14} strokeWidth={1.5} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-ink-3 pointer-events-none" aria-hidden />
                <Input data-page-search value={q} onChange={(e) => setQ(e.target.value)} placeholder="Ürün, belge, açıklama…" className="pl-8" aria-label="Hareket ara" />
              </div>
              <DateRangePicker {...range} onChange={setRange} />
              <Select value={group} onChange={(e) => setGroup(e.target.value)} className="w-44" aria-label="Hareket tipi">
                <option value="">Tüm hareketler</option>
                {TYPE_GROUPS.map((g) => (
                  <option key={g.value} value={g.value}>
                    {g.label}
                  </option>
                ))}
              </Select>
              <Select value={userId} onChange={(e) => setUserId(e.target.value)} className="w-40" aria-label="Kullanıcı">
                <option value="">Tüm kullanıcılar</option>
                {users.data?.map((u) => (
                  <option key={u.id} value={u.id}>
                    {u.full_name}
                  </option>
                ))}
              </Select>
            </>
          }
          empty={<EmptyState icon="circuit" title="Bu filtrelere uyan stok hareketi yok." />}
        />
      )}
    </div>
  );
}
