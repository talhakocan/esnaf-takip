import { useQuery } from "@tanstack/react-query";
import { Printer, Trash2 } from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { useSearchParams } from "react-router-dom";
import { Button, IconButton } from "@/design/Button";
import { Barcode } from "@/design/Codes";
import { cx } from "@/design/cx";
import { EmptyState } from "@/design/Feedback";
import { Input } from "@/design/Input";
import { PageHeader, Panel } from "@/design/Page";
import { api } from "@/lib/api";
import { money } from "@/lib/format";
import { useTitle } from "@/lib/hooks";
import { printNode } from "@/lib/print";
import type { Product } from "@/lib/types";
import { ProductSearch } from "../shared/Pickers";

type Template = "a4" | "thermal";

interface Item {
  product: Product;
  copies: number;
}

/** Tek etiket: ad (2 satır), fiyat (büyük mono), barkod, SKU, raf. */
function Label({ p, template }: { p: Product; template: Template }) {
  const thermal = template === "thermal";
  const code = p.barcode || p.sku;
  return (
    <div
      style={{
        width: thermal ? "40mm" : "70mm",
        height: thermal ? "30mm" : "37.1mm",
        padding: thermal ? "1.5mm 2mm" : "3mm 4mm",
        boxSizing: "border-box",
        display: "flex",
        flexDirection: "column",
        justifyContent: "space-between",
        overflow: "hidden",
        color: "#000",
        background: "#fff",
        fontFamily: "'IBM Plex Sans', sans-serif",
      }}
    >
      <div
        style={{
          fontSize: thermal ? "7pt" : "9pt",
          lineHeight: 1.15,
          fontWeight: 500,
          display: "-webkit-box",
          WebkitLineClamp: 2,
          WebkitBoxOrient: "vertical",
          overflow: "hidden",
        }}
      >
        {p.name}
      </div>
      <div style={{ display: "flex", alignItems: "flex-end", justifyContent: "space-between", gap: 4 }}>
        <div style={{ fontFamily: "'IBM Plex Mono', monospace", fontWeight: 600, fontSize: thermal ? "12pt" : "17pt", lineHeight: 1 }}>
          {money(p.sale_price_kurus)}
          {p.unit_type === "METER" && <span style={{ fontSize: "7pt", fontWeight: 400 }}>/m</span>}
        </div>
        {!thermal && (
          <div style={{ fontFamily: "'IBM Plex Mono', monospace", fontSize: "7pt", textAlign: "right", lineHeight: 1.2 }}>
            {p.sku}
            {p.location_code && (
              <>
                <br />
                RAF {p.location_code}
              </>
            )}
          </div>
        )}
      </div>
      <div style={{ display: "flex", justifyContent: thermal ? "center" : "space-between", alignItems: "flex-end" }}>
        <Barcode value={code} height={thermal ? 22 : 26} width={thermal ? 1 : 1.2} fontSize={thermal ? 7 : 8} color="#000" />
      </div>
    </div>
  );
}

function Sheet({ items, template }: { items: Item[]; template: Template }) {
  const labels = items.flatMap((it) => Array.from({ length: it.copies }, () => it.product));
  if (template === "thermal") {
    return (
      <div>
        {labels.map((p, i) => (
          <div key={i} style={{ breakAfter: "page" }}>
            <Label p={p} template="thermal" />
          </div>
        ))}
      </div>
    );
  }
  const pages: Product[][] = [];
  for (let i = 0; i < labels.length; i += 24) pages.push(labels.slice(i, i + 24));
  return (
    <div>
      {pages.map((page, pi) => (
        <div
          key={pi}
          style={{
            width: "210mm",
            height: "297mm",
            padding: "4.35mm 0",
            boxSizing: "border-box",
            display: "grid",
            gridTemplateColumns: "repeat(3, 70mm)",
            gridAutoRows: "37.1mm",
            breakAfter: pi < pages.length - 1 ? "page" : "auto",
          }}
        >
          {page.map((p, i) => (
            <Label key={i} p={p} template="a4" />
          ))}
        </div>
      ))}
    </div>
  );
}

export default function LabelsPage() {
  useTitle("Etiket Basımı");
  const [params] = useSearchParams();
  const ids = (params.get("ids") ?? "").split(",").filter(Boolean);
  const [items, setItems] = useState<Item[]>([]);
  const [template, setTemplate] = useState<Template>("a4");
  const initial = useQuery({
    queryKey: ["labels-initial", ids.join(",")],
    queryFn: async () => Promise.all(ids.map((id) => api.get<Product>(`/products/${id}`))),
    enabled: ids.length > 0,
  });
  useEffect(() => {
    if (initial.data) setItems(initial.data.map((p) => ({ product: p, copies: 1 })));
  }, [initial.data]);
  const total = items.reduce((s, i) => s + i.copies, 0);
  const pages = template === "a4" ? Math.ceil(total / 24) : total;
  const preview = useMemo(() => items.slice(0, 12), [items]);

  return (
    <div className="pb-10">
      <PageHeader
        title="Etiket Basımı"
        sub="Raf ve ürün etiketleri: A4 3×8 etiket kâğıdı (70×37 mm) veya 40×30 mm termal etiket."
        actions={
          <Button variant="primary" icon={Printer} disabled={!total} onClick={() => printNode(<Sheet items={items} template={template} />, template === "a4" ? "label-a4" : "label-thermal")}>
            Yazdır ({total} etiket{template === "a4" ? `, ${pages} sayfa` : ""})
          </Button>
        }
      />
      <div className="grid xl:grid-cols-[420px_1fr] gap-4 px-4 md:px-6">
        <Panel title="Ürünler">
          <div className="p-3 border-b border-rule">
            <ProductSearch
              placeholder="Ürün ekle: ad, SKU, barkod…"
              onPick={(p) => setItems((xs) => (xs.some((x) => x.product.id === p.id) ? xs : [...xs, { product: p, copies: 1 }]))}
            />
          </div>
          {items.length === 0 ? (
            <EmptyState icon="resistor" title="Etiket basılacak ürün seçin. Ürün listesinden çoklu seçimle de gelebilirsiniz." />
          ) : (
            <ul>
              {items.map((it, i) => (
                <li key={it.product.id} className="flex items-center gap-2 px-3 py-1.5 border-b border-rule last:border-b-0 text-13">
                  <span className="flex-1 min-w-0">
                    <span className="block truncate">{it.product.name}</span>
                    <span className="num text-11 text-ink-3">
                      {it.product.sku} · {money(it.product.sale_price_kurus)}
                    </span>
                  </span>
                  <label className="flex items-center gap-1 text-12 text-ink-2">
                    Adet
                    <Input
                      mono
                      align="right"
                      className="w-14 h-7"
                      value={it.copies}
                      onChange={(e) => {
                        const n = Math.max(0, Math.min(500, Number(e.target.value.replace(/\D/g, "")) || 0));
                        setItems((xs) => xs.map((x, j) => (j === i ? { ...x, copies: n } : x)));
                      }}
                      aria-label={`${it.product.name} etiket adedi`}
                    />
                  </label>
                  <IconButton icon={Trash2} label="Çıkar" size={26} onClick={() => setItems((xs) => xs.filter((_, j) => j !== i))} />
                </li>
              ))}
            </ul>
          )}
        </Panel>
        <Panel
          title="Önizleme"
          right={
            <div className="inline-flex border border-rule-strong rounded-ctl overflow-hidden" role="group" aria-label="Şablon">
              {(["a4", "thermal"] as const).map((t) => (
                <button
                  key={t}
                  type="button"
                  aria-pressed={template === t}
                  onClick={() => setTemplate(t)}
                  className={cx("h-7 px-2.5 text-12 border-r border-rule-strong last:border-r-0 cursor-pointer", template === t ? "bg-ink text-paper" : "bg-surface text-ink-2 hover:bg-surface-2")}
                >
                  {t === "a4" ? "A4 3×8" : "Termal 40×30"}
                </button>
              ))}
            </div>
          }
        >
          <div className="p-4 bg-surface-2 overflow-auto scroll-thin">
            {preview.length === 0 ? (
              <p className="text-13 text-ink-2">Önizleme için ürün ekleyin.</p>
            ) : (
              <div className={cx("flex flex-wrap gap-3", template === "thermal" && "gap-2")}>
                {preview.map((it) => (
                  <div key={it.product.id} className="border border-rule-strong shadow-[0_1px_0_var(--rule)]">
                    <Label p={it.product} template={template} />
                  </div>
                ))}
              </div>
            )}
            {items.length > preview.length && <p className="text-12 text-ink-3 mt-3">+{items.length - preview.length} ürün daha</p>}
          </div>
        </Panel>
      </div>
    </div>
  );
}
