import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Camera, CheckCheck, ScanBarcode, X } from "lucide-react";
import { useMemo, useRef, useState } from "react";
import { useParams } from "react-router-dom";
import { useCan } from "@/app/auth";
import { useCrumb } from "@/app/crumbs";
import { Button } from "@/design/Button";
import { cx } from "@/design/cx";
import { type ColumnDef, DataTable } from "@/design/DataTable";
import { useConfirm } from "@/design/Dialog";
import { ErrorState, Loading } from "@/design/Feedback";
import { Led, Money, Qty } from "@/design/Indicators";
import { Input, Select } from "@/design/Input";
import { useToast } from "@/design/Toast";
import { api, errorMessage } from "@/lib/api";
import { dateTime, decimalInput, parseDecimal, qty as fmtQty } from "@/lib/format";
import type { CountDetail, Product } from "@/lib/types";
import { CameraScanner } from "../shared/CameraScanner";

type Row = CountDetail["items"][number];

export default function CountDetailPage() {
  const { id } = useParams();
  const qc = useQueryClient();
  const toast = useToast();
  const confirm = useConfirm();
  const canApply = useCan("count.apply");
  const canCost = useCan("product.cost_view");
  const [code, setCode] = useState("");
  const [meterFor, setMeterFor] = useState<Product | null>(null);
  const [meterQty, setMeterQty] = useState("");
  const [filter, setFilter] = useState("");
  const [camera, setCamera] = useState(false);
  const [last, setLast] = useState<string | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const q = useQuery({ queryKey: ["count", id], queryFn: () => api.get<CountDetail>(`/stock-counts/${id}`) });
  const c = q.data;
  useCrumb(c?.name);
  const open = c?.status === "OPEN";

  const setData = (d: CountDetail) => qc.setQueryData(["count", id], d);
  const scan = async (value: string, qty?: number) => {
    const v = value.trim();
    if (!v) return;
    try {
      const r = await api.post<{ product: Product; needs_qty: boolean; counted_qty?: number; count: CountDetail }>(`/stock-counts/${id}/scan`, { code: v, qty: qty ?? null });
      setData(r.count);
      if (r.needs_qty) {
        setMeterFor(r.product);
        setMeterQty("");
      } else {
        setLast(`${r.product.name} → ${fmtQty(r.counted_qty ?? 0, r.product.unit_type)}`);
        setMeterFor(null);
        inputRef.current?.focus();
      }
      setCode("");
    } catch (e) {
      toast({ tone: "crit", title: "Okunamadı", message: errorMessage(e) });
      setCode("");
    }
  };
  const setCounted = async (productId: number, value: string) => {
    const n = value.trim() === "" ? null : parseDecimal(value);
    if (value.trim() !== "" && (n === null || n < 0)) return;
    try {
      setData(await api.patch<CountDetail>(`/stock-counts/${id}/items`, { items: [{ product_id: productId, counted_qty: n }] }));
    } catch (e) {
      toast({ tone: "crit", title: "Kaydedilemedi", message: errorMessage(e) });
    }
  };
  const apply = async () => {
    if (!c) return;
    const ok = await confirm({
      title: "Sayım onaylansın mı?",
      message: `${c.diff_count} üründe fark stoğa SAYIM hareketi olarak işlenecek. Sayılmayan kalemler değişmez. Onaylanan sayım değiştirilemez.`,
      confirmLabel: "Onayla ve uygula",
    });
    if (!ok) return;
    try {
      setData(await api.post<CountDetail>(`/stock-counts/${id}/apply`));
      toast({ title: "Sayım uygulandı", message: `${c.diff_count} fark stoğa işlendi` });
      await qc.invalidateQueries({ queryKey: ["counts"] });
      await qc.invalidateQueries({ queryKey: ["products"] });
    } catch (e) {
      toast({ tone: "crit", title: "Uygulanamadı", message: errorMessage(e) });
    }
  };
  const cancel = async () => {
    if (!(await confirm({ title: "Sayım iptal edilsin mi?", confirmLabel: "İptal et", danger: true }))) return;
    try {
      setData(await api.post<CountDetail>(`/stock-counts/${id}/cancel`));
      await qc.invalidateQueries({ queryKey: ["counts"] });
    } catch (e) {
      toast({ tone: "crit", title: "İptal edilemedi", message: errorMessage(e) });
    }
  };

  const rows = useMemo(() => {
    const items = c?.items ?? [];
    if (filter === "uncounted") return items.filter((i) => i.counted_qty === null);
    if (filter === "diff") return items.filter((i) => i.diff !== null && i.diff !== 0);
    return items;
  }, [c, filter]);

  const columns = useMemo<ColumnDef<Row, any>[]>(
    () => [
      { accessorKey: "sku", header: "SKU", meta: { mono: true, className: "text-12" } },
      { accessorKey: "name", header: "Ürün" },
      { accessorKey: "location_code", header: "Raf", meta: { mono: true, className: "text-12" } },
      { accessorKey: "expected_qty", header: "Beklenen", meta: { align: "right" }, cell: ({ row }) => <Qty value={row.original.expected_qty} unit={row.original.unit_type} /> },
      {
        accessorKey: "counted_qty",
        header: "Sayılan",
        meta: { align: "right" },
        cell: ({ row }) =>
          open ? (
            <Input
              mono
              align="right"
              className="h-7 w-24 ml-auto"
              aria-label={`${row.original.name} sayılan`}
              defaultValue={row.original.counted_qty === null ? "" : decimalInput(row.original.counted_qty)}
              key={`${row.original.id}-${row.original.counted_qty}`}
              onBlur={(e) => {
                const current = row.original.counted_qty === null ? "" : decimalInput(row.original.counted_qty);
                if (e.target.value !== current) void setCounted(row.original.product_id, e.target.value);
              }}
              onKeyDown={(e) => e.key === "Enter" && (e.target as HTMLInputElement).blur()}
            />
          ) : row.original.counted_qty === null ? (
            <span className="text-ink-3">—</span>
          ) : (
            <Qty value={row.original.counted_qty} unit={row.original.unit_type} />
          ),
      },
      {
        accessorKey: "diff",
        header: "Fark",
        meta: { align: "right" },
        cell: ({ row }) => {
          const d = row.original.diff;
          if (d === null) return <span className="text-ink-3">—</span>;
          return (
            <span className={cx("num", d > 0 ? "text-ok" : d < 0 ? "text-crit" : "text-ink-3")}>
              {d > 0 ? "+" : ""}
              {fmtQty(d, row.original.unit_type)}
            </span>
          );
        },
      },
      ...(canCost
        ? ([{ accessorKey: "diff_value", header: "TL karşılığı", meta: { align: "right" }, cell: ({ getValue }) => (getValue() ? <Money value={getValue()} /> : "") }] as ColumnDef<Row, any>[])
        : []),
    ],
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [open, canCost],
  );

  if (q.isLoading) return <Loading />;
  if (q.isError || !c) return <ErrorState error={q.error} onRetry={() => q.refetch()} />;
  const progress = c.items.length ? Math.round((c.counted_count / c.items.length) * 100) : 0;

  return (
    <div className="pb-10">
      <div className="px-4 md:px-6 pt-5 pb-3 flex flex-wrap justify-between gap-3">
        <div>
          <Led tone={open ? "warn" : c.status === "APPLIED" ? "ok" : "neutral"}>{open ? "Açık" : c.status === "APPLIED" ? `Onaylandı · ${dateTime(c.applied_at)}` : "İptal"}</Led>
          <h1 className="font-cond text-20 font-semibold mt-1">{c.name}</h1>
          <div className="num text-13 text-ink-2">
            {c.counted_count}/{c.items.length} sayıldı · {c.diff_count} fark
            {canCost && c.diff_value_total !== undefined && (
              <>
                {" "}
                · <Money value={c.diff_value_total} />
              </>
            )}
          </div>
        </div>
        {open && (
          <div className="flex gap-2 items-start">
            <Button variant="danger" icon={X} onClick={cancel}>
              İptal
            </Button>
            {canApply && (
              <Button variant="primary" icon={CheckCheck} onClick={apply} disabled={!c.counted_count}>
                Onayla ve uygula
              </Button>
            )}
          </div>
        )}
      </div>
      {open && (
        <div className="px-4 md:px-6 py-3 bg-surface border-y border-rule">
          <div className="h-1 bg-surface-2 mb-3" aria-hidden>
            <div className="h-1 bg-ink" style={{ width: `${progress}%` }} />
          </div>
          {meterFor ? (
            <form
              className="flex flex-wrap items-center gap-2"
              onSubmit={(e) => {
                e.preventDefault();
                const n = parseDecimal(meterQty);
                if (n && n > 0 && meterFor.barcode) void scan(meterFor.barcode, n);
                else if (n && n > 0) void scan(meterFor.sku, n);
              }}
            >
              <span className="text-14">{meterFor.name}</span>
              <span className="text-12 text-ink-3">metre ürün — sayılan miktarı ekleyin:</span>
              <Input mono align="right" autoFocus className="w-28 h-10 text-16" value={meterQty} onChange={(e) => setMeterQty(e.target.value)} aria-label="Metre" />
              <Button type="submit" variant="primary" size="lg">
                Ekle
              </Button>
              <Button size="lg" variant="ghost" onClick={() => setMeterFor(null)}>
                Vazgeç
              </Button>
            </form>
          ) : (
            <form
              className="flex gap-2"
              onSubmit={(e) => {
                e.preventDefault();
                void scan(code);
              }}
            >
              <div className="relative flex-1">
                <ScanBarcode size={18} strokeWidth={1.5} className="absolute left-3 top-1/2 -translate-y-1/2 text-ink-3 pointer-events-none" aria-hidden />
                <input
                  ref={inputRef}
                  autoFocus
                  data-page-search
                  value={code}
                  onChange={(e) => setCode(e.target.value)}
                  placeholder="Barkod / SKU okutun — her okutma +1"
                  aria-label="Sayım barkodu"
                  className="w-full h-10 pl-10 pr-3 rounded-ctl border border-ink bg-paper font-mono text-16 placeholder:font-sans placeholder:text-14 placeholder:text-ink-3"
                  autoComplete="off"
                />
              </div>
              <Button size="lg" icon={Camera} onClick={() => setCamera(true)} aria-label="Kamerayla oku">
                <span className="hidden sm:inline">Kamera</span>
              </Button>
            </form>
          )}
          {last && <p className="num text-12 text-ok mt-2">✓ {last}</p>}
        </div>
      )}
      <DataTable
        data={rows}
        columns={columns}
        getRowId={(r) => String(r.id)}
        exportName={`sayim-${c.id}`}
        className="border-t-0"
        toolbar={
          <Select value={filter} onChange={(e) => setFilter(e.target.value)} className="w-44" aria-label="Filtre">
            <option value="">Tüm kalemler</option>
            <option value="uncounted">Sayılmayanlar</option>
            <option value="diff">Farklı olanlar</option>
          </Select>
        }
      />
      <CameraScanner open={camera} onOpenChange={setCamera} onCode={(v) => void scan(v)} />
    </div>
  );
}
