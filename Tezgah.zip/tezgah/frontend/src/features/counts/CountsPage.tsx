import { useQuery } from "@tanstack/react-query";
import { Plus } from "lucide-react";
import { useState } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { useCan } from "@/app/auth";
import { Button } from "@/design/Button";
import { type ColumnDef, DataTable } from "@/design/DataTable";
import { Dialog } from "@/design/Dialog";
import { EmptyState, ErrorState, Loading } from "@/design/Feedback";
import { Led } from "@/design/Indicators";
import { Field, Input, Select } from "@/design/Input";
import { PageHeader } from "@/design/Page";
import { ApiError, api } from "@/lib/api";
import { dateTime } from "@/lib/format";
import { useCategories, useLocations, useTitle } from "@/lib/hooks";
import type { CountDetail, CountSummary } from "@/lib/types";

const STATUS = { OPEN: ["Açık", "warn"], APPLIED: ["Onaylandı", "ok"], CANCELLED: ["İptal", "neutral"] } as const;

export default function CountsPage() {
  useTitle("Sayım");
  const navigate = useNavigate();
  const [params, setParams] = useSearchParams();
  const canWrite = useCan("count.write");
  const locations = useLocations();
  const categories = useCategories();
  const [open, setOpen] = useState(params.get("yeni") === "1");
  const [name, setName] = useState("");
  const [loc, setLoc] = useState("");
  const [cat, setCat] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const q = useQuery({ queryKey: ["counts"], queryFn: () => api.get<CountSummary[]>("/stock-counts") });

  const create = async () => {
    setBusy(true);
    setError(null);
    try {
      const c = await api.post<CountDetail>("/stock-counts", { name, location_id: loc ? Number(loc) : null, category_id: cat ? Number(cat) : null });
      navigate(`/sayim/${c.id}`);
    } catch (e) {
      setError(e instanceof ApiError ? e.message : "Oluşturulamadı.");
    } finally {
      setBusy(false);
    }
  };

  const columns: ColumnDef<CountSummary, any>[] = [
    { accessorKey: "name", header: "Sayım", cell: ({ getValue }) => <span className="font-medium">{getValue()}</span> },
    { accessorKey: "status", header: "Durum", cell: ({ row }) => <Led tone={STATUS[row.original.status][1]}>{STATUS[row.original.status][0]}</Led> },
    { accessorKey: "location_code", header: "Raf", meta: { mono: true, className: "text-12" } },
    { accessorKey: "category_path", header: "Kategori", meta: { className: "text-12 text-ink-2" } },
    {
      id: "progress",
      header: "Sayılan",
      meta: { align: "right", mono: true },
      accessorFn: (c) => c.counted_count,
      cell: ({ row }) => `${row.original.counted_count}/${row.original.item_count}`,
    },
    { accessorKey: "created_by_name", header: "Oluşturan", meta: { className: "text-12 text-ink-2" } },
    { accessorKey: "created_at", header: "Tarih", meta: { mono: true, className: "text-12" }, cell: ({ getValue }) => dateTime(getValue()) },
    { accessorKey: "applied_at", header: "Onay", meta: { mono: true, className: "text-12" }, cell: ({ getValue }) => dateTime(getValue()) },
  ];

  return (
    <div>
      <PageHeader
        title="Sayım"
        count={q.data?.length}
        sub="Raf veya kategori seçerek sayım listesi oluşturun; barkod okutarak sayın; farkları yönetici onayıyla stoğa işleyin."
        actions={
          canWrite && (
            <Button variant="primary" icon={Plus} onClick={() => setOpen(true)}>
              Yeni sayım
            </Button>
          )
        }
      />
      {q.isLoading ? (
        <Loading />
      ) : q.isError ? (
        <ErrorState error={q.error} onRetry={() => q.refetch()} />
      ) : (
        <DataTable data={q.data ?? []} columns={columns} onRowClick={(c) => navigate(`/sayim/${c.id}`)} empty={<EmptyState icon="ground" title="Henüz sayım yapılmadı." />} />
      )}
      <Dialog
        open={open}
        onOpenChange={(o) => {
          setOpen(o);
          if (!o && params.get("yeni")) setParams({}, { replace: true });
        }}
        title="Yeni sayım"
        width={460}
        footer={
          <>
            <Button variant="ghost" onClick={() => setOpen(false)}>
              Vazgeç
            </Button>
            <Button variant="primary" onClick={create} loading={busy}>
              Sayım listesini oluştur
            </Button>
          </>
        }
      >
        <div className="flex flex-col gap-3">
          <Field label="Ad" hint="Boş bırakılırsa tarih ve filtreden üretilir">
            {(id) => <Input id={id} value={name} onChange={(e) => setName(e.target.value)} />}
          </Field>
          <Field label="Raf / konum">
            {(id) => (
              <Select id={id} value={loc} onChange={(e) => setLoc(e.target.value)}>
                <option value="">Tüm raflar</option>
                {locations.data?.map((l) => (
                  <option key={l.id} value={l.id}>
                    {l.code} {l.name && `· ${l.name}`}
                  </option>
                ))}
              </Select>
            )}
          </Field>
          <Field label="Kategori">
            {(id) => (
              <Select id={id} value={cat} onChange={(e) => setCat(e.target.value)}>
                <option value="">Tüm kategoriler</option>
                {categories.data?.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.path}
                  </option>
                ))}
              </Select>
            )}
          </Field>
          {error && <p className="text-12 text-crit">{error}</p>}
        </div>
      </Dialog>
    </div>
  );
}
