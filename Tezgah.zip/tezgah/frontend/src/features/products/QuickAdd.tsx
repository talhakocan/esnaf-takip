import { useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { Button } from "@/design/Button";
import { Dialog } from "@/design/Dialog";
import { Field, Input, Select } from "@/design/Input";
import { ApiError, api } from "@/lib/api";
import { useCategories } from "@/lib/hooks";

export type QuickKind = "category" | "brand" | "location";

const TITLE: Record<QuickKind, string> = { category: "Yeni kategori", brand: "Yeni marka", location: "Yeni raf / konum" };
const PATH: Record<QuickKind, string> = { category: "/categories", brand: "/brands", location: "/locations" };
const KEY: Record<QuickKind, string> = { category: "categories", brand: "brands", location: "locations" };

/** Ürün formundan ayrılmadan kategori, marka veya raf ekleme. */
export function QuickAddDialog({ kind, onClose, onCreated }: { kind: QuickKind | null; onClose: () => void; onCreated: (kind: QuickKind, id: number) => void }) {
  const qc = useQueryClient();
  const categories = useCategories();
  const [name, setName] = useState("");
  const [code, setCode] = useState("");
  const [parent, setParent] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  if (!kind) return null;
  const save = async () => {
    setBusy(true);
    setError(null);
    try {
      const body = kind === "category" ? { name, parent_id: parent ? Number(parent) : null } : kind === "brand" ? { name } : { code, name };
      const created = await api.post<{ id: number }>(PATH[kind], body);
      await qc.invalidateQueries({ queryKey: [KEY[kind]] });
      onCreated(kind, created.id);
      setName("");
      setCode("");
      setParent("");
      onClose();
    } catch (e) {
      setError(e instanceof ApiError ? e.message : "Kaydedilemedi.");
    } finally {
      setBusy(false);
    }
  };
  return (
    <Dialog
      open
      onOpenChange={(o) => !o && onClose()}
      title={TITLE[kind]}
      width={420}
      footer={
        <>
          <Button variant="ghost" onClick={onClose}>
            Vazgeç
          </Button>
          <Button variant="primary" onClick={save} loading={busy} disabled={kind === "location" ? !code.trim() : !name.trim()}>
            Ekle
          </Button>
        </>
      }
    >
      <form
        className="flex flex-col gap-3"
        onSubmit={(e) => {
          e.preventDefault();
          void save();
        }}
      >
        {kind === "location" && (
          <Field label="Raf kodu" hint="Örn. A-03, DEPO-1">
            {(id) => <Input id={id} mono autoFocus value={code} onChange={(e) => setCode(e.target.value.toLocaleUpperCase("tr-TR"))} />}
          </Field>
        )}
        <Field label={kind === "location" ? "Açıklama" : "Ad"}>
          {(id) => <Input id={id} autoFocus={kind !== "location"} value={name} onChange={(e) => setName(e.target.value)} />}
        </Field>
        {kind === "category" && (
          <Field label="Üst kategori">
            {(id) => (
              <Select id={id} value={parent} onChange={(e) => setParent(e.target.value)}>
                <option value="">(Ana kategori)</option>
                {categories.data?.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.path}
                  </option>
                ))}
              </Select>
            )}
          </Field>
        )}
        {error && <p className="text-12 text-crit">{error}</p>}
        <button type="submit" className="hidden" />
      </form>
    </Dialog>
  );
}
