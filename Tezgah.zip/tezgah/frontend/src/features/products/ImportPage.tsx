import { useQueryClient } from "@tanstack/react-query";
import { Download, Upload } from "lucide-react";
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/design/Button";
import { type ColumnDef, DataTable } from "@/design/DataTable";
import { Led, Money } from "@/design/Indicators";
import { PageHeader, Panel } from "@/design/Page";
import { useToast } from "@/design/Toast";
import { ApiError, api, download, errorMessage } from "@/lib/api";
import { UNIT_LABEL } from "@/lib/format";
import { useTitle } from "@/lib/hooks";
import type { UnitType } from "@/lib/types";

interface Row {
  row: number;
  sku: string;
  name: string;
  action: "NEW" | "UPDATE" | "ERROR";
  errors: string[];
  sale_price_kurus?: number;
  unit_type?: UnitType;
}

interface Preview {
  rows: Row[];
  counts: { NEW: number; UPDATE: number; ERROR: number };
}

const ACTION = { NEW: ["Yeni", "ok"], UPDATE: ["Güncelleme", "info"], ERROR: ["Hata", "crit"] } as const;

export default function ImportPage() {
  useTitle("Excel'den içe aktar");
  const navigate = useNavigate();
  const qc = useQueryClient();
  const toast = useToast();
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<Preview | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const load = async (f: File) => {
    setFile(f);
    setBusy(true);
    setError(null);
    try {
      setPreview(await api.upload<Preview>("/products/import/preview", f));
    } catch (e) {
      setPreview(null);
      setError(e instanceof ApiError ? e.message : "Dosya okunamadı.");
    } finally {
      setBusy(false);
    }
  };
  const apply = async () => {
    if (!file) return;
    setBusy(true);
    try {
      const r = await api.upload<{ created: number; updated: number }>("/products/import/apply", file);
      await qc.invalidateQueries({ queryKey: ["products"] });
      await qc.invalidateQueries({ queryKey: ["categories"] });
      await qc.invalidateQueries({ queryKey: ["brands"] });
      toast({ title: "İçe aktarma tamamlandı", message: `${r.created} yeni, ${r.updated} güncellenen ürün` });
      navigate("/urunler");
    } catch (e) {
      setError(errorMessage(e));
    } finally {
      setBusy(false);
    }
  };

  const columns: ColumnDef<Row, any>[] = [
    { accessorKey: "row", header: "Satır", meta: { mono: true, align: "right", className: "w-16" } },
    { accessorKey: "action", header: "İşlem", cell: ({ row }) => <Led tone={ACTION[row.original.action][1]}>{ACTION[row.original.action][0]}</Led> },
    { accessorKey: "sku", header: "SKU", meta: { mono: true, className: "text-12" } },
    { accessorKey: "name", header: "Ürün" },
    { accessorKey: "unit_type", header: "Birim", cell: ({ getValue }) => (getValue() ? UNIT_LABEL[getValue() as UnitType] : "—") },
    { accessorKey: "sale_price_kurus", header: "Satış fiyatı", meta: { align: "right" }, cell: ({ getValue }) => <Money value={getValue()} /> },
    {
      accessorKey: "errors",
      header: "Hata",
      meta: { exportValue: (r) => r.errors.join(" ") },
      cell: ({ row }) => (row.original.errors.length ? <span className="text-12 text-crit">{row.original.errors.join(" ")}</span> : <span className="text-ink-3">—</span>),
    },
  ];

  return (
    <div className="pb-10">
      <PageHeader
        title="Excel'den ürün içe aktar"
        sub="SKU eşleşen ürünler güncellenir, diğerleri yeni ürün olarak eklenir. Kategori, marka ve raf yoksa oluşturulur."
        actions={
          <Button icon={Download} onClick={() => download("/products/import-template.xlsx").catch((e) => toast({ tone: "crit", title: "İndirilemedi", message: errorMessage(e) }))}>
            Şablonu indir
          </Button>
        }
      />
      <div className="flex flex-col gap-4 px-4 md:px-6">
        <Panel title="1 · Dosya">
          <div className="p-4 flex flex-wrap items-center gap-3">
            <label className="inline-flex items-center gap-2 h-8 px-3 border border-rule-strong rounded-ctl bg-surface hover:bg-surface-2 cursor-pointer text-13 font-medium">
              <Upload size={16} strokeWidth={1.5} aria-hidden />
              .xlsx dosyası seç
              <input type="file" accept=".xlsx,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" className="sr-only" onChange={(e) => e.target.files?.[0] && void load(e.target.files[0])} />
            </label>
            {file && <span className="num text-13 text-ink-2">{file.name}</span>}
            {busy && <span className="num text-12 text-ink-3">işleniyor…</span>}
            {error && <p className="w-full text-13 text-crit">{error}</p>}
          </div>
        </Panel>
        {preview && (
          <Panel
            title="2 · Önizleme"
            right={
              <span className="flex gap-3 text-12">
                <Led tone="ok">{preview.counts.NEW} yeni</Led>
                <Led tone="info">{preview.counts.UPDATE} güncelleme</Led>
                <Led tone="crit">{preview.counts.ERROR} hata</Led>
              </span>
            }
          >
            <DataTable data={preview.rows} columns={columns} className="border-y-0" exportName="ice-aktarma-onizleme" />
            <div className="flex items-center justify-end gap-3 p-3 border-t border-rule">
              {preview.counts.ERROR > 0 && <span className="text-13 text-crit">Hatalı satırları düzeltip dosyayı yeniden yükleyin.</span>}
              <Button variant="primary" onClick={apply} loading={busy} disabled={preview.counts.ERROR > 0 || !preview.rows.length}>
                İçe aktar
              </Button>
            </div>
          </Panel>
        )}
      </div>
    </div>
  );
}
