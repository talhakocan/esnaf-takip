import { useQuery, useQueryClient } from "@tanstack/react-query";
import type { RowSelectionState } from "@tanstack/react-table";
import { Archive, FileSpreadsheet, FolderTree, Percent, Plus, Search, Tag as TagIcon } from "lucide-react";
import { useMemo, useState } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { useCan } from "@/app/auth";
import { Button, ButtonLink } from "@/design/Button";
import { type ColumnDef, DataTable } from "@/design/DataTable";
import { Dialog, useConfirm } from "@/design/Dialog";
import { EmptyState, ErrorState, Loading } from "@/design/Feedback";
import { Money, StockMeter, Tag } from "@/design/Indicators";
import { Input, Select } from "@/design/Input";
import { PageHeader } from "@/design/Page";
import { useToast } from "@/design/Toast";
import { api, download, errorMessage } from "@/lib/api";
import { pct, rate, relativeDays } from "@/lib/format";
import { useCategories, useLocations, useTitle } from "@/lib/hooks";
import type { Product } from "@/lib/types";

const norm = (s: string) => s.toLocaleLowerCase("tr-TR");

export default function ProductsPage() {
  useTitle("Ürünler");
  const navigate = useNavigate();
  const qc = useQueryClient();
  const toast = useToast();
  const confirm = useConfirm();
  const [params, setParams] = useSearchParams();
  const canWrite = useCan("product.write");
  const canCost = useCan("product.cost_view");
  const canBulk = useCan("product.bulk_price");
  const canImport = useCan("product.import");
  const canArchive = useCan("product.archive");
  const categories = useCategories();
  const locations = useLocations();
  const [q, setQ] = useState(params.get("q") ?? "");
  const [selection, setSelection] = useState<RowSelectionState>({});
  const [catDialog, setCatDialog] = useState(false);
  const [newCat, setNewCat] = useState("");

  const filters = {
    category_id: params.get("kategori") ?? undefined,
    location_id: params.get("raf") ?? undefined,
    stock: params.get("stok") ?? undefined,
    pricing_mode: params.get("fiyat") ?? undefined,
    active: params.get("durum") ?? "active",
  };
  const setFilter = (key: string, value: string) => {
    const next = new URLSearchParams(params);
    if (value) next.set(key, value);
    else next.delete(key);
    setParams(next, { replace: true });
    setSelection({});
  };

  const query = useQuery({ queryKey: ["products", filters], queryFn: () => api.get<Product[]>("/products", filters) });
  const rows = useMemo(() => {
    const all = query.data ?? [];
    const needle = norm(q.trim());
    if (!needle) return all;
    return all.filter((p) => norm(`${p.name} ${p.sku} ${p.barcode ?? ""} ${p.brand_name ?? ""}`).includes(needle));
  }, [query.data, q]);
  const selectedIds = Object.keys(selection).map(Number);

  const columns = useMemo<ColumnDef<Product, any>[]>(() => {
    const cols: ColumnDef<Product, any>[] = [
      { accessorKey: "sku", header: "SKU", meta: { mono: true, className: "w-28 text-12" } },
      {
        accessorKey: "name",
        header: "Ürün",
        cell: ({ row }) => (
          <div className="min-w-[220px]">
            <div className="truncate max-w-[360px]">{row.original.name}</div>
            {row.original.brand_name && <div className="text-12 text-ink-3">{row.original.brand_name}</div>}
          </div>
        ),
      },
      {
        accessorKey: "category_path",
        header: "Kategori",
        cell: ({ getValue }) => (getValue() ? <span className="text-12 text-ink-2">{getValue()}</span> : <span className="text-ink-3">—</span>),
      },
      { accessorKey: "location_code", header: "Konum", meta: { mono: true, className: "text-12" } },
      {
        id: "stock",
        accessorFn: (p) => p.stock_qty,
        header: "Stok",
        meta: { align: "right", exportValue: (p) => p.stock_qty },
        cell: ({ row }) => (
          <StockMeter qty={row.original.stock_qty} min={row.original.min_stock} unit={row.original.unit_type} status={row.original.stock_status} />
        ),
      },
      {
        accessorKey: "sale_price_kurus",
        header: "Satış fiyatı",
        meta: { align: "right", exportValue: (p) => (p.sale_price_kurus / 100).toFixed(2) },
        cell: ({ row }) => (
          <span className="inline-flex items-center gap-1.5">
            {row.original.pricing_mode === "FX_LINKED" && <Tag>KUR</Tag>}
            <Money value={row.original.sale_price_kurus} />
            {row.original.unit_type === "METER" && <span className="text-11 text-ink-3">/m</span>}
          </span>
        ),
      },
    ];
    if (canCost) {
      cols.push(
        {
          id: "purchase",
          accessorFn: (p) => p.purchase_price,
          header: "Alış",
          meta: { align: "right", mono: true, exportValue: (p) => `${p.purchase_price} ${p.purchase_currency}` },
          cell: ({ row }) =>
            row.original.unit_type === "SERVICE" ? (
              <span className="text-ink-3">—</span>
            ) : (
              <span className="text-12">
                {rate(row.original.purchase_price)} <span className="text-ink-3">{row.original.purchase_currency}</span>
              </span>
            ),
        },
        {
          accessorKey: "margin_pct",
          header: "Marj",
          meta: { align: "right", mono: true, exportValue: (p) => p.margin_pct ?? "" },
          cell: ({ getValue }) => {
            const v = getValue() as number | null;
            if (v === null || v === undefined) return <span className="text-ink-3">—</span>;
            return <span className={v < 10 ? "text-crit" : undefined}>{pct(v)}</span>;
          },
        },
      );
    }
    cols.push({
      accessorKey: "last_movement_at",
      header: "Son hareket",
      meta: { align: "right", className: "text-12 text-ink-2 whitespace-nowrap" },
      cell: ({ row }) =>
        row.original.unit_type === "SERVICE" ? (
          <span className="text-ink-3">—</span>
        ) : (
          <span className={row.original.is_dead ? "text-warn" : undefined}>{relativeDays(row.original.last_movement_at)}</span>
        ),
    });
    return cols;
  }, [canCost]);

  const bulkArchive = async () => {
    const ok = await confirm({
      title: `${selectedIds.length} ürün arşivlensin mi?`,
      message: "Arşivlenen ürünler satış ekranında görünmez; geçmiş kayıtlar korunur. Arşivden geri alınabilir.",
      confirmLabel: "Arşivle",
      danger: true,
    });
    if (!ok) return;
    try {
      await api.post("/products/bulk-update", { product_ids: selectedIds, archive: true });
      toast({ title: "Ürünler arşivlendi", message: `${selectedIds.length} ürün` });
      setSelection({});
      await qc.invalidateQueries({ queryKey: ["products"] });
    } catch (e) {
      toast({ tone: "crit", title: "Arşivlenemedi", message: errorMessage(e) });
    }
  };

  const bulkCategory = async () => {
    try {
      await api.post("/products/bulk-update", { product_ids: selectedIds, category_id: Number(newCat) });
      toast({ title: "Kategori değiştirildi", message: `${selectedIds.length} ürün` });
      setCatDialog(false);
      setSelection({});
      await qc.invalidateQueries({ queryKey: ["products"] });
    } catch (e) {
      toast({ tone: "crit", title: "Güncellenemedi", message: errorMessage(e) });
    }
  };

  const anyFilter = !!(filters.category_id || filters.location_id || filters.stock || filters.pricing_mode || filters.active !== "active" || q);

  return (
    <div>
      <PageHeader
        title="Ürünler"
        count={rows.length}
        actions={
          <>
            {canImport && (
              <ButtonLink to="/urunler/ice-aktar" icon={FileSpreadsheet}>
                İçe aktar
              </ButtonLink>
            )}
            {canBulk && (
              <ButtonLink to="/urunler/toplu-fiyat" icon={Percent}>
                Toplu fiyat
              </ButtonLink>
            )}
            {canWrite && (
              <ButtonLink to="/urunler/yeni" variant="primary" icon={Plus}>
                Yeni ürün
              </ButtonLink>
            )}
          </>
        }
      />
      {selectedIds.length > 0 && (
        <div className="flex flex-wrap items-center gap-2 px-4 md:px-6 py-2 bg-surface-2 border-t border-rule anim-in">
          <span className="num text-13 mr-2">{selectedIds.length} ürün seçili</span>
          {canBulk && (
            <Button size="sm" icon={Percent} onClick={() => navigate(`/urunler/toplu-fiyat?ids=${selectedIds.join(",")}`)}>
              Fiyat güncelle
            </Button>
          )}
          <Button size="sm" icon={TagIcon} onClick={() => navigate(`/etiket?ids=${selectedIds.join(",")}`)}>
            Etiket bas
          </Button>
          {canWrite && (
            <Button size="sm" icon={FolderTree} onClick={() => setCatDialog(true)}>
              Kategori değiştir
            </Button>
          )}
          {canArchive && (
            <Button size="sm" variant="danger" icon={Archive} onClick={bulkArchive}>
              Arşivle
            </Button>
          )}
          <Button size="sm" variant="ghost" onClick={() => setSelection({})}>
            Seçimi temizle
          </Button>
        </div>
      )}
      {query.isLoading ? (
        <Loading />
      ) : query.isError ? (
        <ErrorState error={query.error} onRetry={() => query.refetch()} />
      ) : (
        <DataTable
          data={rows}
          columns={columns}
          getRowId={(p) => String(p.id)}
          onRowClick={(p) => navigate(`/urunler/${p.id}`)}
          selectable
          selection={selection}
          onSelectionChange={setSelection}
          storageKey="products"
          exportName="tezgah-urunler"
          onExportXlsx={() => download("/products/export.xlsx").catch((e) => toast({ tone: "crit", title: "İndirilemedi", message: errorMessage(e) }))}
          rowClassName={(p) => (!p.is_active ? "opacity-60" : undefined)}
          toolbar={
            <>
              <div className="relative w-full sm:w-64">
                <Search size={14} strokeWidth={1.5} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-ink-3 pointer-events-none" aria-hidden />
                <Input
                  data-page-search
                  value={q}
                  onChange={(e) => setQ(e.target.value)}
                  placeholder="Ad, SKU, barkod…  /"
                  className="pl-8"
                  aria-label="Ürün ara"
                />
              </div>
              <Select value={filters.category_id ?? ""} onChange={(e) => setFilter("kategori", e.target.value)} aria-label="Kategori" className="w-52">
                <option value="">Tüm kategoriler</option>
                {categories.data?.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.path}
                  </option>
                ))}
              </Select>
              <Select value={filters.location_id ?? ""} onChange={(e) => setFilter("raf", e.target.value)} aria-label="Konum" className="w-32">
                <option value="">Tüm raflar</option>
                {locations.data?.map((l) => (
                  <option key={l.id} value={l.id}>
                    {l.code}
                  </option>
                ))}
              </Select>
              <Select value={filters.stock ?? ""} onChange={(e) => setFilter("stok", e.target.value)} aria-label="Stok durumu" className="w-36">
                <option value="">Tüm stoklar</option>
                <option value="critical">Kritik</option>
                <option value="out">Tükendi</option>
                <option value="warn">Azalıyor</option>
                <option value="dead">Ölü stok</option>
              </Select>
              <Select value={filters.pricing_mode ?? ""} onChange={(e) => setFilter("fiyat", e.target.value)} aria-label="Fiyat modu" className="w-36">
                <option value="">Tüm fiyatlar</option>
                <option value="FIXED">Sabit TL</option>
                <option value="FX_LINKED">Kura bağlı</option>
              </Select>
              <Select value={filters.active} onChange={(e) => setFilter("durum", e.target.value === "active" ? "" : e.target.value)} aria-label="Durum" className="w-28">
                <option value="active">Aktif</option>
                <option value="archived">Arşiv</option>
                <option value="all">Tümü</option>
              </Select>
              {anyFilter && (
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => {
                    setQ("");
                    setParams(new URLSearchParams(), { replace: true });
                  }}
                >
                  Filtreleri temizle
                </Button>
              )}
            </>
          }
          empty={
            <EmptyState
              icon="resistor"
              title={anyFilter ? "Filtreye uyan ürün yok." : "Henüz ürün eklenmemiş."}
              action={
                canWrite && !anyFilter ? (
                  <ButtonLink to="/urunler/yeni" variant="primary" icon={Plus}>
                    İlk ürünü ekle
                  </ButtonLink>
                ) : undefined
              }
            />
          }
        />
      )}
      <Dialog
        open={catDialog}
        onOpenChange={setCatDialog}
        title="Kategori değiştir"
        description={`${selectedIds.length} ürünün kategorisi değişecek.`}
        width={420}
        footer={
          <>
            <Button variant="ghost" onClick={() => setCatDialog(false)}>
              Vazgeç
            </Button>
            <Button variant="primary" onClick={bulkCategory} disabled={!newCat}>
              Uygula
            </Button>
          </>
        }
      >
        <Select value={newCat} onChange={(e) => setNewCat(e.target.value)} aria-label="Yeni kategori">
          <option value="">Kategori seçin…</option>
          {categories.data?.map((c) => (
            <option key={c.id} value={c.id}>
              {c.path}
            </option>
          ))}
        </Select>
      </Dialog>
    </div>
  );
}
