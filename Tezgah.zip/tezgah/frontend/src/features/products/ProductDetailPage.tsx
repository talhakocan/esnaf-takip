import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Archive, ArchiveRestore, ArrowDownToLine, Pencil, Tag as TagIcon } from "lucide-react";
import { useMemo, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { useCan } from "@/app/auth";
import { useCrumb } from "@/app/crumbs";
import { Button, ButtonLink } from "@/design/Button";
import { LineSeries } from "@/design/Charts";
import { Barcode } from "@/design/Codes";
import { type ColumnDef, DataTable } from "@/design/DataTable";
import { useConfirm } from "@/design/Dialog";
import { EmptyState, ErrorState, Loading } from "@/design/Feedback";
import { Led, Money, StockMeter, Tag } from "@/design/Indicators";
import { KeyValues, Panel, TabPanel, Tabs } from "@/design/Page";
import { useToast } from "@/design/Toast";
import { api, errorMessage } from "@/lib/api";
import { dateOnly, dateTime, money, pct, qty, rate, relativeDays, UNIT_LABEL } from "@/lib/format";
import { PRICE_REASON_TR, ROUNDING_TR, STOCK_STATUS_TONE, STOCK_STATUS_TR } from "@/lib/labels";
import type { Movement, PriceHistoryRow, Product, Serial } from "@/lib/types";
import { movementColumns } from "../stock/movementColumns";

const SERIAL_TR: Record<string, string> = { IN_STOCK: "Stokta", SOLD: "Satıldı", RETURNED: "İade (stokta)", DEFECTIVE: "Arızalı" };
const SERIAL_TONE = { IN_STOCK: "ok", SOLD: "info", RETURNED: "warn", DEFECTIVE: "crit" } as const;

interface SupplierRow {
  supplier_id: number;
  supplier_name: string;
  order_id: number;
  order_no: string;
  status: string;
  date: string;
  qty: number;
  received_qty: number;
  unit_price?: number;
  currency?: string;
}

export default function ProductDetailPage() {
  const { id } = useParams();
  const qc = useQueryClient();
  const toast = useToast();
  const confirm = useConfirm();
  const canWrite = useCan("product.write");
  const canCost = useCan("product.cost_view");
  const canArchive = useCan("product.archive");
  const [tab, setTab] = useState("genel");
  const q = useQuery({ queryKey: ["product", id], queryFn: () => api.get<Product>(`/products/${id}`) });
  const p = q.data;
  useCrumb(p?.name);
  const movements = useQuery({
    queryKey: ["product", id, "movements"],
    queryFn: () => api.get<Movement[]>(`/products/${id}/movements`),
    enabled: tab === "hareketler",
  });
  const serials = useQuery({
    queryKey: ["product", id, "serials"],
    queryFn: () => api.get<Serial[]>(`/products/${id}/serials`),
    enabled: tab === "seri" && !!p?.track_serial,
  });
  const prices = useQuery({
    queryKey: ["product", id, "prices"],
    queryFn: () => api.get<PriceHistoryRow[]>(`/products/${id}/price-history`),
    enabled: tab === "fiyat",
  });
  const suppliers = useQuery({
    queryKey: ["product", id, "suppliers"],
    queryFn: () => api.get<SupplierRow[]>(`/products/${id}/suppliers`),
    enabled: tab === "tedarik",
  });
  const moveCols = useMemo(() => movementColumns({ withProduct: false, withCost: canCost }), [canCost]);

  if (q.isLoading) return <Loading />;
  if (q.isError || !p) return <ErrorState error={q.error} onRetry={() => q.refetch()} />;

  const toggleArchive = async () => {
    const archiving = p.is_active;
    if (archiving) {
      const ok = await confirm({
        title: "Ürün arşivlensin mi?",
        message: `"${p.name}" satış ekranında görünmeyecek. Geçmiş kayıtlar korunur; istediğinizde geri alabilirsiniz.`,
        confirmLabel: "Arşivle",
        danger: true,
      });
      if (!ok) return;
    }
    try {
      await api.post(`/products/${p.id}/${archiving ? "archive" : "restore"}`);
      toast({ title: archiving ? "Ürün arşivlendi" : "Ürün arşivden alındı" });
      await qc.invalidateQueries({ queryKey: ["product", id] });
      await qc.invalidateQueries({ queryKey: ["products"] });
    } catch (e) {
      toast({ tone: "crit", title: "İşlem yapılamadı", message: errorMessage(e) });
    }
  };

  const bd = p.price_breakdown;
  const priceSeries = (prices.data ?? [])
    .slice()
    .reverse()
    .map((h) => ({ label: dateOnly(h.at), price: h.new_price }));
  if (prices.data?.length) priceSeries.unshift({ label: "başlangıç", price: prices.data[prices.data.length - 1].old_price });

  const priceCols: ColumnDef<PriceHistoryRow, any>[] = [
    { accessorKey: "at", header: "Tarih", meta: { mono: true, className: "text-12" }, cell: ({ getValue }) => dateTime(getValue()) },
    { accessorKey: "old_price", header: "Eski fiyat", meta: { align: "right" }, cell: ({ getValue }) => <Money value={getValue()} className="text-ink-2" /> },
    { accessorKey: "new_price", header: "Yeni fiyat", meta: { align: "right" }, cell: ({ getValue }) => <Money value={getValue()} /> },
    {
      id: "change",
      header: "Değişim",
      meta: { align: "right", mono: true },
      accessorFn: (h) => (h.old_price ? ((h.new_price - h.old_price) / h.old_price) * 100 : null),
      cell: ({ getValue }) => {
        const v = getValue() as number | null;
        return v === null ? "—" : <span className={v > 0 ? "text-ok" : v < 0 ? "text-crit" : undefined}>{(v > 0 ? "+" : "") + pct(v)}</span>;
      },
    },
    { accessorKey: "reason", header: "Neden", cell: ({ getValue }) => PRICE_REASON_TR[getValue()] ?? getValue() },
    { accessorKey: "user_name", header: "Kullanıcı", meta: { className: "text-12 text-ink-2" } },
  ];
  const serialCols: ColumnDef<Serial, any>[] = [
    { accessorKey: "serial_no", header: "Seri no", meta: { mono: true } },
    {
      accessorKey: "status",
      header: "Durum",
      cell: ({ row }) => <Led tone={SERIAL_TONE[row.original.status]}>{SERIAL_TR[row.original.status]}</Led>,
    },
    { accessorKey: "created_at", header: "Giriş", meta: { mono: true, className: "text-12" }, cell: ({ getValue }) => dateOnly(getValue()) },
    {
      accessorKey: "receipt_no",
      header: "Satış fişi",
      meta: { mono: true, className: "text-12" },
      cell: ({ row }) =>
        row.original.sale_id ? (
          <Link to={`/satislar/${row.original.sale_id}`} className="underline decoration-rule-strong">
            {row.original.receipt_no}
          </Link>
        ) : (
          <span className="text-ink-3">—</span>
        ),
    },
    {
      accessorKey: "warranty_until",
      header: "Garanti bitişi",
      meta: { mono: true, className: "text-12" },
      cell: ({ getValue }) => {
        const v = getValue();
        if (!v) return <span className="text-ink-3">—</span>;
        const active = new Date(v) >= new Date(new Date().toDateString());
        return <Led tone={active ? "ok" : "neutral"}>{dateOnly(v)}</Led>;
      },
    },
  ];
  const supplierCols: ColumnDef<SupplierRow, any>[] = [
    { accessorKey: "date", header: "Tarih", meta: { mono: true, className: "text-12" }, cell: ({ getValue }) => dateOnly(getValue()) },
    {
      accessorKey: "supplier_name",
      header: "Tedarikçi",
      cell: ({ row }) => (
        <Link to={`/tedarikciler/${row.original.supplier_id}`} className="hover:underline">
          {row.original.supplier_name}
        </Link>
      ),
    },
    {
      accessorKey: "order_no",
      header: "Sipariş",
      meta: { mono: true, className: "text-12" },
      cell: ({ row }) => (
        <Link to={`/siparisler/${row.original.order_id}`} className="underline decoration-rule-strong">
          {row.original.order_no}
        </Link>
      ),
    },
    { accessorKey: "qty", header: "Miktar", meta: { align: "right" }, cell: ({ row }) => <span className="num">{qty(row.original.qty, p.unit_type)}</span> },
    {
      accessorKey: "received_qty",
      header: "Gelen",
      meta: { align: "right" },
      cell: ({ row }) => <span className="num">{qty(row.original.received_qty, p.unit_type)}</span>,
    },
    ...(canCost
      ? [
          {
            id: "price",
            header: "Birim fiyat",
            meta: { align: "right" as const, mono: true },
            accessorFn: (r: SupplierRow) => r.unit_price,
            cell: ({ row }: { row: { original: SupplierRow } }) => `${rate(row.original.unit_price)} ${row.original.currency}`,
          },
        ]
      : []),
  ];

  return (
    <div className="pb-8">
      <div className="px-4 md:px-6 pt-5 pb-4 flex flex-wrap items-start justify-between gap-4">
        <div className="min-w-0">
          <div className="flex flex-wrap items-center gap-2 mb-1">
            <Led tone={STOCK_STATUS_TONE[p.stock_status]}>{STOCK_STATUS_TR[p.stock_status]}</Led>
            {p.is_dead && <Led tone="warn">Ölü stok</Led>}
            {!p.is_active && <Tag tone="crit">ARŞİV</Tag>}
            {p.pricing_mode === "FX_LINKED" && <Tag>KURA BAĞLI</Tag>}
            {p.track_serial && <Tag>SERİ TAKİPLİ</Tag>}
          </div>
          <h1 className="font-cond text-20 font-semibold">{p.name}</h1>
          <div className="num text-13 text-ink-2 mt-0.5">
            {p.sku}
            {p.category_path && <span className="font-sans text-ink-3"> · {p.category_path}</span>}
          </div>
        </div>
        <div className="flex flex-wrap items-start gap-4">
          {p.barcode && (
            <div className="bg-surface border border-rule px-3 py-2 text-ink">
              <Barcode value={p.barcode} height={34} />
            </div>
          )}
          <div className="flex flex-wrap gap-2">
            {p.unit_type !== "SERVICE" && (
              <ButtonLink to={`/stok/giris?urun=${p.id}`} icon={ArrowDownToLine}>
                Stok girişi
              </ButtonLink>
            )}
            <ButtonLink to={`/etiket?ids=${p.id}`} icon={TagIcon}>
              Etiket
            </ButtonLink>
            {canArchive && (
              <Button icon={p.is_active ? Archive : ArchiveRestore} variant={p.is_active ? "danger" : "secondary"} onClick={toggleArchive}>
                {p.is_active ? "Arşivle" : "Arşivden al"}
              </Button>
            )}
            {canWrite && (
              <ButtonLink to={`/urunler/${p.id}/duzenle`} variant="primary" icon={Pencil}>
                Düzenle
              </ButtonLink>
            )}
          </div>
        </div>
      </div>

      <div className="grid lg:grid-cols-[1fr_340px] gap-0 lg:gap-6 lg:pr-6">
        <div className="min-w-0 bg-surface border-y border-rule lg:border-r">
          <Tabs
            value={tab}
            onValueChange={setTab}
            tabs={[
              { value: "genel", label: "Genel" },
              { value: "hareketler", label: "Hareketler" },
              ...(p.track_serial ? [{ value: "seri", label: "Seri numaraları" }] : []),
              { value: "fiyat", label: "Fiyat geçmişi" },
              { value: "tedarik", label: "Tedarikçiler" },
            ]}
          >
            <TabPanel value="genel">
              <KeyValues
                rows={[
                  ["Kategori", p.category_path],
                  ["Marka", p.brand_name],
                  ["Varsayılan tedarikçi", p.supplier_name && <Link to={`/tedarikciler/${p.supplier_id}`}>{p.supplier_name}</Link>],
                  ["Birim", UNIT_LABEL[p.unit_type]],
                  ["KDV oranı", <span className="num">%{p.vat_rate}</span>],
                  ["Fiyat modu", p.pricing_mode === "FX_LINKED" ? "Kura bağlı" : "Sabit TL"],
                  ["Barkod", p.barcode ? <span className="num">{p.barcode}</span> : null],
                  ["Seri takibi", p.track_serial ? "Var" : "Yok"],
                  ["Garanti", p.warranty_months ? <span className="num">{p.warranty_months} ay</span> : "—"],
                  ["Notlar", p.notes || null],
                  ["Oluşturma", <span className="num text-12">{dateTime(p.created_at)}</span>],
                  ["Son güncelleme", <span className="num text-12">{dateTime(p.updated_at)}</span>],
                ]}
              />
            </TabPanel>
            <TabPanel value="hareketler">
              {movements.isLoading ? (
                <Loading />
              ) : (
                <DataTable
                  data={movements.data ?? []}
                  columns={moveCols}
                  exportName={`hareketler-${p.sku}`}
                  storageKey="product-movements"
                  className="border-y-0"
                  empty={<EmptyState icon="circuit" title="Bu ürün için henüz stok hareketi yok." />}
                />
              )}
            </TabPanel>
            {p.track_serial && (
              <TabPanel value="seri">
                {serials.isLoading ? (
                  <Loading />
                ) : (
                  <DataTable
                    data={serials.data ?? []}
                    columns={serialCols}
                    exportName={`seri-${p.sku}`}
                    className="border-y-0"
                    empty={<EmptyState icon="connector" title="Kayıtlı seri numarası yok. Stok girişinde seri numaraları eklenir." />}
                  />
                )}
              </TabPanel>
            )}
            <TabPanel value="fiyat">
              {prices.isLoading ? (
                <Loading />
              ) : prices.data?.length ? (
                <>
                  <LineSeries data={priceSeries} x="label" series={[{ key: "price", label: "Satış fiyatı" }]} height={180} step />
                  <DataTable data={prices.data} columns={priceCols} exportName={`fiyat-${p.sku}`} className="border-b-0" hideFooter={prices.data.length <= 50} />
                </>
              ) : (
                <EmptyState icon="resistor" title="Fiyat değişikliği kaydı yok." />
              )}
            </TabPanel>
            <TabPanel value="tedarik">
              {suppliers.isLoading ? (
                <Loading />
              ) : (
                <DataTable
                  data={suppliers.data ?? []}
                  columns={supplierCols}
                  className="border-y-0"
                  empty={<EmptyState icon="connector" title="Bu ürün henüz bir satın alma siparişinde yer almadı." />}
                />
              )}
            </TabPanel>
          </Tabs>
        </div>

        <aside className="flex flex-col gap-4 px-4 lg:px-0 mt-4 lg:mt-0">
          <Panel title="Stok">
            <div className="px-4 py-3 flex flex-col gap-2">
              {p.unit_type === "SERVICE" ? (
                <p className="text-13 text-ink-2">Hizmet ürünü — stok tutulmaz.</p>
              ) : (
                <>
                  <div className="flex items-center justify-between">
                    <span className="num text-28">{qty(p.stock_qty, p.unit_type)}</span>
                    <StockMeter qty={p.stock_qty} min={p.min_stock} unit={p.unit_type} status={p.stock_status} compact />
                  </div>
                  <div className="text-13 text-ink-2 flex justify-between">
                    <span>Min. stok</span>
                    <span className="num">{qty(p.min_stock, p.unit_type)}</span>
                  </div>
                  <div className="text-13 text-ink-2 flex justify-between">
                    <span>Raf</span>
                    <span className="num">{p.location_code ?? "—"}</span>
                  </div>
                  <div className="text-13 text-ink-2 flex justify-between">
                    <span>Son hareket</span>
                    <span className="num">{relativeDays(p.last_movement_at)}</span>
                  </div>
                  {p.track_serial && p.serial_counts && (
                    <div className="text-13 text-ink-2 flex justify-between">
                      <span>Stoktaki seri no</span>
                      <span className="num">{(p.serial_counts.IN_STOCK ?? 0) + (p.serial_counts.RETURNED ?? 0)}</span>
                    </div>
                  )}
                </>
              )}
            </div>
          </Panel>
          <Panel title="Fiyat">
            <div className="px-4 py-3 flex flex-col gap-2">
              <div className="flex items-baseline justify-between">
                <span className="text-13 text-ink-2">Satış (KDV dahil)</span>
                <span className="num text-20 font-semibold">{money(p.sale_price_kurus)}</span>
              </div>
              {bd && (
                <div className="border-t border-rule pt-2 mt-1">
                  <div className="label-caps mb-1">Kur bağlı hesap</div>
                  <p className="num text-12 text-ink-2 leading-relaxed">
                    {bd.currency === "USD" ? "$" : bd.currency === "EUR" ? "€" : "₺"}
                    {rate(bd.purchase_price)} × {rate(bd.rate)} × {rate(1 + bd.markup_pct / 100)} = {money(bd.raw_kurus)}
                    <br />→ {money(bd.rounded_kurus)} <span className="font-sans text-ink-3">({ROUNDING_TR[bd.rounding_rule]})</span>
                  </p>
                </div>
              )}
              {canCost && p.unit_type !== "SERVICE" && (
                <div className="border-t border-rule pt-2 mt-1 flex flex-col gap-1 text-13">
                  <div className="flex justify-between text-ink-2">
                    <span>Alış</span>
                    <span className="num">
                      {rate(p.purchase_price)} {p.purchase_currency}
                    </span>
                  </div>
                  <div className="flex justify-between text-ink-2">
                    <span>Ort. maliyet (KDV hariç)</span>
                    <Money value={p.cost_kurus} />
                  </div>
                  <div className="flex justify-between text-ink-2">
                    <span>Brüt marj</span>
                    <span className="num">{pct(p.margin_pct)}</span>
                  </div>
                </div>
              )}
            </div>
          </Panel>
        </aside>
      </div>
    </div>
  );
}
