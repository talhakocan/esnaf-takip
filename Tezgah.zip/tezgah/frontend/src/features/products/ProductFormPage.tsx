import { zodResolver } from "@hookform/resolvers/zod";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Plus, ScanBarcode } from "lucide-react";
import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { useNavigate, useParams } from "react-router-dom";
import { z } from "zod";
import { useCrumb } from "@/app/crumbs";
import { Button, IconButton } from "@/design/Button";
import { ErrorState, Loading } from "@/design/Feedback";
import { Checkbox, Field, Input, Radio, Select, Textarea } from "@/design/Input";
import { PageHeader, Panel } from "@/design/Page";
import { useToast } from "@/design/Toast";
import { ApiError, api } from "@/lib/api";
import { decimalInput, money, moneyInput, parseDecimal, parseMoney, rate } from "@/lib/format";
import { useBrands, useCategories, useLocations, useSettings, useSuppliers } from "@/lib/hooks";
import { ROUNDING_TR } from "@/lib/labels";
import { computeFxPrice } from "@/lib/pricing";
import type { FxInfo, Product } from "@/lib/types";
import { type QuickKind, QuickAddDialog } from "./QuickAdd";

const decimal = (msg: string, opts: { min?: number; integer?: boolean } = {}) =>
  z.string().refine(
    (v) => {
      if (v.trim() === "") return true;
      const n = parseDecimal(v);
      if (n === null) return false;
      if (opts.min !== undefined && n < opts.min) return false;
      return !(opts.integer && !Number.isInteger(n));
    },
    { message: msg },
  );

const schema = z
  .object({
    name: z.string().trim().min(2, "Ürün adı en az 2 karakter olmalı."),
    sku: z.string().trim().max(40, "SKU en fazla 40 karakter."),
    barcode: z.string().trim().max(64),
    category_id: z.string(),
    brand_id: z.string(),
    supplier_id: z.string(),
    location_id: z.string(),
    unit_type: z.enum(["PIECE", "METER", "SERVICE"]),
    vat_rate: z.enum(["0", "1", "10", "20"]),
    pricing_mode: z.enum(["FIXED", "FX_LINKED"]),
    purchase_currency: z.enum(["TRY", "USD", "EUR"]),
    purchase_price: decimal("Geçerli bir alış fiyatı girin.", { min: 0 }),
    markup_pct: decimal("Geçerli bir yüzde girin.", { min: -99 }),
    sale_price: decimal("Geçerli bir fiyat girin.", { min: 0 }),
    min_stock: decimal("Geçerli bir miktar girin.", { min: 0 }),
    track_serial: z.boolean(),
    warranty_months: decimal("Ay sayısı tam sayı olmalı.", { min: 0, integer: true }),
    notes: z.string().max(2000),
    initial_stock: decimal("Geçerli bir miktar girin.", { min: 0 }),
    initial_serials: z.string(),
  })
  .superRefine((v, ctx) => {
    if (v.pricing_mode === "FIXED" && v.unit_type !== "SERVICE" && !(parseMoney(v.sale_price) ?? 0)) {
      ctx.addIssue({ code: "custom", path: ["sale_price"], message: "Satış fiyatı girin." });
    }
    if (v.pricing_mode === "FX_LINKED" && !(parseDecimal(v.purchase_price) ?? 0)) {
      ctx.addIssue({ code: "custom", path: ["purchase_price"], message: "Kura bağlı fiyat için alış fiyatı gerekli." });
    }
    if (v.unit_type === "PIECE") {
      for (const key of ["min_stock", "initial_stock"] as const) {
        const n = parseDecimal(v[key]);
        if (n !== null && !Number.isInteger(n)) ctx.addIssue({ code: "custom", path: [key], message: "Adet ile satılan üründe tam sayı olmalı." });
      }
    }
    const stock = parseDecimal(v.initial_stock) ?? 0;
    const serials = v.initial_serials.split(/\s*[\n,;]\s*/).filter(Boolean);
    if (v.track_serial && stock > 0 && serials.length !== stock) {
      ctx.addIssue({ code: "custom", path: ["initial_serials"], message: `${stock} adet seri numarası girin (şu an ${serials.length}).` });
    }
  });

type FormValues = z.infer<typeof schema>;

const EMPTY: FormValues = {
  name: "",
  sku: "",
  barcode: "",
  category_id: "",
  brand_id: "",
  supplier_id: "",
  location_id: "",
  unit_type: "PIECE",
  vat_rate: "20",
  pricing_mode: "FIXED",
  purchase_currency: "TRY",
  purchase_price: "",
  markup_pct: "",
  sale_price: "",
  min_stock: "",
  track_serial: false,
  warranty_months: "",
  notes: "",
  initial_stock: "",
  initial_serials: "",
};

function toForm(p: Product): FormValues {
  return {
    name: p.name,
    sku: p.sku,
    barcode: p.barcode ?? "",
    category_id: p.category_id ? String(p.category_id) : "",
    brand_id: p.brand_id ? String(p.brand_id) : "",
    supplier_id: p.supplier_id ? String(p.supplier_id) : "",
    location_id: p.location_id ? String(p.location_id) : "",
    unit_type: p.unit_type,
    vat_rate: String(p.vat_rate) as FormValues["vat_rate"],
    pricing_mode: p.pricing_mode,
    purchase_currency: p.purchase_currency ?? "TRY",
    purchase_price: decimalInput(p.purchase_price),
    markup_pct: decimalInput(p.markup_pct),
    sale_price: moneyInput(p.sale_price_kurus),
    min_stock: decimalInput(p.min_stock),
    track_serial: p.track_serial,
    warranty_months: p.warranty_months ? String(p.warranty_months) : "",
    notes: p.notes,
    initial_stock: "",
    initial_serials: "",
  };
}

export default function ProductFormPage() {
  const { id } = useParams();
  const editing = !!id;
  const navigate = useNavigate();
  const qc = useQueryClient();
  const toast = useToast();
  const categories = useCategories();
  const brands = useBrands();
  const locations = useLocations();
  const suppliers = useSuppliers();
  const settings = useSettings();
  const fx = useQuery({ queryKey: ["fx"], queryFn: () => api.get<FxInfo>("/fx-rates") });
  const product = useQuery({ queryKey: ["product", id], queryFn: () => api.get<Product>(`/products/${id}`), enabled: editing });
  const [quick, setQuick] = useState<QuickKind | null>(null);
  const [formError, setFormError] = useState<string | null>(null);
  useCrumb(editing ? (product.data ? `${product.data.name} · düzenle` : "Düzenle") : "Yeni ürün");

  const form = useForm<FormValues>({ resolver: zodResolver(schema), defaultValues: EMPTY, mode: "onBlur" });
  const { register, handleSubmit, watch, setValue, reset, setError, formState } = form;
  const errors = formState.errors;

  useEffect(() => {
    if (product.data) reset(toForm(product.data));
  }, [product.data, reset]);

  const v = watch();
  const isService = v.unit_type === "SERVICE";
  const rateValue = v.purchase_currency === "TRY" ? 1 : fx.data?.rates[v.purchase_currency]?.rate;
  const rule = settings.data?.rounding_rule ?? "NEAREST_5";
  const preview =
    v.pricing_mode === "FX_LINKED" && rateValue
      ? computeFxPrice(parseDecimal(v.purchase_price) ?? 0, rateValue, parseDecimal(v.markup_pct) ?? 0, rule)
      : null;

  const generateBarcode = async () => {
    const r = await api.get<{ barcode: string }>("/products/next-barcode");
    setValue("barcode", r.barcode, { shouldDirty: true });
  };

  const onSubmit = async (values: FormValues) => {
    setFormError(null);
    const body: Record<string, unknown> = {
      name: values.name,
      barcode: values.barcode || null,
      category_id: values.category_id ? Number(values.category_id) : null,
      brand_id: values.brand_id ? Number(values.brand_id) : null,
      supplier_id: values.supplier_id ? Number(values.supplier_id) : null,
      location_id: values.location_id ? Number(values.location_id) : null,
      unit_type: values.unit_type,
      vat_rate: Number(values.vat_rate),
      pricing_mode: values.pricing_mode,
      purchase_currency: values.purchase_currency,
      purchase_price: parseDecimal(values.purchase_price) ?? 0,
      markup_pct: parseDecimal(values.markup_pct) ?? 0,
      sale_price_kurus: parseMoney(values.sale_price) ?? 0,
      min_stock: parseDecimal(values.min_stock) ?? 0,
      track_serial: values.track_serial,
      warranty_months: Number(values.warranty_months || 0),
      notes: values.notes,
    };
    if (values.sku) body.sku = values.sku;
    if (!editing) {
      body.initial_stock = parseDecimal(values.initial_stock) ?? 0;
      body.initial_serials = values.initial_serials.split(/\s*[\n,;]\s*/).filter(Boolean);
    }
    try {
      const saved = editing ? await api.patch<Product>(`/products/${id}`, body) : await api.post<Product>("/products", body);
      await qc.invalidateQueries({ queryKey: ["products"] });
      await qc.invalidateQueries({ queryKey: ["product", String(saved.id)] });
      toast({ title: editing ? "Ürün güncellendi" : "Ürün eklendi", message: `${saved.sku} · ${saved.name}` });
      navigate(`/urunler/${saved.id}`);
    } catch (e) {
      if (e instanceof ApiError) {
        const map: Record<string, keyof FormValues> = { sale_price_kurus: "sale_price" };
        Object.entries(e.fields).forEach(([k, msg]) => setError((map[k] ?? k) as keyof FormValues, { message: msg }));
        setFormError(e.message);
      } else setFormError("Kaydedilemedi.");
    }
  };

  if (editing && product.isLoading) return <Loading />;
  if (editing && product.isError) return <ErrorState error={product.error} />;

  const selectWithAdd = (name: "category_id" | "brand_id" | "location_id", label: string, options: { value: number; label: string }[], kind: QuickKind) => (
    <Field label={label} error={errors[name]?.message}>
      {(fid) => (
        <div className="flex gap-1">
          <Select id={fid} {...register(name)} className="flex-1">
            <option value="">—</option>
            {options.map((o) => (
              <option key={o.value} value={o.value}>
                {o.label}
              </option>
            ))}
          </Select>
          <IconButton icon={Plus} label={`${label} ekle`} onClick={() => setQuick(kind)} className="border border-rule-strong" />
        </div>
      )}
    </Field>
  );

  return (
    <form onSubmit={handleSubmit(onSubmit)} noValidate className="pb-10">
      <PageHeader
        title={editing ? "Ürünü düzenle" : "Yeni ürün"}
        sub={editing ? <span className="num">{product.data?.sku}</span> : "Zorunlu alanlar: ad ve fiyat. SKU boş bırakılırsa otomatik üretilir."}
        actions={
          <>
            <Button variant="ghost" onClick={() => navigate(-1)}>
              Vazgeç
            </Button>
            <Button type="submit" variant="primary" loading={formState.isSubmitting}>
              Kaydet
            </Button>
          </>
        }
      />
      {formError && (
        <p className="mx-4 md:mx-6 mb-3 text-13 text-crit border-l-2 border-crit pl-2" role="alert">
          {formError}
        </p>
      )}
      <div className="grid xl:grid-cols-2 gap-4 px-4 md:px-6">
        <Panel title="Kimlik">
          <div className="grid sm:grid-cols-2 gap-3 p-4">
            <Field label="Ürün adı" error={errors.name?.message} required className="sm:col-span-2">
              {(fid) => <Input id={fid} autoFocus={!editing} {...register("name")} invalid={!!errors.name} />}
            </Field>
            <Field label="SKU" error={errors.sku?.message} hint={editing ? undefined : "Boş bırakın → TL-00123"}>
              {(fid) => <Input id={fid} mono {...register("sku")} />}
            </Field>
            <Field label="Barkod" error={errors.barcode?.message}>
              {(fid) => (
                <div className="flex gap-1">
                  <Input id={fid} mono {...register("barcode")} className="flex-1" />
                  <Button icon={ScanBarcode} onClick={generateBarcode} title="İç barkod üret (Code128, TL + 8 hane)">
                    Üret
                  </Button>
                </div>
              )}
            </Field>
          </div>
        </Panel>

        <Panel title="Sınıflandırma">
          <div className="grid sm:grid-cols-2 gap-3 p-4">
            {selectWithAdd("category_id", "Kategori", (categories.data ?? []).map((c) => ({ value: c.id, label: c.path })), "category")}
            {selectWithAdd("brand_id", "Marka", (brands.data ?? []).map((b) => ({ value: b.id, label: b.name })), "brand")}
            {selectWithAdd("location_id", "Raf / konum", (locations.data ?? []).map((l) => ({ value: l.id, label: `${l.code}${l.name ? ` · ${l.name}` : ""}` })), "location")}
            <Field label="Varsayılan tedarikçi">
              {(fid) => (
                <Select id={fid} {...register("supplier_id")}>
                  <option value="">—</option>
                  {suppliers.data?.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.name}
                    </option>
                  ))}
                </Select>
              )}
            </Field>
          </div>
        </Panel>

        <Panel title="Birim ve stok">
          <div className="grid sm:grid-cols-2 gap-3 p-4">
            <fieldset className="sm:col-span-2 flex flex-wrap gap-4" disabled={editing && !!product.data && product.data.stock_qty !== 0}>
              <legend className="text-12 text-ink-2 mb-1">Birim tipi</legend>
              <Radio label="Adet" value="PIECE" {...register("unit_type")} />
              <Radio label="Metre (ondalıklı)" value="METER" {...register("unit_type")} />
              <Radio label="Hizmet (stoksuz)" value="SERVICE" {...register("unit_type")} />
            </fieldset>
            {!isService && (
              <>
                <Field label={`Min. stok (${v.unit_type === "METER" ? "m" : "adet"})`} error={errors.min_stock?.message} hint="Altına inince kritik stok uyarısı">
                  {(fid) => <Input id={fid} mono align="right" inputMode="decimal" {...register("min_stock")} />}
                </Field>
                {!editing && (
                  <Field label="Açılış stoğu" error={errors.initial_stock?.message} hint="Stok defterine GİRİŞ olarak yazılır">
                    {(fid) => <Input id={fid} mono align="right" inputMode="decimal" {...register("initial_stock")} />}
                  </Field>
                )}
                {v.unit_type === "PIECE" && (
                  <div className="sm:col-span-2 flex flex-col gap-3">
                    <Checkbox label="Seri numarası takibi (SSD, RAM, modem…)" {...register("track_serial")} />
                    {v.track_serial && (
                      <div className="grid sm:grid-cols-2 gap-3">
                        <Field label="Garanti süresi (ay)" error={errors.warranty_months?.message}>
                          {(fid) => <Input id={fid} mono align="right" inputMode="numeric" {...register("warranty_months")} />}
                        </Field>
                        {!editing && (parseDecimal(v.initial_stock) ?? 0) > 0 && (
                          <Field label="Seri numaraları (her satıra bir tane)" error={errors.initial_serials?.message} className="sm:col-span-2">
                            {(fid) => <Textarea id={fid} className="font-mono" rows={4} {...register("initial_serials")} />}
                          </Field>
                        )}
                      </div>
                    )}
                  </div>
                )}
              </>
            )}
            {isService && <p className="sm:col-span-2 text-13 text-ink-2">Hizmet ürünlerinde stok tutulmaz; satışta ve serviste kullanılabilir.</p>}
          </div>
        </Panel>

        <Panel title="Fiyat">
          <div className="grid sm:grid-cols-2 gap-3 p-4">
            <Field label="KDV oranı">
              {(fid) => (
                <Select id={fid} {...register("vat_rate")}>
                  <option value="20">%20</option>
                  <option value="10">%10</option>
                  <option value="1">%1</option>
                  <option value="0">%0</option>
                </Select>
              )}
            </Field>
            <fieldset className="flex flex-wrap gap-4 items-end pb-1.5">
              <legend className="text-12 text-ink-2 mb-1">Fiyat modu</legend>
              <Radio label="Sabit TL" value="FIXED" {...register("pricing_mode")} />
              <Radio label="Kura bağlı" value="FX_LINKED" {...register("pricing_mode")} />
            </fieldset>
            <Field label="Alış para birimi">
              {(fid) => (
                <Select id={fid} {...register("purchase_currency")}>
                  <option value="TRY">TRY (₺)</option>
                  <option value="USD">USD ($)</option>
                  <option value="EUR">EUR (€)</option>
                </Select>
              )}
            </Field>
            <Field label="Alış fiyatı (KDV hariç)" error={errors.purchase_price?.message}>
              {(fid) => <Input id={fid} mono align="right" inputMode="decimal" {...register("purchase_price")} />}
            </Field>
            {v.pricing_mode === "FX_LINKED" ? (
              <>
                <Field label="Kâr marjı %" error={errors.markup_pct?.message}>
                  {(fid) => <Input id={fid} mono align="right" inputMode="decimal" {...register("markup_pct")} />}
                </Field>
                <div className="flex flex-col justify-end">
                  <div className="text-12 text-ink-2">Hesaplanan satış fiyatı</div>
                  <div className="num text-20 font-semibold">{preview ? money(preview[1]) : "—"}</div>
                </div>
                <p className="sm:col-span-2 num text-12 text-ink-2 border-t border-rule pt-2">
                  {preview
                    ? `${rate(parseDecimal(v.purchase_price) ?? 0)} ${v.purchase_currency} × ${rate(rateValue)} × ${rate(1 + (parseDecimal(v.markup_pct) ?? 0) / 100)} = ${money(preview[0])} → ${money(preview[1])} (${ROUNDING_TR[rule]})`
                    : `${v.purchase_currency} kuru tanımlı değil — Ayarlar › Fiyat & Kur.`}
                </p>
              </>
            ) : (
              <Field label="Satış fiyatı (KDV dahil, ₺)" error={errors.sale_price?.message} required={!isService} className="sm:col-span-2">
                {(fid) => <Input id={fid} mono align="right" inputMode="decimal" placeholder="0,00" {...register("sale_price")} invalid={!!errors.sale_price} />}
              </Field>
            )}
          </div>
        </Panel>

        <Panel title="Notlar" className="xl:col-span-2">
          <div className="p-4">
            <Textarea aria-label="Notlar" rows={3} {...register("notes")} placeholder="Ürünle ilgili iç notlar (müşteriye gösterilmez)" />
          </div>
        </Panel>
      </div>
      <QuickAddDialog
        kind={quick}
        onClose={() => setQuick(null)}
        onCreated={(kind, newId) => setValue(kind === "category" ? "category_id" : kind === "brand" ? "brand_id" : "location_id", String(newId), { shouldDirty: true })}
      />
    </form>
  );
}
