import { useQueryClient } from "@tanstack/react-query";
import { Eye } from "lucide-react";
import { useState } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { Button } from "@/design/Button";
import { type ColumnDef, DataTable } from "@/design/DataTable";
import { useConfirm } from "@/design/Dialog";
import { Money, Tag } from "@/design/Indicators";
import { Field, Input, Select } from "@/design/Input";
import { PageHeader, Panel } from "@/design/Page";
import { useToast } from "@/design/Toast";
import { ApiError, api } from "@/lib/api";
import { parseDecimal, pct } from "@/lib/format";
import { useBrands, useCategories, useSuppliers, useTitle } from "@/lib/hooks";
import { ROUNDING_TR } from "@/lib/labels";
import type { RoundingRule } from "@/lib/types";

interface PreviewRow {
  id: number;
  sku: string;
  name: string;
  pricing_mode: "FIXED" | "FX_LINKED";
  old_price: number;
  new_price: number;
  old_markup: number | null;
  new_markup: number | null;
}

interface Preview {
  pct: number;
  rounding_rule: RoundingRule;
  count: number;
  rows: PreviewRow[];
}

export default function BulkPricePage() {
  useTitle("Toplu fiyat güncelleme");
  const [params] = useSearchParams();
  const navigate = useNavigate();
  const qc = useQueryClient();
  const toast = useToast();
  const confirm = useConfirm();
  const categories = useCategories();
  const brands = useBrands();
  const suppliers = useSuppliers();
  const ids = (params.get("ids") ?? "").split(",").filter(Boolean).map(Number);
  const [category, setCategory] = useState("");
  const [brand, setBrand] = useState("");
  const [supplier, setSupplier] = useState("");
  const [pctText, setPctText] = useState("");
  const [preview, setPreview] = useState<Preview | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const body = () => ({
    product_ids: ids,
    category_id: category ? Number(category) : null,
    brand_id: brand ? Number(brand) : null,
    supplier_id: supplier ? Number(supplier) : null,
    pct: parseDecimal(pctText) ?? 0,
  });
  const runPreview = async () => {
    setBusy(true);
    setError(null);
    try {
      setPreview(await api.post<Preview>("/products/bulk-price/preview", body()));
    } catch (e) {
      setPreview(null);
      setError(e instanceof ApiError ? e.message : "Önizleme alınamadı.");
    } finally {
      setBusy(false);
    }
  };
  const apply = async () => {
    if (!preview) return;
    const ok = await confirm({
      title: `${preview.count} ürünün fiyatı güncellensin mi?`,
      message: `Fiyatlar ${pct(preview.pct)} değişecek ve fiyat geçmişine "toplu güncelleme" olarak yazılacak. Kura bağlı ürünlerde kâr marjı güncellenir.`,
      confirmLabel: "Uygula",
    });
    if (!ok) return;
    setBusy(true);
    try {
      const r = await api.post<{ updated: number }>("/products/bulk-price/apply", body());
      await qc.invalidateQueries({ queryKey: ["products"] });
      toast({ title: "Fiyatlar güncellendi", message: `${r.updated} ürün` });
      navigate("/urunler");
    } catch (e) {
      setError(e instanceof ApiError ? e.message : "Uygulanamadı.");
    } finally {
      setBusy(false);
    }
  };

  const columns: ColumnDef<PreviewRow, any>[] = [
    { accessorKey: "sku", header: "SKU", meta: { mono: true, className: "text-12" } },
    { accessorKey: "name", header: "Ürün", cell: ({ row }) => (<span>{row.original.name} {row.original.pricing_mode === "FX_LINKED" && <Tag>KUR</Tag>}</span>) },
    { accessorKey: "old_price", header: "Eski fiyat", meta: { align: "right" }, cell: ({ getValue }) => <Money value={getValue()} className="text-ink-2" /> },
    { accessorKey: "new_price", header: "Yeni fiyat", meta: { align: "right" }, cell: ({ getValue }) => <Money value={getValue()} strong /> },
    {
      id: "delta",
      header: "Fark",
      meta: { align: "right" },
      accessorFn: (r) => r.new_price - r.old_price,
      cell: ({ getValue }) => <Money value={getValue()} plusSign className={getValue() > 0 ? "text-ok" : undefined} />,
    },
    {
      id: "markup",
      header: "Marj (kur)",
      meta: { align: "right", mono: true },
      accessorFn: (r) => r.new_markup,
      cell: ({ row }) => (row.original.new_markup === null ? <span className="text-ink-3">—</span> : `${pct(row.original.old_markup)} → ${pct(row.original.new_markup)}`),
    },
  ];

  return (
    <div className="pb-10">
      <PageHeader title="Toplu fiyat güncelleme" sub="Filtreyle seçilen ürünlere yüzde zam veya indirim. Uygulamadan önce önizleme gösterilir." />
      <div className="grid xl:grid-cols-[340px_1fr] gap-4 px-4 md:px-6">
        <Panel title="Seçim">
          <form
            className="p-4 flex flex-col gap-3"
            onSubmit={(e) => {
              e.preventDefault();
              void runPreview();
            }}
          >
            {ids.length > 0 && <p className="text-13 border-l-2 border-info pl-2">Ürün listesinden {ids.length} ürün seçildi.</p>}
            <Field label="Kategori">
              {(id) => (
                <Select id={id} value={category} onChange={(e) => setCategory(e.target.value)}>
                  <option value="">—</option>
                  {categories.data?.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.path}
                    </option>
                  ))}
                </Select>
              )}
            </Field>
            <Field label="Marka">
              {(id) => (
                <Select id={id} value={brand} onChange={(e) => setBrand(e.target.value)}>
                  <option value="">—</option>
                  {brands.data?.map((b) => (
                    <option key={b.id} value={b.id}>
                      {b.name}
                    </option>
                  ))}
                </Select>
              )}
            </Field>
            <Field label="Tedarikçi">
              {(id) => (
                <Select id={id} value={supplier} onChange={(e) => setSupplier(e.target.value)}>
                  <option value="">—</option>
                  {suppliers.data?.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.name}
                    </option>
                  ))}
                </Select>
              )}
            </Field>
            <Field label="Değişim %" hint="Zam için 10, indirim için -5">
              {(id) => <Input id={id} mono align="right" value={pctText} onChange={(e) => setPctText(e.target.value)} placeholder="10" />}
            </Field>
            {error && <p className="text-12 text-crit">{error}</p>}
            <Button type="submit" icon={Eye} loading={busy} disabled={!parseDecimal(pctText)}>
              Önizle
            </Button>
          </form>
        </Panel>
        <Panel
          title="Önizleme"
          right={preview && <span className="text-12 text-ink-2">{preview.count} ürün · {ROUNDING_TR[preview.rounding_rule]}</span>}
        >
          {preview ? (
            <>
              <DataTable data={preview.rows} columns={columns} className="border-y-0" exportName="toplu-fiyat-onizleme" />
              <div className="flex justify-end p-3 border-t border-rule">
                <Button variant="primary" onClick={apply} loading={busy} disabled={!preview.count}>
                  {preview.count} ürüne uygula
                </Button>
              </div>
            </>
          ) : (
            <p className="px-4 py-6 text-13 text-ink-2">Filtreleri ve yüzdeyi seçip "Önizle"ye basın; eski ve yeni fiyatlar yan yana gösterilir.</p>
          )}
        </Panel>
      </div>
    </div>
  );
}
