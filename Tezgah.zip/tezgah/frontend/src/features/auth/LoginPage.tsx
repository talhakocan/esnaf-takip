import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { Navigate, useNavigate, useSearchParams } from "react-router-dom";
import { useAuth } from "@/app/auth";
import { Button } from "@/design/Button";
import { Field, Input } from "@/design/Input";
import { ApiError, api } from "@/lib/api";
import type { Me } from "@/lib/types";

const DAYS = ["Pazar", "Pazartesi", "Salı", "Çarşamba", "Perşembe", "Cuma", "Cumartesi"];
const MONTHS = ["Ocak", "Şubat", "Mart", "Nisan", "Mayıs", "Haziran", "Temmuz", "Ağustos", "Eylül", "Ekim", "Kasım", "Aralık"];
const p2 = (n: number) => String(n).padStart(2, "0");

function Clock() {
  const [now, setNow] = useState(() => new Date());
  useEffect(() => {
    const t = window.setInterval(() => setNow(new Date()), 1000);
    return () => window.clearInterval(t);
  }, []);
  return (
    <div>
      <div className="num text-[88px] leading-none font-medium tracking-tight" aria-label="Saat">
        {p2(now.getHours())}:{p2(now.getMinutes())}
        <span className="text-ink-3 text-40">:{p2(now.getSeconds())}</span>
      </div>
      <div className="num text-16 text-ink-2 mt-3">
        {p2(now.getDate())} {MONTHS[now.getMonth()]} {now.getFullYear()} · {DAYS[now.getDay()]}
      </div>
    </div>
  );
}

/** Alt kenarda ince, tek renkli devre hattı. */
function CircuitLine() {
  return (
    <svg className="absolute left-0 right-0 bottom-6 w-full h-10 text-rule-strong" viewBox="0 0 1200 40" preserveAspectRatio="none" aria-hidden>
      <path
        d="M0 30 H180 V12 H340 V30 H520 L528 20 L540 38 L552 20 L564 38 L572 30 H760 V8 H900 V30 H1200"
        fill="none"
        stroke="currentColor"
        strokeWidth="1.5"
        vectorEffect="non-scaling-stroke"
      />
      <circle cx="180" cy="30" r="3" fill="currentColor" />
      <circle cx="340" cy="12" r="3" fill="currentColor" />
      <circle cx="760" cy="30" r="3" fill="currentColor" />
      <circle cx="900" cy="8" r="3" fill="currentColor" />
    </svg>
  );
}

export default function LoginPage() {
  const { me } = useAuth();
  const qc = useQueryClient();
  const navigate = useNavigate();
  const [params] = useSearchParams();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const shop = useQuery({ queryKey: ["public-shop"], queryFn: () => api.get<{ shop_name: string; address: string; phone: string }>("/public/shop") });

  useEffect(() => {
    document.title = "Giriş · Tezgâh";
  }, []);

  const next = params.get("next");
  const target = next && next.startsWith("/") && !next.startsWith("//") ? next : "/";
  if (me) return <Navigate to={target} replace />;

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      const user = await api.post<Me>("/auth/login", { username, password });
      qc.setQueryData(["me"], user);
      navigate(target, { replace: true });
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Giriş yapılamadı.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="min-h-full grid md:grid-cols-[400px_1fr] bg-paper">
      <div className="bg-surface border-r border-rule flex flex-col">
        <div className="px-8 pt-8 pb-3">
          <div className="font-cond font-semibold text-20 tracking-[.14em] leading-none">TEKNOLIFE</div>
          <div className="font-mono text-12 text-ink-3 mt-1.5">tezgâh · dükkan yönetim sistemi</div>
        </div>
        <svg className="block w-full h-[2px]" aria-hidden preserveAspectRatio="none">
          <defs>
            <pattern id="tz-earth-login" width="12" height="12" patternUnits="userSpaceOnUse" patternTransform="rotate(45)">
              <rect width="6" height="12" style={{ fill: "var(--earth-a)" }} />
              <rect x="6" width="6" height="12" style={{ fill: "var(--earth-b)" }} />
            </pattern>
          </defs>
          <rect width="100%" height="2" fill="url(#tz-earth-login)" />
        </svg>
        <form onSubmit={submit} className="flex flex-col gap-4 px-8 py-10" noValidate>
          <h1 className="font-cond text-20 font-semibold">Giriş</h1>
          <Field label="Kullanıcı adı">
            {(id) => (
              <Input id={id} name="username" autoComplete="username" autoFocus value={username} onChange={(e) => setUsername(e.target.value)} required />
            )}
          </Field>
          <Field label="Şifre">
            {(id) => (
              <Input
                id={id}
                name="password"
                type="password"
                autoComplete="current-password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
            )}
          </Field>
          {error && (
            <p className="text-13 text-crit border-l-2 border-crit pl-2" role="alert">
              {error}
            </p>
          )}
          <Button type="submit" variant="primary" size="lg" loading={busy} disabled={!username || !password}>
            Giriş
          </Button>
        </form>
        <p className="mt-auto px-8 pb-6 text-12 text-ink-3">Sorun mu var? Yönetici hesabıyla şifre sıfırlanabilir.</p>
      </div>
      <div className="relative hidden md:flex flex-col justify-center px-16 overflow-hidden">
        <Clock />
        <div className="mt-10 text-14 text-ink-2 max-w-[48ch]">
          <div className="font-medium text-ink">{shop.data?.shop_name ?? "Teknolife"}</div>
          {shop.data?.address && <div>{shop.data.address}</div>}
          {shop.data?.phone && <div className="num">{shop.data.phone}</div>}
        </div>
        <CircuitLine />
      </div>
    </div>
  );
}
