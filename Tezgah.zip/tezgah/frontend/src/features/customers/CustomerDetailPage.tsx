import { useQuery, useQueryClient } from "@tanstack/react-query";
import { HandCoins, Pencil, Printer, Scale } from "lucide-react";
import { useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { useCan } from "@/app/auth";
import { useCrumb } from "@/app/crumbs";
import { Button } from "@/design/Button";
import { type ColumnDef, DataTable } from "@/design/DataTable";
import { Dialog } from "@/design/Dialog";
import { EmptyState, ErrorState, Loading } from "@/design/Feedback";
import { Led, Money } from "@/design/Indicators";
import { Field, Input, Select } from "@/design/Input";
import { KeyValues, Panel, TabPanel, Tabs } from "@/design/Page";
import { useToast } from "@/design/Toast";
import { ApiError, api } from "@/lib/api";
import { dateOnly, dateTime, money, moneyInput, moneyPlain, parseMoney, phone } from "@/lib/format";
import { useSettings } from "@/lib/hooks";
import { DEVICE_TR, SERVICE_STATUS_TONE, SERVICE_STATUS_TR } from "@/lib/labels";
import { printNode } from "@/lib/print";
import type { CustomerDetail, Settings, Statement, StatementRow } from "@/lib/types";
import { CustomerDialog } from "./CustomerForm";

function StatementA4({ st, settings }: { st: Statement; settings: Settings }) {
  const cell = { padding: "3px 6px", borderBottom: "1px solid #999" } as const;
  const num = { ...cell, textAlign: "right" as const, fontFamily: "'IBM Plex Mono'" };
  return (
    <div style={{ fontFamily: "'IBM Plex Sans'", fontSize: "10pt", color: "#000" }}>
      <div style={{ display: "flex", justifyContent: "space-between", borderBottom: "2px solid #000", paddingBottom: 6 }}>
        <div>
          <div style={{ fontFamily: "'IBM Plex Sans Condensed'", fontWeight: 600, fontSize: "16pt", letterSpacing: ".08em" }}>
            {settings.shop_name.toLocaleUpperCase("tr-TR")}
          </div>
          <div>{settings.address}</div>
          <div>{settings.phone}</div>
        </div>
        <div style={{ textAlign: "right" }}>
          <div style={{ fontFamily: "'IBM Plex Sans Condensed'", fontWeight: 600, fontSize: "13pt" }}>HESAP EKSTRESİ</div>
          <div>{st.customer.full_name}</div>
          <div style={{ fontFamily: "'IBM Plex Mono'" }}>{phone(st.customer.phone)}</div>
          <div style={{ fontFamily: "'IBM Plex Mono'" }}>{dateTime(new Date())}</div>
        </div>
      </div>
      <table style={{ width: "100%", borderCollapse: "collapse", marginTop: 10 }}>
        <thead>
          <tr style={{ textAlign: "left" }}>
            <th style={cell}>Tarih</th>
            <th style={cell}>Açıklama</th>
            <th style={cell}>Vade</th>
            <th style={{ ...num, fontFamily: "inherit" }}>Borç</th>
            <th style={{ ...num, fontFamily: "inherit" }}>Alacak</th>
            <th style={{ ...num, fontFamily: "inherit" }}>Bakiye</th>
          </tr>
        </thead>
        <tbody>
          {st.opening_balance !== 0 && (
            <tr>
              <td style={cell} colSpan={5}>
                Devreden bakiye
              </td>
              <td style={num}>{moneyPlain(st.opening_balance)}</td>
            </tr>
          )}
          {st.rows.map((r) => (
            <tr key={r.id}>
              <td style={{ ...cell, fontFamily: "'IBM Plex Mono'" }}>{dateOnly(r.at)}</td>
              <td style={cell}>{r.description}</td>
              <td style={{ ...cell, fontFamily: "'IBM Plex Mono'" }}>{r.due_date ? dateOnly(r.due_date) : ""}</td>
              <td style={num}>{r.debit ? moneyPlain(r.debit) : ""}</td>
              <td style={num}>{r.credit ? moneyPlain(r.credit) : ""}</td>
              <td style={num}>{moneyPlain(r.balance)}</td>
            </tr>
          ))}
          <tr style={{ fontWeight: 600 }}>
            <td style={cell} colSpan={3}>
              Toplam
            </td>
            <td style={num}>{moneyPlain(st.total_debit)}</td>
            <td style={num}>{moneyPlain(st.total_credit)}</td>
            <td style={num}>{money(st.closing_balance)}</td>
          </tr>
        </tbody>
      </table>
      <p style={{ marginTop: 12, fontSize: "9pt" }}>
        Pozitif bakiye müşterinin borcunu gösterir. Bu ekstre bilgi amaçlıdır; mutabakat için lütfen dükkanımızla iletişime geçin.
      </p>
    </div>
  );
}

function PaymentForm({ customerId, balance, onClose, onDone }: { customerId: number; balance: number; onClose: () => void; onDone: () => void }) {
  const [amount, setAmount] = useState(balance > 0 ? moneyInput(balance) : "");
  const [method, setMethod] = useState("CASH");
  const [note, setNote] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const save = async () => {
    setBusy(true);
    try {
      await api.post(`/customers/${customerId}/payments`, { amount: parseMoney(amount), method, note });
      onDone();
    } catch (e) {
      setError(e instanceof ApiError ? e.message : "Kaydedilemedi.");
    } finally {
      setBusy(false);
    }
  };
  return (
    <Dialog
      open
      onOpenChange={(o) => !o && onClose()}
      title="Tahsilat al"
      description={`Güncel borç: ${money(balance)}`}
      width={420}
      footer={
        <>
          <Button variant="ghost" onClick={onClose}>
            Vazgeç
          </Button>
          <Button variant="primary" onClick={save} loading={busy} disabled={!(parseMoney(amount) ?? 0)}>
            Tahsil et
          </Button>
        </>
      }
    >
      <form
        className="flex flex-col gap-3"
        onSubmit={(e) => {
          e.preventDefault();
          void save();
        }}
      >
        <Field label="Tutar (₺)" error={error ?? undefined}>
          {(id) => <Input id={id} mono align="right" autoFocus inputMode="decimal" value={amount} onChange={(e) => setAmount(e.target.value)} />}
        </Field>
        <Field label="Ödeme yöntemi">
          {(id) => (
            <Select id={id} value={method} onChange={(e) => setMethod(e.target.value)}>
              <option value="CASH">Nakit</option>
              <option value="CARD">Kart</option>
              <option value="TRANSFER">Havale/EFT</option>
            </Select>
          )}
        </Field>
        <Field label="Not">{(id) => <Input id={id} value={note} onChange={(e) => setNote(e.target.value)} />}</Field>
        <button type="submit" className="hidden" />
      </form>
    </Dialog>
  );
}

function AdjustForm({ customerId, onClose, onDone }: { customerId: number; onClose: () => void; onDone: () => void }) {
  const [amount, setAmount] = useState("");
  const [description, setDescription] = useState("");
  const [error, setError] = useState<string | null>(null);
  const save = async () => {
    try {
      await api.post(`/customers/${customerId}/adjust`, { amount: parseMoney(amount), description });
      onDone();
    } catch (e) {
      setError(e instanceof ApiError ? e.message : "Kaydedilemedi.");
    }
  };
  return (
    <Dialog
      open
      onOpenChange={(o) => !o && onClose()}
      title="Bakiye düzeltme"
      description="Pozitif tutar borç ekler, negatif tutar borçtan düşer. Denetim kaydına yazılır."
      width={420}
      footer={
        <>
          <Button variant="ghost" onClick={onClose}>
            Vazgeç
          </Button>
          <Button variant="primary" onClick={save} disabled={!parseMoney(amount) || description.trim().length < 3}>
            Kaydet
          </Button>
        </>
      }
    >
      <div className="flex flex-col gap-3">
        <Field label="Tutar (₺, ± işaretli)" error={error ?? undefined}>
          {(id) => <Input id={id} mono align="right" autoFocus value={amount} onChange={(e) => setAmount(e.target.value)} placeholder="-50,00" />}
        </Field>
        <Field label="Açıklama">{(id) => <Input id={id} value={description} onChange={(e) => setDescription(e.target.value)} />}</Field>
      </div>
    </Dialog>
  );
}

export default function CustomerDetailPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const qc = useQueryClient();
  const toast = useToast();
  const settings = useSettings();
  const canCollect = useCan("customer.payment");
  const canAdjust = useCan("customer.adjust");
  const [tab, setTab] = useState("ekstre");
  const [dialog, setDialog] = useState<"edit" | "pay" | "adjust" | null>(null);
  const q = useQuery({ queryKey: ["customer", id], queryFn: () => api.get<CustomerDetail>(`/customers/${id}`) });
  const st = useQuery({ queryKey: ["customer", id, "statement"], queryFn: () => api.get<Statement>(`/customers/${id}/statement`) });
  const c = q.data;
  useCrumb(c?.full_name);
  if (q.isLoading) return <Loading />;
  if (q.isError || !c) return <ErrorState error={q.error} onRetry={() => q.refetch()} />;

  const refresh = async () => {
    await qc.invalidateQueries({ queryKey: ["customer", id] });
    await qc.invalidateQueries({ queryKey: ["customers"] });
  };

  const stmtCols: ColumnDef<StatementRow, any>[] = [
    { accessorKey: "at", header: "Tarih", meta: { mono: true, className: "text-12 whitespace-nowrap" }, cell: ({ getValue }) => dateTime(getValue()) },
    {
      accessorKey: "description",
      header: "Açıklama",
      cell: ({ row }) =>
        row.original.ref_type === "SALE" && row.original.ref_id ? (
          <Link to={`/satislar/${row.original.ref_id}`} className="hover:underline">
            {row.original.description}
          </Link>
        ) : (
          row.original.description
        ),
    },
    {
      accessorKey: "due_date",
      header: "Vade",
      meta: { mono: true, className: "text-12" },
      cell: ({ getValue }) => {
        const v = getValue();
        if (!v) return <span className="text-ink-3">—</span>;
        const past = new Date(v) < new Date(new Date().toDateString());
        return <span className={past ? "text-crit" : undefined}>{dateOnly(v)}</span>;
      },
    },
    { accessorKey: "debit", header: "Borç", meta: { align: "right" }, cell: ({ getValue }) => (getValue() ? <Money value={getValue()} /> : "") },
    { accessorKey: "credit", header: "Alacak", meta: { align: "right" }, cell: ({ getValue }) => (getValue() ? <Money value={getValue()} className="text-ok" /> : "") },
    { accessorKey: "balance", header: "Bakiye", meta: { align: "right" }, cell: ({ getValue }) => <Money value={getValue()} strong /> },
    { accessorKey: "user_name", header: "Kullanıcı", meta: { className: "text-12 text-ink-3" } },
  ];

  return (
    <div className="pb-10">
      <div className="px-4 md:px-6 pt-5 pb-4 flex flex-wrap justify-between gap-4">
        <div>
          <h1 className="font-cond text-20 font-semibold">{c.full_name}</h1>
          <div className="num text-13 text-ink-2">{phone(c.phone)}</div>
          <div className="mt-2 flex items-baseline gap-3">
            <span className="label-caps">Bakiye</span>
            <span className={`num text-28 font-semibold ${c.balance > 0 ? "text-crit" : ""}`}>{money(c.balance)}</span>
            {c.overdue > 0 && <Led tone="crit">vadesi geçmiş {money(c.overdue)}</Led>}
          </div>
        </div>
        <div className="flex flex-wrap gap-2 items-start">
          <Button icon={Printer} onClick={() => st.data && settings.data && printNode(<StatementA4 st={st.data} settings={settings.data} />, "a4")}>
            Ekstre yazdır
          </Button>
          <Button icon={Pencil} onClick={() => setDialog("edit")}>
            Düzenle
          </Button>
          {canAdjust && (
            <Button icon={Scale} onClick={() => setDialog("adjust")}>
              Bakiye düzeltme
            </Button>
          )}
          {canCollect && (
            <Button variant="primary" icon={HandCoins} onClick={() => setDialog("pay")}>
              Tahsilat al
            </Button>
          )}
        </div>
      </div>
      <div className="grid xl:grid-cols-[1fr_320px] gap-4 xl:pr-6">
        <div className="bg-surface border-y border-rule xl:border-r min-w-0">
          <Tabs
            value={tab}
            onValueChange={setTab}
            tabs={[
              { value: "ekstre", label: "Hesap ekstresi", count: st.data?.rows.length },
              { value: "satis", label: "Satışlar", count: c.sales.length },
              { value: "servis", label: "Servis", count: c.service_tickets.length },
              { value: "garanti", label: "Ürünler ve garanti", count: c.serials.length },
            ]}
          >
            <TabPanel value="ekstre">
              {st.isLoading ? (
                <Loading />
              ) : (
                <DataTable
                  data={st.data?.rows ?? []}
                  columns={stmtCols}
                  className="border-y-0"
                  exportName={`ekstre-${c.full_name}`}
                  empty={<EmptyState icon="resistor" title="Cari hareket yok. Veresiye satış veya tahsilat yapıldığında burada görünür." />}
                />
              )}
            </TabPanel>
            <TabPanel value="satis">
              <DataTable
                data={c.sales}
                className="border-y-0"
                onRowClick={(s) => navigate(`/satislar/${s.id}`)}
                columns={[
                  { accessorKey: "receipt_no", header: "Fiş no", meta: { mono: true, className: "text-12" } },
                  { accessorKey: "at", header: "Tarih", meta: { mono: true, className: "text-12" }, cell: ({ getValue }) => dateTime(getValue()) },
                  { accessorKey: "user_name", header: "Personel", meta: { className: "text-12 text-ink-2" } },
                  {
                    accessorKey: "status",
                    header: "Durum",
                    cell: ({ getValue }) => (getValue() === "CANCELLED" ? <Led tone="crit">İptal</Led> : <Led tone="ok">Tamam</Led>),
                  },
                  { accessorKey: "total", header: "Tutar", meta: { align: "right" }, cell: ({ getValue }) => <Money value={getValue()} /> },
                ]}
                empty={<EmptyState icon="circuit" title="Bu müşteriye kayıtlı satış yok." />}
              />
            </TabPanel>
            <TabPanel value="servis">
              <DataTable
                data={c.service_tickets}
                className="border-y-0"
                onRowClick={(t) => navigate(`/servis/${t.id}`)}
                columns={[
                  { accessorKey: "code", header: "Kod", meta: { mono: true } },
                  {
                    id: "dev",
                    header: "Cihaz",
                    accessorFn: (t) => `${DEVICE_TR[t.device_type as keyof typeof DEVICE_TR]} ${t.brand} ${t.model}`,
                  },
                  {
                    accessorKey: "status",
                    header: "Durum",
                    cell: ({ row }) => <Led tone={SERVICE_STATUS_TONE[row.original.status]}>{SERVICE_STATUS_TR[row.original.status]}</Led>,
                  },
                  { accessorKey: "received_at", header: "Kabul", meta: { mono: true, className: "text-12" }, cell: ({ getValue }) => dateOnly(getValue()) },
                ]}
                empty={<EmptyState icon="switch" title="Servis kaydı yok." />}
              />
            </TabPanel>
            <TabPanel value="garanti">
              <DataTable
                data={c.serials}
                className="border-y-0"
                onRowClick={(s) => navigate(`/satislar/${s.sale_id}`)}
                columns={[
                  { accessorKey: "product_name", header: "Ürün" },
                  { accessorKey: "serial_no", header: "Seri no", meta: { mono: true, className: "text-12" } },
                  { accessorKey: "receipt_no", header: "Fiş", meta: { mono: true, className: "text-12" } },
                  { accessorKey: "sold_at", header: "Satış", meta: { mono: true, className: "text-12" }, cell: ({ getValue }) => dateOnly(getValue()) },
                  {
                    accessorKey: "warranty_until",
                    header: "Garanti",
                    cell: ({ row }) =>
                      row.original.warranty_until ? (
                        <Led tone={row.original.under_warranty ? "ok" : "neutral"}>
                          {row.original.under_warranty ? "Garantili" : "Bitti"} · {dateOnly(row.original.warranty_until)}
                        </Led>
                      ) : (
                        <span className="text-ink-3">—</span>
                      ),
                  },
                ]}
                empty={<EmptyState icon="connector" title="Seri numaralı ürün satışı yok." />}
              />
            </TabPanel>
          </Tabs>
        </div>
        <aside className="px-4 xl:px-0">
          <Panel title="Bilgiler">
            <KeyValues
              rows={[
                ["E-posta", c.email || null],
                ["Adres", c.address || null],
                ["Vergi / TC no", c.tax_no ? <span className="num">{c.tax_no}</span> : null],
                ["Kredi limiti", c.credit_limit_kurus ? <span className="num">{money(c.credit_limit_kurus)}</span> : "Veresiye kapalı"],
                ["KVKK onayı", c.kvkk_consent_at ? <span className="num">{dateOnly(c.kvkk_consent_at)}</span> : <Led tone="warn">Alınmadı</Led>],
                ["Not", c.note || null],
                ["Kayıt", <span className="num">{dateOnly(c.created_at)}</span>],
              ]}
            />
          </Panel>
        </aside>
      </div>
      {dialog === "edit" && <CustomerDialog customer={c} onClose={() => setDialog(null)} onSaved={() => (setDialog(null), void refresh())} />}
      {dialog === "pay" && (
        <PaymentForm
          customerId={c.id}
          balance={c.balance}
          onClose={() => setDialog(null)}
          onDone={async () => {
            setDialog(null);
            toast({ title: "Tahsilat kaydedildi" });
            await refresh();
          }}
        />
      )}
      {dialog === "adjust" && (
        <AdjustForm
          customerId={c.id}
          onClose={() => setDialog(null)}
          onDone={async () => {
            setDialog(null);
            toast({ title: "Bakiye düzeltildi" });
            await refresh();
          }}
        />
      )}
    </div>
  );
}
