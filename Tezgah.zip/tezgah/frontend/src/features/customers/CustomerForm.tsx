import { useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { useCan } from "@/app/auth";
import { Button } from "@/design/Button";
import { Dialog } from "@/design/Dialog";
import { Checkbox, Field, Input, Textarea } from "@/design/Input";
import { useToast } from "@/design/Toast";
import { ApiError, api } from "@/lib/api";
import { moneyInput, parseMoney } from "@/lib/format";
import type { Customer } from "@/lib/types";

/** Müşteri ekleme/düzenleme dialog'u. Kredi limiti yalnızca yönetici tarafından değiştirilebilir. */
export function CustomerDialog({ customer, onClose, onSaved }: { customer: Customer | null; onClose: () => void; onSaved: (c: Customer) => void }) {
  const qc = useQueryClient();
  const toast = useToast();
  const isAdmin = useCan("customer.adjust");
  const [v, setV] = useState({
    full_name: customer?.full_name ?? "",
    phone: customer?.phone ?? "",
    email: customer?.email ?? "",
    tax_no: customer?.tax_no ?? "",
    address: customer?.address ?? "",
    note: customer?.note ?? "",
    credit_limit: customer ? moneyInput(customer.credit_limit_kurus) : "",
    kvkk: !!customer?.kvkk_consent_at,
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [busy, setBusy] = useState(false);
  const set = (k: keyof typeof v) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) =>
    setV((s) => ({ ...s, [k]: e.target.type === "checkbox" ? (e.target as HTMLInputElement).checked : e.target.value }));
  const save = async () => {
    setBusy(true);
    setErrors({});
    const body: Record<string, unknown> = {
      full_name: v.full_name,
      phone: v.phone,
      email: v.email,
      tax_no: v.tax_no,
      address: v.address,
      note: v.note,
    };
    if (isAdmin) body.credit_limit_kurus = parseMoney(v.credit_limit) ?? 0;
    if (v.kvkk && !customer?.kvkk_consent_at) body.kvkk_consent = true;
    try {
      const saved = customer ? await api.patch<Customer>(`/customers/${customer.id}`, body) : await api.post<Customer>("/customers", body);
      await qc.invalidateQueries({ queryKey: ["customers"] });
      await qc.invalidateQueries({ queryKey: ["customer", String(saved.id)] });
      toast({ title: customer ? "Müşteri güncellendi" : "Müşteri eklendi", message: saved.full_name });
      onSaved(saved);
    } catch (e) {
      if (e instanceof ApiError) setErrors({ ...e.fields, _: e.message });
    } finally {
      setBusy(false);
    }
  };
  return (
    <Dialog
      open
      onOpenChange={(o) => !o && onClose()}
      title={customer ? "Müşteriyi düzenle" : "Yeni müşteri"}
      width={560}
      footer={
        <>
          <Button variant="ghost" onClick={onClose}>
            Vazgeç
          </Button>
          <Button variant="primary" onClick={save} loading={busy} disabled={v.full_name.trim().length < 2}>
            Kaydet
          </Button>
        </>
      }
    >
      <form
        className="grid sm:grid-cols-2 gap-3"
        onSubmit={(e) => {
          e.preventDefault();
          void save();
        }}
      >
        <Field label="Ad soyad / firma" error={errors.full_name} required className="sm:col-span-2">
          {(id) => <Input id={id} autoFocus value={v.full_name} onChange={set("full_name")} />}
        </Field>
        <Field label="Telefon" error={errors.phone}>
          {(id) => <Input id={id} mono inputMode="tel" value={v.phone} onChange={set("phone")} placeholder="05xx xxx xx xx" />}
        </Field>
        <Field label="E-posta" error={errors.email}>
          {(id) => <Input id={id} type="email" value={v.email} onChange={set("email")} />}
        </Field>
        <Field label="Vergi / TC no">{(id) => <Input id={id} mono value={v.tax_no} onChange={set("tax_no")} />}</Field>
        <Field label="Kredi limiti (₺)" hint={isAdmin ? "Veresiye bu tutarı aşarsa yönetici onayı istenir" : "Yalnızca yönetici değiştirebilir"} error={errors.credit_limit_kurus}>
          {(id) => <Input id={id} mono align="right" inputMode="decimal" disabled={!isAdmin} value={v.credit_limit} onChange={set("credit_limit")} />}
        </Field>
        <Field label="Adres" className="sm:col-span-2">
          {(id) => <Textarea id={id} rows={2} value={v.address} onChange={set("address")} />}
        </Field>
        <Field label="Not" className="sm:col-span-2">
          {(id) => <Textarea id={id} rows={2} value={v.note} onChange={set("note")} />}
        </Field>
        <Checkbox
          className="sm:col-span-2"
          label="KVKK aydınlatma metni müşteriye okundu, açık rıza alındı"
          checked={v.kvkk}
          disabled={!!customer?.kvkk_consent_at}
          onChange={set("kvkk")}
        />
        {errors._ && <p className="sm:col-span-2 text-12 text-crit">{errors._}</p>}
        <button type="submit" className="hidden" />
      </form>
    </Dialog>
  );
}
