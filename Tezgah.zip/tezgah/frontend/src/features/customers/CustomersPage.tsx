import { useQuery } from "@tanstack/react-query";
import { Plus, Search } from "lucide-react";
import { useMemo, useState } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { Button } from "@/design/Button";
import { type ColumnDef, DataTable } from "@/design/DataTable";
import { EmptyState, ErrorState, Loading } from "@/design/Feedback";
import { Led, Money } from "@/design/Indicators";
import { Input, Select } from "@/design/Input";
import { PageHeader } from "@/design/Page";
import { api } from "@/lib/api";
import { dateOnly, money, phone } from "@/lib/format";
import { useTitle } from "@/lib/hooks";
import type { Customer } from "@/lib/types";
import { CustomerDialog } from "./CustomerForm";

export default function CustomersPage() {
  useTitle("Müşteriler");
  const navigate = useNavigate();
  const [params, setParams] = useSearchParams();
  const filter = params.get("filtre") ?? "";
  const [q, setQ] = useState("");
  const [adding, setAdding] = useState(false);
  const query = useQuery({ queryKey: ["customers", filter], queryFn: () => api.get<Customer[]>("/customers", { filter: filter || undefined }) });
  const rows = useMemo(() => {
    const needle = q.trim().toLocaleLowerCase("tr-TR");
    const digits = q.replace(/\D/g, "");
    return (query.data ?? []).filter(
      (c) => !needle || c.full_name.toLocaleLowerCase("tr-TR").includes(needle) || (digits.length >= 3 && c.phone.includes(digits)),
    );
  }, [query.data, q]);
  const receivable = rows.reduce((s, c) => s + Math.max(0, c.balance), 0);
  const overdue = rows.reduce((s, c) => s + c.overdue, 0);

  const columns: ColumnDef<Customer, any>[] = [
    { accessorKey: "full_name", header: "Müşteri", cell: ({ row }) => <span className="font-medium">{row.original.full_name}</span> },
    { accessorKey: "phone", header: "Telefon", meta: { mono: true, className: "text-12" }, cell: ({ getValue }) => phone(getValue()) },
    {
      accessorKey: "overdue",
      header: "Vade",
      meta: { exportValue: (c) => (c.overdue ? "Vadesi geçmiş" : "") },
      cell: ({ row }) =>
        row.original.overdue > 0 ? (
          <Led tone="crit">Vadesi geçmiş {money(row.original.overdue)}</Led>
        ) : row.original.balance > 0 ? (
          <Led tone="warn">Borçlu</Led>
        ) : (
          <span className="text-ink-3">—</span>
        ),
    },
    {
      accessorKey: "credit_limit_kurus",
      header: "Kredi limiti",
      meta: { align: "right", exportValue: (c) => (c.credit_limit_kurus / 100).toFixed(2) },
      cell: ({ getValue }) => (getValue() ? <Money value={getValue()} className="text-ink-2" /> : <span className="text-ink-3">—</span>),
    },
    {
      accessorKey: "balance",
      header: "Bakiye",
      meta: { align: "right", exportValue: (c) => (c.balance / 100).toFixed(2) },
      cell: ({ getValue }) => <Money value={getValue()} className={getValue() > 0 ? "text-crit" : getValue() < 0 ? "text-ok" : "text-ink-3"} />,
    },
    { accessorKey: "created_at", header: "Kayıt", meta: { mono: true, className: "text-12 text-ink-3" }, cell: ({ getValue }) => dateOnly(getValue()) },
  ];

  return (
    <div>
      <PageHeader
        title="Müşteriler"
        count={rows.length}
        sub={
          <span>
            Toplam alacak <span className="num text-ink">{money(receivable)}</span>
            {overdue > 0 && (
              <>
                {" "}
                · vadesi geçen <span className="num text-crit">{money(overdue)}</span>
              </>
            )}
          </span>
        }
        actions={
          <Button variant="primary" icon={Plus} onClick={() => setAdding(true)}>
            Yeni müşteri
          </Button>
        }
      />
      {query.isLoading ? (
        <Loading />
      ) : query.isError ? (
        <ErrorState error={query.error} onRetry={() => query.refetch()} />
      ) : (
        <DataTable
          data={rows}
          columns={columns}
          getRowId={(c) => String(c.id)}
          onRowClick={(c) => navigate(`/cari/${c.id}`)}
          exportName="tezgah-musteriler"
          storageKey="customers"
          initialSort={filter ? [{ id: "balance", desc: true }] : [{ id: "full_name", desc: false }]}
          toolbar={
            <>
              <div className="relative w-full sm:w-64">
                <Search size={14} strokeWidth={1.5} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-ink-3 pointer-events-none" aria-hidden />
                <Input data-page-search value={q} onChange={(e) => setQ(e.target.value)} placeholder="Ad veya telefon…" className="pl-8" aria-label="Müşteri ara" />
              </div>
              <Select
                value={filter}
                onChange={(e) => {
                  const next = new URLSearchParams(params);
                  if (e.target.value) next.set("filtre", e.target.value);
                  else next.delete("filtre");
                  setParams(next, { replace: true });
                }}
                className="w-48"
                aria-label="Filtre"
              >
                <option value="">Tüm müşteriler</option>
                <option value="debt">Borcu olanlar</option>
                <option value="overdue">Vadesi geçmiş borçlular</option>
              </Select>
            </>
          }
          empty={<EmptyState icon="connector" title="Müşteri bulunamadı." action={<Button icon={Plus} onClick={() => setAdding(true)}>Yeni müşteri</Button>} />}
        />
      )}
      {adding && <CustomerDialog customer={null} onClose={() => setAdding(false)} onSaved={(c) => navigate(`/cari/${c.id}`)} />}
    </div>
  );
}
