import { useQuery, useQueryClient } from "@tanstack/react-query";
import { ChevronDown, ExternalLink, PackageCheck, Printer, Trash2 } from "lucide-react";
import { useEffect, useState } from "react";
import { Link, useParams, useSearchParams } from "react-router-dom";
import { useCan } from "@/app/auth";
import { useCrumb } from "@/app/crumbs";
import { Button, IconButton } from "@/design/Button";
import { QrCode } from "@/design/Codes";
import { cx } from "@/design/cx";
import { Dialog, useConfirm } from "@/design/Dialog";
import { ErrorState, Loading } from "@/design/Feedback";
import { Led, Money, Qty, Tag } from "@/design/Indicators";
import { Checkbox, Field, Input, Radio, Select, Textarea } from "@/design/Input";
import { Menu, MenuContent, MenuItem, MenuLabel, MenuTrigger } from "@/design/Menu";
import { KeyValues, Panel } from "@/design/Page";
import { useToast } from "@/design/Toast";
import { ApiError, api, errorMessage } from "@/lib/api";
import { dateTime, money, moneyInput, parseDecimal, parseMoney, phone } from "@/lib/format";
import { useSettings, useUsers } from "@/lib/hooks";
import { DEVICE_TR, SERVICE_STATUS_TONE, SERVICE_STATUS_TR } from "@/lib/labels";
import { printNode } from "@/lib/print";
import type { Product, SaleDetail, Serial, ServiceStatus, TicketDetail } from "@/lib/types";
import { DoneDialog, PaymentDialog } from "../pos/PaymentDialog";
import { SerialPickerDialog } from "../pos/SerialPicker";
import { Receipt80, SaleSummaryA4 } from "../sales/Receipt";
import { ProductSearch } from "../shared/Pickers";
import { IntakeSlip, trackUrl } from "./IntakeSlip";

function StatusDialog({ ticket, to, onClose, onDone }: { ticket: TicketDetail; to: ServiceStatus; onClose: () => void; onDone: () => void }) {
  const [note, setNote] = useState("");
  const [notify, setNotify] = useState(to === "READY" || to === "WAITING_APPROVAL" || to === "WAITING_PARTS");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const submit = async () => {
    setBusy(true);
    try {
      await api.post(`/service-tickets/${ticket.id}/status`, { status: to, note, notify_customer: notify && !!note.trim() });
      onDone();
    } catch (e) {
      setError(errorMessage(e));
    } finally {
      setBusy(false);
    }
  };
  return (
    <Dialog
      open
      onOpenChange={(o) => !o && onClose()}
      title={`Durum: ${SERVICE_STATUS_TR[to]}`}
      description={`${SERVICE_STATUS_TR[ticket.status]} → ${SERVICE_STATUS_TR[to]}`}
      width={460}
      footer={
        <>
          <Button variant="ghost" onClick={onClose}>
            Vazgeç
          </Button>
          <Button variant={to === "CANCELLED" ? "danger" : "primary"} onClick={submit} loading={busy}>
            Kaydet
          </Button>
        </>
      }
    >
      <div className="flex flex-col gap-3">
        <Field label="Not (isteğe bağlı)" error={error ?? undefined}>
          {(id) => <Textarea id={id} rows={3} autoFocus value={note} onChange={(e) => setNote(e.target.value)} />}
        </Field>
        <Checkbox label="Not müşterinin takip sayfasında görünsün" checked={notify} onChange={(e) => setNotify(e.target.checked)} />
      </div>
    </Dialog>
  );
}

function Timeline({ ticket }: { ticket: TicketDetail }) {
  return (
    <ol className="relative px-4 py-4">
      <span className="absolute left-[23px] top-6 bottom-6 w-px bg-rule-strong" aria-hidden />
      {ticket.timeline.map((e, i) => (
        <li key={i} className="relative flex gap-3 pb-4 last:pb-0">
          <span
            className={cx(
              "relative z-10 mt-1 size-[15px] shrink-0 border",
              e.kind === "status" ? "border-ink bg-ink" : e.visibility === "CUSTOMER" ? "border-info bg-surface" : "border-rule-strong bg-surface",
            )}
            style={e.kind === "status" && e.to_status ? { background: `var(--${SERVICE_STATUS_TONE[e.to_status] === "neutral" ? "ink-3" : SERVICE_STATUS_TONE[e.to_status]})`, borderColor: "transparent" } : undefined}
            aria-hidden
          />
          <div className="min-w-0 flex-1">
            <div className="flex flex-wrap items-baseline gap-x-2">
              {e.kind === "status" ? (
                <span className="text-13 font-medium">{SERVICE_STATUS_TR[e.to_status!]}</span>
              ) : (
                <span className="text-13 font-medium">{e.visibility === "CUSTOMER" ? "Müşteriye not" : "İç not"}</span>
              )}
              <span className="num text-11 text-ink-3">{dateTime(e.at)}</span>
              <span className="text-11 text-ink-3">{e.user_name}</span>
              {e.kind === "note" && e.visibility === "CUSTOMER" && <Tag tone="info">MÜŞTERİ GÖRÜR</Tag>}
            </div>
            {(e.note || e.body) && <p className="text-13 text-ink-2 whitespace-pre-wrap mt-0.5">{e.note || e.body}</p>}
          </div>
        </li>
      ))}
    </ol>
  );
}

export default function ServiceDetailPage() {
  const { id } = useParams();
  const [params, setParams] = useSearchParams();
  const qc = useQueryClient();
  const toast = useToast();
  const confirm = useConfirm();
  const settings = useSettings();
  const users = useUsers();
  const canCost = useCan("product.cost_view");
  const [statusTo, setStatusTo] = useState<ServiceStatus | null>(null);
  const [note, setNote] = useState("");
  const [noteVis, setNoteVis] = useState<"INTERNAL" | "CUSTOMER">("INTERNAL");
  const [serialFor, setSerialFor] = useState<Product | null>(null);
  const [deliverOpen, setDeliverOpen] = useState(false);
  const [done, setDone] = useState<{ sale: SaleDetail; change: number | null } | null>(null);
  const [diagnosis, setDiagnosis] = useState<string | null>(null);
  const [labor, setLabor] = useState<string | null>(null);
  const [pendingMeter, setPendingMeter] = useState<Product | null>(null);
  const [meterText, setMeterText] = useState("1");
  const q = useQuery({ queryKey: ["ticket", id], queryFn: () => api.get<TicketDetail>(`/service-tickets/${id}`) });
  const t = q.data;
  useCrumb(t ? `${t.code} · ${t.brand} ${t.model}` : null);

  useEffect(() => {
    if (t && params.get("teslim") === "1" && t.status === "READY") {
      setDeliverOpen(true);
      params.delete("teslim");
      setParams(params, { replace: true });
    }
  }, [t, params, setParams]);

  if (q.isLoading) return <Loading />;
  if (q.isError || !t) return <ErrorState error={q.error} onRetry={() => q.refetch()} />;
  const closed = t.status === "DELIVERED" || t.status === "CANCELLED";

  const refresh = async () => {
    await qc.invalidateQueries({ queryKey: ["ticket", id] });
    await qc.invalidateQueries({ queryKey: ["tickets"] });
  };
  const patch = async (body: Record<string, unknown>, msg: string) => {
    try {
      await api.patch(`/service-tickets/${t.id}`, body);
      toast({ title: msg });
      await refresh();
    } catch (e) {
      toast({ tone: "crit", title: "Kaydedilemedi", message: errorMessage(e) });
    }
  };
  const addPart = async (p: Product, serial?: Serial, qty = 1) => {
    if (p.track_serial && !serial) {
      setSerialFor(p);
      return;
    }
    if (p.unit_type === "METER" && pendingMeter?.id !== p.id) {
      setPendingMeter(p);
      setMeterText("1");
      return;
    }
    setPendingMeter(null);
    try {
      await api.post(`/service-tickets/${t.id}/parts`, { product_id: p.id, qty, serial_id: serial?.id ?? null });
      toast({ title: "Parça eklendi", message: `${p.name} — stoktan düşüldü` });
      await refresh();
      await qc.invalidateQueries({ queryKey: ["products"] });
    } catch (e) {
      toast({ tone: "crit", title: "Parça eklenemedi", message: errorMessage(e) });
    }
  };
  const removePart = async (partId: number, name: string) => {
    const ok = await confirm({ title: "Parça çıkarılsın mı?", message: `${name} stoğa geri alınacak.`, confirmLabel: "Çıkar", danger: true });
    if (!ok) return;
    try {
      await api.post(`/service-tickets/${t.id}/parts/${partId}/remove`);
      toast({ title: "Parça stoğa geri alındı" });
      await refresh();
    } catch (e) {
      toast({ tone: "crit", title: "Çıkarılamadı", message: errorMessage(e) });
    }
  };
  const addNote = async () => {
    try {
      await api.post(`/service-tickets/${t.id}/notes`, { body: note, visibility: noteVis });
      setNote("");
      await refresh();
    } catch (e) {
      toast({ tone: "crit", title: "Not eklenemedi", message: errorMessage(e) });
    }
  };
  const printSlip = () => settings.data && printNode(<IntakeSlip ticket={t} settings={settings.data} />, "a5");
  const startDeliver = async () => {
    if (t.total === 0) {
      const ok = await confirm({ title: "Ücretsiz teslim edilsin mi?", message: "Parça veya işçilik yok; satış oluşturulmadan teslim edilecek.", confirmLabel: "Teslim et" });
      if (!ok) return;
      try {
        await api.post(`/service-tickets/${t.id}/deliver`, { payments: [] });
        toast({ title: "Cihaz teslim edildi" });
        await refresh();
      } catch (e) {
        toast({ tone: "crit", title: "Teslim edilemedi", message: errorMessage(e) });
      }
      return;
    }
    setDeliverOpen(true);
  };

  const next = t.next_status && t.next_status !== "DELIVERED" && t.allowed_transitions.includes(t.next_status) ? t.next_status : null;
  const activeParts = t.parts.filter((p) => !p.removed_at);

  return (
    <div className="pb-10">
      {params.get("yeni") === "1" && (
        <div className="mx-4 md:mx-6 mt-4 flex flex-wrap items-center gap-3 border border-rule bg-surface px-4 py-2.5 anim-in">
          <Led tone="ok">Kayıt açıldı.</Led>
          <span className="text-13 text-ink-2">Kabul fişini yazdırıp müşteriye verin; fişteki QR ile cihazın durumunu takip edebilir.</span>
          <Button size="sm" icon={Printer} onClick={printSlip} className="ml-auto">
            Kabul fişi yazdır
          </Button>
        </div>
      )}
      <div className="px-4 md:px-6 pt-5 pb-4 flex flex-wrap justify-between gap-4">
        <div>
          <Led tone={SERVICE_STATUS_TONE[t.status]}>{SERVICE_STATUS_TR[t.status]}</Led>
          <h1 className="num text-28 font-semibold mt-1 leading-tight">{t.code}</h1>
          <div className="text-14">
            {DEVICE_TR[t.device_type]} · {t.brand} {t.model}
          </div>
          <div className="text-13 text-ink-2">
            {t.customer && (
              <Link to={`/cari/${t.customer.id}`} className="underline decoration-rule-strong">
                {t.customer.full_name}
              </Link>
            )}{" "}
            · <span className="num">{phone(t.customer?.phone)}</span> · bekleme{" "}
            <span className={cx("num", !closed && t.waiting_days > 7 ? "text-crit" : !closed && t.waiting_days > 3 ? "text-warn" : undefined)}>{t.waiting_days} gün</span>
          </div>
        </div>
        <div className="flex flex-wrap items-start gap-2">
          <Button icon={Printer} onClick={printSlip}>
            Kabul fişi
          </Button>
          {!closed && t.allowed_transitions.length > 0 && (
            <Menu>
              <MenuTrigger asChild>
                <Button icon={ChevronDown}>Durum</Button>
              </MenuTrigger>
              <MenuContent>
                <MenuLabel>Durumu değiştir</MenuLabel>
                {t.allowed_transitions.map((s) => (
                  <MenuItem key={s} onSelect={() => setStatusTo(s)} danger={s === "CANCELLED"}>
                    <Led tone={SERVICE_STATUS_TONE[s]} /> {SERVICE_STATUS_TR[s]}
                  </MenuItem>
                ))}
              </MenuContent>
            </Menu>
          )}
          {next && (
            <Button variant="primary" onClick={() => setStatusTo(next)}>
              İlerlet → {SERVICE_STATUS_TR[next]}
            </Button>
          )}
          {t.status === "READY" && (
            <Button variant="signal" icon={PackageCheck} onClick={() => void startDeliver()}>
              Teslim et ve satışa dönüştür
            </Button>
          )}
          {t.sale_id && (
            <Link to={`/satislar/${t.sale_id}`} className="self-center text-13 underline decoration-rule-strong">
              Satış fişi →
            </Link>
          )}
        </div>
      </div>

      <div className="grid xl:grid-cols-[minmax(0,1fr)_minmax(0,1.3fr)] gap-4 px-4 md:px-6">
        <div className="flex flex-col gap-4 min-w-0">
          <Panel title="Zaman çizelgesi">
            <Timeline ticket={t} />
            <form
              className="border-t border-rule p-4 flex flex-col gap-2"
              onSubmit={(e) => {
                e.preventDefault();
                void addNote();
              }}
            >
              <Textarea aria-label="Not" rows={2} value={note} onChange={(e) => setNote(e.target.value)} placeholder="Not ekle…" />
              <div className="flex flex-wrap items-center gap-4">
                <Radio name="vis" label="İç not" checked={noteVis === "INTERNAL"} onChange={() => setNoteVis("INTERNAL")} />
                <Radio name="vis" label="Müşteriye açık" checked={noteVis === "CUSTOMER"} onChange={() => setNoteVis("CUSTOMER")} />
                <Button type="submit" size="sm" className="ml-auto" disabled={!note.trim()}>
                  Notu ekle
                </Button>
              </div>
            </form>
          </Panel>
          <Panel title="Müşteri takibi">
            <div className="p-4 flex items-center gap-4">
              <div className="bg-[#fff] p-1 border border-rule">
                <QrCode value={trackUrl(t.code)} size={96} />
              </div>
              <div className="text-13 text-ink-2 min-w-0">
                <p>Müşteri, kabul fişindeki QR kodla cihazın durumunu giriş yapmadan izler. Kişisel veri gösterilmez.</p>
                <a href={`/takip/${t.code}`} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1 mt-1 num text-12 underline decoration-rule-strong">
                  /takip/{t.code} <ExternalLink size={12} aria-hidden />
                </a>
              </div>
            </div>
          </Panel>
        </div>

        <div className="flex flex-col gap-4 min-w-0">
          <Panel title="Cihaz">
            <KeyValues
              rows={[
                ["Cihaz", `${DEVICE_TR[t.device_type]} · ${t.brand} ${t.model}`],
                ["Seri no", t.serial_no ? <span className="num">{t.serial_no}</span> : null],
                ["Aksesuarlar", t.accessories.length ? t.accessories.join(", ") : "yok"],
                ["Şikâyet", <span className="whitespace-pre-wrap">{t.complaint}</span>],
                ["Kabul", <span className="num">{dateTime(t.received_at)}</span>],
                ["Müşteri onayı", t.approved_by_customer_at ? <span className="num">{dateTime(t.approved_by_customer_at)}</span> : "—"],
                ["Teslim", t.delivered_at ? <span className="num">{dateTime(t.delivered_at)}</span> : "—"],
                [
                  "Atanan",
                  closed ? (
                    t.assigned_name
                  ) : (
                    <Select
                      aria-label="Atanan teknisyen"
                      value={t.assigned_to ?? ""}
                      onChange={(e) => void patch({ assigned_to: e.target.value ? Number(e.target.value) : null }, "Atanan güncellendi")}
                      className="max-w-60"
                    >
                      {users.data?.map((u) => (
                        <option key={u.id} value={u.id}>
                          {u.full_name}
                        </option>
                      ))}
                    </Select>
                  ),
                ],
              ]}
            />
            <div className="p-4 flex flex-col gap-2">
              <Field label="Arıza tespiti">
                {(fid) => (
                  <Textarea
                    id={fid}
                    rows={3}
                    disabled={closed}
                    value={diagnosis ?? t.diagnosis}
                    onChange={(e) => setDiagnosis(e.target.value)}
                    placeholder="Teknisyenin tespit ettiği arıza…"
                  />
                )}
              </Field>
              {diagnosis !== null && diagnosis !== t.diagnosis && (
                <Button size="sm" className="self-end" onClick={() => void patch({ diagnosis }, "Arıza tespiti kaydedildi").then(() => setDiagnosis(null))}>
                  Kaydet
                </Button>
              )}
            </div>
          </Panel>

          <Panel title="Parçalar ve işçilik" right={<span className="num text-12 text-ink-3">{activeParts.length} parça</span>}>
            {!closed && (
              <div className="p-3 border-b border-rule">
                <ProductSearch placeholder="Stoktan parça veya hizmet ekle…" onPick={(p) => void addPart(p)} />
                {pendingMeter && (
                  <form
                    className="flex items-center gap-2 mt-2"
                    onSubmit={(e) => {
                      e.preventDefault();
                      const n = parseDecimal(meterText);
                      if (n && n > 0) void addPart(pendingMeter, undefined, n);
                    }}
                  >
                    <span className="text-13 flex-1 truncate">{pendingMeter.name}</span>
                    <Input mono align="right" className="w-24" autoFocus aria-label="Metre" value={meterText} onChange={(e) => setMeterText(e.target.value)} />
                    <span className="text-12 text-ink-3">m</span>
                    <Button type="submit" size="sm" variant="primary">
                      Ekle
                    </Button>
                    <Button size="sm" variant="ghost" onClick={() => setPendingMeter(null)}>
                      Vazgeç
                    </Button>
                  </form>
                )}
              </div>
            )}
            {t.parts.length > 0 && (
              <table className="w-full text-13">
                <tbody>
                  {t.parts.map((p) => (
                    <tr key={p.id} className={cx("border-b border-rule", p.removed_at && "text-ink-3 line-through")} style={{ height: "var(--row-h)" }}>
                      <td className="pl-4 pr-2">
                        {p.product_name}
                        {p.serial_no && <div className="num text-11 text-ink-3">SN {p.serial_no}</div>}
                      </td>
                      <td className="px-2 text-right whitespace-nowrap">
                        <Qty value={p.qty} unit={p.unit_type === "SERVICE" ? "PIECE" : p.unit_type} />
                      </td>
                      <td className="px-2 text-right">
                        <Money value={p.total} />
                      </td>
                      {canCost && (
                        <td className="px-2 text-right text-12 text-ink-3 hidden md:table-cell">
                          <Money value={p.unit_cost} />
                        </td>
                      )}
                      <td className="pr-3 w-10 text-right">
                        {!closed && !p.removed_at && <IconButton icon={Trash2} label="Parçayı çıkar" size={26} onClick={() => void removePart(p.id, p.product_name)} />}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
            <div className="p-4 flex flex-col gap-2 text-13">
              <div className="flex items-center justify-between gap-3">
                <label htmlFor="labor" className="text-ink-2">
                  İşçilik ücreti (₺)
                </label>
                <div className="flex items-center gap-2">
                  <Input
                    id="labor"
                    mono
                    align="right"
                    className="w-32"
                    disabled={closed}
                    inputMode="decimal"
                    value={labor ?? moneyInput(t.labor_fee)}
                    onChange={(e) => setLabor(e.target.value)}
                  />
                  {labor !== null && parseMoney(labor) !== t.labor_fee && (
                    <Button size="sm" onClick={() => void patch({ labor_fee: parseMoney(labor) ?? 0 }, "İşçilik güncellendi").then(() => setLabor(null))}>
                      Kaydet
                    </Button>
                  )}
                </div>
              </div>
              <div className="flex justify-between text-ink-2">
                <span>Parçalar</span>
                <Money value={t.parts_total} />
              </div>
              <div className="flex justify-between border-t border-rule pt-2">
                <span className="font-medium">Toplam</span>
                <span className="num text-20 font-semibold">{money(t.total)}</span>
              </div>
              <div className="flex justify-between text-12 text-ink-3">
                <span>Tahmini ücret (kabulde)</span>
                <span className="num">{t.estimated_cost ? money(t.estimated_cost) : "—"}</span>
              </div>
              {canCost && t.parts_cost !== undefined && (
                <div className="flex justify-between text-12 text-ink-3">
                  <span>Parça maliyeti</span>
                  <span className="num">{money(t.parts_cost)}</span>
                </div>
              )}
            </div>
          </Panel>
        </div>
      </div>

      {statusTo && (
        <StatusDialog
          ticket={t}
          to={statusTo}
          onClose={() => setStatusTo(null)}
          onDone={async () => {
            toast({ title: `Durum: ${SERVICE_STATUS_TR[statusTo]}` });
            setStatusTo(null);
            await refresh();
          }}
        />
      )}
      <SerialPickerDialog
        product={serialFor}
        exclude={[]}
        onClose={() => setSerialFor(null)}
        onPick={(s) => {
          const p = serialFor;
          setSerialFor(null);
          if (p) void addPart(p, s);
        }}
      />
      {deliverOpen && (
        <PaymentDialog
          total={t.total}
          customer={t.customer}
          submitLabel="Teslim et"
          onSubmit={async (payload) => {
            const updated = await api.post<TicketDetail>(`/service-tickets/${t.id}/deliver`, payload);
            if (!updated.sale_id) throw new ApiError(500, "NO_SALE", "Satış oluşturulamadı.");
            return api.get<SaleDetail>(`/sales/${updated.sale_id}`);
          }}
          onClose={() => setDeliverOpen(false)}
          onPaid={async (sale, change) => {
            setDeliverOpen(false);
            setDone({ sale, change });
            await refresh();
            await qc.invalidateQueries({ queryKey: ["status"] });
          }}
        />
      )}
      {done && (
        <DoneDialog
          sale={done.sale}
          change={done.change}
          onPrint={(kind) =>
            settings.data &&
            printNode(kind === "receipt80" ? <Receipt80 sale={done.sale} settings={settings.data} /> : <SaleSummaryA4 sale={done.sale} settings={settings.data} />, kind)
          }
          onClose={() => setDone(null)}
        />
      )}
    </div>
  );
}
