import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Columns3, List, Plus, Search } from "lucide-react";
import { useMemo, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Button, ButtonLink } from "@/design/Button";
import { cx } from "@/design/cx";
import { type ColumnDef, DataTable } from "@/design/DataTable";
import { EmptyState, ErrorState, Loading } from "@/design/Feedback";
import { Led, Money } from "@/design/Indicators";
import { Input, Select } from "@/design/Input";
import { PageHeader } from "@/design/Page";
import { useToast } from "@/design/Toast";
import { api, errorMessage } from "@/lib/api";
import { dateOnly, money } from "@/lib/format";
import { useTitle, useUsers } from "@/lib/hooks";
import { DEVICE_TR, OPEN_SERVICE, SERVICE_ORDER, SERVICE_STATUS_TONE, SERVICE_STATUS_TR } from "@/lib/labels";
import { readStore, writeStore } from "@/lib/storage";
import type { ServiceStatus, TicketListRow } from "@/lib/types";

function waitTone(row: TicketListRow): "crit" | "warn" | undefined {
  if (!OPEN_SERVICE.includes(row.status)) return undefined;
  if (row.waiting_days > 7) return "crit";
  if (row.waiting_days > 3) return "warn";
  return undefined;
}

function WaitDays({ row }: { row: TicketListRow }) {
  const tone = waitTone(row);
  return <span className={cx("num", tone === "crit" && "text-crit", tone === "warn" && "text-warn")}>{row.waiting_days} gün</span>;
}

export default function ServiceListPage() {
  useTitle("Teknik Servis");
  const navigate = useNavigate();
  const qc = useQueryClient();
  const toast = useToast();
  const users = useUsers();
  const [view, setView] = useState<"table" | "board">(() => readStore("tezgah.service.view", "table"));
  const [status, setStatus] = useState("open");
  const [assigned, setAssigned] = useState("");
  const [q, setQ] = useState("");
  const [dragOver, setDragOver] = useState<ServiceStatus | null>(null);
  const query = useQuery({
    queryKey: ["tickets", view === "board" ? "open" : status, assigned],
    queryFn: () => api.get<TicketListRow[]>("/service-tickets", { status: view === "board" ? "open" : status || undefined, assigned_to: assigned || undefined }),
  });
  const rows = useMemo(() => {
    const needle = q.trim().toLocaleLowerCase("tr-TR");
    return (query.data ?? []).filter(
      (t) => !needle || `${t.code} ${t.brand} ${t.model} ${t.customer_name} ${t.customer_phone}`.toLocaleLowerCase("tr-TR").includes(needle),
    );
  }, [query.data, q]);

  const switchView = (v: "table" | "board") => {
    setView(v);
    writeStore("tezgah.service.view", v);
  };

  const moveTo = async (ticketId: number, to: ServiceStatus) => {
    const t = rows.find((r) => r.id === ticketId);
    if (!t || t.status === to) return;
    if (to === "DELIVERED") {
      navigate(`/servis/${ticketId}?teslim=1`);
      return;
    }
    try {
      await api.post(`/service-tickets/${ticketId}/status`, { status: to, note: "" });
      toast({ title: `${t.code} → ${SERVICE_STATUS_TR[to]}` });
      await qc.invalidateQueries({ queryKey: ["tickets"] });
    } catch (e) {
      toast({ tone: "crit", title: "Durum değiştirilemedi", message: errorMessage(e) });
    }
  };

  const columns: ColumnDef<TicketListRow, any>[] = [
    { accessorKey: "code", header: "Kod", meta: { mono: true } },
    {
      id: "device",
      header: "Cihaz",
      accessorFn: (t) => `${DEVICE_TR[t.device_type]} ${t.brand} ${t.model}`,
      cell: ({ row }) => (
        <div>
          <div>
            {row.original.brand} {row.original.model}
          </div>
          <div className="text-12 text-ink-3">{DEVICE_TR[row.original.device_type]}</div>
        </div>
      ),
    },
    {
      accessorKey: "customer_name",
      header: "Müşteri",
      cell: ({ row }) => (
        <Link to={`/cari/${row.original.customer_id}`} className="hover:underline" onClick={(e) => e.stopPropagation()}>
          {row.original.customer_name}
        </Link>
      ),
    },
    {
      accessorKey: "status",
      header: "Durum",
      meta: { exportValue: (t) => SERVICE_STATUS_TR[t.status] },
      cell: ({ row }) => <Led tone={SERVICE_STATUS_TONE[row.original.status]}>{SERVICE_STATUS_TR[row.original.status]}</Led>,
    },
    { accessorKey: "received_at", header: "Kabul", meta: { mono: true, className: "text-12" }, cell: ({ getValue }) => dateOnly(getValue()) },
    { accessorKey: "waiting_days", header: "Bekleme", meta: { align: "right" }, cell: ({ row }) => <WaitDays row={row.original} /> },
    { accessorKey: "assigned_name", header: "Atanan", meta: { className: "text-12 text-ink-2" } },
    {
      accessorKey: "estimated_cost",
      header: "Tahmini ücret",
      meta: { align: "right", exportValue: (t) => (t.estimated_cost / 100).toFixed(2) },
      cell: ({ getValue }) => (getValue() ? <Money value={getValue()} /> : <span className="text-ink-3">—</span>),
    },
  ];

  const toolbar = (
    <>
      <div className="relative w-full sm:w-64">
        <Search size={14} strokeWidth={1.5} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-ink-3 pointer-events-none" aria-hidden />
        <Input data-page-search value={q} onChange={(e) => setQ(e.target.value)} placeholder="Kod, cihaz, müşteri, telefon…" className="pl-8" aria-label="Servis ara" />
      </div>
      {view === "table" && (
        <Select value={status} onChange={(e) => setStatus(e.target.value)} className="w-44" aria-label="Durum">
          <option value="open">Açık kayıtlar</option>
          <option value="">Tümü</option>
          <option value="closed">Kapanmış</option>
          {SERVICE_ORDER.map((s) => (
            <option key={s} value={s}>
              {SERVICE_STATUS_TR[s]}
            </option>
          ))}
        </Select>
      )}
      <Select value={assigned} onChange={(e) => setAssigned(e.target.value)} className="w-40" aria-label="Atanan">
        <option value="">Tüm teknisyenler</option>
        {users.data?.map((u) => (
          <option key={u.id} value={u.id}>
            {u.full_name}
          </option>
        ))}
      </Select>
    </>
  );

  return (
    <div>
      <PageHeader
        title="Teknik Servis"
        count={rows.length}
        actions={
          <>
            <div className="inline-flex border border-rule-strong rounded-ctl overflow-hidden" role="group" aria-label="Görünüm">
              <Button variant={view === "table" ? "primary" : "ghost"} className="rounded-none border-0" icon={List} onClick={() => switchView("table")} aria-pressed={view === "table"}>
                Tablo
              </Button>
              <Button variant={view === "board" ? "primary" : "ghost"} className="rounded-none border-0" icon={Columns3} onClick={() => switchView("board")} aria-pressed={view === "board"}>
                Pano
              </Button>
            </div>
            <ButtonLink to="/servis/yeni" variant="primary" icon={Plus} kbd="F4">
              Yeni kayıt
            </ButtonLink>
          </>
        }
      />
      {query.isLoading ? (
        <Loading />
      ) : query.isError ? (
        <ErrorState error={query.error} onRetry={() => query.refetch()} />
      ) : view === "table" ? (
        <DataTable
          data={rows}
          columns={columns}
          getRowId={(t) => String(t.id)}
          onRowClick={(t) => navigate(`/servis/${t.id}`)}
          exportName="tezgah-servis"
          storageKey="service"
          toolbar={toolbar}
          initialSort={[{ id: "waiting_days", desc: true }]}
          empty={
            <EmptyState
              icon="switch"
              title="Bu filtrede servis kaydı yok."
              action={
                <ButtonLink to="/servis/yeni" variant="primary" icon={Plus}>
                  Yeni kayıt
                </ButtonLink>
              }
            />
          }
        />
      ) : (
        <div>
          <div className="flex flex-wrap items-center gap-2 px-4 md:px-6 py-2 border-y border-rule bg-surface">{toolbar}</div>
          <p className="px-4 md:px-6 py-2 text-12 text-ink-3">Kartları sürükleyip bırakarak durumu değiştirin. Teslim için kaydı açın.</p>
          <div className="grid grid-flow-col auto-cols-[minmax(230px,1fr)] gap-3 px-4 md:px-6 pb-6 overflow-x-auto scroll-thin">
            {OPEN_SERVICE.map((st) => {
              const items = rows.filter((r) => r.status === st);
              return (
                <section
                  key={st}
                  onDragOver={(e) => {
                    e.preventDefault();
                    setDragOver(st);
                  }}
                  onDragLeave={() => setDragOver(null)}
                  onDrop={(e) => {
                    e.preventDefault();
                    setDragOver(null);
                    const id = Number(e.dataTransfer.getData("text/plain"));
                    if (id) void moveTo(id, st);
                  }}
                  className={cx("flex flex-col bg-surface border border-rule min-h-[320px]", dragOver === st && "border-ink")}
                  aria-label={SERVICE_STATUS_TR[st]}
                >
                  <header className="flex items-center justify-between px-3 h-9 border-b border-rule">
                    <Led tone={SERVICE_STATUS_TONE[st]}>
                      <span className="font-cond text-12 uppercase tracking-[.06em]" lang="tr">
                        {SERVICE_STATUS_TR[st]}
                      </span>
                    </Led>
                    <span className="num text-12 text-ink-3">{items.length}</span>
                  </header>
                  <div className="flex flex-col gap-2 p-2">
                    {items.map((t) => (
                      <Link
                        key={t.id}
                        to={`/servis/${t.id}`}
                        draggable
                        onDragStart={(e) => e.dataTransfer.setData("text/plain", String(t.id))}
                        className="block border border-rule bg-paper px-2.5 py-2 hover:border-ink-3 cursor-grab active:cursor-grabbing"
                      >
                        <div className="flex justify-between items-baseline">
                          <span className="num text-13 font-medium">{t.code}</span>
                          <WaitDays row={t} />
                        </div>
                        <div className="text-13 truncate">
                          {t.brand} {t.model}
                        </div>
                        <div className="text-12 text-ink-2 truncate">{t.customer_name}</div>
                        {t.estimated_cost > 0 && <div className="num text-12 text-ink-3 mt-0.5">{money(t.estimated_cost)}</div>}
                      </Link>
                    ))}
                  </div>
                </section>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}
