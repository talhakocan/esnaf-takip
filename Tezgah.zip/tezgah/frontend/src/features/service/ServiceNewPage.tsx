import { useQueryClient } from "@tanstack/react-query";
import { KeyRound, UserRound, X } from "lucide-react";
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useMe } from "@/app/auth";
import { Button, IconButton } from "@/design/Button";
import { cx } from "@/design/cx";
import { Checkbox, Field, Input, Select, Textarea } from "@/design/Input";
import { Kbd } from "@/design/Kbd";
import { PageHeader, Panel } from "@/design/Page";
import { useToast } from "@/design/Toast";
import { ApiError, api } from "@/lib/api";
import { money, parseMoney, phone } from "@/lib/format";
import { useTitle, useUsers } from "@/lib/hooks";
import { ACCESSORY_OPTIONS, DEVICE_TR } from "@/lib/labels";
import { useHotkeys } from "@/lib/shortcuts";
import type { Customer, DeviceType, TicketDetail } from "@/lib/types";
import { CustomerPickerDialog } from "../shared/Pickers";

export default function ServiceNewPage() {
  useTitle("Yeni servis kaydı");
  const me = useMe();
  const navigate = useNavigate();
  const qc = useQueryClient();
  const toast = useToast();
  const users = useUsers();
  const [customer, setCustomer] = useState<Customer | null>(null);
  const [pickOpen, setPickOpen] = useState(false);
  const [device, setDevice] = useState<DeviceType>("LAPTOP");
  const [brand, setBrand] = useState("");
  const [model, setModel] = useState("");
  const [serial, setSerial] = useState("");
  const [accessories, setAccessories] = useState<string[]>([]);
  const [otherAcc, setOtherAcc] = useState("");
  const [complaint, setComplaint] = useState("");
  const [estimate, setEstimate] = useState("");
  const [assigned, setAssigned] = useState(String(me.id));
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [busy, setBusy] = useState(false);
  useHotkeys({ F7: () => setPickOpen(true) });

  const submit = async () => {
    if (!customer) {
      setErrors({ customer_id: "Müşteri seçin veya ekleyin." });
      return;
    }
    setBusy(true);
    setErrors({});
    try {
      const t = await api.post<TicketDetail>("/service-tickets", {
        customer_id: customer.id,
        device_type: device,
        brand,
        model,
        serial_no: serial,
        accessories: [...accessories, ...otherAcc.split(",").map((s) => s.trim()).filter(Boolean)],
        complaint,
        estimated_cost: parseMoney(estimate) ?? 0,
        assigned_to: assigned ? Number(assigned) : null,
      });
      await qc.invalidateQueries({ queryKey: ["tickets"] });
      toast({ title: "Servis kaydı açıldı", message: `${t.code} · kabul fişini yazdırabilirsiniz` });
      navigate(`/servis/${t.id}?yeni=1`);
    } catch (e) {
      if (e instanceof ApiError) setErrors({ ...e.fields, _: e.message });
    } finally {
      setBusy(false);
    }
  };

  return (
    <form
      className="pb-10"
      onSubmit={(e) => {
        e.preventDefault();
        void submit();
      }}
    >
      <PageHeader
        title="Yeni servis kaydı"
        sub="Cihazı teslim alırken doldurun; kayıttan sonra A5 kabul fişi yazdırılır."
        actions={
          <>
            <Button variant="ghost" onClick={() => navigate(-1)}>
              Vazgeç
            </Button>
            <Button type="submit" variant="primary" loading={busy}>
              Kaydı aç
            </Button>
          </>
        }
      />
      {errors._ && (
        <p className="mx-4 md:mx-6 mb-3 text-13 text-crit border-l-2 border-crit pl-2" role="alert">
          {errors._}
        </p>
      )}
      <div className="grid xl:grid-cols-2 gap-4 px-4 md:px-6">
        <Panel title="Müşteri" right={<Kbd>F7</Kbd>}>
          <div className="p-4">
            {customer ? (
              <div className="flex items-center gap-3 border border-rule px-3 py-2">
                <UserRound size={16} strokeWidth={1.5} className="text-ink-3" aria-hidden />
                <div className="flex-1">
                  <div className="font-medium">{customer.full_name}</div>
                  <div className="num text-12 text-ink-2">{phone(customer.phone)}</div>
                </div>
                {customer.balance > 0 && <span className="num text-12 text-crit">borç {money(customer.balance)}</span>}
                <IconButton icon={X} label="Müşteriyi değiştir" onClick={() => setCustomer(null)} />
              </div>
            ) : (
              <Button className="w-full" icon={UserRound} onClick={() => setPickOpen(true)} autoFocus>
                Müşteri seç veya hızlı ekle
              </Button>
            )}
            {errors.customer_id && <p className="text-12 text-crit mt-1">{errors.customer_id}</p>}
          </div>
        </Panel>

        <Panel title="Cihaz">
          <div className="p-4 grid sm:grid-cols-2 gap-3">
            <div className="sm:col-span-2">
              <div className="text-12 text-ink-2 mb-1">Cihaz tipi</div>
              <div className="flex flex-wrap gap-1" role="radiogroup" aria-label="Cihaz tipi">
                {(Object.keys(DEVICE_TR) as DeviceType[]).map((d) => (
                  <button
                    key={d}
                    type="button"
                    role="radio"
                    aria-checked={device === d}
                    onClick={() => setDevice(d)}
                    className={cx(
                      "h-8 px-3 text-13 border rounded-ctl cursor-pointer",
                      device === d ? "bg-ink text-paper border-ink" : "bg-surface border-rule-strong text-ink-2 hover:bg-surface-2",
                    )}
                  >
                    {DEVICE_TR[d]}
                  </button>
                ))}
              </div>
            </div>
            <Field label="Marka">{(id) => <Input id={id} value={brand} onChange={(e) => setBrand(e.target.value)} placeholder="Lenovo" />}</Field>
            <Field label="Model">{(id) => <Input id={id} value={model} onChange={(e) => setModel(e.target.value)} placeholder="IdeaPad 3" />}</Field>
            <Field label="Seri no" className="sm:col-span-2">
              {(id) => <Input id={id} mono value={serial} onChange={(e) => setSerial(e.target.value.toUpperCase())} />}
            </Field>
            <div className="sm:col-span-2">
              <div className="text-12 text-ink-2 mb-1.5">Teslim alınan aksesuarlar</div>
              <div className="flex flex-wrap gap-x-4 gap-y-1.5">
                {ACCESSORY_OPTIONS.map((a) => (
                  <Checkbox
                    key={a}
                    label={a}
                    checked={accessories.includes(a)}
                    onChange={(e) => setAccessories((xs) => (e.target.checked ? [...xs, a] : xs.filter((x) => x !== a)))}
                  />
                ))}
              </div>
              <Input className="mt-2" value={otherAcc} onChange={(e) => setOtherAcc(e.target.value)} placeholder="Diğer (virgülle ayırın)" aria-label="Diğer aksesuarlar" />
            </div>
          </div>
        </Panel>

        <Panel title="Arıza ve ücret" className="xl:col-span-2">
          <div className="p-4 grid md:grid-cols-[1fr_260px] gap-4">
            <Field label="Müşteri şikâyeti" error={errors.complaint} required>
              {(id) => <Textarea id={id} rows={4} value={complaint} onChange={(e) => setComplaint(e.target.value)} placeholder="Müşterinin anlattığı sorun…" />}
            </Field>
            <div className="flex flex-col gap-3">
              <Field label="Tahmini ücret (₺)" hint="Boş bırakılabilir">
                {(id) => <Input id={id} mono align="right" inputMode="decimal" value={estimate} onChange={(e) => setEstimate(e.target.value)} />}
              </Field>
              <Field label="Atanan teknisyen">
                {(id) => (
                  <Select id={id} value={assigned} onChange={(e) => setAssigned(e.target.value)}>
                    {users.data
                      ?.filter((u) => u.is_active)
                      .map((u) => (
                        <option key={u.id} value={u.id}>
                          {u.full_name}
                        </option>
                      ))}
                  </Select>
                )}
              </Field>
            </div>
            <p className="md:col-span-2 flex items-start gap-2 text-13 text-ink-2 border-l-2 border-warn pl-3">
              <KeyRound size={16} strokeWidth={1.5} className="text-warn shrink-0 mt-0.5" aria-hidden />
              Cihaz şifresi alanı bilinçli olarak yok. Şifre gerekirse müşteriden teslimde isteyin, sisteme kaydetmeyin.
            </p>
          </div>
        </Panel>
      </div>
      <CustomerPickerDialog open={pickOpen} onOpenChange={setPickOpen} onPick={setCustomer} />
    </form>
  );
}
