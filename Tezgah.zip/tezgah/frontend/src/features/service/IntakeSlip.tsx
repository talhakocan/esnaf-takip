import { QrCode } from "@/design/Codes";
import { dateTime, money, phone } from "@/lib/format";
import { DEVICE_TR } from "@/lib/labels";
import type { Settings, TicketDetail } from "@/lib/types";

export function trackUrl(code: string): string {
  return `${window.location.origin}/takip/${code}`;
}

/** A5 servis kabul fişi: büyük kod, takip QR'ı, cihaz bilgileri, şartlar, imza alanı. */
export function IntakeSlip({ ticket, settings }: { ticket: TicketDetail; settings: Settings }) {
  const box = { border: "1px solid #000", padding: "6px 8px" } as const;
  const label = { fontFamily: "'IBM Plex Sans Condensed'", fontSize: "8pt", letterSpacing: ".06em", textTransform: "uppercase" as const };
  return (
    <div style={{ fontFamily: "'IBM Plex Sans', sans-serif", fontSize: "9.5pt", color: "#000", lineHeight: 1.35 }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", borderBottom: "2px solid #000", paddingBottom: 6 }}>
        <div>
          <div style={{ fontFamily: "'IBM Plex Sans Condensed'", fontWeight: 600, fontSize: "15pt", letterSpacing: ".1em" }}>
            {settings.shop_name.toLocaleUpperCase("tr-TR")}
          </div>
          <div>{settings.address}</div>
          <div>{settings.phone}</div>
        </div>
        <div style={{ textAlign: "right" }}>
          <div style={label}>Servis kabul fişi</div>
          <div style={{ fontFamily: "'IBM Plex Mono'", fontSize: "22pt", fontWeight: 600, lineHeight: 1.1 }}>{ticket.code}</div>
          <div style={{ fontFamily: "'IBM Plex Mono'", fontSize: "9pt" }}>{dateTime(ticket.received_at)}</div>
        </div>
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "1fr auto", gap: 10, marginTop: 8 }}>
        <div style={{ display: "grid", gap: 6 }}>
          <div style={box}>
            <div style={label}>Müşteri</div>
            <div>
              {ticket.customer?.full_name} · <span style={{ fontFamily: "'IBM Plex Mono'" }}>{phone(ticket.customer?.phone)}</span>
            </div>
          </div>
          <div style={box}>
            <div style={label}>Cihaz</div>
            <div>
              {DEVICE_TR[ticket.device_type]} · {ticket.brand} {ticket.model}
            </div>
            {ticket.serial_no && <div style={{ fontFamily: "'IBM Plex Mono'" }}>Seri no: {ticket.serial_no}</div>}
            <div>Teslim alınan aksesuarlar: {ticket.accessories.length ? ticket.accessories.join(", ") : "yok"}</div>
          </div>
        </div>
        <div style={{ textAlign: "center" }}>
          <QrCode value={trackUrl(ticket.code)} size={104} />
          <div style={{ fontSize: "7.5pt", maxWidth: 110 }}>Cihazınızın durumunu takip edin</div>
          <div style={{ fontFamily: "'IBM Plex Mono'", fontSize: "7pt", wordBreak: "break-all", maxWidth: 110 }}>{trackUrl(ticket.code).replace(/^https?:\/\//, "")}</div>
        </div>
      </div>
      <div style={{ ...box, marginTop: 6 }}>
        <div style={label}>Müşteri şikâyeti</div>
        <div>{ticket.complaint}</div>
      </div>
      <div style={{ display: "flex", justifyContent: "space-between", marginTop: 6 }}>
        <span>Tahmini ücret: <strong style={{ fontFamily: "'IBM Plex Mono'" }}>{ticket.estimated_cost ? money(ticket.estimated_cost) : "arıza tespitinden sonra bildirilecek"}</strong></span>
      </div>
      <div style={{ marginTop: 8, fontSize: "7.5pt", whiteSpace: "pre-wrap", borderTop: "1px solid #000", paddingTop: 6 }}>
        <div style={label}>Servis şartları</div>
        {settings.service_terms}
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20, marginTop: 22 }}>
        <div style={{ borderTop: "1px solid #000", paddingTop: 3, ...label }}>Müşteri imza</div>
        <div style={{ borderTop: "1px solid #000", paddingTop: 3, ...label }}>Teslim alan</div>
      </div>
      <div style={{ marginTop: 10, fontSize: "7pt" }}>Cihaz şifrenizi bu fişe yazmayın; gerekirse teslimde personele sözlü iletin.</div>
    </div>
  );
}
