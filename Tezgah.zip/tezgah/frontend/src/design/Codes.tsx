import JsBarcode from "jsbarcode";
import QRCode from "qrcode";
import { useLayoutEffect, useMemo, useRef } from "react";

function isEan13(value: string): boolean {
  if (!/^\d{13}$/.test(value)) return false;
  const digits = value.split("").map(Number);
  const sum = digits.slice(0, 12).reduce((s, d, i) => s + d * (i % 2 ? 3 : 1), 0);
  return (10 - (sum % 10)) % 10 === digits[12];
}

/** Barkod (EAN-13 geçerliyse EAN-13, değilse Code128). Yazdırma için siyah çizer. */
export function Barcode({
  value,
  height = 40,
  width = 1.4,
  showText = true,
  fontSize = 11,
  className,
  color = "currentColor",
}: {
  value: string;
  height?: number;
  width?: number;
  showText?: boolean;
  fontSize?: number;
  className?: string;
  color?: string;
}) {
  const ref = useRef<SVGSVGElement>(null);
  useLayoutEffect(() => {
    if (!ref.current || !value) return;
    try {
      JsBarcode(ref.current, value, {
        format: isEan13(value) ? "EAN13" : "CODE128",
        height,
        width,
        displayValue: showText,
        font: "IBM Plex Mono",
        fontSize,
        margin: 0,
        textMargin: 1,
        background: "transparent",
        lineColor: color,
      });
    } catch {
      ref.current.innerHTML = "";
    }
  }, [value, height, width, showText, fontSize, color]);
  return <svg ref={ref} className={className} role="img" aria-label={`Barkod ${value}`} />;
}

/** QR kodu: modüller senkron hesaplanır, SVG olarak çizilir (yazdırmaya uygun). */
export function QrCode({ value, size = 96, className }: { value: string; size?: number; className?: string }) {
  const path = useMemo(() => {
    const qr = QRCode.create(value, { errorCorrectionLevel: "M" });
    const n = qr.modules.size;
    let d = "";
    for (let r = 0; r < n; r++) for (let c = 0; c < n; c++) if (qr.modules.get(r, c)) d += `M${c} ${r}h1v1h-1z`;
    return { d, n };
  }, [value]);
  return (
    <svg viewBox={`-2 -2 ${path.n + 4} ${path.n + 4}`} width={size} height={size} className={className} role="img" aria-label="QR kod" shapeRendering="crispEdges">
      <rect x={-2} y={-2} width={path.n + 4} height={path.n + 4} fill="#fff" />
      <path d={path.d} fill="#000" />
    </svg>
  );
}
