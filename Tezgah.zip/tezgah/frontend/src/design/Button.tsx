import type { LucideIcon } from "lucide-react";
import type { ComponentProps, ReactNode } from "react";
import { Link, type LinkProps } from "react-router-dom";
import { cx } from "./cx";
import { Kbd } from "./Kbd";

export type ButtonVariant = "primary" | "signal" | "secondary" | "ghost" | "danger";
type Size = "sm" | "md" | "lg";

const VARIANT: Record<ButtonVariant, string> = {
  primary: "bg-ink text-paper border-ink hover:bg-ink-2 hover:border-ink-2",
  signal: "bg-signal text-on-signal border-signal font-semibold hover:brightness-95",
  secondary: "bg-surface text-ink border-rule-strong hover:bg-surface-2",
  ghost: "bg-transparent border-transparent text-ink-2 hover:bg-surface-2 hover:text-ink",
  danger: "bg-surface text-crit border-rule-strong hover:bg-surface-2",
};

const SIZE: Record<Size, string> = {
  sm: "h-7 px-2 text-12 gap-1",
  md: "h-8 px-3 text-13 gap-1.5",
  lg: "h-10 px-4 text-14 gap-2",
};

export function buttonClass(variant: ButtonVariant = "secondary", size: Size = "md", className?: string): string {
  return cx(
    "inline-flex items-center justify-center rounded-ctl border font-medium whitespace-nowrap select-none",
    "transition-colors duration-150 ease-out disabled:opacity-50 disabled:pointer-events-none cursor-pointer",
    VARIANT[variant],
    SIZE[size],
    className,
  );
}

interface Own {
  variant?: ButtonVariant;
  size?: Size;
  icon?: LucideIcon;
  kbd?: string;
  loading?: boolean;
  children?: ReactNode;
}

export function Button({ variant, size, icon: Icon, kbd, loading, className, children, disabled, type = "button", ...rest }: Own & ComponentProps<"button">) {
  return (
    <button type={type} className={buttonClass(variant, size, className)} disabled={disabled || loading} aria-busy={loading || undefined} {...rest}>
      {Icon && <Icon size={size === "lg" ? 18 : 16} strokeWidth={1.5} aria-hidden />}
      {children}
      {loading && <span className="num text-11 opacity-70">…</span>}
      {kbd && <Kbd className={variant === "primary" ? "border-paper/40 text-paper" : undefined}>{kbd}</Kbd>}
    </button>
  );
}

export function ButtonLink({ variant, size, icon: Icon, kbd, className, children, ...rest }: Own & LinkProps) {
  return (
    <Link className={buttonClass(variant, size, className)} {...rest}>
      {Icon && <Icon size={16} strokeWidth={1.5} aria-hidden />}
      {children}
      {kbd && <Kbd>{kbd}</Kbd>}
    </Link>
  );
}

export function IconButton({ icon: Icon, label, className, size = 32, ...rest }: { icon: LucideIcon; label: string; size?: number } & ComponentProps<"button">) {
  return (
    <button
      type="button"
      aria-label={label}
      title={label}
      className={cx(
        "inline-flex items-center justify-center rounded-ctl text-ink-2 hover:bg-surface-2 hover:text-ink transition-colors duration-150 cursor-pointer disabled:opacity-40",
        className,
      )}
      style={{ width: size, height: size }}
      {...rest}
    >
      <Icon size={16} strokeWidth={1.5} aria-hidden />
    </button>
  );
}
