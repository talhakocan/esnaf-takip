import { ChevronDown } from "lucide-react";
import { type ComponentProps, type ReactNode, useId } from "react";
import { cx } from "./cx";

const CONTROL =
  "w-full rounded-ctl border border-rule-strong bg-surface text-13 text-ink placeholder:text-ink-3 " +
  "focus-visible:outline-2 focus-visible:outline-signal focus-visible:outline-offset-1 disabled:opacity-60 aria-[invalid=true]:border-crit";

export function Input({ className, mono, align, invalid, ...rest }: ComponentProps<"input"> & { mono?: boolean; align?: "left" | "right"; invalid?: boolean }) {
  return (
    <input
      className={cx(CONTROL, "h-8 px-2.5", mono && "font-mono tabular-nums", align === "right" && "text-right", className)}
      aria-invalid={invalid || undefined}
      {...rest}
    />
  );
}

export function Textarea({ className, invalid, ...rest }: ComponentProps<"textarea"> & { invalid?: boolean }) {
  return <textarea className={cx(CONTROL, "px-2.5 py-1.5 min-h-20 resize-y", className)} aria-invalid={invalid || undefined} {...rest} />;
}

export function Select({ className, children, invalid, ...rest }: ComponentProps<"select"> & { invalid?: boolean }) {
  return (
    <div className={cx("relative", className)}>
      <select className={cx(CONTROL, "h-8 pl-2.5 pr-7 appearance-none cursor-pointer")} aria-invalid={invalid || undefined} {...rest}>
        {children}
      </select>
      <ChevronDown size={14} strokeWidth={1.5} className="pointer-events-none absolute right-2 top-1/2 -translate-y-1/2 text-ink-3" aria-hidden />
    </div>
  );
}

export function Checkbox({ label, className, ...rest }: ComponentProps<"input"> & { label: ReactNode }) {
  return (
    <label className={cx("inline-flex items-center gap-2 text-13 cursor-pointer select-none", className)}>
      <input type="checkbox" className="size-3.5 cursor-pointer accent-[var(--ink)]" {...rest} />
      <span>{label}</span>
    </label>
  );
}

export function Radio({ label, className, ...rest }: ComponentProps<"input"> & { label: ReactNode }) {
  return (
    <label className={cx("inline-flex items-center gap-2 text-13 cursor-pointer select-none", className)}>
      <input type="radio" className="size-3.5 cursor-pointer accent-[var(--ink)]" {...rest} />
      <span>{label}</span>
    </label>
  );
}

/** Etiket + kontrol + hata/ipucu. Kontrol, render prop ile id alır. */
export function Field({
  label,
  error,
  hint,
  className,
  children,
  required,
}: {
  label: ReactNode;
  error?: string;
  hint?: ReactNode;
  className?: string;
  required?: boolean;
  children: (id: string) => ReactNode;
}) {
  const id = useId();
  return (
    <div className={cx("flex flex-col gap-1", className)}>
      <label htmlFor={id} className="text-12 text-ink-2">
        {label}
        {required && <span className="text-crit" aria-hidden> *</span>}
      </label>
      {children(id)}
      {error ? (
        <span className="text-12 text-crit" role="alert">
          {error}
        </span>
      ) : hint ? (
        <span className="text-12 text-ink-3">{hint}</span>
      ) : null}
    </div>
  );
}
