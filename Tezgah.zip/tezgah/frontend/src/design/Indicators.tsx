import type { ReactNode } from "react";
import { money, qty as fmtQty, type UnitType } from "@/lib/format";
import type { Tone } from "@/lib/labels";
import type { StockStatus } from "@/lib/types";
import { cx } from "./cx";

const TONE_VAR: Record<Tone, string> = {
  ok: "var(--ok)",
  warn: "var(--warn)",
  crit: "var(--crit)",
  info: "var(--info)",
  neutral: "var(--ink-3)",
  signal: "var(--signal)",
};

/** 8×8 kare durum ışığı + metin (pill rozet yerine). */
export function Led({ tone = "neutral", children, className, title }: { tone?: Tone; children?: ReactNode; className?: string; title?: string }) {
  return (
    <span className={cx("inline-flex items-center gap-1.5 whitespace-nowrap", className)} title={title}>
      <span
        aria-hidden
        className="inline-block size-2 shrink-0"
        style={{ background: TONE_VAR[tone], boxShadow: "inset 0 0 0 1px rgba(0,0,0,.28)" }}
      />
      {children !== undefined && <span className="text-13">{children}</span>}
    </span>
  );
}

/** Çerçeveli mono etiket (kategori, birim vb.). */
export function Tag({ children, className, tone }: { children: ReactNode; className?: string; tone?: Tone }) {
  return (
    <span
      className={cx("inline-flex items-center h-5 px-1.5 border rounded-ctl font-mono text-11 whitespace-nowrap", className)}
      style={tone ? { borderColor: TONE_VAR[tone], color: TONE_VAR[tone] } : { borderColor: "var(--rule-strong)", color: "var(--ink-2)" }}
    >
      {children}
    </span>
  );
}

const STOCK_TONE: Record<StockStatus, Tone> = { out: "crit", critical: "crit", warn: "warn", ok: "ok", service: "neutral" };

/** 5 segmentli pil göstergesi + mono miktar. */
export function StockMeter({
  qty,
  min,
  unit,
  status,
  compact,
}: {
  qty: number;
  min: number;
  unit: UnitType;
  status: StockStatus;
  compact?: boolean;
}) {
  if (unit === "SERVICE") return <span className="num text-ink-3">—</span>;
  const scale = Math.max(min * 3, unit === "METER" ? 50 : 5);
  const filled = qty <= 0 ? 0 : Math.min(5, Math.max(1, Math.round((qty / scale) * 5)));
  const color = TONE_VAR[STOCK_TONE[status]];
  return (
    <span className="inline-flex items-center gap-2 justify-end" title={`Min. stok: ${fmtQty(min, unit)}`}>
      <span className="inline-flex gap-[2px]" aria-hidden>
        {Array.from({ length: 5 }, (_, i) => (
          <span
            key={i}
            className="inline-block w-[5px] h-3"
            style={i < filled ? { background: color } : { boxShadow: "inset 0 0 0 1px var(--rule-strong)" }}
          />
        ))}
      </span>
      {!compact && <span className={cx("num text-13 min-w-[64px] text-right", qty <= 0 && "text-crit")}>{fmtQty(qty, unit)}</span>}
    </span>
  );
}

/** Para: mono, sağa hizalı; negatif değerler kırmızı ve eksi işaretli. */
export function Money({ value, className, strong, plusSign }: { value: number | null | undefined; className?: string; strong?: boolean; plusSign?: boolean }) {
  const neg = typeof value === "number" && value < 0;
  return <span className={cx("num whitespace-nowrap", neg && "text-crit", strong && "font-semibold", className)}>{money(value, { plusSign })}</span>;
}

export function Qty({ value, unit, className }: { value: number | null | undefined; unit: UnitType; className?: string }) {
  const neg = typeof value === "number" && value < 0;
  return <span className={cx("num whitespace-nowrap", neg && "text-crit", className)}>{fmtQty(value, unit)}</span>;
}

/** Fark göstergesi (düne göre). */
export function Delta({ value, format }: { value: number; format: (v: number) => string }) {
  if (value === 0) return <span className="num text-12 text-ink-3">= düne göre</span>;
  const up = value > 0;
  return (
    <span className={cx("num text-12", up ? "text-ok" : "text-crit")}>
      {up ? "▲" : "▼"} {format(Math.abs(value))} düne göre
    </span>
  );
}
