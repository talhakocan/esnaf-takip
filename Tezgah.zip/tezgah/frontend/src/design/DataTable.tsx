import {
  type ColumnDef,
  flexRender,
  getCoreRowModel,
  getPaginationRowModel,
  getSortedRowModel,
  type RowData,
  type RowSelectionState,
  type SortingState,
  useReactTable,
  type VisibilityState,
} from "@tanstack/react-table";
import { ArrowDown, ArrowUp, ChevronLeft, ChevronRight, Columns3, Download, Rows3 } from "lucide-react";
import { type ReactNode, useEffect, useMemo, useState } from "react";
import { num } from "@/lib/format";
import { readStore, writeStore } from "@/lib/storage";
import { Button, IconButton } from "./Button";
import { cx } from "./cx";
import { Menu, MenuCheck, MenuContent, MenuItem, MenuLabel, MenuSeparator, MenuTrigger } from "./Menu";

declare module "@tanstack/react-table" {
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  interface ColumnMeta<TData extends RowData, TValue> {
    align?: "left" | "right" | "center";
    mono?: boolean;
    className?: string;
    /** CSV dışa aktarımında kullanılacak değer */
    exportValue?: (row: TData) => string | number | null | undefined;
    /** Sütun gizle/göster menüsünde gösterilmesin */
    fixed?: boolean;
  }
}

export type { ColumnDef };

interface Props<T> {
  data: T[];
  columns: ColumnDef<T, any>[];
  getRowId?: (row: T) => string;
  onRowClick?: (row: T) => void;
  initialSort?: SortingState;
  pageSize?: number;
  toolbar?: ReactNode;
  exportName?: string;
  onExportXlsx?: () => void;
  empty?: ReactNode;
  selectable?: boolean;
  selection?: RowSelectionState;
  onSelectionChange?: (s: RowSelectionState) => void;
  activeRowId?: string | null;
  storageKey?: string;
  hideFooter?: boolean;
  className?: string;
  maxHeight?: string;
  rowClassName?: (row: T) => string | undefined;
}

function csvEscape(v: unknown): string {
  const s = v === null || v === undefined ? "" : String(v);
  return /[";\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}

export function DataTable<T>({
  data,
  columns,
  getRowId,
  onRowClick,
  initialSort = [],
  pageSize = 50,
  toolbar,
  exportName,
  onExportXlsx,
  empty,
  selectable,
  selection,
  onSelectionChange,
  activeRowId,
  storageKey,
  hideFooter,
  className,
  maxHeight = "calc(100vh - 250px)",
  rowClassName,
}: Props<T>) {
  const [sorting, setSorting] = useState<SortingState>(initialSort);
  const [visibility, setVisibility] = useState<VisibilityState>(() => (storageKey ? readStore(`tezgah.cols.${storageKey}`, {}) : {}));
  const [internalSel, setInternalSel] = useState<RowSelectionState>({});
  const [pagination, setPagination] = useState({ pageIndex: 0, pageSize });
  const [dense, setDense] = useState(() => readStore<string>("tezgah.density", "normal") === "compact");
  const rowSelection = selection ?? internalSel;

  useEffect(() => {
    if (storageKey) writeStore(`tezgah.cols.${storageKey}`, visibility);
  }, [visibility, storageKey]);
  useEffect(() => setPagination((p) => ({ ...p, pageIndex: 0 })), [data]);

  const allColumns = useMemo<ColumnDef<T, any>[]>(() => {
    if (!selectable) return columns;
    const sel: ColumnDef<T, any> = {
      id: "_select",
      enableSorting: false,
      meta: { fixed: true, className: "w-8" },
      header: ({ table }) => (
        <input
          type="checkbox"
          aria-label="Tümünü seç"
          className="size-3.5 accent-[var(--ink)] cursor-pointer align-middle"
          checked={table.getIsAllRowsSelected()}
          ref={(el) => {
            if (el) el.indeterminate = table.getIsSomeRowsSelected();
          }}
          onChange={table.getToggleAllRowsSelectedHandler()}
        />
      ),
      cell: ({ row }) => (
        <input
          type="checkbox"
          aria-label="Satırı seç"
          className="size-3.5 accent-[var(--ink)] cursor-pointer align-middle"
          checked={row.getIsSelected()}
          onClick={(e) => e.stopPropagation()}
          onChange={row.getToggleSelectedHandler()}
        />
      ),
    };
    return [sel, ...columns];
  }, [columns, selectable]);

  const table = useReactTable({
    data,
    columns: allColumns,
    state: { sorting, columnVisibility: visibility, rowSelection, pagination },
    getRowId: getRowId ? (r) => getRowId(r) : undefined,
    onSortingChange: setSorting,
    onColumnVisibilityChange: setVisibility,
    onRowSelectionChange: (updater) => {
      const next = typeof updater === "function" ? updater(rowSelection) : updater;
      if (onSelectionChange) onSelectionChange(next);
      else setInternalSel(next);
    },
    onPaginationChange: setPagination,
    enableRowSelection: !!selectable,
    getCoreRowModel: getCoreRowModel(),
    getSortedRowModel: getSortedRowModel(),
    getPaginationRowModel: getPaginationRowModel(),
    defaultColumn: {
      cell: (info) => {
        const v = info.getValue();
        return v === null || v === undefined || v === "" ? <span className="text-ink-3">—</span> : String(v);
      },
    },
  });

  const exportCsv = () => {
    const cols = table.getVisibleLeafColumns().filter((c) => c.id !== "_select" && c.id !== "_actions");
    const header = cols.map((c) => csvEscape(typeof c.columnDef.header === "string" ? c.columnDef.header : c.id)).join(";");
    const lines = table.getSortedRowModel().rows.map((r) =>
      cols
        .map((c) => {
          const meta = c.columnDef.meta;
          const v = meta?.exportValue ? meta.exportValue(r.original) : r.getValue(c.id);
          return csvEscape(typeof v === "number" ? String(v).replace(".", ",") : v);
        })
        .join(";"),
    );
    const blob = new Blob(["﻿" + [header, ...lines].join("\r\n")], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${exportName ?? "tezgah"}.csv`;
    a.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  };

  const toggleDensity = () => {
    const next = !dense;
    setDense(next);
    writeStore("tezgah.density", next ? "compact" : "normal");
    document.documentElement.toggleAttribute("data-density", false);
    if (next) document.documentElement.setAttribute("data-density", "compact");
  };

  const total = data.length;
  const { pageIndex, pageSize: size } = table.getState().pagination;
  const from = total === 0 ? 0 : pageIndex * size + 1;
  const to = Math.min(total, (pageIndex + 1) * size);
  const hideable = table.getAllLeafColumns().filter((c) => !c.columnDef.meta?.fixed && c.id !== "_select" && c.id !== "_actions");

  return (
    <div className={cx("bg-surface border-y border-rule flex flex-col min-w-0", className)}>
      <div className="flex flex-wrap items-center gap-2 px-4 md:px-6 py-2 border-b border-rule">
        <div className="flex flex-wrap items-center gap-2 flex-1 min-w-0">{toolbar}</div>
        <div className="flex items-center gap-1">
          <Menu>
            <MenuTrigger asChild>
              <IconButton icon={Columns3} label="Sütunlar" />
            </MenuTrigger>
            <MenuContent>
              <MenuLabel>Sütunlar</MenuLabel>
              {hideable.map((c) => (
                <MenuCheck key={c.id} checked={c.getIsVisible()} onCheckedChange={(v) => c.toggleVisibility(v)}>
                  {typeof c.columnDef.header === "string" ? c.columnDef.header : c.id}
                </MenuCheck>
              ))}
            </MenuContent>
          </Menu>
          <IconButton icon={Rows3} label={dense ? "Normal satır yüksekliği" : "Sıkı mod"} onClick={toggleDensity} aria-pressed={dense} />
          {(exportName || onExportXlsx) && (
            <Menu>
              <MenuTrigger asChild>
                <IconButton icon={Download} label="Dışa aktar" />
              </MenuTrigger>
              <MenuContent>
                <MenuLabel>Dışa aktar</MenuLabel>
                {exportName && <MenuItem onSelect={exportCsv}>CSV (Excel uyumlu)</MenuItem>}
                {onExportXlsx && (
                  <>
                    <MenuSeparator />
                    <MenuItem onSelect={onExportXlsx}>Excel (.xlsx)</MenuItem>
                  </>
                )}
              </MenuContent>
            </Menu>
          )}
        </div>
      </div>

      <div className="overflow-auto scroll-thin" style={{ maxHeight }}>
        <table className="w-full text-13">
          <thead className="sticky top-0 z-10 bg-surface">
            {table.getHeaderGroups().map((hg) => (
              <tr key={hg.id}>
                {hg.headers.map((h) => {
                  const meta = h.column.columnDef.meta;
                  const sort = h.column.getIsSorted();
                  const canSort = h.column.getCanSort();
                  return (
                    <th
                      key={h.id}
                      scope="col"
                      aria-sort={sort === "asc" ? "ascending" : sort === "desc" ? "descending" : undefined}
                      className={cx(
                        "h-8 px-3 font-cond text-11 font-medium uppercase tracking-[.06em] text-ink-3 whitespace-nowrap",
                        "border-b border-rule-strong first:pl-4 md:first:pl-6 last:pr-4 md:last:pr-6",
                        meta?.align === "right" ? "text-right" : meta?.align === "center" ? "text-center" : "text-left",
                        meta?.className,
                      )}
                      lang="tr"
                    >
                      {h.isPlaceholder ? null : canSort ? (
                        <button
                          type="button"
                          onClick={h.column.getToggleSortingHandler()}
                          className={cx("inline-flex items-center gap-1 uppercase cursor-pointer hover:text-ink", meta?.align === "right" && "flex-row-reverse")}
                        >
                          {flexRender(h.column.columnDef.header, h.getContext())}
                          {sort === "asc" ? <ArrowUp size={12} /> : sort === "desc" ? <ArrowDown size={12} /> : null}
                        </button>
                      ) : (
                        flexRender(h.column.columnDef.header, h.getContext())
                      )}
                    </th>
                  );
                })}
              </tr>
            ))}
          </thead>
          <tbody>
            {table.getRowModel().rows.map((row) => {
              const active = activeRowId !== undefined && activeRowId !== null && row.id === activeRowId;
              return (
                <tr
                  key={row.id}
                  onClick={onRowClick ? () => onRowClick(row.original) : undefined}
                  onKeyDown={onRowClick ? (e) => e.key === "Enter" && onRowClick(row.original) : undefined}
                  tabIndex={onRowClick ? 0 : undefined}
                  className={cx(
                    "border-b border-rule hover:bg-surface-2",
                    onRowClick && "cursor-pointer focus-visible:outline-offset-[-2px]",
                    (active || row.getIsSelected()) && "bg-surface-2 shadow-[inset_2px_0_0_var(--signal)]",
                    rowClassName?.(row.original),
                  )}
                  style={{ height: "var(--row-h)" }}
                  aria-selected={row.getIsSelected() || active || undefined}
                >
                  {row.getVisibleCells().map((cell) => {
                    const meta = cell.column.columnDef.meta;
                    return (
                      <td
                        key={cell.id}
                        className={cx(
                          "px-3 first:pl-4 md:first:pl-6 last:pr-4 md:last:pr-6 py-1 align-middle",
                          meta?.align === "right" && "text-right",
                          meta?.align === "center" && "text-center",
                          meta?.mono && "num",
                          meta?.className,
                        )}
                      >
                        {flexRender(cell.column.columnDef.cell, cell.getContext())}
                      </td>
                    );
                  })}
                </tr>
              );
            })}
          </tbody>
        </table>
        {total === 0 && (empty ?? <p className="px-6 py-8 text-13 text-ink-2">Kayıt yok.</p>)}
      </div>

      {!hideFooter && total > 0 && (
        <div className="flex flex-wrap items-center justify-between gap-2 px-4 md:px-6 h-10 border-t border-rule text-12 text-ink-2">
          <span className="num">
            {num(from)}–{num(to)} / {num(total)}
            {selectable && Object.keys(rowSelection).length > 0 && <span className="ml-3 text-ink">· {Object.keys(rowSelection).length} seçili</span>}
          </span>
          <div className="flex items-center gap-2">
            <label className="flex items-center gap-1.5">
              <span>Sayfa başına</span>
              <select
                className="h-7 border border-rule-strong bg-surface rounded-ctl px-1 num text-12 cursor-pointer"
                value={size}
                onChange={(e) => table.setPageSize(Number(e.target.value))}
              >
                {[50, 100, 200].map((n) => (
                  <option key={n} value={n}>
                    {n}
                  </option>
                ))}
              </select>
            </label>
            <Button size="sm" variant="ghost" icon={ChevronLeft} onClick={() => table.previousPage()} disabled={!table.getCanPreviousPage()} aria-label="Önceki sayfa" />
            <span className="num">
              {pageIndex + 1}/{Math.max(1, table.getPageCount())}
            </span>
            <Button size="sm" variant="ghost" icon={ChevronRight} onClick={() => table.nextPage()} disabled={!table.getCanNextPage()} aria-label="Sonraki sayfa" />
          </div>
        </div>
      )}
    </div>
  );
}
