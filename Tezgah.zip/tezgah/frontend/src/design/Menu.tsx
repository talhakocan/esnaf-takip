import * as DM from "@radix-ui/react-dropdown-menu";
import * as RP from "@radix-ui/react-popover";
import * as TT from "@radix-ui/react-tooltip";
import { Check } from "lucide-react";
import type { ReactNode } from "react";
import { cx } from "./cx";

const CONTENT = "z-50 min-w-44 bg-surface border border-rule shadow-pop rounded-dlg py-1 anim-in";
const ITEM =
  "flex items-center gap-2 h-8 px-3 text-13 text-ink cursor-pointer select-none outline-none data-[highlighted]:bg-surface-2 data-[disabled]:opacity-50";

export const Menu = DM.Root;
export const MenuTrigger = DM.Trigger;

export function MenuContent({ children, align = "end" }: { children: ReactNode; align?: "start" | "end" | "center" }) {
  return (
    <DM.Portal>
      <DM.Content align={align} sideOffset={4} className={CONTENT}>
        {children}
      </DM.Content>
    </DM.Portal>
  );
}

export function MenuItem({ children, onSelect, danger, disabled }: { children: ReactNode; onSelect?: () => void; danger?: boolean; disabled?: boolean }) {
  return (
    <DM.Item className={cx(ITEM, danger && "text-crit")} onSelect={onSelect} disabled={disabled}>
      {children}
    </DM.Item>
  );
}

export function MenuCheck({ children, checked, onCheckedChange }: { children: ReactNode; checked: boolean; onCheckedChange: (v: boolean) => void }) {
  return (
    <DM.CheckboxItem className={ITEM} checked={checked} onCheckedChange={onCheckedChange} onSelect={(e) => e.preventDefault()}>
      <span className="inline-flex w-4 justify-center">
        <DM.ItemIndicator>
          <Check size={14} strokeWidth={1.5} />
        </DM.ItemIndicator>
      </span>
      {children}
    </DM.CheckboxItem>
  );
}

export function MenuLabel({ children }: { children: ReactNode }) {
  return <DM.Label className="label-caps px-3 pt-2 pb-1">{children}</DM.Label>;
}

export function MenuSeparator() {
  return <DM.Separator className="h-px bg-rule my-1" />;
}

export function Popover({ trigger, children, align = "start", className }: { trigger: ReactNode; children: ReactNode; align?: "start" | "end"; className?: string }) {
  return (
    <RP.Root>
      <RP.Trigger asChild>{trigger}</RP.Trigger>
      <RP.Portal>
        <RP.Content align={align} sideOffset={4} className={cx("z-50 bg-surface border border-rule shadow-pop rounded-dlg anim-in", className)}>
          {children}
        </RP.Content>
      </RP.Portal>
    </RP.Root>
  );
}

export function Tooltip({ label, children }: { label: ReactNode; children: ReactNode }) {
  return (
    <TT.Root delayDuration={300}>
      <TT.Trigger asChild>{children}</TT.Trigger>
      <TT.Portal>
        <TT.Content sideOffset={4} className="z-50 bg-ink text-paper text-12 px-2 py-1 rounded-ctl anim-fade">
          {label}
        </TT.Content>
      </TT.Portal>
    </TT.Root>
  );
}

export const TooltipProvider = TT.Provider;
