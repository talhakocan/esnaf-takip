import * as RD from "@radix-ui/react-dialog";
import { X } from "lucide-react";
import { createContext, type ReactNode, useCallback, useContext, useRef, useState } from "react";
import { Button } from "./Button";
import { cx } from "./cx";
import { Field, Input } from "./Input";

export function Dialog({
  open,
  onOpenChange,
  title,
  description,
  children,
  footer,
  width = 520,
  className,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  title: ReactNode;
  description?: ReactNode;
  children?: ReactNode;
  footer?: ReactNode;
  width?: number;
  className?: string;
}) {
  return (
    <RD.Root open={open} onOpenChange={onOpenChange}>
      <RD.Portal>
        <RD.Overlay className="fixed inset-0 z-40 bg-scrim anim-fade" />
        <RD.Content
          className={cx(
            "fixed z-50 left-1/2 top-[8vh] -translate-x-1/2 w-[calc(100vw-32px)] max-h-[84vh] flex flex-col",
            "bg-surface border border-rule rounded-dlg shadow-pop anim-in focus:outline-none",
            className,
          )}
          style={{ maxWidth: width }}
          aria-describedby={description ? undefined : undefined}
        >
          <div className="flex items-start justify-between gap-4 px-5 pt-4 pb-3 border-b border-rule">
            <div>
              <RD.Title className="font-cond text-16 font-semibold">{title}</RD.Title>
              {description ? (
                <RD.Description className="text-13 text-ink-2 mt-0.5">{description}</RD.Description>
              ) : (
                <RD.Description className="sr-only">{typeof title === "string" ? title : "İletişim kutusu"}</RD.Description>
              )}
            </div>
            <RD.Close className="p-1 -mr-1 rounded-ctl text-ink-3 hover:text-ink hover:bg-surface-2 cursor-pointer" aria-label="Kapat">
              <X size={16} strokeWidth={1.5} />
            </RD.Close>
          </div>
          <div className="px-5 py-4 overflow-y-auto scroll-thin">{children}</div>
          {footer && <div className="flex items-center justify-end gap-2 px-5 py-3 border-t border-rule">{footer}</div>}
        </RD.Content>
      </RD.Portal>
    </RD.Root>
  );
}

/* ---------------------------------------------------------------- onay dialog'u */

interface ConfirmOptions {
  title: string;
  message?: ReactNode;
  confirmLabel?: string;
  danger?: boolean;
  requireText?: string;
}

type ConfirmFn = (opts: ConfirmOptions) => Promise<boolean>;
const ConfirmCtx = createContext<ConfirmFn>(async () => false);

export function ConfirmProvider({ children }: { children: ReactNode }) {
  const [opts, setOpts] = useState<ConfirmOptions | null>(null);
  const [typed, setTyped] = useState("");
  const resolver = useRef<((v: boolean) => void) | null>(null);
  const confirm = useCallback<ConfirmFn>((o) => {
    setOpts(o);
    setTyped("");
    return new Promise<boolean>((resolve) => {
      resolver.current = resolve;
    });
  }, []);
  const close = (v: boolean) => {
    resolver.current?.(v);
    resolver.current = null;
    setOpts(null);
  };
  const blocked = !!opts?.requireText && typed.trim().toLocaleUpperCase("tr-TR") !== opts.requireText.toLocaleUpperCase("tr-TR");
  return (
    <ConfirmCtx.Provider value={confirm}>
      {children}
      <Dialog
        open={!!opts}
        onOpenChange={(o) => !o && close(false)}
        title={opts?.title ?? ""}
        width={440}
        footer={
          <>
            <Button variant="ghost" onClick={() => close(false)}>
              Vazgeç
            </Button>
            <Button variant={opts?.danger ? "danger" : "primary"} onClick={() => close(true)} disabled={blocked} autoFocus={!opts?.requireText}>
              {opts?.confirmLabel ?? "Onayla"}
            </Button>
          </>
        }
      >
        {opts?.message && <div className="text-14 text-ink-2">{opts.message}</div>}
        {opts?.requireText && (
          <Field label={`Onaylamak için "${opts.requireText}" yazın`} className="mt-3">
            {(id) => <Input id={id} value={typed} onChange={(e) => setTyped(e.target.value)} autoFocus />}
          </Field>
        )}
      </Dialog>
    </ConfirmCtx.Provider>
  );
}

export function useConfirm(): ConfirmFn {
  return useContext(ConfirmCtx);
}
