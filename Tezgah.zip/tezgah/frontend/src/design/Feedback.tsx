import type { ReactNode } from "react";
import { errorMessage } from "@/lib/api";
import { Button } from "./Button";
import { cx } from "./cx";

export type Schematic = "resistor" | "connector" | "circuit" | "ground" | "switch";

/** Şema tarzı tek renkli küçük çizimler (1.5px çizgi). */
export function SchematicIcon({ kind, className }: { kind: Schematic; className?: string }) {
  const common = { fill: "none", stroke: "currentColor", strokeWidth: 1.5, strokeLinecap: "square" as const, strokeLinejoin: "miter" as const };
  return (
    <svg viewBox="0 0 120 40" width="120" height="40" className={className} aria-hidden>
      {kind === "resistor" && <path {...common} d="M4 20 H34 L38 12 L46 28 L54 12 L62 28 L70 12 L78 28 L82 20 H116" />}
      {kind === "connector" && (
        <g {...common}>
          <path d="M4 20 H40" />
          <rect x="40" y="10" width="16" height="20" />
          <path d="M56 15 H64 M56 25 H64" />
          <path d="M76 15 H84 M76 25 H84" />
          <rect x="84" y="10" width="16" height="20" />
          <path d="M100 20 H116" />
        </g>
      )}
      {kind === "circuit" && (
        <g {...common}>
          <path d="M4 30 H24 V10 H56 V30 H80 V16 H116" />
          <circle cx="24" cy="30" r="2.5" />
          <circle cx="56" cy="10" r="2.5" />
          <circle cx="80" cy="16" r="2.5" />
        </g>
      )}
      {kind === "ground" && (
        <g {...common}>
          <path d="M4 8 H60 V22" />
          <path d="M46 22 H74 M51 28 H69 M56 34 H64" />
        </g>
      )}
      {kind === "switch" && (
        <g {...common}>
          <path d="M4 24 H40" />
          <circle cx="42" cy="24" r="2.5" />
          <path d="M44 23 L74 10" />
          <circle cx="78" cy="24" r="2.5" />
          <path d="M80 24 H116" />
        </g>
      )}
    </svg>
  );
}

export function EmptyState({
  icon = "circuit",
  title,
  action,
  className,
}: {
  icon?: Schematic;
  title: ReactNode;
  action?: ReactNode;
  className?: string;
}) {
  return (
    <div className={cx("flex flex-col items-start gap-3 px-5 py-8", className)}>
      <SchematicIcon kind={icon} className="text-ink-3" />
      <p className="text-14 text-ink-2 max-w-[48ch]">{title}</p>
      {action}
    </div>
  );
}

export function Loading({ label = "Yükleniyor", className }: { label?: string; className?: string }) {
  return (
    <div className={cx("px-5 py-6", className)} role="status">
      <div className="h-px w-40 bg-rule overflow-hidden relative">
        <div className="absolute inset-y-0 w-10 bg-ink-3 animate-[tz-slide_1s_ease-in-out_infinite]" />
      </div>
      <p className="num text-12 text-ink-3 mt-2">{label}…</p>
      <style>{"@keyframes tz-slide{0%{left:-40px}100%{left:160px}}"}</style>
    </div>
  );
}

export function ErrorState({ error, onRetry, className }: { error: unknown; onRetry?: () => void; className?: string }) {
  return (
    <div className={cx("px-5 py-6 flex flex-col items-start gap-3", className)} role="alert">
      <SchematicIcon kind="switch" className="text-crit" />
      <p className="text-14 text-ink">{errorMessage(error)}</p>
      {onRetry && (
        <Button size="sm" onClick={onRetry}>
          Tekrar dene
        </Button>
      )}
    </div>
  );
}
