import { X } from "lucide-react";
import { createContext, type ReactNode, useCallback, useContext, useRef, useState } from "react";
import { timeOnly } from "@/lib/format";
import type { Tone } from "@/lib/labels";

interface ToastItem {
  id: number;
  tone: Tone;
  title: string;
  message?: string;
  at: Date;
}

type ToastFn = (t: { tone?: Tone; title: string; message?: string }) => void;
const ToastCtx = createContext<ToastFn>(() => undefined);

const COLOR: Record<Tone, string> = {
  ok: "var(--ok)",
  warn: "var(--warn)",
  crit: "var(--crit)",
  info: "var(--info)",
  neutral: "var(--ink-3)",
  signal: "var(--signal)",
};

export function ToastProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<ToastItem[]>([]);
  const seq = useRef(1);
  const dismiss = (id: number) => setItems((xs) => xs.filter((x) => x.id !== id));
  const toast = useCallback<ToastFn>(({ tone = "ok", title, message }) => {
    const id = seq.current++;
    setItems((xs) => [...xs.slice(-3), { id, tone, title, message, at: new Date() }]);
    window.setTimeout(() => dismiss(id), tone === "crit" ? 6000 : 4000);
  }, []);
  return (
    <ToastCtx.Provider value={toast}>
      {children}
      <div className="fixed left-4 bottom-10 z-[60] flex flex-col gap-2 w-[min(380px,calc(100vw-32px))] print:hidden" role="status" aria-live="polite">
        {items.map((t) => (
          <div
            key={t.id}
            className="anim-in flex items-start gap-3 bg-surface border border-rule shadow-pop pl-3 pr-2 py-2"
            style={{ borderLeft: `3px solid ${COLOR[t.tone]}` }}
          >
            <div className="flex-1 min-w-0">
              <div className="text-13 font-medium">{t.title}</div>
              {t.message && <div className="text-12 text-ink-2 mt-0.5 break-words">{t.message}</div>}
            </div>
            <span className="num text-11 text-ink-3 pt-0.5">{timeOnly(t.at)}</span>
            <button className="text-ink-3 hover:text-ink p-0.5 cursor-pointer" onClick={() => dismiss(t.id)} aria-label="Bildirimi kapat">
              <X size={14} strokeWidth={1.5} />
            </button>
          </div>
        ))}
      </div>
    </ToastCtx.Provider>
  );
}

export function useToast(): ToastFn {
  return useContext(ToastCtx);
}
