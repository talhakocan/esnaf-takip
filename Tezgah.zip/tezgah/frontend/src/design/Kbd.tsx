import type { ReactNode } from "react";
import { cx } from "./cx";

/** Klavye kısayol ipucu (mono). */
export function Kbd({ children, className }: { children: ReactNode; className?: string }) {
  return (
    <kbd
      className={cx(
        "inline-flex items-center h-4 px-1 rounded-ctl border border-rule-strong font-mono text-11 leading-none text-ink-3 font-normal",
        className,
      )}
    >
      {children}
    </kbd>
  );
}
