import * as RT from "@radix-ui/react-tabs";
import type { ReactNode } from "react";
import { num } from "@/lib/format";
import { cx } from "./cx";

/** Sayfa başlığı satırı: solda başlık + mono kayıt sayısı, sağda aksiyonlar. */
export function PageHeader({ title, count, actions, sub }: { title: ReactNode; count?: number; actions?: ReactNode; sub?: ReactNode }) {
  return (
    <div className="flex flex-wrap items-end justify-between gap-3 px-4 md:px-6 pt-5 pb-3">
      <div className="min-w-0">
        <h1 className="font-cond text-20 font-semibold flex items-baseline gap-3">
          <span className="truncate">{title}</span>
          {count !== undefined && <span className="num text-13 font-normal text-ink-3">{num(count)}</span>}
        </h1>
        {sub && <div className="text-13 text-ink-2 mt-0.5">{sub}</div>}
      </div>
      {actions && <div className="flex flex-wrap items-center gap-2">{actions}</div>}
    </div>
  );
}

export function FilterBar({ children, className }: { children: ReactNode; className?: string }) {
  return <div className={cx("flex flex-wrap items-center gap-2 px-4 md:px-6 py-2 border-y border-rule bg-surface", className)}>{children}</div>;
}

export function SectionLabel({ children, className, right }: { children: ReactNode; className?: string; right?: ReactNode }) {
  return (
    <div className={cx("flex items-center justify-between gap-2 px-4 h-9 border-b border-rule", className)}>
      <h2 className="label-caps" lang="tr">
        {children}
      </h2>
      {right}
    </div>
  );
}

/** Düz panel: 1px çizgi, gölge yok. */
export function Panel({ title, right, children, className, bodyClassName }: { title?: ReactNode; right?: ReactNode; children: ReactNode; className?: string; bodyClassName?: string }) {
  return (
    <section className={cx("bg-surface border border-rule", className)}>
      {title && <SectionLabel right={right}>{title}</SectionLabel>}
      <div className={bodyClassName}>{children}</div>
    </section>
  );
}

/** Anahtar-değer satırları (datasheet görünümü). */
export function KeyValues({ rows, className }: { rows: [ReactNode, ReactNode][]; className?: string }) {
  return (
    <dl className={cx("grid grid-cols-[minmax(110px,40%)_1fr] text-13", className)}>
      {rows.map(([k, v], i) => (
        <div key={i} className="contents">
          <dt className="px-4 py-1.5 text-ink-3 border-b border-rule">{k}</dt>
          <dd className="px-4 py-1.5 border-b border-rule min-w-0 break-words">{v ?? "—"}</dd>
        </div>
      ))}
    </dl>
  );
}

export function Tabs({
  value,
  onValueChange,
  tabs,
  className,
  children,
}: {
  value: string;
  onValueChange: (v: string) => void;
  tabs: { value: string; label: ReactNode; count?: number }[];
  className?: string;
  children: ReactNode;
}) {
  return (
    <RT.Root value={value} onValueChange={onValueChange} className={className}>
      <RT.List className="flex gap-1 border-b border-rule px-4 md:px-6 overflow-x-auto scroll-thin" aria-label="Sekmeler">
        {tabs.map((t) => (
          <RT.Trigger
            key={t.value}
            value={t.value}
            className={cx(
              "h-9 px-2 text-13 text-ink-2 border-b-2 border-transparent -mb-px whitespace-nowrap cursor-pointer",
              "hover:text-ink data-[state=active]:text-ink data-[state=active]:border-ink",
            )}
          >
            {t.label}
            {t.count !== undefined && <span className="num text-11 text-ink-3 ml-1.5">{t.count}</span>}
          </RT.Trigger>
        ))}
      </RT.List>
      {children}
    </RT.Root>
  );
}

export const TabPanel = RT.Content;

/** Dikey sekme listesi (raporlar, ayarlar). */
export function SideNav({ items, active, onSelect }: { items: { key: string; label: ReactNode; hidden?: boolean }[]; active: string; onSelect: (k: string) => void }) {
  return (
    <nav className="flex md:flex-col gap-0.5 overflow-x-auto scroll-thin" aria-label="Bölümler">
      {items
        .filter((i) => !i.hidden)
        .map((i) => (
          <button
            key={i.key}
            type="button"
            onClick={() => onSelect(i.key)}
            aria-current={active === i.key ? "page" : undefined}
            className={cx(
              "text-left h-8 px-3 text-13 whitespace-nowrap border-l-2 cursor-pointer",
              active === i.key ? "border-ink bg-surface-2 text-ink" : "border-transparent text-ink-2 hover:bg-surface-2 hover:text-ink",
            )}
          >
            {i.label}
          </button>
        ))}
    </nav>
  );
}
