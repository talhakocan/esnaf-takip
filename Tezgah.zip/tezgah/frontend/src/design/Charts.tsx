import type { ReactNode } from "react";
import { CartesianGrid, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { money, moneyShort, pct } from "@/lib/format";
import { cx } from "./cx";

const AXIS = { fontFamily: "var(--font-mono)", fontSize: 11, fill: "var(--ink-3)" };

function ChartTooltip({ active, payload, label, format }: { active?: boolean; payload?: any[]; label?: string; format: (v: number) => string }) {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-surface border border-rule shadow-pop px-2.5 py-1.5 num text-12">
      <div className="text-ink-3 mb-0.5">{label}</div>
      {payload.map((p) => (
        <div key={p.dataKey} className="flex items-center gap-2">
          <span className="inline-block size-2" style={{ background: p.color }} />
          <span className="text-ink-2">{p.name}</span>
          <span className="ml-auto text-ink">{format(Number(p.value))}</span>
        </div>
      ))}
    </div>
  );
}

export interface Series {
  key: string;
  label: string;
  accent?: boolean;
}

/** Çizgi grafik: 1.5px çizgi, ana seri mürekkep, vurgu sinyal; kesik ızgara; tek seride lejant yok. */
export function LineSeries({
  data,
  x,
  series,
  height = 220,
  kind = "money",
  step,
}: {
  data: Record<string, unknown>[];
  x: string;
  series: Series[];
  height?: number;
  kind?: "money" | "pct" | "number";
  step?: boolean;
}) {
  const fmt = kind === "money" ? (v: number) => money(v) : kind === "pct" ? (v: number) => pct(v) : (v: number) => String(v);
  const tick = kind === "money" ? (v: number) => moneyShort(v) : kind === "pct" ? (v: number) => `%${v}` : (v: number) => String(v);
  return (
    <div>
      {series.length > 1 && (
        <div className="flex gap-4 px-4 pt-2 text-12 text-ink-2">
          {series.map((s) => (
            <span key={s.key} className="inline-flex items-center gap-1.5">
              <span className="inline-block w-3 h-[1.5px]" style={{ background: s.accent ? "var(--signal)" : "var(--ink)" }} />
              {s.label}
            </span>
          ))}
        </div>
      )}
      <ResponsiveContainer width="100%" height={height}>
        <LineChart data={data} margin={{ top: 12, right: 16, left: 4, bottom: 0 }}>
          <CartesianGrid stroke="var(--rule)" strokeDasharray="3 3" vertical={false} />
          <XAxis dataKey={x} tick={AXIS} tickLine={false} axisLine={{ stroke: "var(--rule-strong)" }} minTickGap={24} />
          <YAxis tick={AXIS} tickLine={false} axisLine={false} tickFormatter={tick} width={64} />
          <Tooltip content={<ChartTooltip format={fmt} />} cursor={{ stroke: "var(--rule-strong)" }} />
          {series.map((s) => (
            <Line
              key={s.key}
              type={step ? "stepAfter" : "linear"}
              dataKey={s.key}
              name={s.label}
              stroke={s.accent ? "var(--signal)" : "var(--ink)"}
              strokeWidth={1.5}
              dot={false}
              activeDot={{ r: 3, strokeWidth: 0, fill: s.accent ? "var(--signal)" : "var(--ink)" }}
              isAnimationActive={false}
            />
          ))}
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}

/** Yatay çubuk listesi (pasta grafik yerine): değerler doğrudan etiketlenir. */
export function BarList({
  rows,
  format,
  className,
}: {
  rows: { label: ReactNode; value: number; sub?: ReactNode; accent?: boolean }[];
  format: (v: number) => string;
  className?: string;
}) {
  const max = Math.max(1, ...rows.map((r) => Math.abs(r.value)));
  return (
    <ul className={cx("flex flex-col gap-2 px-4 py-3", className)}>
      {rows.map((r, i) => (
        <li key={i} className="grid grid-cols-[minmax(90px,30%)_1fr_auto] items-center gap-3 text-13">
          <span className="truncate text-ink-2">{r.label}</span>
          <span className="h-2.5 bg-surface-2 relative">
            <span className="absolute inset-y-0 left-0" style={{ width: `${(Math.abs(r.value) / max) * 100}%`, background: r.accent ? "var(--signal)" : "var(--ink)" }} />
          </span>
          <span className="num text-12 text-right min-w-[90px]">
            {format(r.value)}
            {r.sub && <span className="text-ink-3 ml-1.5">{r.sub}</span>}
          </span>
        </li>
      ))}
    </ul>
  );
}
