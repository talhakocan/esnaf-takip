import { useId } from "react";

/** Topraklama şeridi: uygulamanın tek dekoratif öğesi (sarı-yeşil, 45°, 6px aralık). */
export function EarthStrip() {
  const id = useId().replace(/:/g, "");
  return (
    <svg className="block w-full h-[2px]" aria-hidden preserveAspectRatio="none">
      <defs>
        <pattern id={`earth-${id}`} width="12" height="12" patternUnits="userSpaceOnUse" patternTransform="rotate(45)">
          <rect width="6" height="12" style={{ fill: "var(--earth-a)" }} />
          <rect x="6" width="6" height="12" style={{ fill: "var(--earth-b)" }} />
        </pattern>
      </defs>
      <rect width="100%" height="2" fill={`url(#earth-${id})`} />
    </svg>
  );
}
