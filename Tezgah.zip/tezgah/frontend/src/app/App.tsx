import { QueryCache, QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { lazy, Suspense } from "react";
import { BrowserRouter, Navigate, Outlet, Route, Routes } from "react-router-dom";
import { ConfirmProvider } from "@/design/Dialog";
import { Loading } from "@/design/Feedback";
import { TooltipProvider } from "@/design/Menu";
import { ToastProvider } from "@/design/Toast";
import { ApiError } from "@/lib/api";
import { AuthProvider, RequireAuth, RequirePermission } from "./auth";
import { CrumbProvider } from "./crumbs";
import { Layout } from "./Layout";

const LoginPage = lazy(() => import("@/features/auth/LoginPage"));
const TrackPage = lazy(() => import("@/pages/public/TrackPage"));
const DashboardPage = lazy(() => import("@/features/dashboard/DashboardPage"));
const PosPage = lazy(() => import("@/features/pos/PosPage"));
const SalesPage = lazy(() => import("@/features/sales/SalesPage"));
const SaleDetailPage = lazy(() => import("@/features/sales/SaleDetailPage"));
const ProductsPage = lazy(() => import("@/features/products/ProductsPage"));
const ProductDetailPage = lazy(() => import("@/features/products/ProductDetailPage"));
const ProductFormPage = lazy(() => import("@/features/products/ProductFormPage"));
const BulkPricePage = lazy(() => import("@/features/products/BulkPricePage"));
const ImportPage = lazy(() => import("@/features/products/ImportPage"));
const LedgerPage = lazy(() => import("@/features/stock/LedgerPage"));
const StockEntryPage = lazy(() => import("@/features/stock/StockEntryPage"));
const ServiceListPage = lazy(() => import("@/features/service/ServiceListPage"));
const ServiceNewPage = lazy(() => import("@/features/service/ServiceNewPage"));
const ServiceDetailPage = lazy(() => import("@/features/service/ServiceDetailPage"));
const CustomersPage = lazy(() => import("@/features/customers/CustomersPage"));
const CustomerDetailPage = lazy(() => import("@/features/customers/CustomerDetailPage"));
const SuppliersPage = lazy(() => import("@/features/suppliers/SuppliersPage"));
const SupplierDetailPage = lazy(() => import("@/features/suppliers/SupplierDetailPage"));
const OrdersPage = lazy(() => import("@/features/purchasing/OrdersPage"));
const OrderFormPage = lazy(() => import("@/features/purchasing/OrderFormPage"));
const OrderDetailPage = lazy(() => import("@/features/purchasing/OrderDetailPage"));
const CountsPage = lazy(() => import("@/features/counts/CountsPage"));
const CountDetailPage = lazy(() => import("@/features/counts/CountDetailPage"));
const ReportsPage = lazy(() => import("@/features/reports/ReportsPage"));
const LabelsPage = lazy(() => import("@/features/labels/LabelsPage"));
const SettingsPage = lazy(() => import("@/features/settings/SettingsPage"));
const NotFound = lazy(() => import("@/features/NotFound"));

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 20_000,
      refetchOnWindowFocus: false,
      retry: (count, err) => !(err instanceof ApiError && err.status >= 400 && err.status < 500) && count < 1,
    },
  },
  queryCache: new QueryCache(),
});

function Authed() {
  return (
    <AuthProvider>
      <Outlet />
    </AuthProvider>
  );
}

export function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <BrowserRouter>
        <TooltipProvider>
          <ToastProvider>
            <ConfirmProvider>
              <CrumbProvider>
                <Suspense fallback={<Loading />}>
                  <Routes>
                    <Route path="/takip/:kod" element={<TrackPage />} />
                    <Route path="/takip" element={<TrackPage />} />
                    <Route element={<Authed />}>
                      <Route path="/giris" element={<LoginPage />} />
                      <Route
                        element={
                          <RequireAuth>
                            <Layout />
                          </RequireAuth>
                        }
                      >
                        <Route index element={<DashboardPage />} />
                        <Route path="satis" element={<PosPage />} />
                        <Route path="satislar" element={<SalesPage />} />
                        <Route path="satislar/:id" element={<SaleDetailPage />} />
                        <Route path="urunler" element={<ProductsPage />} />
                        <Route
                          path="urunler/yeni"
                          element={
                            <RequirePermission permission="product.write">
                              <ProductFormPage />
                            </RequirePermission>
                          }
                        />
                        <Route
                          path="urunler/toplu-fiyat"
                          element={
                            <RequirePermission permission="product.bulk_price">
                              <BulkPricePage />
                            </RequirePermission>
                          }
                        />
                        <Route
                          path="urunler/ice-aktar"
                          element={
                            <RequirePermission permission="product.import">
                              <ImportPage />
                            </RequirePermission>
                          }
                        />
                        <Route path="urunler/:id" element={<ProductDetailPage />} />
                        <Route
                          path="urunler/:id/duzenle"
                          element={
                            <RequirePermission permission="product.write">
                              <ProductFormPage />
                            </RequirePermission>
                          }
                        />
                        <Route path="stok" element={<LedgerPage />} />
                        <Route path="stok/giris" element={<StockEntryPage />} />
                        <Route path="servis" element={<ServiceListPage />} />
                        <Route path="servis/yeni" element={<ServiceNewPage />} />
                        <Route path="servis/:id" element={<ServiceDetailPage />} />
                        <Route path="cari" element={<CustomersPage />} />
                        <Route path="cari/:id" element={<CustomerDetailPage />} />
                        <Route path="tedarikciler" element={<SuppliersPage />} />
                        <Route path="tedarikciler/:id" element={<SupplierDetailPage />} />
                        <Route path="siparisler" element={<OrdersPage />} />
                        <Route
                          path="siparisler/yeni"
                          element={
                            <RequirePermission permission="purchase.write">
                              <OrderFormPage />
                            </RequirePermission>
                          }
                        />
                        <Route path="siparisler/:id" element={<OrderDetailPage />} />
                        <Route path="sayim" element={<CountsPage />} />
                        <Route path="sayim/:id" element={<CountDetailPage />} />
                        <Route path="raporlar" element={<Navigate to="/raporlar/satis" replace />} />
                        <Route path="raporlar/:rapor" element={<ReportsPage />} />
                        <Route path="etiket" element={<LabelsPage />} />
                        <Route path="ayarlar" element={<Navigate to="/ayarlar/dukkan" replace />} />
                        <Route path="ayarlar/:sekme" element={<SettingsPage />} />
                        <Route path="*" element={<NotFound />} />
                      </Route>
                    </Route>
                  </Routes>
                </Suspense>
              </CrumbProvider>
            </ConfirmProvider>
          </ToastProvider>
        </TooltipProvider>
      </BrowserRouter>
    </QueryClientProvider>
  );
}
