import { useQuery } from "@tanstack/react-query";
import { ChevronsLeft, ChevronsRight, Keyboard, LogOut, Menu as MenuIcon, Monitor, Moon, Search, Sun, UserRound, X } from "lucide-react";
import { Suspense, useEffect, useState } from "react";
import { Link, Outlet, useLocation, useNavigate } from "react-router-dom";
import { IconButton } from "@/design/Button";
import { cx } from "@/design/cx";
import { Dialog } from "@/design/Dialog";
import { Loading } from "@/design/Feedback";
import { Kbd } from "@/design/Kbd";
import { Menu, MenuContent, MenuItem, MenuLabel, MenuSeparator, MenuTrigger } from "@/design/Menu";
import { api } from "@/lib/api";
import { rate, timeOnly } from "@/lib/format";
import { GLOBAL_SHORTCUTS, POS_SHORTCUTS, useHotkeys } from "@/lib/shortcuts";
import { readStore, writeStore } from "@/lib/storage";
import type { StatusInfo } from "@/lib/types";
import { useAuth, useMe } from "./auth";
import { CommandPalette } from "./CommandPalette";
import { useCrumbValue } from "./crumbs";
import { CRUMB_ROOT, CRUMB_SUB, NAV } from "./nav";
import { PasswordDialog } from "./PasswordDialog";
import { THEME_LABEL, useTheme } from "./theme";

export const APP_VERSION = "1.0.0";

/** Topraklama şeridi: uygulamanın tek dekoratif öğesi (sarı-yeşil, 45°). */
function EarthStrip() {
  return (
    <svg className="block w-full h-[2px]" aria-hidden preserveAspectRatio="none">
      <defs>
        <pattern id="tz-earth" width="12" height="12" patternUnits="userSpaceOnUse" patternTransform="rotate(45)">
          <rect width="6" height="12" style={{ fill: "var(--earth-a)" }} />
          <rect x="6" width="6" height="12" style={{ fill: "var(--earth-b)" }} />
        </pattern>
      </defs>
      <rect width="100%" height="2" fill="url(#tz-earth)" />
    </svg>
  );
}

/** Ray menüsünde etkin öğe: alt sayfalar üst öğeyi etkin gösterir; "yeni/giriş" kısayol öğeleri tam eşleşir. */
function isNavActive(to: string, path: string): boolean {
  if (to === "/") return path === "/";
  if (to === "/servis/yeni" || to === "/stok/giris" || to === "/stok") return path === to;
  if (to === "/servis") return path.startsWith("/servis") && path !== "/servis/yeni";
  return path === to || path.startsWith(`${to}/`);
}

function Rail({ collapsed, onToggle, onNavigate }: { collapsed: boolean; onToggle: () => void; onNavigate?: () => void }) {
  const me = useMe();
  const location = useLocation();
  return (
    <aside className={cx("flex flex-col h-full bg-surface border-r border-rule", collapsed ? "w-14" : "w-[220px]")} aria-label="Ana menü">
      <Link to="/" className="block px-4 pt-3.5 pb-2.5" onClick={onNavigate} aria-label="Teknolife tezgâh — Pano">
        {collapsed ? (
          <span className="font-cond font-semibold text-16 tracking-wide">TL</span>
        ) : (
          <>
            <span className="block font-cond font-semibold text-16 tracking-[.12em] leading-none">TEKNOLIFE</span>
            <span className="block font-mono text-11 text-ink-3 mt-1">tezgâh</span>
          </>
        )}
      </Link>
      <EarthStrip />
      <nav className="flex-1 overflow-y-auto scroll-thin py-2">
        {NAV.map((g, gi) => (
          <div key={gi} className="mb-1">
            {g.label && !collapsed && (
              <div className="label-caps px-4 pt-3 pb-1" lang="tr">
                {g.label.toLocaleUpperCase("tr-TR")}
              </div>
            )}
            {g.label && collapsed && <div className="h-px bg-rule mx-3 my-2" />}
            {g.items
              .filter((i) => !i.permission || me.permissions.includes(i.permission))
              .map((item) => {
                const isActive = isNavActive(item.to, location.pathname);
                return (
                  <Link
                    key={item.to}
                    to={item.to}
                    onClick={onNavigate}
                    title={collapsed ? item.label : undefined}
                    aria-current={isActive ? "page" : undefined}
                    className={cx(
                      "flex items-center gap-2.5 h-8 text-13 border-l-2",
                      collapsed ? "justify-center px-0" : "px-4",
                      isActive ? "border-ink bg-surface-2 text-ink font-medium" : "border-transparent text-ink-2 hover:text-ink hover:bg-surface-2",
                    )}
                  >
                    <item.icon size={16} strokeWidth={1.5} aria-hidden />
                    {!collapsed && <span className="flex-1 truncate">{item.label}</span>}
                    {!collapsed && item.kbd && <Kbd>{item.kbd}</Kbd>}
                  </Link>
                );
              })}
          </div>
        ))}
      </nav>
      <button
        type="button"
        onClick={onToggle}
        className="hidden md:flex items-center gap-2 h-9 px-4 border-t border-rule text-12 text-ink-3 hover:text-ink cursor-pointer"
        aria-label={collapsed ? "Menüyü genişlet" : "Menüyü daralt"}
      >
        {collapsed ? <ChevronsRight size={16} strokeWidth={1.5} /> : <ChevronsLeft size={16} strokeWidth={1.5} />}
        {!collapsed && "Daralt"}
      </button>
    </aside>
  );
}

function FxStrip({ status }: { status?: StatusInfo }) {
  const fx = status?.fx;
  if (!fx) return null;
  const usd = fx.rates.USD?.rate;
  const eur = fx.rates.EUR?.rate;
  return (
    <Link
      to="/ayarlar/kur"
      className={cx("hidden lg:inline-flex items-center gap-2 num text-12 px-2 h-7 rounded-ctl hover:bg-surface-2", fx.stale ? "text-warn" : "text-ink-2")}
      title={fx.stale ? `Kur ${fx.stale_days} günden eski — güncelleyin` : "Döviz kurları (Ayarlar › Fiyat & Kur)"}
    >
      <span>USD {rate(usd)}</span>
      <span className="text-ink-3">·</span>
      <span>EUR {rate(eur)}</span>
      <span className="text-ink-3">·</span>
      <span>{fx.fetched_at ? timeOnly(fx.fetched_at) : "—"}</span>
      {fx.stale && <span className="font-sans text-11 border border-warn px-1 rounded-ctl">ESKİ</span>}
    </Link>
  );
}

function Breadcrumb() {
  const location = useLocation();
  const crumb = useCrumbValue();
  const parts = location.pathname.split("/").filter(Boolean);
  const root = CRUMB_ROOT[parts[0] ?? ""] ?? "";
  const items: { label: string; to?: string }[] = [{ label: root, to: `/${parts[0] ?? ""}` }];
  if (parts[0] === "stok" && parts[1] === "giris") items[0] = { label: "Stok Girişi" };
  else if (parts.length > 1) {
    const sub = CRUMB_SUB[parts[1]];
    items.push({ label: crumb ?? sub ?? parts[1] });
  }
  return (
    <nav aria-label="Konum" className="flex items-center gap-1.5 min-w-0 text-13">
      {items.map((it, i) => (
        <span key={i} className="flex items-center gap-1.5 min-w-0">
          {i > 0 && <span className="text-ink-3">/</span>}
          {it.to && i < items.length - 1 ? (
            <Link to={it.to} className="text-ink-2 hover:text-ink truncate">
              {it.label}
            </Link>
          ) : (
            <span className="text-ink truncate font-medium">{it.label}</span>
          )}
        </span>
      ))}
    </nav>
  );
}

function TopBar({ onPalette, onHelp, onMenu, onPassword, status }: { onPalette: () => void; onHelp: () => void; onMenu: () => void; onPassword: () => void; status?: StatusInfo }) {
  const me = useMe();
  const { logout } = useAuth();
  const [theme, setTheme] = useTheme();
  const next = theme === "system" ? "light" : theme === "light" ? "dark" : "system";
  const ThemeIcon = theme === "dark" ? Moon : theme === "light" ? Sun : Monitor;
  return (
    <header className="h-11 shrink-0 flex items-center gap-3 px-3 md:px-4 bg-surface border-b border-rule print:hidden">
      <IconButton icon={MenuIcon} label="Menü" className="md:hidden" onClick={onMenu} />
      <div className="flex-1 min-w-0 md:flex-none md:w-[28%]">
        <Breadcrumb />
      </div>
      <button
        type="button"
        onClick={onPalette}
        className="hidden sm:flex flex-1 max-w-[440px] mx-auto items-center gap-2 h-7 px-2.5 rounded-ctl border border-rule-strong bg-paper text-13 text-ink-3 hover:border-ink-3 cursor-pointer"
      >
        <Search size={14} strokeWidth={1.5} aria-hidden />
        <span className="flex-1 text-left truncate">Ürün, müşteri, servis kodu, seri no, fiş no ara…</span>
        <Kbd>Ctrl K</Kbd>
      </button>
      <IconButton icon={Search} label="Ara" className="sm:hidden" onClick={onPalette} />
      <div className="flex items-center gap-1 ml-auto">
        <FxStrip status={status} />
        <IconButton icon={ThemeIcon} label={`Tema: ${THEME_LABEL[theme]} (değiştir: ${THEME_LABEL[next]})`} onClick={() => setTheme(next)} />
        <Menu>
          <MenuTrigger asChild>
            <button type="button" className="flex items-center gap-2 h-8 px-2 rounded-ctl hover:bg-surface-2 cursor-pointer text-13" aria-label="Kullanıcı menüsü">
              <UserRound size={16} strokeWidth={1.5} aria-hidden />
              <span className="hidden md:inline max-w-[140px] truncate">{me.full_name}</span>
            </button>
          </MenuTrigger>
          <MenuContent>
            <MenuLabel>{me.role === "ADMIN" ? "Yönetici" : "Personel"}</MenuLabel>
            <div className="px-3 pb-2 text-13">
              {me.full_name}
              <div className="num text-11 text-ink-3">{me.username}</div>
            </div>
            <MenuSeparator />
            <MenuItem onSelect={onPassword}>Şifremi değiştir</MenuItem>
            <MenuItem onSelect={onHelp}>
              <Keyboard size={14} strokeWidth={1.5} /> Klavye kısayolları <Kbd className="ml-auto">?</Kbd>
            </MenuItem>
            <MenuSeparator />
            <MenuItem onSelect={() => void logout()}>
              <LogOut size={14} strokeWidth={1.5} /> Çıkış
            </MenuItem>
          </MenuContent>
        </Menu>
      </div>
    </header>
  );
}

function StatusBar({ status, error }: { status?: StatusInfo; error: boolean }) {
  const me = useMe();
  return (
    <footer className="h-6 shrink-0 flex items-center gap-2 px-3 md:px-4 bg-surface border-t border-rule font-mono text-11 text-ink-2 overflow-hidden whitespace-nowrap print:hidden">
      <span className={cx("inline-flex items-center gap-1", error ? "text-crit" : "text-ok")}>
        <span aria-hidden>●</span>
        {error ? "Bağlantı yok" : "Bağlı"}
      </span>
      <span className="text-ink-3">·</span>
      <span>Son yedek {status?.last_backup_at ? timeOnly(status.last_backup_at) : "—"}</span>
      <span className="text-ink-3">·</span>
      <span>Kasa: {status?.today_sales ?? "—"} satış</span>
      <span className="text-ink-3 hidden sm:inline">·</span>
      <span className="hidden sm:inline">
        {me.role === "ADMIN" ? "Yönetici" : "Personel"}: {me.full_name}
      </span>
      <span className="ml-auto text-ink-3">v{APP_VERSION}</span>
    </footer>
  );
}

function ShortcutHelp({ open, onOpenChange }: { open: boolean; onOpenChange: (v: boolean) => void }) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange} title="Klavye kısayolları" width={520}>
      <div className="grid md:grid-cols-2 gap-6">
        {[
          ["Genel", GLOBAL_SHORTCUTS],
          ["Hızlı satış", POS_SHORTCUTS],
        ].map(([title, list]) => (
          <div key={title as string}>
            <div className="label-caps mb-2">{title as string}</div>
            <ul className="flex flex-col gap-1.5">
              {(list as typeof GLOBAL_SHORTCUTS).map((s) => (
                <li key={s.keys} className="flex items-center justify-between gap-3 text-13">
                  <span className="text-ink-2">{s.label}</span>
                  <Kbd>{s.keys}</Kbd>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>
    </Dialog>
  );
}

export function Layout() {
  const navigate = useNavigate();
  const location = useLocation();
  const [collapsed, setCollapsed] = useState(() => readStore("tezgah.rail", false));
  const [mobileOpen, setMobileOpen] = useState(false);
  const [paletteOpen, setPaletteOpen] = useState(false);
  const [helpOpen, setHelpOpen] = useState(false);
  const [pwOpen, setPwOpen] = useState(false);
  const status = useQuery({ queryKey: ["status"], queryFn: () => api.get<StatusInfo>("/status"), refetchInterval: 60_000 });

  useEffect(() => setMobileOpen(false), [location.pathname]);
  useEffect(() => {
    if (!location.pathname.match(/\/\d+/)) document.title = "Tezgâh · Teknolife";
  }, [location.pathname]);

  const focusSearch = () => window.setTimeout(() => (document.querySelector<HTMLInputElement>("[data-page-search]") ?? null)?.focus(), 60);
  useHotkeys({
    "Ctrl+K": () => setPaletteOpen(true),
    F2: () => navigate("/satis"),
    F3: () => {
      navigate("/urunler");
      focusSearch();
    },
    F4: () => navigate("/servis/yeni"),
    F6: () => navigate("/stok/giris"),
    "/": () => document.querySelector<HTMLInputElement>("[data-page-search]")?.focus(),
    "?": () => setHelpOpen(true),
  });

  const toggleRail = () => {
    setCollapsed((c) => {
      writeStore("tezgah.rail", !c);
      return !c;
    });
  };

  return (
    <div className="h-full flex">
      <a href="#main" className="sr-only focus:not-sr-only focus:fixed focus:z-50 focus:top-2 focus:left-2 focus:bg-surface focus:px-3 focus:py-2">
        İçeriğe geç
      </a>
      <div className="hidden md:block h-full print:hidden">
        <Rail collapsed={collapsed} onToggle={toggleRail} />
      </div>
      {mobileOpen && (
        <div className="md:hidden fixed inset-0 z-40 flex print:hidden">
          <div className="h-full anim-in">
            <Rail collapsed={false} onToggle={() => setMobileOpen(false)} onNavigate={() => setMobileOpen(false)} />
          </div>
          <button type="button" className="flex-1 bg-scrim" aria-label="Menüyü kapat" onClick={() => setMobileOpen(false)}>
            <X className="sr-only" />
          </button>
        </div>
      )}
      <div className="flex-1 min-w-0 flex flex-col h-full">
        <TopBar
          onPalette={() => setPaletteOpen(true)}
          onHelp={() => setHelpOpen(true)}
          onMenu={() => setMobileOpen(true)}
          onPassword={() => setPwOpen(true)}
          status={status.data}
        />
        <main id="main" className="flex-1 min-h-0 overflow-y-auto scroll-thin">
          <Suspense fallback={<Loading />}>
            <Outlet />
          </Suspense>
        </main>
        <StatusBar status={status.data} error={status.isError} />
      </div>
      <CommandPalette open={paletteOpen} onOpenChange={setPaletteOpen} onHelp={() => setHelpOpen(true)} />
      <ShortcutHelp open={helpOpen} onOpenChange={setHelpOpen} />
      <PasswordDialog open={pwOpen} onOpenChange={setPwOpen} />
    </div>
  );
}
