import { useCallback, useState } from "react";
import { readRaw, writeRaw } from "@/lib/storage";

export type ThemeMode = "system" | "light" | "dark";

function apply(mode: ThemeMode) {
  const root = document.documentElement;
  if (mode === "system") root.removeAttribute("data-theme");
  else root.setAttribute("data-theme", mode);
}

export function useTheme(): [ThemeMode, (m: ThemeMode) => void] {
  const [mode, setMode] = useState<ThemeMode>(() => {
    const v = readRaw("tezgah.theme");
    return v === "light" || v === "dark" ? v : "system";
  });
  const set = useCallback((m: ThemeMode) => {
    setMode(m);
    apply(m);
    writeRaw("tezgah.theme", m === "system" ? null : m);
  }, []);
  return [mode, set];
}

export const THEME_LABEL: Record<ThemeMode, string> = { system: "Sistem", light: "Gündüz", dark: "Gece" };
