import * as RD from "@radix-ui/react-dialog";
import { useQuery } from "@tanstack/react-query";
import { Command } from "cmdk";
import { CornerDownLeft, Search } from "lucide-react";
import { type ReactNode, useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Led } from "@/design/Indicators";
import { Kbd } from "@/design/Kbd";
import { api } from "@/lib/api";
import { dateOnly, money, qty } from "@/lib/format";
import { SERVICE_STATUS_TONE } from "@/lib/labels";
import type { SearchResult } from "@/lib/types";
import { useAuth } from "./auth";

interface Cmd {
  label: string;
  to?: string;
  kbd?: string;
  perm?: string;
  action?: "help";
  keywords?: string;
}

const COMMANDS: Cmd[] = [
  { label: "Hızlı satış", to: "/satis", kbd: "F2", keywords: "pos kasa satış" },
  { label: "Yeni ürün", to: "/urunler/yeni", perm: "product.write", keywords: "ürün ekle" },
  { label: "Yeni servis kaydı", to: "/servis/yeni", kbd: "F4", keywords: "cihaz kabul arıza" },
  { label: "Stok girişi", to: "/stok/giris", kbd: "F6", keywords: "mal kabul fire" },
  { label: "Kur güncelle", to: "/ayarlar/kur", perm: "fx.write", keywords: "dolar euro tcmb döviz" },
  { label: "Toplu fiyat güncelle", to: "/urunler/toplu-fiyat", perm: "product.bulk_price", keywords: "zam indirim" },
  { label: "Excel'den ürün içe aktar", to: "/urunler/ice-aktar", perm: "product.import", keywords: "xlsx" },
  { label: "Yeni sayım", to: "/sayim?yeni=1", perm: "count.write", keywords: "envanter" },
  { label: "Satın alma siparişi oluştur", to: "/siparisler/yeni", perm: "purchase.write", keywords: "tedarikçi" },
  { label: "Gün sonu kasa raporu", to: "/raporlar/kasa", keywords: "z rapor kasa" },
  { label: "Etiket bas", to: "/etiket", keywords: "barkod raf" },
  { label: "Müşteriler", to: "/cari", keywords: "cari veresiye" },
  { label: "Yedek al / geri yükle", to: "/ayarlar/yedek", perm: "backup.manage", keywords: "backup" },
  { label: "Klavye kısayolları", action: "help", kbd: "?", keywords: "kısayol" },
];

const norm = (s: string) => s.toLocaleLowerCase("tr-TR");

function Group({ heading, children }: { heading: string; children: ReactNode }) {
  return (
    <Command.Group
      heading={heading}
      className="[&_[cmdk-group-heading]]:label-caps [&_[cmdk-group-heading]]:px-3 [&_[cmdk-group-heading]]:pt-2.5 [&_[cmdk-group-heading]]:pb-1"
    >
      {children}
    </Command.Group>
  );
}

function Item({ onSelect, children, value }: { onSelect: () => void; children: ReactNode; value: string }) {
  return (
    <Command.Item
      value={value}
      onSelect={onSelect}
      className="flex items-center gap-3 h-9 px-3 text-13 cursor-pointer data-[selected=true]:bg-surface-2 data-[selected=true]:shadow-[inset_2px_0_0_var(--signal)]"
    >
      {children}
    </Command.Item>
  );
}

export function CommandPalette({ open, onOpenChange, onHelp }: { open: boolean; onOpenChange: (v: boolean) => void; onHelp: () => void }) {
  const navigate = useNavigate();
  const { me } = useAuth();
  const [q, setQ] = useState("");
  const [debounced, setDebounced] = useState("");
  useEffect(() => {
    const t = window.setTimeout(() => setDebounced(q.trim()), 150);
    return () => window.clearTimeout(t);
  }, [q]);
  useEffect(() => {
    if (!open) setQ("");
  }, [open]);
  const search = useQuery({
    queryKey: ["search", debounced],
    queryFn: () => api.get<SearchResult>("/search", { q: debounced }),
    enabled: open && debounced.length >= 2,
    staleTime: 10_000,
  });

  const go = (to: string) => {
    onOpenChange(false);
    navigate(to);
  };
  const cmds = COMMANDS.filter((c) => !c.perm || me?.permissions.includes(c.perm)).filter(
    (c) => !q || norm(`${c.label} ${c.keywords ?? ""}`).includes(norm(q.trim())),
  );
  const r = search.data;
  const hasResults = !!r && (r.products.length || r.customers.length || r.tickets.length || r.serials.length || r.sales.length);

  return (
    <RD.Root open={open} onOpenChange={onOpenChange}>
      <RD.Portal>
        <RD.Overlay className="fixed inset-0 z-40 bg-scrim anim-fade" />
        <RD.Content className="fixed z-50 left-1/2 top-[12vh] -translate-x-1/2 w-[calc(100vw-32px)] max-w-[640px] bg-surface border border-rule rounded-dlg shadow-pop anim-in focus:outline-none">
          <RD.Title className="sr-only">Komut paleti</RD.Title>
          <RD.Description className="sr-only">Ürün, müşteri, servis kaydı, seri numarası veya fiş numarası arayın ya da bir komut seçin.</RD.Description>
          <Command shouldFilter={false} loop label="Komut paleti">
            <div className="flex items-center gap-2 px-3 h-11 border-b border-rule">
              <Search size={16} strokeWidth={1.5} className="text-ink-3" aria-hidden />
              <Command.Input
                value={q}
                onValueChange={setQ}
                placeholder="Ürün, müşteri, SRV kodu, seri no, fiş no veya komut…"
                className="flex-1 h-full bg-transparent text-14 outline-none placeholder:text-ink-3 focus-visible:outline-none"
              />
              <Kbd>Esc</Kbd>
            </div>
            <Command.List className="max-h-[60vh] overflow-y-auto scroll-thin py-1">
              {debounced.length >= 2 && search.isFetching && !r && <div className="px-3 py-3 num text-12 text-ink-3">Aranıyor…</div>}
              {debounced.length >= 2 && r && !hasResults && cmds.length === 0 && (
                <Command.Empty className="px-3 py-3 text-13 text-ink-2">"{debounced}" için sonuç yok.</Command.Empty>
              )}
              {r?.serials.length ? (
                <Group heading="Seri numaraları">
                  {r.serials.map((s) => (
                    <Item key={`s${s.id}`} value={`serial-${s.id}`} onSelect={() => go(s.sale_id ? `/satislar/${s.sale_id}` : `/urunler/${s.product_id}`)}>
                      <span className="num">{s.serial_no}</span>
                      <span className="truncate text-ink-2">{s.product_name}</span>
                      <span className="ml-auto">
                        {s.receipt_no ? (
                          <Led tone={s.under_warranty ? "ok" : "neutral"}>
                            {s.under_warranty ? `Garantili · ${dateOnly(s.warranty_until)}` : "Garanti bitti"} · {s.receipt_no}
                          </Led>
                        ) : (
                          <Led tone="info">Stokta, satılmadı</Led>
                        )}
                      </span>
                    </Item>
                  ))}
                </Group>
              ) : null}
              {r?.products.length ? (
                <Group heading="Ürünler">
                  {r.products.map((p) => (
                    <Item key={`p${p.id}`} value={`product-${p.id}`} onSelect={() => go(`/urunler/${p.id}`)}>
                      <span className="num text-12 text-ink-3 w-24 shrink-0">{p.sku}</span>
                      <span className="truncate">{p.name}</span>
                      <span className="ml-auto num text-12 text-ink-2">{qty(p.stock_qty, p.unit_type)}</span>
                      <span className="num text-12 w-24 text-right">{money(p.sale_price_kurus)}</span>
                    </Item>
                  ))}
                </Group>
              ) : null}
              {r?.tickets.length ? (
                <Group heading="Servis kayıtları">
                  {r.tickets.map((t) => (
                    <Item key={`t${t.id}`} value={`ticket-${t.id}`} onSelect={() => go(`/servis/${t.id}`)}>
                      <span className="num">{t.code}</span>
                      <span className="truncate text-ink-2">
                        {t.model} · {t.customer_name}
                      </span>
                      <span className="ml-auto">
                        <Led tone={SERVICE_STATUS_TONE[t.status]}>{t.status_label}</Led>
                      </span>
                    </Item>
                  ))}
                </Group>
              ) : null}
              {r?.customers.length ? (
                <Group heading="Müşteriler">
                  {r.customers.map((c) => (
                    <Item key={`c${c.id}`} value={`customer-${c.id}`} onSelect={() => go(`/cari/${c.id}`)}>
                      <span>{c.full_name}</span>
                      <span className="ml-auto num text-12 text-ink-3">{c.phone}</span>
                    </Item>
                  ))}
                </Group>
              ) : null}
              {r?.sales.length ? (
                <Group heading="Fişler">
                  {r.sales.map((s) => (
                    <Item key={`r${s.id}`} value={`sale-${s.id}`} onSelect={() => go(`/satislar/${s.id}`)}>
                      <span className="num">{s.receipt_no}</span>
                      <span className="text-ink-2 num text-12">{dateOnly(s.created_at)}</span>
                      <span className="ml-auto num">{money(s.total)}</span>
                    </Item>
                  ))}
                </Group>
              ) : null}
              {cmds.length > 0 && (
                <Group heading="Komutlar">
                  {cmds.map((c) => (
                    <Item
                      key={c.label}
                      value={`cmd-${c.label}`}
                      onSelect={() => {
                        if (c.action === "help") {
                          onOpenChange(false);
                          onHelp();
                        } else if (c.to) go(c.to);
                      }}
                    >
                      <CornerDownLeft size={14} strokeWidth={1.5} className="text-ink-3" aria-hidden />
                      <span>{c.label}</span>
                      {c.kbd && <Kbd className="ml-auto">{c.kbd}</Kbd>}
                    </Item>
                  ))}
                </Group>
              )}
            </Command.List>
          </Command>
        </RD.Content>
      </RD.Portal>
    </RD.Root>
  );
}
