import { useQuery, useQueryClient } from "@tanstack/react-query";
import { createContext, type ReactNode, useContext, useEffect } from "react";
import { Navigate, useLocation, useNavigate } from "react-router-dom";
import { Loading } from "@/design/Feedback";
import { api, UNAUTHORIZED_EVENT } from "@/lib/api";
import type { Me } from "@/lib/types";

interface AuthValue {
  me: Me | null;
  loading: boolean;
  logout: () => Promise<void>;
  refresh: () => Promise<unknown>;
}

const AuthCtx = createContext<AuthValue>({ me: null, loading: true, logout: async () => undefined, refresh: async () => undefined });

export function AuthProvider({ children }: { children: ReactNode }) {
  const qc = useQueryClient();
  const navigate = useNavigate();
  const q = useQuery({
    queryKey: ["me"],
    queryFn: async () => (await api.get<{ user: Me | null }>("/auth/session")).user,
    staleTime: 5 * 60_000,
    retry: false,
  });
  useEffect(() => {
    const onUnauthorized = () => {
      qc.setQueryData(["me"], null);
      navigate("/giris", { replace: true });
    };
    window.addEventListener(UNAUTHORIZED_EVENT, onUnauthorized);
    return () => window.removeEventListener(UNAUTHORIZED_EVENT, onUnauthorized);
  }, [qc, navigate]);
  const logout = async () => {
    await api.post("/auth/logout").catch(() => undefined);
    qc.clear();
    qc.setQueryData(["me"], null);
    navigate("/giris", { replace: true });
  };
  return (
    <AuthCtx.Provider value={{ me: q.data ?? null, loading: q.isLoading, logout, refresh: q.refetch }}>{children}</AuthCtx.Provider>
  );
}

export function useAuth(): AuthValue {
  return useContext(AuthCtx);
}

/** Korunan sayfalarda oturum açmış kullanıcı. */
export function useMe(): Me {
  const { me } = useAuth();
  if (!me) throw new Error("Oturum yok");
  return me;
}

export function useCan(permission: string): boolean {
  const { me } = useAuth();
  return !!me?.permissions.includes(permission);
}

export function RequireAuth({ children }: { children: ReactNode }) {
  const { me, loading } = useAuth();
  const location = useLocation();
  if (loading) return <Loading label="Oturum kontrol ediliyor" />;
  if (!me) return <Navigate to={`/giris?next=${encodeURIComponent(location.pathname + location.search)}`} replace />;
  return <>{children}</>;
}

export function RequirePermission({ permission, children }: { permission: string; children: ReactNode }) {
  const can = useCan(permission);
  if (!can)
    return (
      <div className="px-6 py-10">
        <h1 className="font-cond text-20 font-semibold">Yetkiniz yok</h1>
        <p className="text-14 text-ink-2 mt-1">Bu ekran yalnızca yönetici hesabıyla görüntülenebilir.</p>
      </div>
    );
  return <>{children}</>;
}
