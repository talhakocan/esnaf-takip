import { createContext, type ReactNode, useContext, useEffect, useState } from "react";

/** Detay sayfaları kendi başlığını breadcrumb'a yazar (ör. ürün adı). */
const Ctx = createContext<{ crumb: string | null; setCrumb: (s: string | null) => void }>({ crumb: null, setCrumb: () => undefined });

export function CrumbProvider({ children }: { children: ReactNode }) {
  const [crumb, setCrumb] = useState<string | null>(null);
  return <Ctx.Provider value={{ crumb, setCrumb }}>{children}</Ctx.Provider>;
}

export function useCrumbValue(): string | null {
  return useContext(Ctx).crumb;
}

export function useCrumb(label: string | null | undefined): void {
  const { setCrumb } = useContext(Ctx);
  useEffect(() => {
    setCrumb(label ?? null);
    if (label) document.title = `${label} · Tezgâh`;
    return () => setCrumb(null);
  }, [label, setCrumb]);
}
