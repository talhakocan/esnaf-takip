import { useState } from "react";
import { Button } from "@/design/Button";
import { Dialog } from "@/design/Dialog";
import { Field, Input } from "@/design/Input";
import { useToast } from "@/design/Toast";
import { ApiError, api } from "@/lib/api";

export function PasswordDialog({ open, onOpenChange }: { open: boolean; onOpenChange: (v: boolean) => void }) {
  const toast = useToast();
  const [current, setCurrent] = useState("");
  const [next, setNext] = useState("");
  const [again, setAgain] = useState("");
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [busy, setBusy] = useState(false);

  const submit = async () => {
    if (next !== again) {
      setErrors({ again: "Yeni şifreler eşleşmiyor." });
      return;
    }
    setBusy(true);
    try {
      await api.post("/auth/change-password", { current_password: current, new_password: next });
      toast({ title: "Şifreniz değiştirildi" });
      setCurrent("");
      setNext("");
      setAgain("");
      setErrors({});
      onOpenChange(false);
    } catch (e) {
      if (e instanceof ApiError) setErrors({ ...e.fields, _: e.message });
    } finally {
      setBusy(false);
    }
  };

  return (
    <Dialog
      open={open}
      onOpenChange={onOpenChange}
      title="Şifre değiştir"
      width={400}
      footer={
        <>
          <Button variant="ghost" onClick={() => onOpenChange(false)}>
            Vazgeç
          </Button>
          <Button variant="primary" onClick={submit} loading={busy} disabled={!current || next.length < 8}>
            Kaydet
          </Button>
        </>
      }
    >
      <form
        className="flex flex-col gap-3"
        onSubmit={(e) => {
          e.preventDefault();
          void submit();
        }}
      >
        <Field label="Mevcut şifre" error={errors.current_password}>
          {(id) => <Input id={id} type="password" autoComplete="current-password" value={current} onChange={(e) => setCurrent(e.target.value)} />}
        </Field>
        <Field label="Yeni şifre" hint="En az 8 karakter, harf ve rakam." error={errors.new_password}>
          {(id) => <Input id={id} type="password" autoComplete="new-password" value={next} onChange={(e) => setNext(e.target.value)} />}
        </Field>
        <Field label="Yeni şifre (tekrar)" error={errors.again}>
          {(id) => <Input id={id} type="password" autoComplete="new-password" value={again} onChange={(e) => setAgain(e.target.value)} />}
        </Field>
        {errors._ && !errors.current_password && !errors.new_password && <p className="text-12 text-crit">{errors._}</p>}
        <button type="submit" className="hidden" />
      </form>
    </Dialog>
  );
}
