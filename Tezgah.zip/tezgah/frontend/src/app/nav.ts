import {
  ArrowDownToLine,
  BarChart3,
  Boxes,
  ClipboardCheck,
  ClipboardList,
  Gauge,
  NotebookTabs,
  PlusSquare,
  ReceiptText,
  ScanBarcode,
  Settings,
  Tag,
  Truck,
  Users,
  Wrench,
  type LucideIcon,
} from "lucide-react";

export interface NavItem {
  to: string;
  label: string;
  icon: LucideIcon;
  kbd?: string;
  permission?: string;
}

export interface NavGroup {
  label: string | null;
  items: NavItem[];
}

export const NAV: NavGroup[] = [
  { label: null, items: [{ to: "/", label: "Pano", icon: Gauge }] },
  {
    label: "Satış",
    items: [
      { to: "/satis", label: "Hızlı Satış", icon: ScanBarcode, kbd: "F2" },
      { to: "/satislar", label: "Satışlar", icon: ReceiptText },
    ],
  },
  {
    label: "Stok",
    items: [
      { to: "/urunler", label: "Ürünler", icon: Boxes, kbd: "F3" },
      { to: "/stok", label: "Stok Defteri", icon: NotebookTabs },
      { to: "/stok/giris", label: "Stok Girişi", icon: ArrowDownToLine, kbd: "F6" },
      { to: "/sayim", label: "Sayım", icon: ClipboardCheck },
      { to: "/etiket", label: "Etiket Basımı", icon: Tag },
    ],
  },
  {
    label: "Servis",
    items: [
      { to: "/servis", label: "Teknik Servis", icon: Wrench },
      { to: "/servis/yeni", label: "Yeni Kayıt", icon: PlusSquare, kbd: "F4" },
    ],
  },
  {
    label: "Cari",
    items: [
      { to: "/cari", label: "Müşteriler", icon: Users },
      { to: "/tedarikciler", label: "Tedarikçiler", icon: Truck },
      { to: "/siparisler", label: "Satın Alma", icon: ClipboardList },
    ],
  },
  { label: "Rapor", items: [{ to: "/raporlar", label: "Raporlar", icon: BarChart3 }] },
  { label: "Sistem", items: [{ to: "/ayarlar", label: "Ayarlar", icon: Settings }] },
];

export const CRUMB_ROOT: Record<string, string> = {
  "": "Pano",
  satis: "Hızlı Satış",
  satislar: "Satışlar",
  urunler: "Ürünler",
  stok: "Stok Defteri",
  sayim: "Sayım",
  etiket: "Etiket Basımı",
  servis: "Teknik Servis",
  cari: "Müşteriler",
  tedarikciler: "Tedarikçiler",
  siparisler: "Satın Alma",
  raporlar: "Raporlar",
  ayarlar: "Ayarlar",
};

export const CRUMB_SUB: Record<string, string> = {
  yeni: "Yeni",
  giris: "Stok Girişi",
  duzenle: "Düzenle",
  "toplu-fiyat": "Toplu fiyat",
  "ice-aktar": "Excel'den içe aktar",
};
