import { useQuery } from "@tanstack/react-query";
import { Phone } from "lucide-react";
import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { Button } from "@/design/Button";
import { cx } from "@/design/cx";
import { EarthStrip } from "@/design/EarthStrip";
import { SchematicIcon } from "@/design/Feedback";
import { Input } from "@/design/Input";
import { ApiError, api } from "@/lib/api";
import { dateOnly, dateTime, money } from "@/lib/format";
import { DEVICE_TR } from "@/lib/labels";
import type { PublicTrack } from "@/lib/types";

function Shell({ children, shop }: { children: React.ReactNode; shop?: PublicTrack["shop"] | { name: string; phone: string; address: string } }) {
  return (
    <div className="min-h-full bg-paper flex flex-col">
      <header className="bg-surface border-b border-rule">
        <div className="max-w-[560px] mx-auto px-4 pt-4 pb-3">
          <div className="font-cond font-semibold text-16 tracking-[.14em] leading-none">{(shop?.name ?? "Teknolife").toLocaleUpperCase("tr-TR")}</div>
          <div className="font-mono text-11 text-ink-3 mt-1">teknik servis · cihaz takibi</div>
        </div>
        <EarthStrip />
      </header>
      <main className="flex-1 w-full max-w-[560px] mx-auto px-4 py-6">{children}</main>
      {shop && (shop.phone || shop.address) && (
        <footer className="max-w-[560px] mx-auto w-full px-4 pb-8 text-13 text-ink-2">
          <div className="border-t border-rule pt-3">
            {shop.phone && (
              <a href={`tel:${shop.phone.replace(/[^\d+]/g, "")}`} className="inline-flex items-center gap-1.5 num text-ink">
                <Phone size={14} strokeWidth={1.5} aria-hidden /> {shop.phone}
              </a>
            )}
            {shop.address && <div className="mt-1">{shop.address}</div>}
          </div>
        </footer>
      )}
    </div>
  );
}

function CodeForm({ initial = "" }: { initial?: string }) {
  const navigate = useNavigate();
  const [code, setCode] = useState(initial);
  return (
    <form
      className="flex gap-2"
      onSubmit={(e) => {
        e.preventDefault();
        const c = code.trim().toUpperCase();
        if (c) navigate(`/takip/${c.startsWith("SRV-") ? c : `SRV-${c}`}`);
      }}
    >
      <Input mono value={code} onChange={(e) => setCode(e.target.value.toUpperCase())} placeholder="SRV-XXXX" aria-label="Servis kodu" className="h-10 text-16" />
      <Button type="submit" variant="primary" size="lg">
        Sorgula
      </Button>
    </form>
  );
}

export default function TrackPage() {
  const { kod } = useParams();
  const shop = useQuery({ queryKey: ["public-shop"], queryFn: () => api.get<{ shop_name: string; address: string; phone: string }>("/public/shop") });
  const q = useQuery({
    queryKey: ["track", kod],
    queryFn: () => api.get<PublicTrack>(`/public/track/${encodeURIComponent(kod ?? "")}`),
    enabled: !!kod,
    retry: false,
    refetchInterval: 120_000,
  });
  useEffect(() => {
    document.title = kod ? `${kod} · Servis takibi` : "Servis takibi";
  }, [kod]);
  const shopInfo = q.data?.shop ?? (shop.data ? { name: shop.data.shop_name, phone: shop.data.phone, address: shop.data.address } : undefined);

  if (!kod) {
    return (
      <Shell shop={shopInfo}>
        <h1 className="font-cond text-20 font-semibold mb-1">Cihazım ne durumda?</h1>
        <p className="text-14 text-ink-2 mb-4">Kabul fişinizdeki servis kodunu girin.</p>
        <CodeForm />
      </Shell>
    );
  }
  if (q.isLoading) {
    return (
      <Shell shop={shopInfo}>
        <p className="num text-13 text-ink-3">Sorgulanıyor…</p>
      </Shell>
    );
  }
  if (q.isError || !q.data) {
    const notFound = q.error instanceof ApiError && q.error.status === 404;
    return (
      <Shell shop={shopInfo}>
        <SchematicIcon kind="switch" className="text-ink-3 mb-3" />
        <h1 className="font-cond text-20 font-semibold">{notFound ? "Kayıt bulunamadı" : "Şu an sorgulanamıyor"}</h1>
        <p className="text-14 text-ink-2 mt-1 mb-4">
          {notFound ? (
            <>
              <span className="num">{kod}</span> koduyla bir servis kaydı yok. Kodu kabul fişinden kontrol edin.
            </>
          ) : (
            "Lütfen biraz sonra tekrar deneyin."
          )}
        </p>
        <CodeForm initial={kod} />
      </Shell>
    );
  }
  const t = q.data;
  return (
    <Shell shop={shopInfo}>
      <div className="label-caps">Servis kodu</div>
      <h1 className="num text-40 font-semibold leading-none mt-1">{t.code}</h1>
      <div className={cx("mt-3 inline-flex items-center gap-2 px-3 h-9 border text-14 font-medium", t.cancelled ? "border-crit text-crit" : "border-ink")}>
        <span
          className="inline-block size-2.5"
          style={{ background: t.cancelled ? "var(--crit)" : t.status === "READY" || t.status === "DELIVERED" ? "var(--ok)" : "var(--signal)" }}
          aria-hidden
        />
        {t.status_label}
      </div>

      {!t.cancelled && (
        <ol className="mt-6 grid gap-0" style={{ gridTemplateColumns: `repeat(${t.steps.length}, minmax(0, 1fr))` }} aria-label="Durum adımları">
          {t.steps.map((s, i) => (
            <li key={s.status} className="flex flex-col items-center text-center relative">
              {i > 0 && <span className={cx("absolute top-[7px] right-1/2 w-full h-px", s.done || s.current ? "bg-ink" : "bg-rule-strong")} aria-hidden />}
              <span
                className={cx("relative z-10 size-[15px] border", s.current ? "border-signal bg-signal" : s.done ? "border-ink bg-ink" : "border-rule-strong bg-surface")}
                aria-hidden
              />
              <span className={cx("text-11 mt-1.5 leading-tight px-0.5", s.current ? "text-ink font-medium" : s.done ? "text-ink-2" : "text-ink-3")}>{s.label}</span>
              {s.at && <span className="num text-[10px] text-ink-3 mt-0.5 hidden sm:block">{dateOnly(s.at)}</span>}
              <span className="sr-only">{s.current ? "(şu anki durum)" : s.done ? "(tamamlandı)" : "(bekliyor)"}</span>
            </li>
          ))}
        </ol>
      )}

      <dl className="mt-6 bg-surface border border-rule text-14">
        {[
          ["Cihaz", `${DEVICE_TR[t.device_type]} · ${t.brand} ${t.model}`.trim()],
          ["Kabul tarihi", dateTime(t.received_at)],
          ["Son güncelleme", dateTime(t.updated_at)],
          ["Tahmini ücret", t.estimated_cost ? money(t.estimated_cost) : "İnceleme sonrası bildirilecek"],
          ...(t.delivered_at ? [["Teslim tarihi", dateTime(t.delivered_at)]] : []),
        ].map(([k, v]) => (
          <div key={k} className="flex justify-between gap-3 px-4 py-2.5 border-b border-rule last:border-b-0">
            <dt className="text-ink-2">{k}</dt>
            <dd className="text-right num">{v}</dd>
          </div>
        ))}
      </dl>

      {t.notes.length > 0 && (
        <section className="mt-6">
          <h2 className="label-caps mb-2">Servisten notlar</h2>
          <ul className="flex flex-col gap-2">
            {t.notes.map((n, i) => (
              <li key={i} className="bg-surface border border-rule px-4 py-2.5">
                <div className="num text-11 text-ink-3">{dateTime(n.at)}</div>
                <p className="text-14 mt-0.5 whitespace-pre-wrap">{n.body}</p>
              </li>
            ))}
          </ul>
        </section>
      )}
      {t.status === "READY" && <p className="mt-6 text-14 border-l-2 border-ok pl-3">Cihazınız hazır. Kabul fişinizle dükkanımızdan teslim alabilirsiniz.</p>}
    </Shell>
  );
}
