#!/usr/bin/env bash
# Tezgâh — Linux/macOS başlatma betiği
set -euo pipefail
cd "$(dirname "$0")"

echo
echo " TEKNOLIFE  tezgâh  —  dükkan yönetim sistemi"
echo " ------------------------------------------------"

PY=""
for c in python3.12 python3.13 python3.11 python3; do
  if command -v "$c" >/dev/null 2>&1 && "$c" -c 'import sys; sys.exit(0 if sys.version_info >= (3, 11) else 1)'; then
    PY="$c"; break
  fi
done
if [ -z "$PY" ]; then
  echo "[HATA] Python 3.11 veya üzeri bulunamadı. Python 3.12 kurun." >&2
  exit 1
fi

if [ ! -x backend/.venv/bin/python ]; then
  echo "[1/4] Python sanal ortamı oluşturuluyor…"
  "$PY" -m venv backend/.venv
fi
VPY="$(pwd)/backend/.venv/bin/python"

if ! cmp -s backend/requirements.txt backend/.venv/kurulu-gereksinimler.txt; then
  echo "[2/4] Python paketleri yükleniyor…"
  "$VPY" -m pip install --disable-pip-version-check -q --upgrade pip
  "$VPY" -m pip install --disable-pip-version-check -q -r backend/requirements.txt
  cp backend/requirements.txt backend/.venv/kurulu-gereksinimler.txt
else
  echo "[2/4] Python paketleri hazır."
fi

if [ ! -f frontend/dist/index.html ]; then
  if ! command -v npm >/dev/null 2>&1; then
    echo "[HATA] Node.js bulunamadı. Node.js 22 LTS kurun." >&2
    exit 1
  fi
  echo "[3/4] Arayüz derleniyor…"
  (cd frontend && { [ -f package-lock.json ] && npm ci --no-audit --no-fund || npm install --no-audit --no-fund; } && npm run build)
else
  echo "[3/4] Arayüz hazır."
fi

echo "[4/4] Veritabanı güncelleniyor (boşsa demo verisi yüklenir)…"
cd backend
"$VPY" -m app.seed

echo
echo " Uygulama: http://localhost:8000   (Ctrl+C ile kapatın)"
echo
exec "$VPY" -m uvicorn app.main:app --host 0.0.0.0 --port 8000
